public class etox
{
	public static void main(String args[])
	{
		
		double val=1,n=100000000,i,exp=2;
		
		for(i=1;i<=n;i++)
		{
			val*=(1+exp/n);
			
		}
		
		System.out.println("E to x: "+val);	
		
		double sum=1;
		n=100;
		double x=2;
		for(i=n-1; i>0;i--)
		{
			sum=1+x*sum/i;
		}
		
		System.out.println("E to x: "+sum);	
		
		double[] fib = new double[8];
			
		
		int g;
		for(g=0;g<=7;g++)
			fib[g]=0;
		fib[0]=1;
		fib[1]=1;
		sum=2;
		double prod=1;
		for(g=2;g<=7;g++)
		{
			fib[g]=fib[g-1]+fib[g-2];
			sum+=fib[g];
			prod*=fib[g];
		}
		System.out.println("8th fibonacci number: "+fib[7]);
		System.out.println("the fibonacci sum of 8 numbers: "+sum);
		System.out.println("the fibonacci product of 8 numbers: "+prod);

		val=0;
		n=0;
		while(val<4)
		{
			n++;
			if(n%2==0)
			{
				sum=0;
				for(i=1;i<=n/2;i++)
				{
					if(n%i==0)
					{
						sum+=i;
						if(sum==n&&i==n/2)
						{
							val++;
							System.out.println("The perfect number "+val+" is: "+sum);
							break;
						}	
					}	
				}	
			}	
		}		
		
	}
}