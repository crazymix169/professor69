import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class DonutHole extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        // donut by shape subtraction.
        Circle whole = new Circle(20, 20, 20);
        Circle inside = new Circle(20, 20, 10);
        Shape donutShape = Shape.subtract(whole, inside);
        donutShape.setFill(Color.BLUE);

        // donut by arc.
        Arc donutArc = new Arc(60, 20, 10, 10, 0, 360);
        donutArc.setStrokeWidth(10);
        donutArc.setStrokeType(StrokeType.OUTSIDE);
        donutArc.setStroke(Color.RED);
        donutArc.setStrokeLineCap(StrokeLineCap.BUTT);
        donutArc.setFill(null);

        Scene scene = new Scene(new Group(donutShape, donutArc), Color.PALEGREEN);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}