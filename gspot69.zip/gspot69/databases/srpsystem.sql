-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2021 at 09:01 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srpsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activity`
--

CREATE TABLE `tbl_activity` (
  `activityid` int(11) NOT NULL,
  `bookid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activitypersonnel`
--

CREATE TABLE `tbl_activitypersonnel` (
  `activitypersonnelid` int(11) NOT NULL,
  `activityid` int(11) NOT NULL,
  `neighborhoodid` int(11) NOT NULL,
  `individualid` int(11) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_book`
--

CREATE TABLE `tbl_book` (
  `bookid` int(11) NOT NULL,
  `book` text NOT NULL,
  `description` text NOT NULL,
  `unit1` text DEFAULT NULL,
  `unit2` text DEFAULT NULL,
  `unit3` text DEFAULT NULL,
  `type` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bookgraduate`
--

CREATE TABLE `tbl_bookgraduate` (
  `bookgraduateid` int(11) NOT NULL,
  `bookid` int(11) NOT NULL,
  `tutorid` int(11) NOT NULL,
  `individualid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cluster`
--

CREATE TABLE `tbl_cluster` (
  `clusterid` int(11) NOT NULL,
  `regionid` int(11) NOT NULL,
  `cluster` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_continent`
--

CREATE TABLE `tbl_continent` (
  `continentid` int(11) NOT NULL,
  `planetid` int(11) NOT NULL,
  `continent` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_galaxy`
--

CREATE TABLE `tbl_galaxy` (
  `galaxyid` int(11) NOT NULL,
  `galaxyclusterid` int(11) NOT NULL,
  `galaxy` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_galaxycluster`
--

CREATE TABLE `tbl_galaxycluster` (
  `galaxyclusterid` int(11) NOT NULL,
  `galaxysuperclusterid` int(11) NOT NULL,
  `galaxycluster` int(11) NOT NULL,
  `description` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_galaxysupercluster`
--

CREATE TABLE `tbl_galaxysupercluster` (
  `galaxysuperclusterid` int(11) NOT NULL,
  `realmid` int(11) NOT NULL,
  `galaxysupercluster` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_individual`
--

CREATE TABLE `tbl_individual` (
  `individualid` int(11) NOT NULL,
  `neighborhoodid` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `lastname` text NOT NULL,
  `suffix` text NOT NULL,
  `sex` text NOT NULL,
  `birthdate` text NOT NULL,
  `hobby` text NOT NULL,
  `individualtype` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_locality`
--

CREATE TABLE `tbl_locality` (
  `localityid` int(11) NOT NULL,
  `towncityid` int(11) NOT NULL,
  `locality` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nation`
--

CREATE TABLE `tbl_nation` (
  `nationid` int(11) NOT NULL,
  `subcontinentid` int(11) NOT NULL,
  `nation` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_neighborhood`
--

CREATE TABLE `tbl_neighborhood` (
  `neighborhoodid` int(11) NOT NULL,
  `villageid` int(11) NOT NULL,
  `neighborhood` text NOT NULL,
  `description` text NOT NULL,
  `longitude` text DEFAULT NULL,
  `latitude` text DEFAULT NULL,
  `housenumber` text DEFAULT NULL,
  `street` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_planet`
--

CREATE TABLE `tbl_planet` (
  `planetid` int(11) NOT NULL,
  `planetarysystemid` int(11) NOT NULL,
  `planet` int(11) NOT NULL,
  `description` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_planetarysystem`
--

CREATE TABLE `tbl_planetarysystem` (
  `planetarysystemid` int(11) NOT NULL,
  `galaxyid` int(11) NOT NULL,
  `planetarysystem` text NOT NULL,
  `description` text NOT NULL,
  `star` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_realm`
--

CREATE TABLE `tbl_realm` (
  `realmid` int(11) NOT NULL,
  `worldid` int(11) NOT NULL,
  `realm` text NOT NULL,
  `description` text NOT NULL,
  `stagesofcreation` text DEFAULT NULL,
  `colorsymbolism` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_region`
--

CREATE TABLE `tbl_region` (
  `regionid` int(11) NOT NULL,
  `nationid` int(11) NOT NULL,
  `region` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcontinent`
--

CREATE TABLE `tbl_subcontinent` (
  `subcontinentid` int(11) NOT NULL,
  `continentid` int(11) NOT NULL,
  `subcontinent` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_towncity`
--

CREATE TABLE `tbl_towncity` (
  `towncityid` int(11) NOT NULL,
  `clusterid` int(11) NOT NULL,
  `towncity` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` text NOT NULL,
  `userpassword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(1, 'a', 'a'),
(2, 'd', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userslogtrail`
--

CREATE TABLE `tbl_userslogtrail` (
  `userslogtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_village`
--

CREATE TABLE `tbl_village` (
  `villageid` int(11) NOT NULL,
  `localityid` int(11) NOT NULL,
  `village` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_world`
--

CREATE TABLE `tbl_world` (
  `worldid` int(11) NOT NULL,
  `world` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activity`
--
ALTER TABLE `tbl_activity`
  ADD PRIMARY KEY (`activityid`);

--
-- Indexes for table `tbl_activitypersonnel`
--
ALTER TABLE `tbl_activitypersonnel`
  ADD PRIMARY KEY (`activitypersonnelid`);

--
-- Indexes for table `tbl_bookgraduate`
--
ALTER TABLE `tbl_bookgraduate`
  ADD PRIMARY KEY (`bookgraduateid`);

--
-- Indexes for table `tbl_cluster`
--
ALTER TABLE `tbl_cluster`
  ADD PRIMARY KEY (`clusterid`);

--
-- Indexes for table `tbl_continent`
--
ALTER TABLE `tbl_continent`
  ADD PRIMARY KEY (`continentid`);

--
-- Indexes for table `tbl_galaxy`
--
ALTER TABLE `tbl_galaxy`
  ADD PRIMARY KEY (`galaxyid`);

--
-- Indexes for table `tbl_galaxysupercluster`
--
ALTER TABLE `tbl_galaxysupercluster`
  ADD PRIMARY KEY (`galaxysuperclusterid`);

--
-- Indexes for table `tbl_individual`
--
ALTER TABLE `tbl_individual`
  ADD PRIMARY KEY (`individualid`);

--
-- Indexes for table `tbl_locality`
--
ALTER TABLE `tbl_locality`
  ADD PRIMARY KEY (`localityid`);

--
-- Indexes for table `tbl_nation`
--
ALTER TABLE `tbl_nation`
  ADD PRIMARY KEY (`nationid`);

--
-- Indexes for table `tbl_planetarysystem`
--
ALTER TABLE `tbl_planetarysystem`
  ADD PRIMARY KEY (`planetarysystemid`);

--
-- Indexes for table `tbl_realm`
--
ALTER TABLE `tbl_realm`
  ADD PRIMARY KEY (`realmid`);

--
-- Indexes for table `tbl_region`
--
ALTER TABLE `tbl_region`
  ADD PRIMARY KEY (`regionid`);

--
-- Indexes for table `tbl_subcontinent`
--
ALTER TABLE `tbl_subcontinent`
  ADD PRIMARY KEY (`subcontinentid`);

--
-- Indexes for table `tbl_towncity`
--
ALTER TABLE `tbl_towncity`
  ADD PRIMARY KEY (`towncityid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  ADD PRIMARY KEY (`userslogtrailid`);

--
-- Indexes for table `tbl_village`
--
ALTER TABLE `tbl_village`
  ADD PRIMARY KEY (`villageid`);

--
-- Indexes for table `tbl_world`
--
ALTER TABLE `tbl_world`
  ADD PRIMARY KEY (`worldid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activity`
--
ALTER TABLE `tbl_activity`
  MODIFY `activityid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_activitypersonnel`
--
ALTER TABLE `tbl_activitypersonnel`
  MODIFY `activitypersonnelid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bookgraduate`
--
ALTER TABLE `tbl_bookgraduate`
  MODIFY `bookgraduateid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cluster`
--
ALTER TABLE `tbl_cluster`
  MODIFY `clusterid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_continent`
--
ALTER TABLE `tbl_continent`
  MODIFY `continentid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_galaxy`
--
ALTER TABLE `tbl_galaxy`
  MODIFY `galaxyid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_galaxysupercluster`
--
ALTER TABLE `tbl_galaxysupercluster`
  MODIFY `galaxysuperclusterid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_individual`
--
ALTER TABLE `tbl_individual`
  MODIFY `individualid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_locality`
--
ALTER TABLE `tbl_locality`
  MODIFY `localityid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_nation`
--
ALTER TABLE `tbl_nation`
  MODIFY `nationid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_planetarysystem`
--
ALTER TABLE `tbl_planetarysystem`
  MODIFY `planetarysystemid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_realm`
--
ALTER TABLE `tbl_realm`
  MODIFY `realmid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_region`
--
ALTER TABLE `tbl_region`
  MODIFY `regionid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_subcontinent`
--
ALTER TABLE `tbl_subcontinent`
  MODIFY `subcontinentid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_towncity`
--
ALTER TABLE `tbl_towncity`
  MODIFY `towncityid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  MODIFY `userslogtrailid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_village`
--
ALTER TABLE `tbl_village`
  MODIFY `villageid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_world`
--
ALTER TABLE `tbl_world`
  MODIFY `worldid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
