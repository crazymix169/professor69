/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugust;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustStocksMaintenance extends javax.swing.JFrame {
    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String goodsname;
    String goodsid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    
    public SalesAndInventoryAugustStocksMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }
    
    public SalesAndInventoryAugustStocksMaintenance() {
        initComponents();
        
        DoConnect();
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_stocks";
            sql="";
            sql = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 
            
            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));
            
            textDate.setText(date);
            textTime.setText(time);
            
            //stmt.close();
            //con.close();
            /*
            stmt2 = con.createStatement( );
            sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            rowCount=0;

            rs2.next( ); 
            
            int id_col2 = rs2.getInt("goodsid");
            
            String goodsname2 = rs2.getString("goodsname");
            String goodsdescription2 = rs2.getString("goodsdescription");
            

            //textGoodsID.setText(Integer.toString(id_col2));
           
            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);*/
            
            //stmt.close();
            //con.close();
            
            
            
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustStocksTable> getStocksList()
    {
        ArrayList<SalesAndInventoryAugustStocksTable> stocksList= new ArrayList<SalesAndInventoryAugustStocksTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid";
            }
            else 
            {
                goodsid=textGoodsID.getText();
                int goodsid1=Integer.parseInt(goodsid);
                /*
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid and tbl_stocks.goodsid = "+goodsid+" ";*/
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid and tbl_stocks.goodsname like '%"+goodsname+"%' ";
                //query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
                //query = "Select * from tbl_stocks where goodsid = "+goodsid+"";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustStocksTable stocks1;
            
            while(rs.next())
            {
                stocks1 = new  SalesAndInventoryAugustStocksTable(rs.getInt("stocksid"),rs.getInt("goodsid"),
                        rs.getString("goodsname"),rs.getString("goodsdescription"),rs.getInt("quantity"),rs.getDouble("price"),rs.getDate("date")
                        , rs.getTime("time"));
                stocksList.add(stocks1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return stocksList;
     
    }
    
    public void Show_Stocks_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustStocksTable> list = getStocksList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[8];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getStocksID();
            row[1]=list.get(i).getGoodsID();
            row[2]=list.get(i).getGoodsname();
            row[3]=list.get(i).getGoodsDescription();
            row[4]=list.get(i).getQuantity();
            row[5]=list.get(i).getPrice();
            row[6]=list.get(i).getDateofStocks();
            row[7]=list.get(i).getTimeofStocks();
                        
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustGoodsTable> getGoodsList()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> goodsList= new ArrayList<SalesAndInventoryAugustGoodsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query = "Select * from tbl_goods";
            }
            else
            {
                goodsname=textGoodsName.getText();
                query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustGoodsTable goods1;
            
            while(rs2.next())
            {
                goods1 = new  SalesAndInventoryAugustGoodsTable(rs2.getInt("goodsid"), rs2.getString("goodsname"), 
                              rs2.getString("goodsdescription"));
                goodsList.add(goods1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return goodsList;
     
    }
    
    public void Show_Goods_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> list = getGoodsList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getGoodsID();
            row[1]=list.get(i).getGoodsName();
            row[2]=list.get(i).getGoodsDescription();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textGoodsName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByGoodsname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textStocksID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textGoodsDescription = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        textQuantity = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        textPrice = new javax.swing.JTextField();
        textDate = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        textTime = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        textGoodsID = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Stocks ID", "Goods ID", "Goods Name", "Goods Description", "Price", "Quantity", "Date", "Time"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Goods Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        textGoodsName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Goods ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Goods Name");

        btnSearchByGoodsname.setText("Search by Goods Name");
        btnSearchByGoodsname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Stocks ID");

        textGoodsDescription.setBackground(new java.awt.Color(51, 255, 255));
        textGoodsDescription.setColumns(20);
        textGoodsDescription.setRows(5);
        jScrollPane1.setViewportView(textGoodsDescription);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Quantity");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Price");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText(" Date");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Goods ID", "Goods Name", "Goods Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textQuantity, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textPrice))
                                .addGap(467, 467, 467))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByGoodsname)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 10, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(92, 92, 92))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textTime)
                            .addComponent(textDate))
                        .addGap(467, 467, 467))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textGoodsID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                                    .addComponent(textGoodsName, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textStocksID)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnFanAdminWelcome)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textGoodsName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearchByGoodsname)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textGoodsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textDate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll)
                        .addComponent(btnFanAdminWelcome))
                    .addComponent(btnSaveRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int stocksid = rs.getInt("stocksid");
                int goodsid = rs.getInt("goodsid");
                String goodsname=rs.getString("goodsname");
                String goodsdescription=rs.getString("goodsdescription");
                double price=rs.getDouble("price");
                int quantity=rs.getInt("quantity");

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft = 
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 = 
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(rs.getDate("date"));
                String time = ft.format(rs.getTime("time"));

                textStocksID.setText(Integer.toString(stocksid));
                textGoodsID.setText(Integer.toString(goodsid));
                textPrice.setText(Double.toString(price));
                textQuantity.setText(Integer.toString(quantity));

                textDate.setText(date);
                textTime.setText(time);

                stmt2 = con.createStatement( );
                String sql="Select * from tbl_goods where goodsid="+goodsid+"";
                rs2 = stmt2.executeQuery(sql);

                int rowCount=0;
                int goodsid2 = 0;

                String goodsname2 = "";
                String goodsdescription2 = "";

                while(rs2.next( ))
                {
                    if(goodsid==rs2.getInt("goodsid"))
                    {
                        goodsid2 = rs2.getInt("goodsid");

                        goodsname2 = rs2.getString("goodsname");
                        goodsdescription2 = rs2.getString("goodsdescription");


                        textGoodsID.setText(Integer.toString(goodsid2));

                        textGoodsName.setText(goodsname2);
                        textGoodsDescription.setText(goodsdescription2);
                        break;
                    }
                }
                

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));
            
            textDate.setText(date);
            textTime.setText(time);
            
            stmt2 = con.createStatement( );
            String sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            int rowCount=0;
            int goodsid2 = 0;
            
            String goodsname2 = "";
            String goodsdescription2 = "";

            while(rs2.next( ))
            {
                if(goodsid==rs2.getInt("goodsid"))
                {
                    goodsid2 = rs2.getInt("goodsid");
            
                    goodsname2 = rs2.getString("goodsname");
                    goodsdescription2 = rs2.getString("goodsdescription");


                    textGoodsID.setText(Integer.toString(goodsid2));

                    textGoodsName.setText(goodsname2);
                    textGoodsDescription.setText(goodsdescription2);
                    break;
                }
            }

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textStocksID.setText(model.getValueAt(i, 0).toString());
        textGoodsID.setText(model.getValueAt(i, 1).toString());
        textGoodsName.setText(model.getValueAt(i, 2).toString());
        textGoodsDescription.setText(model.getValueAt(i, 3).toString());
        textPrice.setText(model.getValueAt(i, 4).toString());
        textQuantity.setText(model.getValueAt(i, 5).toString());

        textDate.setText(model.getValueAt(i, 6).toString());
        textTime.setText(model.getValueAt(i, 7).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textStocksID.setText(model.getValueAt(i, 0).toString());
            textGoodsID.setText(model.getValueAt(i, 1).toString());
            textGoodsName.setText(model.getValueAt(i, 2).toString());
            textGoodsDescription.setText(model.getValueAt(i, 3).toString());
            textPrice.setText(model.getValueAt(i, 4).toString());
            textQuantity.setText(model.getValueAt(i, 5).toString());
            
            textDate.setText(model.getValueAt(i, 6).toString());
            textTime.setText(model.getValueAt(i, 7).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

        
    
    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);
                
                stmt = con.createStatement( );
                String sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("goodsid");
                    String goodsname2 = rs.getString("goodsname");
                    String goodsdescription2 = rs.getString("goodsdescription");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*
                    sql="Update table_idolinformation"
                    + " SET  fangoodsname='"+goodsname+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                    + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                    + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                    + " where idolinformationid="+goodsid2+"";*/

                    sql="DELETE FROM  tbl_stocks"
                    + " where stocksid="+stocksid2+"";

                    stmt.executeUpdate(sql);
                    
                    /*
                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    
                    sql="DELETE FROM  tbl_stocktrail"
                    + " where stocksid="+stocksid2+"";

                    stmt.executeUpdate(sql);
                    
                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    
                    sql="DELETE FROM  tbl_sales"
                    + " where stocksid="+stocksid2+"";

                    stmt.executeUpdate(sql);*/

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                
                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String goodsid=textGoodsID.getText().trim();
                int goodsid2=Integer.parseInt(goodsid);
                
                String price=textPrice.getText().trim();
                double price2=Double.parseDouble(price);
                
                String quantity=textQuantity.getText().trim();
                int quantity2=Integer.parseInt(quantity);
                
                
                
                /*
                
                Date dNow = new Date( );
                SimpleDateFormat ft = 
                new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

                System.out.println("Current Date: " + ft.format(dNow));
                
                */
                
                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft = 
                new SimpleDateFormat (" yyyy.MM.dd " ) ;
                
                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 = 
                new SimpleDateFormat (" hh:mm:ss ");
                
                
                
                String date=ft.format(dNow);//textDate.getText().trim();
                String time = ft.format(dNow2);//textTime.getText().trim();
                
                
                
                
                /*
                int stocksid = rs.getInt("stocksid");
                int goodsid = rs.getInt("goodsid");
                double price=rs.getDouble("price");
                int quantity=rs.getInt("quantity");
                double totalcost=rs.getInt("totalcost");
                double totalamountpaid=rs.getInt("totalamountpaid");
                double remainingamount=rs.getInt("remainingamount");
                double change1=rs.getInt("change1");
                String salesstatus=rs.getString("salesstatus");
                String date=rs.getString("date");
                String time = rs.getString("time");

                textStocksID.setText(Integer.toString(stocksid));
                textGoodsID.setText(Integer.toString(goodsid));
                textPrice.setText(Double.toString(price));
                textQuantity.setText(Integer.toString(quantity));
                textTotalCost.setText(Double.toString(totalcost));
                textTotalAmountPaid.setText(Double.toString(totalamountpaid));
                textRemainingAmount.setText(Double.toString(remainingamount));
                textChange.setText(Double.toString(change1));
                textSalesStatus.setText(salesstatus);
                textDate.setText(date);
                textTime.setText(time);*/

                if(stocksid.equals("")|| goodsid.equals("")|| price.equals("")|| quantity.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_stocks where stocksid="+stocksid2+" goodsid="+goodsid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("goodsid");
                        String goodsname2 = rs.getString("goodsname");
                        String goodsdescription2 = rs.getString("goodsdescription");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==0)
                    {
                        JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, No Record Found! ");
                    }
                    else
                    {
                        
                        

                        /*
                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */

                        sql="Update tbl_stocks,tbl_sales"
                        + " SET  tbl_stocks.goodsid="+goodsid2+",tbl_stocks.price="+price2+",tbl_stocks.quantity="+quantity2+","
                        + " tbl_sales.totalpayable=tbl_sales.quantityordered*"+price2+", date=CURDATE(),time=CURTIME()"
                                + " where tbl_stocks.stocksid="+stocksid2+" and tbl_sales.stocksid=tbl_stocks.stocksid";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_sales"
                        + " SET  salesstatus='unsold', date=CURDATE(),time=CURTIME()"
                                + " where stocksid="+stocksid2+" and totalpayment=0 and totalpayment<totalpayable";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_sales"
                        + " SET  salesstatus='partially sold', date=CURDATE(),time=CURTIME()"
                                + " where stocksid="+stocksid2+" and totalpayment>0 and totalpayment<totalpayable";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( );
                        sql="Select * from tbl_stocks where stocksid="+stocksid2+" ";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            /*int id_col2 = rs.getInt("goodsid");
                            String goodsname2 = rs.getString("goodsname");
                            String goodsdescription2 = rs.getString("goodsdescription");
                            String userlevel2 = rs.getString("userlevel");

                            String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                            System.out.println( p );*/

                            rowCount++;
                            if(rowCount==1)
                            {
                               

                                textStocksID.setText(Integer.toString(stocksid2));
                                textGoodsID.setText(Integer.toString(goodsid2));
                                textPrice.setText(Double.toString(price2));
                                textQuantity.setText(Integer.toString(quantity2));
                                
                                
                                textDate.setText(date);
                                textTime.setText(time);

                                stmt2 = con.createStatement( );
                                sql="Select * from tbl_goods where goodsid="+goodsid+"";
                                rs2 = stmt2.executeQuery(sql);

                                rowCount=0;
                                goodsid2 = 0;

                                String goodsname2 = "";
                                String goodsdescription2 = "";

                                while(rs2.next( ))
                                {
                                    if(goodsid2==rs2.getInt("goodsid"))
                                    {
                                        goodsid2 = rs2.getInt("goodsid");

                                        goodsname2 = rs2.getString("goodsname");
                                        goodsdescription2 = rs2.getString("goodsdescription");


                                        textGoodsID.setText(Integer.toString(goodsid2));

                                        textGoodsName.setText(goodsname2);
                                        textGoodsDescription.setText(goodsdescription2);
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        //Show_Goods_In_JTable();
                        //Show_Stocks_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //String stocksid=textStocksID.getText().trim();
            //int stocksid2=Integer.parseInt(stocksid);

            String goodsid=textGoodsID.getText().trim();
            int goodsid2=Integer.parseInt(goodsid);

            String price=textPrice.getText().trim();
            double price2=Double.parseDouble(price);

            String quantity=textQuantity.getText().trim();
            int quantity2=Integer.parseInt(quantity);

            
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");

            String salesstatus="unsold";//textSalesStatus.getText().trim();

            String date=ft.format(dNow);//textDate.getText().trim();
            String time = ft2.format(dNow2);//textTime.getText().trim();

             if(goodsid.equals("")|| price.equals("")|| quantity.equals("")||
                        salesstatus.equals("")|| date.equals("") || time.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Either the goodsname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
                //String sql="Select * from tbl_stocks where goodsid="+goodsid2+" ";
                String sql="Select * from tbl_stocks ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("goodsid");
                    String goodsname2 = rs.getString("goodsname");
                    String goodsdescription2 = rs.getString("goodsdescription");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {

                    /*
                    String stocksid=textStocksID.getText().trim();
                    int stocksid2=Integer.parseInt(stocksid);

                    String goodsid=textGoodsID.getText().trim();
                    int goodsid2=Integer.parseInt(goodsid);

                    String price=textPrice.getText().trim();
                    double price2=Double.parseDouble(price);

                    String quantity=textQuantity.getText().trim();
                    int quantity2=Integer.parseInt(quantity);

                    String totalcost=textTotalCost.getText().trim();
                    double totalcost2=Double.parseDouble(totalcost);

                    String totalamountpaid=textTotalCost.getText().trim();
                    double totalamountpaid2=Double.parseDouble(totalamountpaid);

                    String remainingamount=textTotalCost.getText().trim();
                    double remainingamount2=Double.parseDouble(remainingamount);

                    String change=textTotalCost.getText().trim();
                    double change2=Double.parseDouble(change);
                    
                    //current date
                    Date dNow = new Date( );
                    SimpleDateFormat ft = 
                    new SimpleDateFormat (" yyyy.MM.dd " ) ;

                    //current time
                    Date dNow2 = new Date( );
                    SimpleDateFormat ft2 = 
                    new SimpleDateFormat (" hh:mm:ss ");

                    String salesstatus=textSalesStatus.getText().trim();

                    String date=ft.format(dNow);//textDate.getText().trim();
                    String time = ft.format(dNow2);//textTime.getText().trim();
                    
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_stocks " + "VALUES (NULL,"+goodsid2+", "+price2+","+quantity2+","
                            +"CURDATE(),CURTIME())";

                    stmt.executeUpdate(sql);
                    
                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_stocks where goodsid="+goodsid2+" ";
                    //sql="Select * from tbl_stocks ";
                    sql = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();
                    
                    int stocksid2=rs.getInt("stocksid");
                    
                    
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " new inserted stocktrail item: "+Double.toString(stocksid2));
                    
                    /*
                    stmt2 = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_stocktrail " + "VALUES (NULL,"+stocksid2+", 'stockin', '"+date+"', '"+time+"')";

                    stmt2.executeUpdate(sql);*/
                                       

                    //JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"A New Stock Item is Added!");
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Goods_In_JTable();
                    Show_Stocks_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            textGoodsID.setText("");
            textGoodsName.setText("");
            textGoodsDescription.setText("");
            //textStocksID.setText("");
            //textGoodsID.setText("");
            textPrice.setText("");
            textQuantity.setText("");
            
            textDate.setText("");
            textTime.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");

            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));

            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");

                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textGoodsID.setText("");
        textGoodsName.setText("");
        textGoodsDescription.setText("");
        
        textStocksID.setText("");
        textGoodsID.setText("");
        textPrice.setText("");
        textQuantity.setText("");
        
        textDate.setText("");
        textTime.setText("");
        
    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnSearchByGoodsnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsnameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Goods_In_JTable();
        viewall2=1;
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsnameActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int stocksid = rs.getInt("stocksid");
                int goodsid = rs.getInt("goodsid");
                String goodsname=rs.getString("goodsname");
                String goodsdescription=rs.getString("goodsdescription");
                double price=rs.getDouble("price");
                int quantity=rs.getInt("quantity");

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft = 
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 = 
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(rs.getDate("date"));
                String time = ft.format(rs.getTime("time"));

                textStocksID.setText(Integer.toString(stocksid));
                textGoodsID.setText(Integer.toString(goodsid));
                textPrice.setText(Double.toString(price));
                textQuantity.setText(Integer.toString(quantity));

                textDate.setText(date);
                textTime.setText(time);

                stmt2 = con.createStatement( );
                String sql="Select * from tbl_goods where goodsid="+goodsid+"";
                rs2 = stmt2.executeQuery(sql);

                int rowCount=0;
                int goodsid2 = 0;

                String goodsname2 = "";
                String goodsdescription2 = "";

                while(rs2.next( ))
                {
                    if(goodsid==rs2.getInt("goodsid"))
                    {
                        goodsid2 = rs2.getInt("goodsid");

                        goodsname2 = rs2.getString("goodsname");
                        goodsdescription2 = rs2.getString("goodsdescription");


                        textGoodsID.setText(Integer.toString(goodsid2));

                        textGoodsName.setText(goodsname2);
                        textGoodsDescription.setText(goodsdescription2);
                        break;
                    }
                }
                

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();
            
            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));
            
            textDate.setText(date);
            textTime.setText(time);
            
            stmt2 = con.createStatement( );
            String sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            int rowCount=0;
            int goodsid2 = 0;
            
            String goodsname2 = "";
            String goodsdescription2 = "";

            while(rs2.next( ))
            {
                if(goodsid==rs2.getInt("goodsid"))
                {
                    goodsid2 = rs2.getInt("goodsid");
            
                    goodsname2 = rs2.getString("goodsname");
                    goodsdescription2 = rs2.getString("goodsdescription");


                    textGoodsID.setText(Integer.toString(goodsid2));

                    textGoodsName.setText(goodsname2);
                    textGoodsDescription.setText(goodsdescription2);
                    break;
                }
            }
            
            
            
            
            

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();

        textGoodsID.setText(model.getValueAt(i, 0).toString());
        textGoodsName.setText(model.getValueAt(i, 1).toString());
        textGoodsDescription.setText(model.getValueAt(i, 2).toString());
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
        
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable2KeyTyped
 
   
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustStocksMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustStocksMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustStocksMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustStocksMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalesAndInventoryAugustStocksMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByGoodsname;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextArea textGoodsDescription;
    private javax.swing.JTextField textGoodsID;
    private javax.swing.JTextField textGoodsName;
    private javax.swing.JTextField textPrice;
    private javax.swing.JTextField textQuantity;
    private javax.swing.JTextField textStocksID;
    private javax.swing.JTextField textTime;
    // End of variables declaration//GEN-END:variables
}
