/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugust;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustStocksTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int stocksid;
    int goodsid;
    String goodsname;
    String goodsdescription;
    int quantity;
    double price;
    Date dateofstocks;
    Date timeofstocks;
    
    
    
    
    public SalesAndInventoryAugustStocksTable
    (            
    int stocksid,
    int goodsid,
    String goodsname,
    String goodsdescription,
    int quantity,
    double price,
    Date dateofstocks,
    Date timeofstocks 
    )
            
    {
        
       
        
        this.stocksid=stocksid;
        this.goodsid=goodsid;
        this.goodsname=goodsname;
        this.goodsdescription=goodsdescription;
        this.price=price;
        this.quantity=quantity;
        this.dateofstocks=dateofstocks;
        this.timeofstocks=timeofstocks;
               
        
    }
    
    public int getStocksID()
    {
        return stocksid;
    }
    
    public int getGoodsID()
    {
        return goodsid;
    }
    public String getGoodsname()
    {
        return goodsname;
    }
    public String getGoodsDescription()
    {
        return goodsdescription;
    }
    public double getPrice()
    {
        return price;
    }
    public int getQuantity()
    {
        return quantity;
    }
    
     
    public Date getDateofStocks()
    {
        return dateofstocks;
    }
    
    public Date getTimeofStocks()
    {
        return timeofstocks;
    }
    
}
