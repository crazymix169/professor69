/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugust;



/**
 *
 * @author crazymix69
 */

public class SalesAndInventoryAugustGoodsTable
{
 
    int goodsid;
    String goodsname;
    String goodsdescription;
    
    
    public SalesAndInventoryAugustGoodsTable(int goodsid, String goodsname, String goodsdescription)
    {
        
        this.goodsid=goodsid;
        this.goodsname=goodsname;
        this.goodsdescription=goodsdescription;
               
        
    }
    
    public int getGoodsID()
    {
        return goodsid;
    }
    
    public String getGoodsName()
    {
        return goodsname;
    }
    
    public String getGoodsDescription()
    {
        return goodsdescription;
    }
    
    
    
    
}
