/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugust;

import java.util.Date;




/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustUserLogtrailTable
{
 
    int logtrailid;
    int userid;
    String logtype;
    Date date;
    Date time;
    
    
    public SalesAndInventoryAugustUserLogtrailTable(int logtrailid,int userid, String logtype, Date date, Date time)
    {
        
        this.logtrailid=logtrailid;
        this.userid=userid;
        this.logtype=logtype;
        this.date=date;
        this.time=time;
               
        
    }
    
    public int getLogtrailID()
    {
        return logtrailid;
    }
    
    public int getUserID()
    {
        return userid;
    }
    
    public String getLogtype()
    {
        return logtype;
    }
    
    public Date getDate()
    {
        return date;
    }
    
    public Date getTime()
    {
        return time;
    }
    
    
    
    
}

