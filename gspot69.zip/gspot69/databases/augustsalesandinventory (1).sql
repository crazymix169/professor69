-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2020 at 08:45 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `augustsalesandinventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_badsales`
--

CREATE TABLE `tbl_badsales` (
  `badsalesid` int(11) NOT NULL,
  `salesid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_badstock`
--

CREATE TABLE `tbl_badstock` (
  `badstockid` int(11) NOT NULL,
  `stocksid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_goods`
--

CREATE TABLE `tbl_goods` (
  `goodsid` int(11) NOT NULL,
  `goodsname` varchar(1000) NOT NULL,
  `goodsdescription` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_goods`
--

INSERT INTO `tbl_goods` (`goodsid`, `goodsname`, `goodsdescription`) VALUES
(2, 'tuna', 'spicy and sexy'),
(3, 'corned beef2', 'spicy and sexy'),
(4, 'tunafd', 'spicy and sexy'),
(6, 'dsfas', 'fdaf'),
(7, 'dsfas', 'fdaf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logtrail`
--

CREATE TABLE `tbl_logtrail` (
  `logtrailID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_logtrail`
--

INSERT INTO `tbl_logtrail` (`logtrailID`, `userid`, `logtype`, `date`, `time`) VALUES
(47, 2, 'login', '2020-06-05', '16:32:25'),
(48, 2, 'login', '2020-06-05', '16:36:28'),
(49, 2, 'login', '2020-06-05', '16:41:55'),
(50, 2, 'login', '2020-06-05', '16:48:40'),
(51, 2, 'login', '2020-06-05', '16:49:41'),
(52, 2, 'login', '2020-06-05', '16:50:52'),
(53, 2, 'login', '2020-06-05', '16:51:40'),
(54, 2, 'login', '2020-06-05', '16:52:22'),
(55, 2, 'login', '2020-06-05', '16:54:41'),
(56, 2, 'login', '2020-06-05', '16:56:09'),
(57, 2, 'login', '2020-06-05', '17:01:43');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `paymentid` int(11) NOT NULL,
  `salesid` int(11) NOT NULL,
  `amountpaid` double NOT NULL,
  `change1` double NOT NULL,
  `income` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales`
--

CREATE TABLE `tbl_sales` (
  `salesid` int(11) NOT NULL,
  `stocksid` int(11) NOT NULL,
  `quantityordered` int(11) NOT NULL,
  `actualsales` double NOT NULL,
  `salesstatus` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stocks`
--

CREATE TABLE `tbl_stocks` (
  `stocksID` int(11) NOT NULL,
  `goodsid` int(11) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `userpassword` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(2, 'august', 'kako'),
(5, 'lovez', 'kanayui'),
(7, 'dfadd', 'dfa'),
(8, 'yahagi', 'aaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_badsales`
--
ALTER TABLE `tbl_badsales`
  ADD PRIMARY KEY (`badsalesid`),
  ADD KEY `salesid` (`salesid`);

--
-- Indexes for table `tbl_badstock`
--
ALTER TABLE `tbl_badstock`
  ADD PRIMARY KEY (`badstockid`),
  ADD KEY `stocksid` (`stocksid`);

--
-- Indexes for table `tbl_goods`
--
ALTER TABLE `tbl_goods`
  ADD PRIMARY KEY (`goodsid`);

--
-- Indexes for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  ADD PRIMARY KEY (`logtrailID`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`paymentid`),
  ADD KEY `salesid` (`salesid`);

--
-- Indexes for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  ADD PRIMARY KEY (`salesid`),
  ADD KEY `stocksid` (`stocksid`);

--
-- Indexes for table `tbl_stocks`
--
ALTER TABLE `tbl_stocks`
  ADD PRIMARY KEY (`stocksID`),
  ADD KEY `goodsid` (`goodsid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_badsales`
--
ALTER TABLE `tbl_badsales`
  MODIFY `badsalesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_badstock`
--
ALTER TABLE `tbl_badstock`
  MODIFY `badstockid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_goods`
--
ALTER TABLE `tbl_goods`
  MODIFY `goodsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  MODIFY `logtrailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `paymentid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_stocks`
--
ALTER TABLE `tbl_stocks`
  MODIFY `stocksID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_badsales`
--
ALTER TABLE `tbl_badsales`
  ADD CONSTRAINT `tbl_badsales_ibfk_1` FOREIGN KEY (`salesid`) REFERENCES `tbl_sales` (`salesid`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_badstock`
--
ALTER TABLE `tbl_badstock`
  ADD CONSTRAINT `tbl_badstock_ibfk_1` FOREIGN KEY (`stocksid`) REFERENCES `tbl_stocks` (`stocksID`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  ADD CONSTRAINT `tbl_logtrail_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `tbl_users` (`userid`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD CONSTRAINT `tbl_payment_ibfk_1` FOREIGN KEY (`salesid`) REFERENCES `tbl_sales` (`salesid`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  ADD CONSTRAINT `tbl_sales_ibfk_1` FOREIGN KEY (`stocksid`) REFERENCES `tbl_stocks` (`stocksID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
