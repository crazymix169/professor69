/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jdk.nashorn.internal.objects.NativeString.trim;

public class FanAdminIdolsheetMaintenance extends javax.swing.JFrame {

    /**
     * Creates new form FanAdminIdolsheetMaintenance
     */
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    int curRow = 0,viewall=0;
    String query;
    
    String username;
    String userid;
    
    public FanAdminIdolsheetMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        comboScore.removeAllItems();
        int y=1;
        
        for(y=1;y<=10;y++)
        {
            comboScore.addItem(Integer.toString(y));
        }
        
        Show_Users_In_JTable();
    }
    
    public FanAdminIdolsheetMaintenance() {
        initComponents();
        
        DoConnect();
        
        comboScore.removeAllItems();
        int y=1;
        
        for(y=1;y<=10;y++)
        {
            comboScore.addItem(Integer.toString(y));
        }
        
        
        Show_Users_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from table_idolsheet";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
            

            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " error269: "+ex.getMessage());
            Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textIdolsheetID.setText(first_name);
            textQuestion.setText(last_name);
            textRating.setText(job);*/
            
            return con;
            
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<FanTable_IdolSheet> getUsersList()
    {
        ArrayList<FanTable_IdolSheet> idolList= new ArrayList<FanTable_IdolSheet>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from table_idolsheet";
            }
            else
            {
                String question=textQuestion.getText();
                query = "Select * from table_idolsheet where fanusername like '%"+question+"%'";
            }
            
               
//String s=textIdolsheetID.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            FanTable_IdolSheet idolsheet;
            
            while(rs.next())
            {
                idolsheet = new  FanTable_IdolSheet(rs.getInt("idolsheetid"),rs.getString("question"),rs.getInt("score"));
                idolList.add(idolsheet);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return idolList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<FanTable_IdolSheet> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getIdolSheetID();
            row[1]=list.get(i).getQuestion();
            row[2]=list.get(i).getScore();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSaveRecord = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnNewRecord = new javax.swing.JButton();
        textIdolsheetID = new javax.swing.JTextField();
        btnCancelNewRecord = new javax.swing.JButton();
        btnSearchByUsername = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        textQuestion = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnEdit = new javax.swing.JButton();
        comboScore = new javax.swing.JComboBox<>();
        textScore = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Idol Sheet Maintenance");

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Question");

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnSearchByUsername.setText("Search by Questionnaire");
        btnSearchByUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUsernameActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idol Sheet ID", "Question", "Score"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Score");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Idol Sheet ID");

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        comboScore.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboScoreActionPerformed(evt);
            }
        });

        textScore.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                textScoreMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(22, 22, 22)
                        .addComponent(btnFanAdminWelcome)
                        .addGap(175, 175, 175))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(212, 212, 212)
                        .addComponent(btnSaveRecord)
                        .addGap(36, 36, 36)
                        .addComponent(btnCancelNewRecord)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textQuestion)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(comboScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textScore))))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textIdolsheetID)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSearchByUsername, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(245, 245, 245))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnViewAll)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(textIdolsheetID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(textQuestion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSearchByUsername))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(comboScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete)
                        .addComponent(btnNewRecord))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnFanAdminWelcome)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(131, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String idolsheetid=trim(textIdolsheetID.getText());
            String question=trim(textQuestion.getText());
            String rating=trim(comboScore.getSelectedItem().toString());
            

            if(idolsheetid.equals("")|| question.equals("")|| rating.equals(""))
            {
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " Sorry, Empty Textbox/es! ");
            }
            else
            {
                stmt = con.createStatement( );
                String sql="Select * from table_idolsheet where question='"+question+"'  ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " Sorry, question already exists! ");
                }
                else
                {

                    /*
                    String fname=trim(textIdolsheetID.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textQuestion.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textRating.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */
                    
                    rating="5";

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO table_idolsheet " + "VALUES (NULL,'"+question+"', "+Integer.parseInt(rating)+")";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"A New Question is Added!");
                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );
                    
                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:

        try
        {
            curRow = rs.getRow( );
            textIdolsheetID.setText("");
            textQuestion.setText("");
            comboScore.setSelectedItem(0);
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this," Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textIdolsheetID.setText("");
        textMiddleName.setText("");
        textQuestion.setText("");
        textAddress.setText("");
        textRating.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            
            rs.absolute( curRow );

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
 
            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));
            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );
            
            try
            {
                rs.first();

                int id_col2 = rs.getInt("idolsheetid");
                String question2 = rs.getString("question");
                int score2 = rs.getInt("score");

                textIdolsheetID.setText(Integer.toString(id_col2));
                textQuestion.setText(question2);
                comboScore.setSelectedItem(Integer.toString(score2));
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnSearchByUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUsernameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSearchByUsernameActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
 
            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));
        
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new FanAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                //rs.next();

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
 
            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
 
            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col2 = rs.getInt("idolsheetid");
            String question2 = rs.getString("question");
            int score2 = rs.getInt("score");
 
            textIdolsheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        
        textIdolsheetID.setText(model.getValueAt(i, 0).toString());
        textQuestion.setText(model.getValueAt(i, 1).toString());
        comboScore.setSelectedItem(model.getValueAt(i, 2).toString());
        textScore.setText(model.getValueAt(i, 2).toString());   
        
            
            
        
        
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textIdolsheetID.setText(model.getValueAt(i, 0).toString());
            textQuestion.setText(model.getValueAt(i, 1).toString());
            comboScore.setSelectedItem(model.getValueAt(i, 2).toString());
            textScore.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String idolsheetid=trim(textIdolsheetID.getText());
                int idolsheetid2=Integer.parseInt(idolsheetid);

                String question=trim(textQuestion.getText());
                String score=trim(comboScore.getSelectedItem().toString());
                

                stmt = con.createStatement( );
                String sql="Select * from table_idolsheet";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount<=10)
                {
                    JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " Sorry, number of records is less than or equal to 10! ");
                }
                else
                {

                    /*
                    String fname=trim(textIdolsheetID.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textQuestion.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textRating.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */
                    
                    stmt = con.createStatement( );
                    sql="Select * from table_idolsheet where idolsheetid="+idolsheetid2+"";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("userid");
                        String username2 = rs.getString("username");
                        String userpassword2 = rs.getString("userpassword");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }
                    
                    if(rowCount==1)
                    {

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textIdolsheetID.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textQuestion.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textRating.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */
                        /*
                        sql="Update table_idolinformation"
                        + " SET  fanusername='"+username+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                        + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                        + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                        + " where idolinformationid="+userid2+"";*/

                        sql="DELETE FROM  table_idolsheet"
                        + " where idolsheetid="+idolsheetid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Question Record Successfully Deleted!");
                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String idolsheetid3=trim(textIdolsheetID.getText());
                int idolsheetid2=Integer.parseInt(idolsheetid3);
  
                
                String question=trim(textQuestion.getText());
                String score=trim(comboScore.getSelectedItem().toString());
                int score2=Integer.parseInt(score);
                
                if(idolsheetid3.equals("")|| question.equals("")|| score.equals(""))
                {
                    JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from table_idolsheet where idolsheetid="+idolsheetid2+" or question='"+question+"'";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("userid");
                        String username2 = rs.getString("username");
                        String userpassword2 = rs.getString("userpassword");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==2)
                    {
                        JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " Sorry, There Will be a Duplicate Record! ");
                    }
                    else
                    {

                        /*
                        String fname=trim(textIdolsheetID.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textQuestion.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textRating.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textIdolsheetID.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textQuestion.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textRating.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */

                        sql="Update table_idolsheet"
                        + " SET  question='"+question+"',score="+score2+""
                        + " where idolsheetid="+idolsheetid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Question Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminIdolsheetMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void textScoreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_textScoreMouseClicked
        // TODO add your handling code here:
        textScore.setText("");
    }//GEN-LAST:event_textScoreMouseClicked

    private void comboScoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboScoreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboScoreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolsheetMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolsheetMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolsheetMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolsheetMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FanAdminIdolsheetMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUsername;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JComboBox<String> comboScore;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textIdolsheetID;
    private javax.swing.JTextField textQuestion;
    private javax.swing.JTextField textScore;
    // End of variables declaration//GEN-END:variables
}
