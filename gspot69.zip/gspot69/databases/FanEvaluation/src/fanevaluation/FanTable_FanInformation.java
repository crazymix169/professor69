/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */
public class FanTable_FanInformation
{
    
    int faninformationid;
    String username;
    String userpassword;
    String firstname;
    String middlename;
    String lastname;
    String address;
    String sex;
    String jobtitle;
    String email;
    String dateofbirth;
    String hobby;
    
    FanTable_FanInformation(int faninformationid, String username, String userpassword, String firstname, String middlename, String lastname, String address, String sex, String jobtitle, String email, String dateofbirth, String hobby)
    {
        this.faninformationid=faninformationid;
        this.username=username;
        this.userpassword=userpassword;
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.address=address;
        this.sex=sex;
        this.jobtitle=jobtitle;
        this.email=email;
        this.dateofbirth=dateofbirth;
        this.hobby=hobby;
    }
    
    public int getFanInformationID()
    {
        return faninformationid;
    }
    
    public String getUsername()
    {
        return username;
    }
    
    public String getUserpassword()
    {
        return userpassword;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    
    public String getMiddleName()
    {
        return middlename;
    }
    
    public String getLastName()
    {
        return lastname;
    }
    
    public String getAddress()
    {
        return address;
    }
    
    public String getSex()
    {
        return sex;
    }
    
    public String getJobTitle()
    {
        return jobtitle;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public String getDOB()
    {
        return dateofbirth;
    }
    
    public String getHobby()
    {
        return hobby;
    }
}
