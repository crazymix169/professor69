/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */
public class FanTable_IdolOverallRating
{
    int ovrratingid;
    int idolinformationid;
    double rating;
    
    FanTable_IdolOverallRating(int ovrratingid, int idolinformationid, double rating)
    {
        this.ovrratingid=ovrratingid;
        this.idolinformationid=idolinformationid;
        this.rating=rating;
    }
    
    public int getOverallratingID()
    {
        return ovrratingid;
    }
    
    public int getIdolInformationID()
    {
        return idolinformationid;
    }
    
    public double getRating()
    {
        return rating;
    }   
}
