/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jdk.nashorn.internal.objects.NativeString.trim;

public class FanFanIdolsheetEvaluationSheet extends javax.swing.JFrame {

    /**
     * Creates new form FanFanIdolsheetEvaluationSheet
     */
    
    Connection con;
    Statement stmt,stmt2;
    ResultSet rs,rs2;
    
    int curRow = 0,viewall=0;
    String query;
    
    String username;
    String userid;
    
    String x2;
    
    int x;
    
    public FanFanIdolsheetEvaluationSheet(String Userid, String Username) {
        initComponents();
        comboUserID.removeAllItems();
        DoConnect();
        
        userid=Userid;
        username=Username;
        textUserID.setVisible(false);
        
        comboScore.removeAllItems();
        int y=1;
        
        for(y=1;y<=10;y++)
        {
            comboScore.addItem(Integer.toString(y));
        }
        
        Show_Users_In_JTable();
        
    }
    
    public FanFanIdolsheetEvaluationSheet() {
        initComponents();
        comboUserID.removeAllItems();
        DoConnect();
        textUserID.setVisible(false);
        
        comboScore.removeAllItems();
        int y=1;
        
        for(y=1;y<=10;y++)
        {
            comboScore.addItem(Integer.toString(y));
        }
        
        
        Show_Users_In_JTable();
        
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from table_idolinformation";
            rs = stmt.executeQuery(sql);
            
           

            rs.next();

            int id_col2 = rs.getInt("idolinformationid");
            
            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");

            comboUserID.setSelectedItem(Integer.toString(id_col2));
           
            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            textSex.setText(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);
            
            stmt = con.createStatement( );
            sql="Select * from table_idolinformation";
            rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
                comboUserID.addItem(Integer.toString(rs.getInt("idolinformationid")));
            }
            
            //stmt.close();
            
            stmt2 = con.createStatement( );
            sql="Select * from table_idolsheet";
            rs2 = stmt.executeQuery(sql);
            
            int rowCount=0;

            rs2.next( ); 
            
            int id_col3 = rs2.getInt("idolsheetid");

            String question2 = rs2.getString("question");
            int score2 = rs2.getInt("score");
            

            //comboUserID.setSelectedItem(Integer.toString(id_col2));

            textIdolSheetID.setText(Integer.toString(id_col3));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this, " error269: "+ex.getMessage());
            Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<FanTable_IdolSheet> getUsersList()
    {
        ArrayList<FanTable_IdolSheet> idolList= new ArrayList<FanTable_IdolSheet>();
        Connection connection = getConnection();
        
        
        
        try
        {
            
            
            
            query = "Select * from table_idolsheet";
            
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            FanTable_IdolSheet fansheet;
            
            while(rs.next())
            {
                fansheet = new  FanTable_IdolSheet(rs.getInt("idolsheetid"), rs.getString("question"), rs.getInt("score"));
                idolList.add(fansheet);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return idolList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<FanTable_IdolSheet> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getIdolSheetID();
            row[1]=list.get(i).getQuestion();
            row[2]=list.get(i).getScore();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNext = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        textJobTitle = new javax.swing.JTextField();
        textLastName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btnLast = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textHobby = new javax.swing.JTextField();
        textAddress = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnSearchByUserID = new javax.swing.JButton();
        textEmail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        textFirstName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        btnFirst = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        textMiddleName = new javax.swing.JTextField();
        textDateOfBirth = new javax.swing.JTextField();
        btnPrevious = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        textSex = new javax.swing.JTextField();
        comboUserID = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        textIdolSheetID = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        textQuestion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textUserID = new javax.swing.JTextField();
        btnSaveOverAllRating = new javax.swing.JButton();
        btnSaveCurrentScore = new javax.swing.JButton();
        comboScore = new javax.swing.JComboBox<>();
        textScore = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Idol Evaluation Sheet");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Middle Name");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Last Name");

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Address");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idol Sheet ID", "Question", "Score"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        textAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textAddressActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Sex");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Job Title");

        btnSearchByUserID.setText("Search by UserID");
        btnSearchByUserID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUserIDActionPerformed(evt);
            }
        });

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Email");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Date of Birth");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Hobby");

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Search by User ID");

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("First Name");

        comboUserID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboUserID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboUserIDMouseClicked(evt);
            }
        });
        comboUserID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboUserIDActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("IdolSheet ID");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Question");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Score(input must be 1-10)");

        btnSaveOverAllRating.setText("Save Over All Rating");
        btnSaveOverAllRating.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveOverAllRatingActionPerformed(evt);
            }
        });

        btnSaveCurrentScore.setText("Save Current Score");
        btnSaveCurrentScore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveCurrentScoreActionPerformed(evt);
            }
        });

        comboScore.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnFanAdminWelcome)
                .addGap(58, 58, 58))
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE)
                        .addGap(172, 172, 172))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textAddress)
                                    .addComponent(textMiddleName)
                                    .addComponent(textLastName)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(textIdolSheetID)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByUserID, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textUserID, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(comboScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textScore, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(textQuestion))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(textJobTitle, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
                                    .addComponent(textEmail, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textDateOfBirth, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textHobby, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textSex)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnSaveOverAllRating, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnSaveCurrentScore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrevious)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(btnFanAdminWelcome))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btnSearchByUserID, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(textSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(textJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(textDateOfBirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(textHobby, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(comboUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(textAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textIdolSheetID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSaveOverAllRating))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textQuestion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(btnSaveCurrentScore)
                    .addComponent(comboScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textScore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs2.next()) {

                //rs.next();

                int id_col2 = rs2.getInt("idolsheetid");

                String question2 = rs2.getString("question");
                int score2 = rs2.getInt("score");


                //comboUserID.setSelectedItem(Integer.toString(id_col2));

                textIdolSheetID.setText(Integer.toString(id_col2));
                textQuestion.setText(question2);
                comboScore.setSelectedItem(Integer.toString(score2));

            }
            else {
                rs2.previous();
                JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this, "End of File");
            }
        } catch (SQLException | NumberFormatException err ) {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs2.last();

            int id_col2 = rs2.getInt("idolsheetid");

            String question2 = rs2.getString("question");
            int score2 = rs2.getInt("score");
            

            //comboUserID.setSelectedItem(Integer.toString(id_col2));

            textIdolSheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));

        }
        catch (SQLException | NumberFormatException err) {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textIdolSheetID.setText(model.getValueAt(i, 0).toString());
        textQuestion.setText(model.getValueAt(i, 1).toString());
        comboScore.setSelectedItem(model.getValueAt(i, 2).toString());
        textScore.setText(model.getValueAt(i, 2).toString());
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textIdolSheetID.setText(model.getValueAt(i, 0).toString());
            textQuestion.setText(model.getValueAt(i, 1).toString());
            comboScore.setSelectedItem(model.getValueAt(i, 2).toString());
            textScore.setText(model.getValueAt(i, 2).toString());
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void textAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textAddressActionPerformed

    private void btnSearchByUserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUserIDActionPerformed
        // TODO add your handling code here:
        
        
        try
        {
            //x2=textUserID.getText();
            //x=Integer.parseInt(x2);
            
            x2=comboUserID.getSelectedItem().toString();
            x=Integer.parseInt(x2);

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );



            stmt = con.createStatement( );
            String sql="Select * from table_idolinformation where idolinformationid="+x+"";
            rs = stmt.executeQuery(sql);



            int rowCount=0;

            rs.next( ); 

            int id_col2 = rs.getInt("idolinformationid");

            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");

            comboUserID.setSelectedItem(Integer.toString(id_col2));

            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            textSex.setText(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);


            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Value is: "+ x2);
        
        }
        catch(ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ ex.getMessage());
        } 
        
    }//GEN-LAST:event_btnSearchByUserIDActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs2.first();

            int id_col2 = rs2.getInt("idolsheetid");

            String question2 = rs2.getString("question");
            int score2 = rs2.getInt("score");
            

            //comboUserID.setSelectedItem(Integer.toString(id_col2));

            textIdolSheetID.setText(Integer.toString(id_col2));
            textQuestion.setText(question2);
            comboScore.setSelectedItem(Integer.toString(score2));
            

        }
        catch (SQLException | NumberFormatException err)
        {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new FanWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs2.previous() ) {

                int id_col2 = rs2.getInt("idolsheetid");

                String question2 = rs2.getString("question");
                int score2 = rs2.getInt("score");


                //comboUserID.setSelectedItem(Integer.toString(id_col2));

                textIdolSheetID.setText(Integer.toString(id_col2));
                textQuestion.setText(question2);
                comboScore.setSelectedItem(Integer.toString(score2));

            }
            else {
                rs2.next();
                JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this, "Start of File");
            }
        }
        catch (SQLException | NumberFormatException err ) {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void comboUserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboUserIDActionPerformed
        // TODO add your handling code here:
     
    }//GEN-LAST:event_comboUserIDActionPerformed

    private void comboUserIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboUserIDMouseClicked
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_comboUserIDMouseClicked
    
    //save the overall rating
    private void btnSaveOverAllRatingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveOverAllRatingActionPerformed
        // TODO add your handling code here:
        try
        {
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );



            stmt = con.createStatement( );
            String sql="Select * from table_idolsheet";
            rs2 = stmt.executeQuery(sql);



            int rowCount=0;
            double sum=0;
            while(rs2.next())
            {
                rowCount++;
                sum=sum+rs2.getInt("score");
            }
            
           //int IDOLUSERID=Integer.parseInt(textUserID.getText());
           //String idoluserid=textUserID.getText();
           
           int IDOLUSERID=Integer.parseInt(comboUserID.getSelectedItem().toString());
           String idoluserid=comboUserID.getSelectedItem().toString();
           
           if(rowCount==0)
           {
               JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"No Record present!");
           }
           else if(rowCount!=0 && !idoluserid.equals("")&& IDOLUSERID!=0)
           {
               JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Value is: "+ sum/rowCount);
               
               stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
               sql ="INSERT INTO table_idoloverallrating " + "VALUES (NULL, "+IDOLUSERID+", "+sum/rowCount+")";

               stmt.executeUpdate(sql);
               
               JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Idol Evaluation Successfully Added!: ");
               
           }
            


            
        
        }
        catch(ClassNotFoundException | SQLException | NullPointerException | NumberFormatException | ArithmeticException ex)
        {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ ex.getMessage());
        } 
        
    }//GEN-LAST:event_btnSaveOverAllRatingActionPerformed
    
    //Saves Current Inputted Score
    private void btnSaveCurrentScoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveCurrentScoreActionPerformed
        // TODO add your handling code here:
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            int idolsheetid=Integer.parseInt(textIdolSheetID.getText());
            int score=Integer.parseInt(comboScore.getSelectedItem().toString());
            
            //input must be 1-10
            if(score>=1 && score <=10)
            {
                stmt = con.createStatement( );
                String sql="Update table_idolsheet"
                    + " SET  score='"+score+"'"
                    + " where idolsheetid="+idolsheetid+"";

                stmt.executeUpdate(sql);
                
                textScore.setText(comboScore.getSelectedItem().toString());
            }
            
            Show_Users_In_JTable();

            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Question Record Successfully Modified!");
                  
        }
        catch(ClassNotFoundException | SQLException | NullPointerException | NumberFormatException | ArithmeticException ex)
        {
            JOptionPane.showMessageDialog(FanFanIdolsheetEvaluationSheet.this,"Error: "+ ex.getMessage());
        } 
        
    }//GEN-LAST:event_btnSaveCurrentScoreActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FanFanIdolsheetEvaluationSheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FanFanIdolsheetEvaluationSheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FanFanIdolsheetEvaluationSheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FanFanIdolsheetEvaluationSheet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FanFanIdolsheetEvaluationSheet().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveCurrentScore;
    private javax.swing.JButton btnSaveOverAllRating;
    private javax.swing.JButton btnSearchByUserID;
    private javax.swing.JComboBox<String> comboScore;
    private javax.swing.JComboBox<String> comboUserID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textAddress;
    private javax.swing.JTextField textDateOfBirth;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textHobby;
    private javax.swing.JTextField textIdolSheetID;
    private javax.swing.JTextField textJobTitle;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextField textQuestion;
    private javax.swing.JTextField textScore;
    private javax.swing.JTextField textSex;
    private javax.swing.JTextField textUserID;
    // End of variables declaration//GEN-END:variables
}
