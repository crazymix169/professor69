/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jdk.nashorn.internal.objects.NativeString.trim;

public class FanAdminFanInformationMaintenance extends javax.swing.JFrame {

    /**
     * Creates new form FanAdminFanInformationMaintenance
     */
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    int curRow = 0,viewall=0;
    String query;
    
    String username;
    String userid;
    
    public FanAdminFanInformationMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        textpassPassword.setEchoChar('Y');
        textpassVerifyPassword.setEchoChar('Y');
        comboSex.removeAllItems();
        comboSex.addItem("male");
        comboSex.addItem("female");
        Show_Users_In_JTable();
        
        
    }
    
    public FanAdminFanInformationMaintenance() {
        initComponents();
        
        DoConnect();
        textpassPassword.setEchoChar('Y');
        textpassVerifyPassword.setEchoChar('Y');
        comboSex.removeAllItems();
        comboSex.addItem("male");
        comboSex.addItem("female");
        Show_Users_In_JTable();
        
        
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from table_faninformation";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 

            int id_col2 = rs.getInt("faninformationid");
            String username2 = rs.getString("fanusername");
            String userpassword2 = rs.getString("fanuserpassword");
            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");

            textUserID.setText(Integer.toString(id_col2));
            textUsername.setText(username2);
            textpassPassword.setText(userpassword2);
            textpassVerifyPassword.setText(userpassword2);
            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            comboSex.setSelectedItem(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " error269: "+ex.getMessage());
            Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<FanTable_FanInformation> getUsersList()
    {
        ArrayList<FanTable_FanInformation> fanList= new ArrayList<FanTable_FanInformation>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from table_faninformation";
            }
            else
            {
                String uname=textUsername.getText();
                query = "Select * from table_faninformation where fanusername like '%"+uname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            FanTable_FanInformation faninformation;
            
            while(rs.next())
            {
                faninformation = new  FanTable_FanInformation(rs.getInt("faninformationid"),rs.getString("fanusername"),rs.getString("fanuserpassword"), rs.getString("fname"), rs.getString("mname"), rs.getString("lname"), rs.getString("address"), rs.getString("sex"), rs.getString("job_title"), rs.getString("email"), rs.getString("dob"), rs.getString("hobby") );
                fanList.add(faninformation);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return fanList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<FanTable_FanInformation> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getFanInformationID();
            row[1]=list.get(i).getUsername();
            row[2]=list.get(i).getUserpassword();
            row[3]=list.get(i).getFirstName();
            row[4]=list.get(i).getMiddleName();
            row[5]=list.get(i).getLastName();
            row[6]=list.get(i).getAddress();
            row[7]=list.get(i).getSex();
            row[8]=list.get(i).getJobTitle();
            row[9]=list.get(i).getEmail();
            row[10]=list.get(i).getDOB();
            row[11]=list.get(i).getHobby();
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnEdit = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        textFirstName = new javax.swing.JTextField();
        textMiddleName = new javax.swing.JTextField();
        textUsername = new javax.swing.JTextField();
        textJobTitle = new javax.swing.JTextField();
        textLastName = new javax.swing.JTextField();
        textAddress = new javax.swing.JTextField();
        textpassPassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        textEmail = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        textDateOfBirth = new javax.swing.JTextField();
        textUserID = new javax.swing.JTextField();
        textpassVerifyPassword = new javax.swing.JPasswordField();
        btnDelete = new javax.swing.JButton();
        textHobby = new javax.swing.JTextField();
        comboSex = new javax.swing.JComboBox<>();
        btnSearchByUsername = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Fan Information Maintenance");

        btnEdit.setText("Edit Account");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Account");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("First Name");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Middle Name");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Last Name");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Address");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Sex");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Job Title");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Email");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Date of Birth");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Hobby");

        textAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textAddressActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("User Name");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("User Password");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Verify Password");

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("User ID");

        textUserID.setEnabled(false);

        btnDelete.setText("Delete this Account");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        comboSex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboSexActionPerformed(evt);
            }
        });

        btnSearchByUsername.setText("Search by Username");
        btnSearchByUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUsernameActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Account");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Account");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "User ID", "User Name", "User Password", "First Name", "Middle Name", "Last Name", "Address", "Sex", "Job Title", "Email", "Date of Birth", "Hobby"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textpassVerifyPassword)
                            .addComponent(textFirstName)
                            .addComponent(textMiddleName)
                            .addComponent(textLastName)
                            .addComponent(textAddress)
                            .addComponent(textJobTitle)
                            .addComponent(textEmail)
                            .addComponent(textDateOfBirth)
                            .addComponent(textHobby)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 624, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textpassPassword, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textUsername, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textUserID, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSearchByUsername, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addComponent(btnViewAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnDelete))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCancelNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(139, 139, 139)
                .addComponent(btnFanAdminWelcome)
                .addGap(36, 36, 36))
            .addGroup(layout.createSequentialGroup()
                .addGap(84, 84, 84)
                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnPrevious)
                .addGap(25, 25, 25)
                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(textUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchByUsername))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textpassPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewAll))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(textpassVerifyPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(textAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(textJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(textDateOfBirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(textHobby, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnFanAdminWelcome)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(79, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    //modifies records unless specified otherwise
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=trim(textUserID.getText());
                int userid2=Integer.parseInt(userid);
                String username=trim(textUsername.getText());
                char userpass2[]=textpassPassword.getPassword();
                String userpass= new String(userpass2);
                userpass=trim(userpass);
                char verifyuserpass[]=textpassVerifyPassword.getPassword();
                String verifyuserpassword= new String(verifyuserpass);
                verifyuserpassword=trim(verifyuserpassword);
                
                String fname=trim(textFirstName.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textLastName.getText());
                String address=trim(textAddress.getText());
                //String sex=trim(textSex.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textJobTitle.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());

                if(username.equals("")||userpass.equals("")||verifyuserpassword.equals("") || fname.equals("")|| mname.equals("")|| lname.equals("")||
                    address.equals("")|| sex.equals("")|| jobtitle.equals("")|| email.equals("")|| dateofbirth.equals("")|| hobby.equals("")|| !userpass.equals(verifyuserpassword))
                {
                    JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from table_faninformation where faninformationid="+userid2+" or fanusername='"+username+"'";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("userid");
                        String username2 = rs.getString("username");
                        String userpassword2 = rs.getString("userpassword");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==2)
                    {
                        JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, There Will be a Duplicate Record! ");
                    }
                    else
                    {

                        /*
                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_faninformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */

                        sql="Update table_faninformation"
                        + " SET  fanusername='"+username+"',FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                        + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                        + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                        + " where faninformationid="+userid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Fan Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/
        
        try {
            rs.absolute( curRow );
            
            int id_col2 = rs.getInt("faninformationid");
            String username2 = rs.getString("fanusername");
            String userpassword2 = rs.getString("fanuserpassword");
            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");
            
            textUserID.setText(Integer.toString(id_col2));
            textUsername.setText(username2);
            textpassPassword.setText(userpassword2);
            textpassVerifyPassword.setText(userpassword2);
            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            comboSex.setSelectedItem(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);
        

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );
            
            try
            {
                
                rs.first();

                int id_col2 = rs.getInt("faninformationid");
                String username2 = rs.getString("fanusername");
                String userpassword2 = rs.getString("fanuserpassword");
                String fname2 = rs.getString("fname");
                String mname2 = rs.getString("mname");
                String lname2 = rs.getString("lname");
                String address2 = rs.getString("address");
                String sex2 = rs.getString("sex");
                String job_title2 = rs.getString("job_title");
                String email2 = rs.getString("email");
                String dateofbirth2 = rs.getString("dob");
                String hobby2 = rs.getString("hobby");

                textUserID.setText(Integer.toString(id_col2));
                textUsername.setText(username2);
                textpassPassword.setText(userpassword2);
                textpassVerifyPassword.setText(userpassword2);
                textFirstName.setText(fname2);
                textMiddleName.setText(mname2);
                textLastName.setText(lname2);
                textAddress.setText(address2);
                comboSex.setSelectedItem(sex2);
                textJobTitle.setText(job_title2);
                textEmail.setText(email2);
                textDateOfBirth.setText(dateofbirth2);
                textHobby.setText(hobby2);
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled(false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Error: "+ e.getMessage());
            }   
        }

    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new FanAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void textAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textAddressActionPerformed

    
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=trim(textUserID.getText());
                int userid2=Integer.parseInt(userid);
                String username=trim(textUsername.getText());
                char userpass2[]=textpassPassword.getPassword();
                String userpass= new String(userpass2);
                userpass=trim(userpass);
                char verifyuserpass[]=textpassVerifyPassword.getPassword();
                String verifyuserpassword= new String(verifyuserpass);
                verifyuserpassword=trim(verifyuserpassword);

                String fname=trim(textFirstName.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textLastName.getText());
                String address=trim(textAddress.getText());
                //String sex=trim(textSex.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textJobTitle.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());

                stmt = con.createStatement( );
                String sql="Select * from table_faninformation where faninformationid="+userid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_faninformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*
                    sql="Update table_faninformation"
                    + " SET  fanusername='"+username+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                    + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                    + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                    + " where faninformationid="+userid2+"";*/

                    sql="DELETE FROM  table_faninformation"
                    + " where faninformationid="+userid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Fan Record Successfully Deleted!");
                    

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();

    }//GEN-LAST:event_btnDeleteActionPerformed

    private void comboSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboSexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboSexActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String username=trim(textUsername.getText());
            char userpass2[]=textpassPassword.getPassword();
            String userpass= new String(userpass2);
            userpass=trim(userpass);
            char verifyuserpass[]=textpassVerifyPassword.getPassword();
            String verifyuserpassword= new String(verifyuserpass);
            verifyuserpassword=trim(verifyuserpassword);

            String fname=trim(textFirstName.getText());
            String mname=trim(textMiddleName.getText());
            String lname=trim(textLastName.getText());
            String address=trim(textAddress.getText());
            String sex=trim(comboSex.getSelectedItem());
            String jobtitle=trim(textJobTitle.getText());
            String email=trim(textEmail.getText());
            String dateofbirth=trim(textDateOfBirth.getText());
            String hobby=trim(textHobby.getText());

            if(username.equals("")||userpass.equals("")||verifyuserpassword.equals("") || fname.equals("")|| mname.equals("")|| lname.equals("")||
                address.equals("")|| sex.equals("")|| jobtitle.equals("")|| email.equals("")|| dateofbirth.equals("")|| hobby.equals(""))
            {
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, Either the username or password field/s is/are empty! ");
            }
            else if(userpass.equals(verifyuserpassword))
            {
                stmt = con.createStatement( );
                String sql="Select * from table_faninformation where fanusername='"+username+"'";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, Username already exists! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO table_faninformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"A New Username is Added!");
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled(false );

                }

            }
            else
            {
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " Sorry, Password Mismatch ");
            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Users_In_JTable();

    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int id_col2 = rs.getInt("faninformationid");
            String username2 = rs.getString("fanusername");
            String userpassword2 = rs.getString("fanuserpassword");
            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");

            textUserID.setText(Integer.toString(id_col2));
            textUsername.setText(username2);
            textpassPassword.setText(userpassword2);
            textpassVerifyPassword.setText(userpassword2);
            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            comboSex.setSelectedItem(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int id_col2 = rs.getInt("faninformationid");
                String username2 = rs.getString("fanusername");
                String userpassword2 = rs.getString("fanuserpassword");
                String fname2 = rs.getString("fname");
                String mname2 = rs.getString("mname");
                String lname2 = rs.getString("lname");
                String address2 = rs.getString("address");
                String sex2 = rs.getString("sex");
                String job_title2 = rs.getString("job_title");
                String email2 = rs.getString("email");
                String dateofbirth2 = rs.getString("dob");
                String hobby2 = rs.getString("hobby");

                textUserID.setText(Integer.toString(id_col2));
                textUsername.setText(username2);
                textpassPassword.setText(userpassword2);
                textpassVerifyPassword.setText(userpassword2);
                textFirstName.setText(fname2);
                textMiddleName.setText(mname2);
                textLastName.setText(lname2);
                textAddress.setText(address2);
                comboSex.setSelectedItem(sex2);
                textJobTitle.setText(job_title2);
                textEmail.setText(email2);
                textDateOfBirth.setText(dateofbirth2);
                textHobby.setText(hobby2);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                //rs.next();

                int id_col2 = rs.getInt("faninformationid");
                String username2 = rs.getString("fanusername");
                String userpassword2 = rs.getString("fanuserpassword");
                String fname2 = rs.getString("fname");
                String mname2 = rs.getString("mname");
                String lname2 = rs.getString("lname");
                String address2 = rs.getString("address");
                String sex2 = rs.getString("sex");
                String job_title2 = rs.getString("job_title");
                String email2 = rs.getString("email");
                String dateofbirth2 = rs.getString("dob");
                String hobby2 = rs.getString("hobby");

                textUserID.setText(Integer.toString(id_col2));
                textUsername.setText(username2);
                textpassPassword.setText(userpassword2);
                textpassVerifyPassword.setText(userpassword2);
                textFirstName.setText(fname2);
                textMiddleName.setText(mname2);
                textLastName.setText(lname2);
                textAddress.setText(address2);
                comboSex.setSelectedItem(sex2);
                textJobTitle.setText(job_title2);
                textEmail.setText(email2);
                textDateOfBirth.setText(dateofbirth2);
                textHobby.setText(hobby2);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col2 = rs.getInt("faninformationid");
            String username2 = rs.getString("fanusername");
            String userpassword2 = rs.getString("fanuserpassword");
            String fname2 = rs.getString("fname");
            String mname2 = rs.getString("mname");
            String lname2 = rs.getString("lname");
            String address2 = rs.getString("address");
            String sex2 = rs.getString("sex");
            String job_title2 = rs.getString("job_title");
            String email2 = rs.getString("email");
            String dateofbirth2 = rs.getString("dob");
            String hobby2 = rs.getString("hobby");

            textUserID.setText(Integer.toString(id_col2));
            textUsername.setText(username2);
            textpassPassword.setText(userpassword2);
            textpassVerifyPassword.setText(userpassword2);
            textFirstName.setText(fname2);
            textMiddleName.setText(mname2);
            textLastName.setText(lname2);
            textAddress.setText(address2);
            comboSex.setSelectedItem(sex2);
            textJobTitle.setText(job_title2);
            textEmail.setText(email2);
            textDateOfBirth.setText(dateofbirth2);
            textHobby.setText(hobby2);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:
        
        try
        {
            curRow = rs.getRow( );
            
            textUserID.setText("");
            textUsername.setText("");
            textpassPassword.setText("");
            textpassVerifyPassword.setText("");
            textFirstName.setText("");
            textMiddleName.setText("");
            textLastName.setText("");
            textAddress.setText("");
            textJobTitle.setText("");
            textEmail.setText("");
            textDateOfBirth.setText("");
            textHobby.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {
            
            JOptionPane.showMessageDialog(FanAdminFanInformationMaintenance.this," Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );
        }
        
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textUserID.setText(model.getValueAt(i, 0).toString());
        textUsername.setText(model.getValueAt(i, 1).toString());
        textpassPassword.setText(model.getValueAt(i, 2).toString());
        textpassVerifyPassword.setText(model.getValueAt(i, 2).toString());

        textFirstName.setText(model.getValueAt(i, 3).toString());
        textMiddleName.setText(model.getValueAt(i, 4).toString());
        textLastName.setText(model.getValueAt(i, 5).toString());
        textAddress.setText(model.getValueAt(i, 6).toString());
        comboSex.setSelectedItem(model.getValueAt(i, 7).toString());
        textJobTitle.setText(model.getValueAt(i, 8).toString());
        textEmail.setText(model.getValueAt(i, 9).toString());
        textDateOfBirth.setText(model.getValueAt(i, 10).toString());
        textHobby.setText(model.getValueAt(i, 11).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textUserID.setText(model.getValueAt(i, 0).toString());
            textUsername.setText(model.getValueAt(i, 1).toString());
            textpassPassword.setText(model.getValueAt(i, 2).toString());
            textpassVerifyPassword.setText(model.getValueAt(i, 2).toString());
            
            textFirstName.setText(model.getValueAt(i, 3).toString());
            textMiddleName.setText(model.getValueAt(i, 4).toString());
            textLastName.setText(model.getValueAt(i, 5).toString());
            textAddress.setText(model.getValueAt(i, 6).toString());
            comboSex.setSelectedItem(model.getValueAt(i, 7).toString());
            textJobTitle.setText(model.getValueAt(i, 8).toString());
            textEmail.setText(model.getValueAt(i, 9).toString());
            textDateOfBirth.setText(model.getValueAt(i, 10).toString());
            textHobby.setText(model.getValueAt(i, 11).toString());
        }

    }//GEN-LAST:event_jTable1KeyPressed

                             

   
    

                                                   

   
    
    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:

    }//GEN-LAST:event_jTable1KeyTyped

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnSearchByUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUsernameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
        
        
    }//GEN-LAST:event_btnSearchByUsernameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FanAdminFanInformationMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FanAdminFanInformationMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FanAdminFanInformationMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FanAdminFanInformationMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FanAdminFanInformationMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUsername;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JComboBox<String> comboSex;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textAddress;
    private javax.swing.JTextField textDateOfBirth;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textHobby;
    private javax.swing.JTextField textJobTitle;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextField textUserID;
    private javax.swing.JTextField textUsername;
    private javax.swing.JPasswordField textpassPassword;
    private javax.swing.JPasswordField textpassVerifyPassword;
    // End of variables declaration//GEN-END:variables
}
