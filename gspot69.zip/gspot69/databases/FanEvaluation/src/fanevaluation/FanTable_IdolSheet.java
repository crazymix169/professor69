/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */
public class FanTable_IdolSheet 
{
    int idolsheetid;
    String question;
    int score;
    
    FanTable_IdolSheet(int idolsheetid, String question, int score)
    {
        this.idolsheetid=idolsheetid;
        this.question=question;
        this.score=score;
    }
    
    public int getIdolSheetID()
    {
        return idolsheetid;
    }
    
    public String getQuestion()
    {
        return question;
    }
    
    public double getScore()
    {
        return score;
    }
}
