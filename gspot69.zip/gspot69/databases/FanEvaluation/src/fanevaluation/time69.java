/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;


/**
 *
 * @author crazymix69
 */
public class time69 {
    
    public static void main(String args[])
	{
		String dateStart = "11/03/14 09:29:58";
		String dateStop = "11/03/14 09:33:43";

		// Custom date format
		SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd HH:mm:ss");

		Date d1 = null;
		Date d2 = null;
		try {
		    d1 = (Date) format.parse(dateStart);
		    d2 = (Date) format.parse(dateStop);
		} catch (ParseException e) {
		    e.printStackTrace();
		}

		// Get msec from each, and subtract.
		long diff = d2.getTime() - d1.getTime();
		long diffSeconds = diff / 1000;
		long diffMinutes = diff / (60 * 1000);
		long diffHours = diff / (60 * 60 * 1000);
                long diffDays = diff / (60 * 60 * 1000 * 24);
                long diffWeeks = diff / (60 * 60 * 1000 * 24 * 7);
                long diffMonths = (long) (diff / (60 * 60 * 1000 * 24 * 30.41666666));
                long diffYears = diff / ((long)60 * 60 * 1000 * 24 * 365);
		System.out.println("Time in seconds: " + diffSeconds + " seconds.");
		System.out.println("Time in minutes: " + diffMinutes + " minutes.");
		System.out.println("Time in hours: " + diffHours + " hours.");
                System.out.println("Time in seconds: " + diffDays + " days.");
		System.out.println("Time in minutes: " + diffWeeks + " weeks.");
		System.out.println("Time in hours: " + diffMonths + " Months.");
                System.out.println("Time in seconds: " + diffYears + " years.");
		
                
                //long diff = d2.getTime() - d1.getTime();//as given

                //long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);
                //long minutes = TimeUnit.MILLISECONDS.toMinutes(diff); 
                
                
	}
    
    /*
    String friendlyTimeDiff(long timeDifferenceMilliseconds) {
    long diffSeconds = timeDifferenceMilliseconds / 1000;
    long diffMinutes = timeDifferenceMilliseconds / (60 * 1000);
    long diffHours = timeDifferenceMilliseconds / (60 * 60 * 1000);
    long diffDays = timeDifferenceMilliseconds / (60 * 60 * 1000 * 24);
    long diffWeeks = timeDifferenceMilliseconds / (60 * 60 * 1000 * 24 * 7);
    long diffMonths = (long) (timeDifferenceMilliseconds / (60 * 60 * 1000 * 24 * 30.41666666));
    long diffYears = timeDifferenceMilliseconds / ((long)60 * 60 * 1000 * 24 * 365);

    if (diffSeconds < 1) {
        return "less than a second";
    } else if (diffMinutes < 1) {
        return diffSeconds + " seconds";
    } else if (diffHours < 1) {
        return diffMinutes + " minutes";
    } else if (diffDays < 1) {
        return diffHours + " hours";
    } else if (diffWeeks < 1) {
        return diffDays + " days";
    } else if (diffMonths < 1) {
        return diffWeeks + " weeks";
    } else if (diffYears < 1) {
        return diffMonths + " months";
    } else {
        return diffYears + " years";
    }
}
    */
    
    
}
