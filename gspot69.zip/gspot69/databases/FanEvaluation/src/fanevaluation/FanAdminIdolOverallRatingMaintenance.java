/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import static jdk.nashorn.internal.objects.NativeString.trim;

public class FanAdminIdolOverallRatingMaintenance extends javax.swing.JFrame {

    /**
     * Creates new form FanAdminIdolOverallRatingMaintenance
     */
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    int curRow = 0,viewall=0;
    String query;
    
    String username;
    String userid;
    
    public FanAdminIdolOverallRatingMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        
        
        viewall=0;
        Show_Users_In_JTable();
    }
    
    public FanAdminIdolOverallRatingMaintenance() {
        initComponents();
        
        DoConnect();
        
        
        
        viewall=0;
        Show_Users_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from table_idoloverallrating";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 
            
            //rs.first();
            
            int id_col2 = rs.getInt("idoloverallratingid");
            int idolinformationid2 = rs.getInt("idolinformationid");
            double rating2 = rs.getDouble("rating");
            

            textIdolOverallRatingID.setText(Integer.toString(id_col2));
            comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
            textRating.setText(Double.toString(rating2));
            
            comboIdolInformationID.removeAllItems();
            stmt = con.createStatement( );
            sql="Select  distinct idolinformationid from table_idoloverallrating order by idolinformationid asc";
            rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
                comboIdolInformationID.addItem(Integer.toString(rs.getInt("idolinformationid")));
            }
            
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textIdolsheetID.setText(first_name);
            textQuestion.setText(last_name);
            textRating.setText(job);*/
            
            return con;
            
        }
        catch (ClassNotFoundException | SQLException e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<FanTable_IdolOverallRating> getUsersList()
    {
        ArrayList<FanTable_IdolOverallRating> idolList= new ArrayList<FanTable_IdolOverallRating>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from table_idoloverallrating";
            }
            else
            {
                //int x=Integer.parseInt(textIdolInformationID.getText());
                int x=Integer.parseInt(comboIdolInformationID.getSelectedItem().toString());
                query = "Select * from table_idoloverallrating where idolinformationid = "+x+"";
            }
            
               
//String s=textIdolsheetID.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
            

           
            
            //rs.first();
            
            
            
           
            
            FanTable_IdolOverallRating idolsheet;
            
            while(rs.next())
            {
                int id_col2 = rs.getInt("idoloverallratingid");
                int idolinformationid2 = rs.getInt("idolinformationid");
                double rating2 = rs.getDouble("rating");


                textIdolOverallRatingID.setText(Integer.toString(id_col2));
                comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
                textRating.setText(Double.toString(rating2));
            
                idolsheet = new  FanTable_IdolOverallRating(rs.getInt("idoloverallratingid"),rs.getInt("idolinformationid"),rs.getDouble("rating"));
                idolList.add(idolsheet);
                
            }
            
            
            
        }
        catch (SQLException | NullPointerException e)
        {
            
        }
        
        return idolList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<FanTable_IdolOverallRating> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getOverallratingID();
            row[1]=list.get(i).getIdolInformationID();
            row[2]=list.get(i).getRating();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnEdit = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        textRating = new javax.swing.JTextField();
        btnNext = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnNewRecord = new javax.swing.JButton();
        textIdolOverallRatingID = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        btnCancelNewRecord = new javax.swing.JButton();
        btnSearchByUsername = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnViewAll = new javax.swing.JButton();
        btnAverageOfIdol = new javax.swing.JButton();
        comboIdolInformationID = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Idol Overall Rating Maintenance");

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Idol Information ID");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Idol Overall Rating ID", "Idol Infromation ID", "Rating"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Rating");

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnSearchByUsername.setText("Search by Idol Information ID");
        btnSearchByUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUsernameActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Idol Overall Rating ID");

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnAverageOfIdol.setText("Compute Average of Idol");
        btnAverageOfIdol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAverageOfIdolActionPerformed(evt);
            }
        });

        comboIdolInformationID.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboIdolInformationID.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboIdolInformationIDMouseClicked(evt);
            }
        });
        comboIdolInformationID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboIdolInformationIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                        .addGap(22, 22, 22)
                        .addComponent(btnFanAdminWelcome)
                        .addGap(175, 175, 175))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(212, 212, 212)
                        .addComponent(btnSaveRecord)
                        .addGap(36, 36, 36)
                        .addComponent(btnCancelNewRecord)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textRating)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(comboIdolInformationID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnSearchByUsername, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textIdolOverallRatingID)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnViewAll, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                    .addComponent(btnAverageOfIdol, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(325, 325, 325))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnViewAll)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(textIdolOverallRatingID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(btnSearchByUsername)
                            .addComponent(btnAverageOfIdol)
                            .addComponent(comboIdolInformationID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(textRating, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete)
                        .addComponent(btnNewRecord))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnFanAdminWelcome)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(135, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String idoloverallrating3=trim(textIdolOverallRatingID.getText());
                int idoloverallrating2=Integer.parseInt(idoloverallrating3);

                int idolinformationid2=Integer.parseInt(comboIdolInformationID.getSelectedItem().toString());

                String rating=trim(textRating.getText());
                double rating2=Double.parseDouble(rating);
          
                                

                /*
                String fname=trim(textIdolsheetID.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textQuestion.getText());
                String address=trim(textAddress.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textRating.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());
                */

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                /*
                sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                String fname=trim(textIdolsheetID.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textQuestion.getText());
                String address=trim(textAddress.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textRating.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());

                */

                String sql="Update table_idoloverallrating"
                + " SET  idolinformationid="+idolinformationid2+",rating="+rating2+""
                + " where idoloverallratingid="+idoloverallrating2+"";

                stmt.executeUpdate(sql);

                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Idol Rating Successfully Modified!");
                
                comboIdolInformationID.removeAllItems();
                stmt = con.createStatement( );
                sql="Select  distinct idolinformationid from table_idoloverallrating order by idolinformationid asc";
                rs = stmt.executeQuery(sql);

                while(rs.next())
                {
                    comboIdolInformationID.addItem(Integer.toString(rs.getInt("idolinformationid")));
                }
                //new FanLogin().setVisible(true);
                //this.dispose();

                

                

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new FanAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                //rs.next();

                int id_col2 = rs.getInt("idoloverallratingid");
                int idolinformationid2 = rs.getInt("idolinformationid");
                double rating2 = rs.getDouble("rating");


                textIdolOverallRatingID.setText(Integer.toString(id_col2));
                comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
                textRating.setText(Double.toString(rating2));
            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int id_col2 = rs.getInt("idoloverallratingid");
                int idolinformationid2 = rs.getInt("idolinformationid");
                double rating2 = rs.getDouble("rating");


                textIdolOverallRatingID.setText(Integer.toString(id_col2));
                comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
                textRating.setText(Double.toString(rating2));

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String idoloverallratingid=trim(textIdolOverallRatingID.getText());
            String idolinformationid=trim(comboIdolInformationID.getSelectedItem().toString());
            String rating=trim(textRating.getText());

            if(idolinformationid.equals("")|| rating.equals("")||Double.parseDouble(rating)<1 ||Double.parseDouble(rating)>10)
            {
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " Sorry, Empty Textbox/es! ");
            }
            else
            {
                

                int rowCount=0;

                

                    

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    String sql ="INSERT INTO table_idoloverallrating " + "VALUES (NULL,"+Integer.parseInt(idolinformationid)+", "+Double.parseDouble(rating)+")";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"A New Idol Rating is Added!");
                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );
                    
                    comboIdolInformationID.removeAllItems();
                    stmt = con.createStatement( );
                    sql="Select  distinct idolinformationid from table_idoloverallrating order by idolinformationid asc";
                    rs = stmt.executeQuery(sql);

                    while(rs.next())
                    {
                        comboIdolInformationID.addItem(Integer.toString(rs.getInt("idolinformationid")));
                    }

                

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        viewall=0;
        //Show_Users_In_JTable();
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col2 = rs.getInt("idoloverallratingid");
            int idolinformationid2 = rs.getInt("idolinformationid");
            double rating2 = rs.getDouble("rating");
            

            textIdolOverallRatingID.setText(Integer.toString(id_col2));
            comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
            textRating.setText(Double.toString(rating2));

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textIdolOverallRatingID.setText(model.getValueAt(i, 0).toString());
        comboIdolInformationID.setSelectedItem((model.getValueAt(i, 1).toString()));
        textRating.setText(model.getValueAt(i, 2).toString());

    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textIdolOverallRatingID.setText(model.getValueAt(i, 0).toString());
            comboIdolInformationID.setSelectedItem((model.getValueAt(i, 1).toString()));
            textRating.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:

        try
        {
            curRow = rs.getRow( );
            textIdolOverallRatingID.setText("");
            comboIdolInformationID.setSelectedItem(0);
            textRating.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textIdolsheetID.setText("");
        textMiddleName.setText("");
        textQuestion.setText("");
        textAddress.setText("");
        textRating.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            
            rs.absolute( curRow );

            int id_col2 = rs.getInt("idoloverallratingid");

            int idolinformationid2 = rs.getInt("idolinformationid");

            double rating2 = rs.getDouble("rating");

            textIdolOverallRatingID.setText(Integer.toString(id_col2));

            comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
            textRating.setText(Double.toString(rating2));

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
            try
            {
                rs.first();

                int id_col2 = rs.getInt("idoloverallratingid");
                int idolinformationid2 = rs.getInt("idolinformationid");
                double rating2 = rs.getDouble("rating");


                textIdolOverallRatingID.setText(Integer.toString(id_col2));
                comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
                textRating.setText(Double.toString(rating2));
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnSearchByUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUsernameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSearchByUsernameActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String idoloverallratingid=trim(textIdolOverallRatingID.getText());
                int idoloverallratingid2=Integer.parseInt(idoloverallratingid);

                String idolinformation=trim(comboIdolInformationID.getSelectedItem().toString());
                String rating=trim(textRating.getText());

                stmt = con.createStatement( );
                String sql="Select * from table_idoloverallrating where idoloverallratingid="+idoloverallratingid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textIdolsheetID.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textQuestion.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textRating.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textIdolsheetID.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textQuestion.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textRating.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*
                    sql="Update table_idolinformation"
                    + " SET  fanusername='"+username+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                    + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                    + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                    + " where idolinformationid="+userid2+"";*/

                    sql="DELETE FROM  table_idoloverallrating"
                    + " where idoloverallratingid="+idoloverallratingid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Idol Rating Record Successfully Deleted!");
                    
                    comboIdolInformationID.removeAllItems();
                    stmt = con.createStatement( );
                    sql="Select  distinct idolinformationid from table_idoloverallrating order by idolinformationid asc";
                    rs = stmt.executeQuery(sql);

                    while(rs.next())
                    {
                        comboIdolInformationID.addItem(Integer.toString(rs.getInt("idolinformationid")));
                    }
                    

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Nothing is Deleted!");
        }
        viewall=0;
        //Show_Users_In_JTable();
        //Show_Users_In_JTable();
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int id_col2 = rs.getInt("idoloverallratingid");
            int idolinformationid2 = rs.getInt("idolinformationid");
            double rating2 = rs.getDouble("rating");
            

            textIdolOverallRatingID.setText(Integer.toString(id_col2));
            comboIdolInformationID.setSelectedItem(Integer.toString(idolinformationid2));
            textRating.setText(Double.toString(rating2));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnAverageOfIdolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAverageOfIdolActionPerformed
        // TODO add your handling code here:
        try
        {
            int x=Integer.parseInt(comboIdolInformationID.getSelectedItem().toString());
            stmt = con.createStatement( );
            String sql="Select * from table_idoloverallrating where idolinformationid="+x+" ";
            rs = stmt.executeQuery(sql);
            
            
            double sum1=0;
            int cnt1=0;
            while(rs.next())
            {
                sum1=sum1+rs.getDouble("rating");
                cnt1++;
            }
            if(cnt1>0)
            {
                JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"The average is: "+sum1/cnt1);
            }
            
                  
            stmt = con.createStatement( );
            sql="Select Avg(rating) from table_idoloverallrating where idolinformationid="+x+"";
            rs = stmt.executeQuery(sql);
            rs.next();
            
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"The average is: "+rs.getDouble(1));
        }
        catch(SQLException | ArithmeticException | NumberFormatException  e)
        {
            JOptionPane.showMessageDialog(FanAdminIdolOverallRatingMaintenance.this,"Error: "+ e.getMessage());
        }
    }//GEN-LAST:event_btnAverageOfIdolActionPerformed

    private void comboIdolInformationIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboIdolInformationIDActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_comboIdolInformationIDActionPerformed

    private void comboIdolInformationIDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboIdolInformationIDMouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_comboIdolInformationIDMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolOverallRatingMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolOverallRatingMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolOverallRatingMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FanAdminIdolOverallRatingMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FanAdminIdolOverallRatingMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAverageOfIdol;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUsername;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JComboBox<String> comboIdolInformationID;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textIdolOverallRatingID;
    private javax.swing.JTextField textRating;
    // End of variables declaration//GEN-END:variables
}
