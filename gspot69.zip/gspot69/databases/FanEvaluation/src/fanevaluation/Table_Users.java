/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */
public class Table_Users
{
 
    int userid;
    String username;
    String userpassword;
    String userlevel;
    
    public Table_Users(int userid, String username, String userpassword, String userlevel)
    {
        
        this.userid=userid;
        this.username=username;
        this.userpassword=userpassword;
        this.userlevel=userlevel;       
        
    }
    
}
