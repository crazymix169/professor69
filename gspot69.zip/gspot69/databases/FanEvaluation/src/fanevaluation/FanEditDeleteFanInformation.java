/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fanevaluation;

/**
 *
 * @author crazymix69
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static jdk.nashorn.internal.objects.NativeString.trim;
import java.lang.*;

public class FanEditDeleteFanInformation extends javax.swing.JFrame {

    /**
     * Creates new form FanEditDeleteFanInformation
     */
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    String userid;
    String username;
    
    public FanEditDeleteFanInformation(String Userid,String Username)
    {
        initComponents();
        textpassPassword.setEchoChar('Y');
        textpassVerifyPassword.setEchoChar('Y');
        userid=Userid;
        username=Username;
        textUserID.setText(userid);
        comboSex.removeAllItems();
        comboSex.addItem("male");
        comboSex.addItem("female");
        
        
        
        
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            /*
            String userid=trim(textUserID.getText());
            int userid2=Integer.parseInt(userid);
            String username=trim(textUsername.getText());
            char userpass2[]=textpassPassword.getPassword();
            String userpass= new String(userpass2);
            userpass=trim(userpass);
            char verifyuserpass[]=textpassVerifyPassword.getPassword();
            String verifyuserpassword= new String(verifyuserpass);
            verifyuserpassword=trim(verifyuserpassword);

            String fname=trim(textFirstName.getText());
            String mname=trim(textMiddleName.getText());
            String lname=trim(textLastName.getText());
            String address=trim(textAddress.getText());
            //String sex=trim(textSex.getText());
            String sex=trim(comboSex.getSelectedItem());
            String jobtitle=trim(textJobTitle.getText());
            String email=trim(textEmail.getText());
            String dateofbirth=trim(textDateOfBirth.getText());
            String hobby=trim(textHobby.getText());*/

            stmt = con.createStatement( );
            String sql="Select * from table_faninformation where faninformationid="+Integer.parseInt(userid)+"";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while ( rs.next( ) )
            {
                /*int id_col2 = rs.getInt("userid");
                String username2 = rs.getString("username");
                String userpassword2 = rs.getString("userpassword");
                String userlevel2 = rs.getString("userlevel");

                String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                System.out.println( p );*/

                textUsername.setText(rs.getString("fanusername"));
                textpassPassword.setText(rs.getString("fanuserpassword"));
                textpassVerifyPassword.setText(rs.getString("fanuserpassword"));
                textFirstName.setText(rs.getString("fname"));
                textMiddleName.setText(rs.getString("mname"));
                textLastName.setText(rs.getString("lname"));
                textAddress.setText(rs.getString("address"));
                //textSex.setText(rs.getString("sex"));
                comboSex.setSelectedItem(rs.getString("sex"));
                textJobTitle.setText(rs.getString("job_title"));
                textEmail.setText(rs.getString("email"));
                textDateOfBirth.setText(rs.getString("dob"));
                textHobby.setText(rs.getString("hobby"));
                
                //combo.addItem(rs.getString("fanusername"));

                rowCount++;
            }

            

            

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " error269: "+ex.getMessage());
            Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    public FanEditDeleteFanInformation()
    {
        initComponents();
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textUsername = new javax.swing.JTextField();
        textJobTitle = new javax.swing.JTextField();
        textpassPassword = new javax.swing.JPasswordField();
        textEmail = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        textDateOfBirth = new javax.swing.JTextField();
        textpassVerifyPassword = new javax.swing.JPasswordField();
        textHobby = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        btnLogin = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        textFirstName = new javax.swing.JTextField();
        textMiddleName = new javax.swing.JTextField();
        textLastName = new javax.swing.JTextField();
        textAddress = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        textUserID = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        comboSex = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Edit or Delete Fan Information");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Verify Password");

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });

        btnLogin.setText("Back to Fan Welcome Form");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("First Name");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Middle Name");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Last Name");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Address");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Sex");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Job Title");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Email");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Date of Birth");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Hobby");

        textAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textAddressActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("User Name");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("User Password");

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("User ID");

        textUserID.setEnabled(false);

        btnDelete.setText("Delete this Account");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        comboSex.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboSex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboSexActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLogin))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textpassVerifyPassword)
                            .addComponent(textFirstName)
                            .addComponent(textMiddleName)
                            .addComponent(textLastName)
                            .addComponent(textAddress)
                            .addComponent(textJobTitle)
                            .addComponent(textEmail)
                            .addComponent(textDateOfBirth)
                            .addComponent(textHobby)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textpassPassword, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textUsername, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textUserID, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(153, 153, 153))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(textUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(textpassPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(textpassVerifyPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(textAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(comboSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(textJobTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(textEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(textDateOfBirth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(textHobby, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEdit)
                    .addComponent(btnCancel)
                    .addComponent(btnLogin)
                    .addComponent(btnDelete))
                .addContainerGap(113, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        
        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);
        
        if(p==0)
        {
        
            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=trim(textUserID.getText());
                int userid2=Integer.parseInt(userid);
                String username=trim(textUsername.getText());
                char userpass2[]=textpassPassword.getPassword();
                String userpass= new String(userpass2);
                userpass=trim(userpass);
                char verifyuserpass[]=textpassVerifyPassword.getPassword();
                String verifyuserpassword= new String(verifyuserpass);
                verifyuserpassword=trim(verifyuserpassword);

                String fname=trim(textFirstName.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textLastName.getText());
                String address=trim(textAddress.getText());
                //String sex=trim(textSex.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textJobTitle.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());

                if(username.equals("")||userpass.equals("")||verifyuserpassword.equals("") || fname.equals("")|| mname.equals("")|| lname.equals("")||
                    address.equals("")|| sex.equals("")|| jobtitle.equals("")|| email.equals("")|| dateofbirth.equals("")|| hobby.equals("")|| !userpass.equals(verifyuserpassword))
                {
                    JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from table_faninformation where faninformationid="+userid2+" or fanusername='"+username+"'";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("userid");
                        String username2 = rs.getString("username");
                        String userpassword2 = rs.getString("userpassword");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==2)
                    {
                        JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " Sorry, There Will be a Duplicate Record! ");
                    }
                    else
                    {

                        /*
                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_faninformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */

                        sql="Update table_faninformation"
                            + " SET  fanusername='"+username+"',FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                                + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                                + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                            + " where faninformationid="+userid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this,"Fan Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this,"Nothing is modified!");
        }

    }//GEN-LAST:event_btnEditActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        // TODO add your handling code here:

        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");
        

    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        // TODO add your handling code here:
        
        new FanWelcome(userid,username).setVisible(true);
        this.dispose();

    }//GEN-LAST:event_btnLoginActionPerformed

    private void textAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textAddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textAddressActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
        
        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);
        
        if(p==0)
        {
        
            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/fanevaluation?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=trim(textUserID.getText());
                int userid2=Integer.parseInt(userid);
                String username=trim(textUsername.getText());
                char userpass2[]=textpassPassword.getPassword();
                String userpass= new String(userpass2);
                userpass=trim(userpass);
                char verifyuserpass[]=textpassVerifyPassword.getPassword();
                String verifyuserpassword= new String(verifyuserpass);
                verifyuserpassword=trim(verifyuserpassword);

                String fname=trim(textFirstName.getText());
                String mname=trim(textMiddleName.getText());
                String lname=trim(textLastName.getText());
                String address=trim(textAddress.getText());
                //String sex=trim(textSex.getText());
                String sex=trim(comboSex.getSelectedItem());
                String jobtitle=trim(textJobTitle.getText());
                String email=trim(textEmail.getText());
                String dateofbirth=trim(textDateOfBirth.getText());
                String hobby=trim(textHobby.getText());

               
                stmt = con.createStatement( );
                String sql="Select * from table_faninformation where faninformationid="+userid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("userid");
                    String username2 = rs.getString("username");
                    String userpassword2 = rs.getString("userpassword");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + username2 + "      " + userpassword2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_faninformation " + "VALUES (NULL, '"+username+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*                
                    sql="Update table_faninformation"
                        + " SET  fanusername='"+username+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                            + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                            + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                        + " where faninformationid="+userid2+"";*/

                    sql="DELETE FROM  table_faninformation"
                    + " where faninformationid="+userid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this,"Fan Record Successfully Deleted!");
                    new FanLogin().setVisible(true);
                    new FanWelcome().dispose();
                    this.dispose();


                }

                

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this, " error269: "+ex.getMessage());
                Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(FanEditDeleteFanInformation.this,"Nothing is modified!");
        }
        
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void comboSexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboSexActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboSexActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FanEditDeleteFanInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FanEditDeleteFanInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FanEditDeleteFanInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FanEditDeleteFanInformation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FanEditDeleteFanInformation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnLogin;
    private javax.swing.JComboBox<String> comboSex;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField textAddress;
    private javax.swing.JTextField textDateOfBirth;
    private javax.swing.JTextField textEmail;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textHobby;
    private javax.swing.JTextField textJobTitle;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextField textUserID;
    private javax.swing.JTextField textUsername;
    private javax.swing.JPasswordField textpassPassword;
    private javax.swing.JPasswordField textpassVerifyPassword;
    // End of variables declaration//GEN-END:variables

    private void setText(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
