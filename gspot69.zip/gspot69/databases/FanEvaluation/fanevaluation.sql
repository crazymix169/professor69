-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2018 at 07:28 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fanevaluation`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_adminlogtrail`
--

CREATE TABLE `table_adminlogtrail` (
  `logtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(50) NOT NULL,
  `dateandtime` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_adminlogtrail`
--

INSERT INTO `table_adminlogtrail` (`logtrailid`, `userid`, `logtype`, `dateandtime`) VALUES
(1, 1, 'login', 'Thu 2018.02.22 at 09:31:47 PM CST'),
(2, 1, 'logout', 'Thu 2018.02.22 at 09:31:49 PM CST');

-- --------------------------------------------------------

--
-- Table structure for table `table_faninformation`
--

CREATE TABLE `table_faninformation` (
  `FANINFORMATIONID` int(11) NOT NULL,
  `FANUSERNAME` varchar(50) NOT NULL,
  `FANUSERPASSWORD` varchar(50) NOT NULL,
  `FNAME` varchar(50) NOT NULL,
  `MNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(300) NOT NULL,
  `SEX` varchar(50) NOT NULL,
  `JOB_TITLE` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `HOBBY` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_faninformation`
--

INSERT INTO `table_faninformation` (`FANINFORMATIONID`, `FANUSERNAME`, `FANUSERPASSWORD`, `FNAME`, `MNAME`, `LNAME`, `ADDRESS`, `SEX`, `JOB_TITLE`, `EMAIL`, `DOB`, `HOBBY`) VALUES
(1, 'crazymix69', 'aya', 'august', 'rosito', 'tabucanon', 'San Pablo, Ormoc City', 'male', 'Hunter', 'aug_sniper@yahoo.com', 'August 25, 1987', 'Chess, Computers'),
(2, 'lover45', 'aya', 'aa', 'aaa', 'asss', 'ass', 'female', 'huntress', 'aa', 'july 25, 2000', 'chess'),
(3, 'marnie29', 'stan1010', 'Marnie', 'Gomez', 'Ylanana', 'montebello, kananga, leyte', 'female', 'teacher', 'Maa@gmail.com', 'April 29, 1995', 'Drawing');

-- --------------------------------------------------------

--
-- Table structure for table `table_fanlogtrail`
--

CREATE TABLE `table_fanlogtrail` (
  `logtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(50) NOT NULL,
  `dateandtime` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_fanlogtrail`
--

INSERT INTO `table_fanlogtrail` (`logtrailid`, `userid`, `logtype`, `dateandtime`) VALUES
(17, 1, 'login', 'Thu 2018.02.22 at 03:45:00 PM CST'),
(18, 1, 'logout', 'Thu 2018.02.22 at 03:45:02 PM CST'),
(19, 1, 'login', 'Thu 2018.02.22 at 03:54:25 PM CST'),
(20, 1, 'logout', 'Thu 2018.02.22 at 03:54:27 PM CST'),
(21, 1, 'login', 'Thu 2018.02.22 at 04:01:47 PM CST'),
(22, 1, 'logout', 'Thu 2018.02.22 at 04:01:48 PM CST');

-- --------------------------------------------------------

--
-- Table structure for table `table_idolinformation`
--

CREATE TABLE `table_idolinformation` (
  `FNAME` varchar(50) NOT NULL,
  `MNAME` varchar(50) NOT NULL,
  `LNAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(300) NOT NULL,
  `SEX` varchar(50) NOT NULL,
  `JOB_TITLE` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `HOBBY` varchar(300) NOT NULL,
  `idolinformationid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_idolinformation`
--

INSERT INTO `table_idolinformation` (`FNAME`, `MNAME`, `LNAME`, `ADDRESS`, `SEX`, `JOB_TITLE`, `EMAIL`, `DOB`, `HOBBY`, `idolinformationid`) VALUES
('august', 'rosito', 'tabucanon', 'San Pablo, Ormoc City', 'male', 'Hunter', 'a@gmail.com', 'august 25, 1987', 'chess', 1),
('aya', 'chance', 'okamoto', 'iwaki, fukushima, japan', 'female', 'actress, voice actress', 'yes@yahoo.com', 'july 15, 1985', 'acting', 2),
('elmer', 'laude', 'pemio', 'san isidro, ormoc city', 'male', 'hunter', 'hunter45@gmail.com', 'December 1, 1998', 'Chess', 3);

-- --------------------------------------------------------

--
-- Table structure for table `table_idoloverallrating`
--

CREATE TABLE `table_idoloverallrating` (
  `IDOLOVERALLRATINGID` int(11) NOT NULL,
  `IDOLINFORMATIONID` int(11) NOT NULL,
  `RATING` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_idoloverallrating`
--

INSERT INTO `table_idoloverallrating` (`IDOLOVERALLRATINGID`, `IDOLINFORMATIONID`, `RATING`) VALUES
(1, 2, 5.3),
(2, 2, 5),
(3, 1, 6),
(4, 1, 6.3),
(5, 3, 8.7),
(6, 3, 7.5),
(7, 1, 6.5),
(8, 1, 9.5);

-- --------------------------------------------------------

--
-- Table structure for table `table_idolsheet`
--

CREATE TABLE `table_idolsheet` (
  `IDOLSHEETID` int(11) NOT NULL,
  `QUESTION` varchar(300) NOT NULL,
  `SCORE` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_idolsheet`
--

INSERT INTO `table_idolsheet` (`IDOLSHEETID`, `QUESTION`, `SCORE`) VALUES
(1, 'a', 6),
(2, 'aa', 5),
(3, 'aaa', 7),
(4, 'aaaa', 5),
(5, 'aaaaa', 5),
(6, 'aaaaaa', 5),
(7, 'aaaaaaa', 5),
(8, 'aaaaaaaa', 5),
(9, 'aaaaaaaaa', 5),
(10, 'aaaaaaaaaa', 5);

-- --------------------------------------------------------

--
-- Table structure for table `table_users`
--

CREATE TABLE `table_users` (
  `USERID` int(11) NOT NULL,
  `USERNAME` varchar(50) NOT NULL,
  `USERPASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_users`
--

INSERT INTO `table_users` (`USERID`, `USERNAME`, `USERPASSWORD`) VALUES
(1, 'august', 'aya'),
(2, 'albert', 'reyes45'),
(3, 'elmer', 'ople');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_adminlogtrail`
--
ALTER TABLE `table_adminlogtrail`
  ADD PRIMARY KEY (`logtrailid`);

--
-- Indexes for table `table_faninformation`
--
ALTER TABLE `table_faninformation`
  ADD PRIMARY KEY (`FANINFORMATIONID`);

--
-- Indexes for table `table_fanlogtrail`
--
ALTER TABLE `table_fanlogtrail`
  ADD PRIMARY KEY (`logtrailid`);

--
-- Indexes for table `table_idolinformation`
--
ALTER TABLE `table_idolinformation`
  ADD PRIMARY KEY (`idolinformationid`);

--
-- Indexes for table `table_idoloverallrating`
--
ALTER TABLE `table_idoloverallrating`
  ADD PRIMARY KEY (`IDOLOVERALLRATINGID`);

--
-- Indexes for table `table_idolsheet`
--
ALTER TABLE `table_idolsheet`
  ADD PRIMARY KEY (`IDOLSHEETID`);

--
-- Indexes for table `table_users`
--
ALTER TABLE `table_users`
  ADD PRIMARY KEY (`USERID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `table_adminlogtrail`
--
ALTER TABLE `table_adminlogtrail`
  MODIFY `logtrailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `table_faninformation`
--
ALTER TABLE `table_faninformation`
  MODIFY `FANINFORMATIONID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `table_fanlogtrail`
--
ALTER TABLE `table_fanlogtrail`
  MODIFY `logtrailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `table_idolinformation`
--
ALTER TABLE `table_idolinformation`
  MODIFY `idolinformationid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `table_idoloverallrating`
--
ALTER TABLE `table_idoloverallrating`
  MODIFY `IDOLOVERALLRATINGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `table_idolsheet`
--
ALTER TABLE `table_idolsheet`
  MODIFY `IDOLSHEETID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `table_users`
--
ALTER TABLE `table_users`
  MODIFY `USERID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
