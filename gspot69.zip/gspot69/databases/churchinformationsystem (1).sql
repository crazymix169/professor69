-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 09:10 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `churchinformationsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activities`
--

CREATE TABLE `tbl_activities` (
  `activitiesid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `activitytype` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_announcement`
--

CREATE TABLE `tbl_announcement` (
  `announcementid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `announcement` varchar(10000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_applicationform`
--

CREATE TABLE `tbl_applicationform` (
  `applicationformid` int(11) NOT NULL,
  `servicesid` int(11) NOT NULL,
  `firstname` varchar(1000) NOT NULL,
  `middlename` varchar(1000) NOT NULL,
  `lastname` varchar(1000) NOT NULL,
  `birthdate` varchar(1000) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `birthplace` varchar(1000) NOT NULL,
  `citizenship` varchar(1000) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `hobby` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_applicationform`
--

INSERT INTO `tbl_applicationform` (`applicationformid`, `servicesid`, `firstname`, `middlename`, `lastname`, `birthdate`, `sex`, `birthplace`, `citizenship`, `address`, `hobby`) VALUES
(1, 1, 'yahagi', 'a', 'Honoka', 'a', 'female', 'a', 'a', 'Chiba, Japan', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_church`
--

CREATE TABLE `tbl_church` (
  `churchid` int(11) NOT NULL,
  `churchname` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_church`
--

INSERT INTO `tbl_church` (`churchid`, `churchname`, `description`, `date`) VALUES
(1, 'sts peter and paul parish', 'nice', 'sss'),
(2, 'fatima', 'nice', 'sss');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_information`
--

CREATE TABLE `tbl_information` (
  `informationid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_priest`
--

CREATE TABLE `tbl_priest` (
  `priestid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `priestfristname` varchar(1000) NOT NULL,
  `priestMI` varchar(10) NOT NULL,
  `priestlastname` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_records`
--

CREATE TABLE `tbl_records` (
  `recordsid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_requirements`
--

CREATE TABLE `tbl_requirements` (
  `requirementsid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `serviceid` int(11) NOT NULL,
  `requirement` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE `tbl_schedule` (
  `scheduleid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `priestid` int(11) NOT NULL,
  `starttime` varchar(1000) NOT NULL,
  `endtime` varchar(1000) NOT NULL,
  `scheduletype` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services`
--

CREATE TABLE `tbl_services` (
  `serviceid` int(11) NOT NULL,
  `churchid` int(11) NOT NULL,
  `servicetype` varchar(1000) NOT NULL,
  `description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_services`
--

INSERT INTO `tbl_services` (`serviceid`, `churchid`, `servicetype`, `description`) VALUES
(1, 1, 'baptism', 'nice'),
(2, 2, 'matrimony', 'nice');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `userpassword` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(1, 'august', 'aya'),
(2, 'crazymix69', 'cindy');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userslogtrail`
--

CREATE TABLE `tbl_userslogtrail` (
  `logtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(1000) NOT NULL,
  `date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activities`
--
ALTER TABLE `tbl_activities`
  ADD PRIMARY KEY (`activitiesid`);

--
-- Indexes for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  ADD PRIMARY KEY (`announcementid`);

--
-- Indexes for table `tbl_applicationform`
--
ALTER TABLE `tbl_applicationform`
  ADD PRIMARY KEY (`applicationformid`);

--
-- Indexes for table `tbl_church`
--
ALTER TABLE `tbl_church`
  ADD PRIMARY KEY (`churchid`);

--
-- Indexes for table `tbl_information`
--
ALTER TABLE `tbl_information`
  ADD PRIMARY KEY (`informationid`);

--
-- Indexes for table `tbl_priest`
--
ALTER TABLE `tbl_priest`
  ADD PRIMARY KEY (`priestid`);

--
-- Indexes for table `tbl_records`
--
ALTER TABLE `tbl_records`
  ADD PRIMARY KEY (`recordsid`);

--
-- Indexes for table `tbl_requirements`
--
ALTER TABLE `tbl_requirements`
  ADD PRIMARY KEY (`requirementsid`);

--
-- Indexes for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD PRIMARY KEY (`scheduleid`);

--
-- Indexes for table `tbl_services`
--
ALTER TABLE `tbl_services`
  ADD PRIMARY KEY (`serviceid`),
  ADD UNIQUE KEY `serviceid` (`serviceid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  ADD PRIMARY KEY (`logtrailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activities`
--
ALTER TABLE `tbl_activities`
  MODIFY `activitiesid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  MODIFY `announcementid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_applicationform`
--
ALTER TABLE `tbl_applicationform`
  MODIFY `applicationformid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_church`
--
ALTER TABLE `tbl_church`
  MODIFY `churchid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_information`
--
ALTER TABLE `tbl_information`
  MODIFY `informationid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_priest`
--
ALTER TABLE `tbl_priest`
  MODIFY `priestid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_records`
--
ALTER TABLE `tbl_records`
  MODIFY `recordsid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_requirements`
--
ALTER TABLE `tbl_requirements`
  MODIFY `requirementsid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_services`
--
ALTER TABLE `tbl_services`
  MODIFY `serviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  MODIFY `logtrailid` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
