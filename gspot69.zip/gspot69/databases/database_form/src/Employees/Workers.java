/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employees;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

import java.lang.NullPointerException;
import java.lang.NumberFormatException;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

/**
 *
 * @author crazymix69
 */
public class Workers extends javax.swing.JFrame {

    /**
     * Creates new form Workers
     */
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    int curRow = 0,viewall=0;
    String query;
    
    
    public Workers() {
        initComponents();
        DoConnect();
        getConnection();
        Show_Users_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            
            String host=    "jdbc:derby://localhost:1527/Employees";
            String uName= "user1";
            String uPass= "august";
        
            con = DriverManager.getConnection( host, uName, uPass );
            
            stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
          
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);
            
            
        }
        catch ( SQLException | NumberFormatException | NullPointerException err) {
        //System.out.println( err.getMessage( ) );
            
            JOptionPane.showMessageDialog(Workers.this,"Error: "+err.getMessage());
            
        }    
    }
    
    public Connection getConnection()
    {
        try
        {
        
            String host=    "jdbc:derby://localhost:1527/Employees";
            String uName= "user1";
            String uPass= "august";

            con = DriverManager.getConnection( host, uName, uPass );
            
            stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<User> getUsersList()
    {
        ArrayList<User> usersList= new ArrayList<User>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from Workers";
            }
            else
            {
                String fname=textSearchFirstName.getText();
                query = "Select * from Workers where FIRST_NAME like '%"+fname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            
            
            
            stmt= connection.createStatement();
            rs=stmt.executeQuery(query);
            
           
            
            User user;
            
            while(rs.next())
            {
                user = new  User(rs.getInt("ID"),rs.getString("FIRST_NAME"),rs.getString("LAST_NAME"), rs.getString("JOB_TITLE") );
                usersList.add(user);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return usersList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<User> list = getUsersList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[4];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getId();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getLastName();
            row[3]=list.get(i).getJobTitle();
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        textFirstName = new javax.swing.JTextField();
        textID = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        textJobTitle = new javax.swing.JTextField();
        textLastName = new javax.swing.JTextField();
        btnNext = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnUpdateRecord = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textSearchFirstName = new javax.swing.JTextField();
        btnSearchbyFirstName = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Workers Maintenance");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));
        jPanel1.setLayout(null);
        jPanel1.add(textFirstName);
        textFirstName.setBounds(150, 110, 300, 30);
        jPanel1.add(textID);
        textID.setBounds(150, 30, 300, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Last Name");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(40, 150, 89, 30);
        jPanel1.add(textJobTitle);
        textJobTitle.setBounds(150, 190, 300, 30);
        jPanel1.add(textLastName);
        textLastName.setBounds(150, 150, 300, 30);

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        jPanel1.add(btnNext);
        btnNext.setBounds(250, 240, 100, 30);

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });
        jPanel1.add(btnPrevious);
        btnPrevious.setBounds(140, 240, 85, 30);

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });
        jPanel1.add(btnFirst);
        btnFirst.setBounds(40, 240, 90, 30);

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });
        jPanel1.add(btnLast);
        btnLast.setBounds(360, 240, 90, 30);

        btnUpdateRecord.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnUpdateRecord.setText("Update Record");
        btnUpdateRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateRecordActionPerformed(evt);
            }
        });
        jPanel1.add(btnUpdateRecord);
        btnUpdateRecord.setBounds(40, 280, 140, 30);

        btnDelete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnDelete.setText("Delete Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete);
        btnDelete.setBounds(200, 280, 120, 30);

        btnNewRecord.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });
        jPanel1.add(btnNewRecord);
        btnNewRecord.setBounds(330, 280, 120, 30);

        btnSaveRecord.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });
        jPanel1.add(btnSaveRecord);
        btnSaveRecord.setBounds(70, 330, 150, 30);

        btnCancelNewRecord.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancelNewRecord);
        btnCancelNewRecord.setBounds(250, 330, 170, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Job Title");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 190, 89, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Search by First Name");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 70, 130, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("First Name");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(40, 110, 89, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("ID");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(40, 30, 89, 30);
        jPanel1.add(textSearchFirstName);
        textSearchFirstName.setBounds(150, 70, 300, 30);

        btnSearchbyFirstName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnSearchbyFirstName.setText("Search by First Name");
        btnSearchbyFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchbyFirstNameActionPerformed(evt);
            }
        });
        jPanel1.add(btnSearchbyFirstName);
        btnSearchbyFirstName.setBounds(460, 70, 160, 30);

        btnViewAll.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnViewAll.setText("View All");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });
        jPanel1.add(btnViewAll);
        btnViewAll.setBounds(460, 30, 160, 30);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "First Name", "Last Name", "Job Title"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 658, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                //rs.next();

                int id_col = rs.getInt("ID");
                String id = Integer.toString(id_col);
                String first = rs.getString("First_Name");
                String last = rs.getString("Last_Name");
                String job = rs.getString("Job_Title");

                textID.setText(id);
                textFirstName.setText(first);
                textLastName.setText(last);
                textJobTitle.setText(job);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(Workers.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int id_col = rs.getInt("ID");
                String id = Integer.toString(id_col);
                String first = rs.getString("First_Name");
                String last = rs.getString("Last_Name");
                String job = rs.getString("Job_Title");

                textID.setText(id);
                textFirstName.setText(first);
                textLastName.setText(last);
                textJobTitle.setText(job);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(Workers.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try {
            rs.first();

            int id_col = rs.getInt("ID");
            String id = Integer.toString(id_col);
            String first = rs.getString("First_Name");
            String last = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            textID.setText(id);
            textFirstName.setText(first);
            textLastName.setText(last);
            textJobTitle.setText(job);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col = rs.getInt("ID");
            String id = Integer.toString(id_col);
            String first = rs.getString("First_Name");
            String last = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            textID.setText(id);
            textFirstName.setText(first);
            textLastName.setText(last);
            textJobTitle.setText(job);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(Workers.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnUpdateRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateRecordActionPerformed
        // TODO add your handling code here:
        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Modify This Recordset?","Modify",JOptionPane.YES_NO_OPTION);
        
        if(p==0)
        {
            try
            {
                String first = textFirstName.getText( );
                String last = textLastName.getText( );
                String job = textJobTitle.getText( );
                String ID = textID.getText( );
                int id=Integer.parseInt(ID);
                /*
                int newID = Integer.parseInt( ID );
                rs.updateInt( "ID", newID );
                rs.updateString( "First_Name", first );
                rs.updateString( "last_Name", last );
                rs.updateString( "Job_Title", job );
                rs.updateRow( );*/

                // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
                // correct way to search an integer or double: String query = "Select * from Workers where ID= "+i+"";

                //String sql="Update Workers"
                //      + " SET  ID="+id+", FIRST_NAME='"+first+"', LAST_NAME='"+last+"', JOB_TITLE='"+job+"'"
                //        + " where ID="+id+"";

                stmt=con.createStatement();
                String sql="Update Workers"
                        + " SET  ID="+id+",FIRST_NAME='"+first+"', LAST_NAME='"+last+"', JOB_TITLE='"+job+"'"
                        + " where ID="+id+"";

                stmt.executeUpdate(sql);



                JOptionPane.showMessageDialog(Workers.this,ID+ " is Updated");

            }
            catch (SQLException | NumberFormatException | NullPointerException err)
            {
                JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
            }
            Show_Users_In_JTable();
        }
        else
        {
            JOptionPane.showMessageDialog(Workers.this,"No record is Updated");
        }
    }//GEN-LAST:event_btnUpdateRecordActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
        
        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Recordset?","Delete",JOptionPane.YES_NO_OPTION);
        
        if(p==0)
        {
            try
            {

                /*
                rs.deleteRow();

                stmt.close( );
                rs.close( );*/

                String first = textFirstName.getText( );
                String last = textLastName.getText( );
                String job = textJobTitle.getText( );
                String ID = textID.getText( );
                int id=Integer.parseInt(ID);

                stmt=con.createStatement();
                String sql="DELETE FROM  Workers"
                        + " where ID="+id+"";

                stmt.executeUpdate(sql);

                stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                sql = "SELECT * FROM Workers";
                rs = stmt.executeQuery(sql);

                rs.next( );
                int id_col = rs.getInt("ID");
                String id2 = Integer.toString(id_col);
                String first2 = rs.getString("First_Name");
                String last2 = rs.getString("Last_Name");
                String job2 = rs.getString("Job_Title");

                textID.setText(id2);
                textFirstName.setText(first);
                textLastName.setText(last);
                textJobTitle.setText(job);

                JOptionPane.showMessageDialog(Workers.this,id+ " is Deleted");
                

            }
            catch (SQLException err)
            {
                JOptionPane.showMessageDialog(Workers.this," Error: "+ err.getMessage());
                System.out.println(err.getMessage() );
            }
            Show_Users_In_JTable();
        }
        else
        {
            JOptionPane.showMessageDialog(Workers.this,"Nothing is Deleted");
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:
        
        try
        {
            curRow = rs.getRow( );
            textFirstName.setText("");
            textLastName.setText("");
            textJobTitle.setText("");
            textID.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnUpdateRecord.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {
            
            JOptionPane.showMessageDialog(Workers.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        // TODO add your handling code here:

        
        try
        {
            
            String first=textFirstName.getText();
            String last=textLastName.getText();
            String job=textJobTitle.getText();
            String ID=textID.getText();
            int newID=Integer.parseInt(ID);


            // create a Statement from the connection
            //Statement statement = conn.createStatement();

            // insert the data
            //statement.executeUpdate("INSERT INTO Customers " + "VALUES (1001, 'Simpson', 'Mr.', 'Springfield', 2001)");

            //String sql="Select * from Workers ";
            //rs = stmt.executeQuery(sql);

            //rs.next();
            /*
            rs.moveToInsertRow( );

            rs.updateInt("ID", newID);
            rs.updateString("First_Name", first);
            rs.updateString("Last_Name", last);
            rs.updateString("Job_Title", job);

            rs.insertRow( );

            stmt.close( );
            rs.close( );

            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            String sql = "SELECT * FROM Workers";*/

            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            //stmt=con.createStatement();
            String sql ="INSERT INTO Workers " + "VALUES ("+newID+", '"+first+"', '"+last+"', '"+job+"')";

            stmt.executeUpdate(sql);
            
            JOptionPane.showMessageDialog(Workers.this,"The Record Number: '"+ ID +"' is Added!!!");

            //rs = stmt.executeQuery(sql);

            sql = "SELECT * FROM Workers";
            rs = stmt.executeQuery(sql);

            rs.next( );
            int id_col = rs.getInt("ID");
            String id = Integer.toString(id_col);
            String first2 = rs.getString("First_Name");
            String last2 = rs.getString("Last_Name");
            String job2 = rs.getString("Job_Title");

            textID.setText(id);
            textFirstName.setText(first2);
            textLastName.setText(last2);
            textJobTitle.setText(job2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnUpdateRecord.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
            
            
            
            Show_Users_In_JTable();

            //stmt.close( );
            //rs.close( );

        }
        catch (SQLException | NumberFormatException | NullPointerException err)
        {
            JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        try {
            rs.absolute( curRow );
            textFirstName.setText( rs.getString("First_Name") );
            textLastName.setText( rs.getString("Last_Name") );
            textJobTitle.setText( rs.getString("Job_Title") );
            textID.setText( Integer.toString( rs.getInt("ID" )) );

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnUpdateRecord.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(Workers.this,"Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed
    
    
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textID.setText(model.getValueAt(i, 0).toString());
        textFirstName.setText(model.getValueAt(i, 1).toString());
        textLastName.setText(model.getValueAt(i, 2).toString());
        textJobTitle.setText(model.getValueAt(i, 3).toString());

    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
        
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textID.setText(model.getValueAt(i, 0).toString());
            textFirstName.setText(model.getValueAt(i, 1).toString());
            textLastName.setText(model.getValueAt(i, 2).toString());
            textJobTitle.setText(model.getValueAt(i, 3).toString());
        }
        
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
        
        
        
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnSearchbyFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchbyFirstNameActionPerformed
            // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSearchbyFirstNameActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
        
    }//GEN-LAST:event_btnViewAllActionPerformed
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Workers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Workers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Workers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Workers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Workers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchbyFirstName;
    private javax.swing.JButton btnUpdateRecord;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textID;
    private javax.swing.JTextField textJobTitle;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textSearchFirstName;
    // End of variables declaration//GEN-END:variables

    
}
