/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employees;

/**
 *
 * @author crazymix69
 */
public class User {
    
    private int id;
    private String firstname;
    private String lastname;
    private String jobtitle;
    
    public User(int ID, String FirstName, String LastName, String JobTitle)
    {
        this.id=ID;
        this.firstname=FirstName;
        this.lastname=LastName;
        this.jobtitle=JobTitle;
    }
    
    public int getId()
    {
        return id;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    
    public String getLastName()
    {
        return lastname;
    }
    
    public String getJobTitle()
    {
        return jobtitle;
    }
    
}
