-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2020 at 04:46 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `legalmonitoringsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_case`
--

CREATE TABLE `tbl_case` (
  `caseid` int(11) NOT NULL,
  `casetitle` text NOT NULL,
  `casedescription` longtext NOT NULL,
  `startdate` text NOT NULL,
  `enddate` text NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_case`
--

INSERT INTO `tbl_case` (`caseid`, `casetitle`, `casedescription`, `startdate`, `enddate`, `comments`) VALUES
(1, 'spice', 'fdsasf', 'may 15, 2020', 'july 27, 2020', 'nice'),
(2, 'spied2', 'fas', 'f', 'fas', 'fsda'),
(3, 'fsda', 'fsda', 'fa', 'sad', 'fas'),
(4, 'faster', 'ddd2', 'dfd', 'df', 'fas'),
(5, 'quick', 'fdsa', 'fas', 'fas', 'fsa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_caseperson`
--

CREATE TABLE `tbl_caseperson` (
  `casepersonid` int(11) NOT NULL,
  `caseid` int(11) NOT NULL,
  `legalpersonid` int(11) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_caseperson`
--

INSERT INTO `tbl_caseperson` (`casepersonid`, `caseid`, `legalpersonid`, `remarks`) VALUES
(1, 1, 1, 'spicy'),
(2, 1, 2, 'fdsa'),
(3, 2, 1, 'fas'),
(4, 2, 3, 'spicy'),
(5, 1, 4, 'fas'),
(6, 1, 5, 'spicy');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_caseproceedings`
--

CREATE TABLE `tbl_caseproceedings` (
  `caseproceedingsid` int(11) NOT NULL,
  `caseid` int(11) NOT NULL,
  `courtid` int(11) NOT NULL,
  `description` text NOT NULL,
  `currentcasestatus` text NOT NULL,
  `date` text NOT NULL,
  `payment` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_caseproceedings`
--

INSERT INTO `tbl_caseproceedings` (`caseproceedingsid`, `caseid`, `courtid`, `description`, `currentcasestatus`, `date`, `payment`) VALUES
(2, 1, 1, 'fas', 'fdf', 'a', 56),
(3, 1, 1, 'dfa', 'fas', 'fa', 35),
(4, 1, 1, 'fdsa', 'fa', 'fsa', 6000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_court`
--

CREATE TABLE `tbl_court` (
  `courtid` int(11) NOT NULL,
  `courtname` text NOT NULL,
  `courtaddress` text NOT NULL,
  `courtdescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_court`
--

INSERT INTO `tbl_court` (`courtid`, `courtname`, `courtaddress`, `courtdescription`) VALUES
(1, 'fas', 'fas', 'fas'),
(2, 'de', 'fa', 'fas'),
(3, 'dfa', 'fda', 'fa'),
(4, 't', 'd', 'd'),
(5, 'd', 'dd', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_legalperson`
--

CREATE TABLE `tbl_legalperson` (
  `legalpersonid` int(11) NOT NULL,
  `legalpersontype` text NOT NULL,
  `suffix` text NOT NULL,
  `role` text NOT NULL,
  `comment` text NOT NULL,
  `firstname` text NOT NULL,
  `middlename` text NOT NULL,
  `lastname` text NOT NULL,
  `sex` text NOT NULL,
  `birthdate` text NOT NULL,
  `address` text NOT NULL,
  `hobby` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_legalperson`
--

INSERT INTO `tbl_legalperson` (`legalpersonid`, `legalpersontype`, `suffix`, `role`, `comment`, `firstname`, `middlename`, `lastname`, `sex`, `birthdate`, `address`, `hobby`) VALUES
(1, 'corporation', 'jr', 'fdsa', 'fas', 'fsa', 'fsa', 'fasf', 'male', 'afas', 'fasd', 'fas'),
(2, 'fsad', 'fas', 'dsfa', 'fa', 'fa', 'fdsa', 'fdas', 'fa', 'fas', 'fa', 'fa'),
(4, 'fsdaf', 'fsda', 'fasd', 'fsa', 'fsa', 'fasdf', 'fsa', 'dsfa', 'aff', 'fasd', 'fa'),
(5, 'fdsa', 'fdas', 'fdsa', 'fdsa', 's', 'fda', 'fa', 'fa', 'a', 'a', 'fa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` text NOT NULL,
  `userpassword` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(1, 'a', 'a'),
(3, 'd', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_userslogtrail`
--

CREATE TABLE `tbl_userslogtrail` (
  `userslogtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` text NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_userslogtrail`
--

INSERT INTO `tbl_userslogtrail` (`userslogtrailid`, `userid`, `logtype`, `date`, `time`) VALUES
(1, 1, 'login', '2020-12-22', '22:20:12'),
(2, 1, 'login', '2020-12-22', '22:20:23'),
(3, 1, 'login', '2020-12-22', '22:20:34'),
(4, 1, 'login', '2020-12-22', '22:23:34'),
(5, 1, 'logout', '2020-12-22', '22:23:50'),
(6, 1, 'login', '2020-12-22', '22:23:53'),
(7, 1, 'logout', '2020-12-22', '22:23:59'),
(8, 1, 'login', '2020-12-22', '23:09:25'),
(9, 1, 'logout', '2020-12-22', '23:10:01'),
(10, 1, 'login', '2020-12-22', '23:10:48'),
(11, 1, 'login', '2020-12-22', '23:11:08'),
(12, 1, 'logout', '2020-12-22', '23:11:38'),
(13, 1, 'logout', '2020-12-22', '23:11:50'),
(14, 1, 'login', '2020-12-22', '23:13:39'),
(15, 1, 'logout', '2020-12-22', '23:13:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_case`
--
ALTER TABLE `tbl_case`
  ADD PRIMARY KEY (`caseid`) USING BTREE;

--
-- Indexes for table `tbl_caseperson`
--
ALTER TABLE `tbl_caseperson`
  ADD PRIMARY KEY (`casepersonid`);

--
-- Indexes for table `tbl_caseproceedings`
--
ALTER TABLE `tbl_caseproceedings`
  ADD PRIMARY KEY (`caseproceedingsid`);

--
-- Indexes for table `tbl_court`
--
ALTER TABLE `tbl_court`
  ADD PRIMARY KEY (`courtid`);

--
-- Indexes for table `tbl_legalperson`
--
ALTER TABLE `tbl_legalperson`
  ADD PRIMARY KEY (`legalpersonid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  ADD PRIMARY KEY (`userslogtrailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_case`
--
ALTER TABLE `tbl_case`
  MODIFY `caseid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_caseperson`
--
ALTER TABLE `tbl_caseperson`
  MODIFY `casepersonid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_caseproceedings`
--
ALTER TABLE `tbl_caseproceedings`
  MODIFY `caseproceedingsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_court`
--
ALTER TABLE `tbl_court`
  MODIFY `courtid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_legalperson`
--
ALTER TABLE `tbl_legalperson`
  MODIFY `legalpersonid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_userslogtrail`
--
ALTER TABLE `tbl_userslogtrail`
  MODIFY `userslogtrailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
