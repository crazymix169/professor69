-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2020 at 09:11 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cristalsalesandinventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_goods`
--

CREATE TABLE `tbl_goods` (
  `goodsid` int(11) NOT NULL,
  `goodsname` varchar(1000) NOT NULL,
  `goodsdescription` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_goods`
--

INSERT INTO `tbl_goods` (`goodsid`, `goodsname`, `goodsdescription`) VALUES
(2, 'tuna', 'spicy and sexy'),
(3, 'corned beef2', 'spicy and sexy'),
(4, 'tunafd', 'spicy and sexy');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logtrail`
--

CREATE TABLE `tbl_logtrail` (
  `logtrailID` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(100) NOT NULL,
  `date` varchar(1000) NOT NULL,
  `time` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sales`
--

CREATE TABLE `tbl_sales` (
  `salesid` int(11) NOT NULL,
  `stocksid` int(11) NOT NULL,
  `amountpaid` double NOT NULL,
  `date` varchar(1000) NOT NULL,
  `time` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sales`
--

INSERT INTO `tbl_sales` (`salesid`, `stocksid`, `amountpaid`, `date`, `time`) VALUES
(1, 10, 200, ' 2019.12.06 ', ' 2019.12.06 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stocks`
--

CREATE TABLE `tbl_stocks` (
  `stocksID` int(11) NOT NULL,
  `goodsid` int(11) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `totalcost` double NOT NULL,
  `totalamountpaid` int(11) NOT NULL,
  `remainingamount` int(11) NOT NULL,
  `change1` int(11) NOT NULL,
  `salesstatus` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_stocks`
--

INSERT INTO `tbl_stocks` (`stocksID`, `goodsid`, `price`, `quantity`, `totalcost`, `totalamountpaid`, `remainingamount`, `change1`, `salesstatus`, `date`, `time`) VALUES
(1, 1, 65, 4, 260, 400, -140, 140, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(2, 1, 33, 7, 231, 200, 31, -31, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(3, 1, 45, 2, 90, 100, -10, 10, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(4, 2, 25, 3, 75, 69, 6, -6, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(5, 4, 45, 4, 180, 0, 180, 0, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(6, 2, 45, 2, 90, 0, 90, 0, 'unsold', ' 2019.12.04 ', ' 2019.12.04 '),
(7, 2, 45, 3, 135, 0, 135, 0, 'unsold', ' 2019.12.06 ', ' 2019.12.06 '),
(8, 2, 45, 3, 135, 0, 135, 0, 'unsold', ' 2019.12.06 ', ' 2019.12.06 '),
(9, 3, 67, 6, 402, 0, 402, 0, 'unsold', ' 2019.12.06 ', ' 2019.12.06 '),
(10, 3, 34, 2, 68, 200, 132, -132, 'sold', ' 2019.12.06 ', ' 2019.12.06 '),
(11, 2, 32, 7, 224, 0, 224, 0, 'unsold', ' 2019.12.06 ', ' 11:12:32 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stocktrail`
--

CREATE TABLE `tbl_stocktrail` (
  `stocktrailid` int(11) NOT NULL,
  `stocksid` int(11) NOT NULL,
  `stocktype` varchar(100) NOT NULL,
  `date` varchar(1000) NOT NULL,
  `time` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_stocktrail`
--

INSERT INTO `tbl_stocktrail` (`stocktrailid`, `stocksid`, `stocktype`, `date`, `time`) VALUES
(1, 10, 'stockin', ' 2019.12.06 ', '11:11'),
(2, 11, 'stockin', ' 2019.12.06 ', ' 11:12:32 '),
(3, 10, 'stockout', ' 2019.12.06 ', ' 2019.12.06 ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `userpassword` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(1, 'august', 'kako'),
(2, 'august', 'kanayui'),
(5, 'dd', 'sas'),
(7, 'dfadd', 'dfa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_goods`
--
ALTER TABLE `tbl_goods`
  ADD PRIMARY KEY (`goodsid`);

--
-- Indexes for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  ADD PRIMARY KEY (`logtrailID`);

--
-- Indexes for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  ADD PRIMARY KEY (`salesid`);

--
-- Indexes for table `tbl_stocks`
--
ALTER TABLE `tbl_stocks`
  ADD PRIMARY KEY (`stocksID`);

--
-- Indexes for table `tbl_stocktrail`
--
ALTER TABLE `tbl_stocktrail`
  ADD PRIMARY KEY (`stocktrailid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_goods`
--
ALTER TABLE `tbl_goods`
  MODIFY `goodsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  MODIFY `logtrailID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sales`
--
ALTER TABLE `tbl_sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_stocks`
--
ALTER TABLE `tbl_stocks`
  MODIFY `stocksID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_stocktrail`
--
ALTER TABLE `tbl_stocktrail`
  MODIFY `stocktrailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
