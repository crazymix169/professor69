public class euclidsalgorithm
{
	public static void main(String args[])
	{		
		
		int a=214, b=36,rem=0;
		
		while((a%b)!=0)
		{
			
			rem=a%b;
			System.out.println(a+" = "+(a/b)+"*"+b+"+"+rem);
			
			
			a=b;
			b=rem;
			
		}
		System.out.println(a+" = "+(a/b)+"*"+b+"+"+a%b);		
		
		
	}
	
	static int gcd(int x, int y)
	{
		int r;
		while((x%y)>0)
		{
			
			r=x%y;		
			
			
			x=y;
			y=r;
			
		}
		return y;
		
	}
	
}