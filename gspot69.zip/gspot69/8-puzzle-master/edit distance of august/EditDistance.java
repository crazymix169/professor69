
import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

public class EditDistance extends JFrame
   implements ActionListener
{
	private JTextField outputField,firstnum,secondnum,thirdnum;
	   //private JTextField in[]=new JTextField[20];

	   private JButton resetButton,clear1Button,clear2Button,clear3Button,clearallButton;
	   private JButton save1Button,save2Button,exitButton;
	   //private JButton sumButton,diffButton,productButton,quotientButton,squareButton;



	   private JButton zeroButton,oneButton,twoButton,threeButton,fourButton;
	   private JButton fiveButton,sixButton,sevenButton,eightButton,nineButton;

	   private JLabel v[]=new JLabel[4];
	   
	   private JTextField edist[][]=new JTextField[21][21];


	   private double num;
	   int yyyy=26;

	    DecimalFormat p33 = new DecimalFormat( "0.0000" );

	double num1,num2,num3,output1;

	public EditDistance()
	{
		JFrame frame=new JFrame("Edit Distance of Two Given Strings!!!");
		      //super( "Computing the values of different bases from base 2 to 36" --> 0-9 and A to Z
			  frame.setLayout(null);

				frame.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});


				frame.setSize(1210,810);

				Font f = new Font("JSL Ancient", Font.ITALIC, 12);
				Font fbi = new Font("JSL Ancient", Font.BOLD | Font.ITALIC,  12);
				Font fp = new Font("JSL Ancient", Font.PLAIN,  12);
		  		Font fb = new Font("JSL Ancient", Font.BOLD ,  16);

				//frame.getContentPane();


		      // get content pane and set its layout
		      //Container container = getContentPane();
		      //container.setLayout( null );

		      v[0] =  new JLabel( "Enter 2 Strings with a maximum length of 20 characters", SwingConstants.LEFT);
			  v[0].setFont(fb);
			  v[0].setForeground(Color.BLACK);
			  v[0].setBounds(1,1,500,40);
			  frame.getContentPane().add( v[0]);



			  outputField = new JTextField();
			  outputField.setFont(fb);
			  outputField.setBounds(202,1,400,40);
		      frame.getContentPane().add( outputField );
			  outputField.setVisible(false);

		      resetButton=new JButton("Clear Principal");
		      resetButton.setBackground(Color.MAGENTA);
			  resetButton.setBounds(602,1,200,40);
			  frame.getContentPane().add(resetButton);
			  resetButton.setVisible(false);

			  resetButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  output1=0;


							outputField.setText("");


					  }
				}
			  );



			  //namer2.addActionListener(this);
			  //namer2.addKeyListener(aug);

			  v[1] =  new JLabel( "Enter First String: ", SwingConstants.LEFT);
			  v[1].setFont(fb);
			  v[1].setForeground(Color.BLACK);
			  v[1].setBounds(1,41,200,40);
			  frame.getContentPane().add( v[1]);


			  firstnum = new JTextField();
			  firstnum.setFont(fb);
			  firstnum.setBounds(202,41,400,40);
		      frame.getContentPane().add( firstnum );

		      save1Button=new JButton("Trim Strings!");
		      save1Button.setBackground(Color.YELLOW);
			  save1Button.setBounds(802,41,200,40);
			  frame.getContentPane().add(save1Button);

			  save1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  try
						  {
							  
							  String base=firstnum.getText().trim();
							  String height=secondnum.getText().trim();
							  firstnum.setText(base);
							  secondnum.setText(height);


					  	  }
					  	  catch(Exception e)
					  	  {
								JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
						  }


					  }
				}
			  );

			  clear1Button=new JButton("Clear first string");
			  clear1Button.setBackground(Color.CYAN);
			  clear1Button.setBounds(602,41,200,40);
			  frame.getContentPane().add(clear1Button);

			  clear1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  num1=0;
						  firstnum.setText("");

					  }
				}
			  );

			  v[2] =  new JLabel( "Enter Second String: ", SwingConstants.LEFT);
			  v[2].setFont(fb);
			  v[2].setForeground(Color.BLACK);
			  v[2].setBounds(1,81,200,40);
			  frame.getContentPane().add( v[2]);


			  secondnum = new JTextField();
			  secondnum.setFont(fb);
			  secondnum.setBounds(202,81,400,40);
		      frame.getContentPane().add( secondnum );

		      save2Button=new JButton("Find the Edit Distance!");
		      save2Button.setBackground(Color.CYAN);
			  save2Button.setBounds(802,81,200,40);
			  frame.getContentPane().add(save2Button);

			  save2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  try
						  {
							 
							String str1 = "sunday"; 
							String str2 = "saturday";
							String base=firstnum.getText().trim();
							String height=secondnum.getText().trim();
							
							if(base.length()>20||height.length()>20)
							{
								JOptionPane.showMessageDialog(null,"One of the Stringlengths is greater than 20! ","Invalid Length!",JOptionPane.INFORMATION_MESSAGE);
								return;
								
							}
							//System.out.println(editDistDP(base, height, base.length(), height.length())); 

							thirdnum.setText(Integer.toString(editDistDP(base, height, base.length(), height.length())));  


						  }
						  catch(Exception e)
						  {
								JOptionPane.showMessageDialog(null,e.getMessage(),"Error: ",JOptionPane.INFORMATION_MESSAGE);
						  }

					  }
				}
			  );

			  clear2Button=new JButton("Clear second string");
			  clear2Button.setBackground(Color.YELLOW);
			  clear2Button.setBounds(602,81,200,40);
			  frame.getContentPane().add(clear2Button);

			  clear2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num2=0;
   						 secondnum.setText("");

					  }
				}
			  );

			  v[3] =  new JLabel( "The Edit distance is: ", SwingConstants.LEFT);
			  v[3].setFont(fb);
			  v[3].setForeground(Color.BLACK);
			  v[3].setBounds(1,121,200,40);
			  frame.getContentPane().add( v[3]);


			  thirdnum = new JTextField();
			  thirdnum.setFont(fb);
			  thirdnum.setBounds(202,121,400,40);
		      frame.getContentPane().add( thirdnum );
			  
			  int xx=0,yy=0,ii=0,jj=0;
			  
			  xx=80;
			  yy=180;
			  
			  for(ii=0;ii<=20;ii++)
			  {
				  yy=180;
				  for(jj=0;jj<=20;jj++)
				  {
					  edist[ii][jj] =  new JTextField("", SwingConstants.LEFT);
					  edist[ii][jj].setFont(fb);
					  edist[ii][jj].setForeground(Color.BLACK);
					  edist[ii][jj].setBackground(Color.CYAN);
					  edist[ii][jj].setBounds(xx,yy,20,20);
					  frame.getContentPane().add( edist[ii][jj]);
					  yy+=25;
				  }
				  xx+=25;
				  
			  }

		      clear3Button=new JButton("Clear Answer");
			  clear3Button.setBackground(Color.CYAN);
			  clear3Button.setBounds(602,121,200,40);
			  frame.getContentPane().add(clear3Button);

			  clear3Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num3=0;
						 thirdnum.setText("");
						 // Fill d[][] in bottom up manner 
						for (int i = 0; i <= 20; i++)
						{ 
							for (int j = 0; j <= 20; j++)
							{ 
								
								edist[i][j].setText("");						
							} 
						}

					  }
				}
			  );



		  	  clearallButton=new JButton("Clear all");
		  	  clearallButton.setBackground(Color.MAGENTA);
			  	  clearallButton.setBounds(670,360,305,20);
			  	  frame.getContentPane().add(clearallButton);

			  	  clearallButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {
			  				  //clearer();
			  				 num1=0;
			  				 num2=0;
			  				 num3=0;
			  				 output1=0;


			  				 outputField.setText("");
			  				 firstnum.setText("");
			  				 secondnum.setText("");
			  				 thirdnum.setText("");
							 
							 // Fill d[][] in bottom up manner 
							for (int i = 0; i <= 20; i++)
							{ 
								for (int j = 0; j <= 20; j++)
								{ 
									
									edist[i][j].setText("");						
								} 
							}

			  			  }
			  		 }
		  		);



			  exitButton=new JButton("Quit Application");
			  exitButton.setBackground(Color.GREEN);
			  exitButton.setBounds(670,385,305,20);
			  frame.getContentPane().add(exitButton);

			  exitButton.addActionListener(

			  	new ActionListener()
			  	{
			  		  public void actionPerformed(ActionEvent event)
			  		  {
						  System.gc();
						  System.exit(0);
			  		  }
			  	}
			  );

				/*
			  squareButton=new JButton("square of the sum");
			  squareButton.setBackground(Color.YELLOW);
			  squareButton.setBounds(1,185,150,20);
			  frame.getContentPane().add(squareButton);
			  squareButton.addActionListener(this);*/

			  //computeButton.addActionListener(this);


			  firstnum.setEditable(!false);
			  secondnum.setEditable(!false);
			  outputField.setEditable(!false);

		      //setSize( 900, 750 );
		      frame.setVisible( true );
      		frame.setResizable(false);

	}
	
	int min(int x, int y, int z) 
    { 
        if (x <= y && x <= z) 
            return x; 
        if (y <= x && y <= z) 
            return y; 
        else
            return z; 
    } 
  
    int editDistDP(String str1, String str2, int m, int n) 
    { 
        /*
		xx=80;
			  yy=180;
			  
			  for(ii=0;ii<=20;ii++)
			  {
				  yy=180;
				  for(jj=0;jj<=20;jj++)
				  {
					  edist[ii][jj] =  new JTextField("", SwingConstants.LEFT);
					  edist[ii][jj].setFont(fb);
					  edist[ii][jj].setForeground(Color.BLACK);
					  edist[ii][jj].setBackground(Color.CYAN);
					  edist[ii][jj].setBounds(xx,yy,20,20);
					  frame.getContentPane().add( edist[ii][jj]);
					  yy+=25;
				  }
				  xx+=25;
				  
			  }
		*/
		// Create a table to store results of subproblems 
        int dp[][] = new int[m + 1][n + 1]; 
  
        // Fill d[][] in bottom up manner 
        for (int i = 0; i <= m; i++) { 
            for (int j = 0; j <= n; j++) { 
                // If first string is empty, only option is to 
                // insert all characters of second string 
                if (i == 0) 
                    dp[i][j] = j; // Min. operations = j 
  
                // If second string is empty, only option is to 
                // remove all characters of second string 
                else if (j == 0) 
                    dp[i][j] = i; // Min. operations = i 
  
                // If last characters are same, ignore last char 
                // and recur for remaining string 
                else if (str1.charAt(i - 1) == str2.charAt(j - 1)) 
                    dp[i][j] = dp[i - 1][j - 1]; 
  
                // If the last character is different, consider all 
                // possibilities and find the minimum 
                else
                    dp[i][j] = 1 + min(dp[i][j - 1], // Insert 
                                       dp[i - 1][j], // Remove 
                                       dp[i - 1][j - 1]); // Replace
				edist[i][j].setText(Integer.toString(dp[i][j]));						
            } 
        } 
  
        return dp[m][n]; 
    }

	public void actionPerformed( ActionEvent event )
	   {


	   }



	// execute application
	   public static void main( String args[] )
	   {
	      EditDistance application = new EditDistance();

	      application.setDefaultCloseOperation(
	         JFrame.EXIT_ON_CLOSE );
   }

}