
import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

public class InterestRateCalculator extends JFrame
   implements ActionListener
{
	private JTextField outputField,firstnum,secondnum,thirdnum;
	   //private JTextField in[]=new JTextField[20];

	   private JButton resetButton,clear1Button,clear2Button,clear3Button,clearallButton;
	   private JButton save1Button,save2Button,exitButton;
	   //private JButton sumButton,diffButton,productButton,quotientButton,squareButton;



	   private JButton zeroButton,oneButton,twoButton,threeButton,fourButton;
	   private JButton fiveButton,sixButton,sevenButton,eightButton,nineButton;

	   private JLabel v[]=new JLabel[4];


	   private double num;
	   int yyyy=26;

	    DecimalFormat p33 = new DecimalFormat( "0.0000" );

	double num1,num2,num3,output1;

	public InterestRateCalculator()
	{
		JFrame frame=new JFrame("Monthly Interest Rate Calculator");
		      //super( "Computing the values of different bases from base 2 to 36" --> 0-9 and A to Z
			  frame.setLayout(null);

				frame.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});


				frame.setSize(1010,510);

				Font f = new Font("JSL Ancient", Font.ITALIC, 12);
				Font fbi = new Font("JSL Ancient", Font.BOLD | Font.ITALIC,  12);
				Font fp = new Font("JSL Ancient", Font.PLAIN,  12);
		  		Font fb = new Font("JSL Ancient", Font.BOLD ,  16);

				//frame.getContentPane();


		      // get content pane and set its layout
		      //Container container = getContentPane();
		      //container.setLayout( null );

		      v[0] =  new JLabel( "Enter Principal Amount", SwingConstants.LEFT);
			  v[0].setFont(fb);
			  v[0].setForeground(Color.BLACK);
			  v[0].setBounds(1,1,200,40);
			  frame.getContentPane().add( v[0]);



			  outputField = new JTextField();
			  outputField.setFont(fb);
			  outputField.setBounds(202,1,400,40);
		      frame.getContentPane().add( outputField );

		      resetButton=new JButton("Clear Principal");
		      resetButton.setBackground(Color.MAGENTA);
			  resetButton.setBounds(602,1,200,40);
			  frame.getContentPane().add(resetButton);

			  resetButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  output1=0;


							outputField.setText("");


					  }
				}
			  );



			  //namer2.addActionListener(this);
			  //namer2.addKeyListener(aug);

			  v[1] =  new JLabel( "Enter Interest Rate(%) ", SwingConstants.LEFT);
			  v[1].setFont(fb);
			  v[1].setForeground(Color.BLACK);
			  v[1].setBounds(1,41,200,40);
			  frame.getContentPane().add( v[1]);


			  firstnum = new JTextField();
			  firstnum.setFont(fb);
			  firstnum.setBounds(202,41,400,40);
		      frame.getContentPane().add( firstnum );

		      save1Button=new JButton("Convert to Percentage");
		      save1Button.setBackground(Color.YELLOW);
			  save1Button.setBounds(802,41,200,40);
			  frame.getContentPane().add(save1Button);

			  save1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  try
						  {
							  String res21="";
							  String base=firstnum.getText();
							  double x=Double.parseDouble(base);

							  //String nm2=secondnum.getText();
							  //String nm2=secondnum.getText();
							  res21=p33.format(x/100);
							  JOptionPane.showMessageDialog(null,"The Decimal Equivalent is: "+res21," Interest rate percentage to Decimal",JOptionPane.INFORMATION_MESSAGE);


					  	  }
					  	  catch(Exception e)
					  	  {
								JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
						  }


					  }
				}
			  );

			  clear1Button=new JButton("Clear first number");
			  clear1Button.setBackground(Color.CYAN);
			  clear1Button.setBounds(602,41,200,40);
			  frame.getContentPane().add(clear1Button);

			  clear1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  num1=0;
						  firstnum.setText("");

					  }
				}
			  );

			  v[2] =  new JLabel( "Number of Months(1-100) ", SwingConstants.LEFT);
			  v[2].setFont(fb);
			  v[2].setForeground(Color.BLACK);
			  v[2].setBounds(1,81,200,40);
			  frame.getContentPane().add( v[2]);


			  secondnum = new JTextField();
			  secondnum.setFont(fb);
			  secondnum.setBounds(202,81,400,40);
		      frame.getContentPane().add( secondnum );

		      save2Button=new JButton("Find the End Balance");
		      save2Button.setBackground(Color.CYAN);
			  save2Button.setBounds(802,81,200,40);
			  frame.getContentPane().add(save2Button);

			  save2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  try
						  {
							  String res21="";
							  String base=firstnum.getText();
							  double x=Double.parseDouble(base);
							  int months1=Integer.parseInt(secondnum.getText());
							  double e;
							  if(months1<1)
							  {
								JOptionPane.showMessageDialog(null,"The months should be between 1-100 "," Finding the End Amount",JOptionPane.INFORMATION_MESSAGE);
							  }
							  else
							  {
								x=x/100;
								x=x+1;
								e=Double.parseDouble(outputField.getText());
								double v=Math.pow(x,months1)*e;

								thirdnum.setText(Double.toString(v));

							  }


							  //String nm2=secondnum.getText();
							  //String nm2=secondnum.getText();
							  //res21=p33.format(x/100);
							  //JOptionPane.showMessageDialog(null,"The Decimal Equivalent is: "+res21," Interest rate percentage to Decimal",JOptionPane.INFORMATION_MESSAGE);


						  }
						  catch(Exception e)
						  {
								JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
						  }

					  }
				}
			  );

			  clear2Button=new JButton("Clear second number");
			  clear2Button.setBackground(Color.YELLOW);
			  clear2Button.setBounds(602,81,200,40);
			  frame.getContentPane().add(clear2Button);

			  clear2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num2=0;
   						 secondnum.setText("");

					  }
				}
			  );

			  v[3] =  new JLabel( "End Balance ", SwingConstants.LEFT);
			  v[3].setFont(fb);
			  v[3].setForeground(Color.BLACK);
			  v[3].setBounds(1,121,200,40);
			  frame.getContentPane().add( v[3]);


			  thirdnum = new JTextField();
			  thirdnum.setFont(fb);
			  thirdnum.setBounds(202,121,400,40);
		      frame.getContentPane().add( thirdnum );

		      clear3Button=new JButton("Clear third number");
			  clear3Button.setBackground(Color.CYAN);
			  clear3Button.setBounds(602,121,200,40);
			  frame.getContentPane().add(clear3Button);

			  clear3Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num3=0;
						 thirdnum.setText("");

					  }
				}
			  );



		  	  clearallButton=new JButton("Clear all");
		  	  clearallButton.setBackground(Color.MAGENTA);
			  	  clearallButton.setBounds(325,360,305,20);
			  	  frame.getContentPane().add(clearallButton);

			  	  clearallButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {
			  				  //clearer();
			  				 num1=0;
			  				 num2=0;
			  				 num3=0;
			  				 output1=0;


			  				 outputField.setText("");
			  				 firstnum.setText("");
			  				 secondnum.setText("");
			  				 thirdnum.setText("");

			  			  }
			  		 }
		  		);



			  exitButton=new JButton("Quit Application");
			  exitButton.setBackground(Color.GREEN);
			  exitButton.setBounds(170,385,460,20);
			  frame.getContentPane().add(exitButton);

			  exitButton.addActionListener(

			  	new ActionListener()
			  	{
			  		  public void actionPerformed(ActionEvent event)
			  		  {
						  System.gc();
						  System.exit(0);
			  		  }
			  	}
			  );

				/*
			  squareButton=new JButton("square of the sum");
			  squareButton.setBackground(Color.YELLOW);
			  squareButton.setBounds(1,185,150,20);
			  frame.getContentPane().add(squareButton);
			  squareButton.addActionListener(this);*/

			  //computeButton.addActionListener(this);


			  firstnum.setEditable(!false);
			  secondnum.setEditable(!false);
			  outputField.setEditable(!false);

		      //setSize( 900, 750 );
		      frame.setVisible( true );
      		frame.setResizable(false);

	}

	public void actionPerformed( ActionEvent event )
	   {


	   }



	// execute application
	   public static void main( String args[] )
	   {
	      InterestRateCalculator application = new InterestRateCalculator();

	      application.setDefaultCloseOperation(
	         JFrame.EXIT_ON_CLOSE );
   }

}