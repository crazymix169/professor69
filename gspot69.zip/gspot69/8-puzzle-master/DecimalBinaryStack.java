import java.util.*;
class DecimalBinaryStack
{
  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);

    // Create Stack object
    Stack<Integer> stack = new Stack<Integer>();

    // User input
    System.out.println("Enter decimal number: ");
    int num = in.nextInt();
	int num3=num;
	int baseT=9;

    while (num != 0)
    {

      int d = num % baseT;

      	stack.push(d);

      num /= baseT;
    }

    System.out.print("\nBase "+baseT+" representation is:");

    while (!(stack.isEmpty() ))
    {
      System.out.print(stack.pop());
    }
    System.out.println();

	System.out.println("\nThe desired base is: "+36+" and the number is: "+DecToChosenRadix(num3,36));

	Scanner in2 = new Scanner(System.in);
	String num2 = in2.nextLine();

	System.out.println("The inputted string is: " +num2);
	System.out.println("reverse: "+reverseString(num2));

	//System.out.println("Decimal of " +num2+ " is: "+getDecimal2(num2));

	System.out.println("The validity of " +num2+ " as input is: "+isValidInput(num2,16));

  }

  public static String reverseString(String str)
  {
      char ch[]=str.toCharArray();
      String rev="";
      for(int i=ch.length-1;i>=0;i--){
          rev+=ch[i];
      }
      return rev;
  }

  public static int getDecimal(String hex)
  {
  	   String digits = "0123456789ABCDEF";
	   hex = hex.toUpperCase();
	   int val = 0;
	   for (int i = 0; i < hex.length(); i++)
	   {
		   char c = hex.charAt(i);
		   int d = digits.indexOf(c);
		   val = 16*val + d;
	   }
	   return val;
	}

	public static long getDecimal2(String hex36, int base)
	{
		   String digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		   hex36 = hex36.toUpperCase();
		   long val = 0;
		   for (int i = 0; i < hex36.length(); i++)
		   {
			   char c = hex36.charAt(i);
			   long d = digits.indexOf(c);
			   val = base*val + d;
		   }
		   return val;
	}

	private static boolean isValidInput(String number, int base)
	{
	    	String digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			String ValidDigits="";
	    	number=number.toUpperCase();

	    	for (int i = 0; i <base; i++)
	    	{
				ValidDigits=ValidDigits+digits.charAt(i);
			}


			boolean valid=true;
			int i,j;
			for(i=0;i<ValidDigits.length();i++)
			{
				for(j=0;j<number.length();j++)
				{
					if((ValidDigits.charAt(i)<number.charAt(j))&&base<i+2)
					{
						valid=false;
						break;
					}
				}
			}

			return valid;

	}

	public static String DecToChosenRadix(int decimal, int radix)
	{
	     int rem;
	     String hex="";
	     char hexchars[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	    while(decimal>0)
	     {
	       rem=decimal%radix;
	       hex=hexchars[rem]+hex;
	       decimal=decimal/radix;
	     }
	    return hex;
	}
}