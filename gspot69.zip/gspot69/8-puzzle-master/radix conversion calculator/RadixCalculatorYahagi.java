
import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

public class RadixCalculatorYahagi extends JFrame
   implements ActionListener
{
	private JTextField outputField,firstnum,secondnum;
	   //private JTextField in[]=new JTextField[20];

	   private JButton resetButton,clear1Button,clear2Button,clearallButton;
	   private JButton save1Button,save2Button,exitButton;
	   //private JButton sumButton,diffButton,productButton,quotientButton,squareButton;

	   private JButton qButton,wButton,eButton,rButton,tButton,yButton,uButton,iButton,oButton,pButton,backspaceButton;
	   private JButton aButton,sButton,dButton,fButton,gButton,hButton,jButton,kButton,lButton;
	   private JButton zButton,xButton,cButton,vButton,bButton,nButton,mButton;

	   private JButton zeroButton,oneButton,twoButton,threeButton,fourButton;
	   private JButton fiveButton,sixButton,sevenButton,eightButton,nineButton;

	   private JLabel v[]=new JLabel[3];


	   private double num;
	   int yyyy=26;

	    DecimalFormat p33 = new DecimalFormat( "0" );

	double num1,num2,output1;

	public RadixCalculatorYahagi()
	{
		JFrame frame=new JFrame("Radix Conversion Calculator");
		      //super( "Computing the values of different bases from base 2 to 36" --> 0-9 and A to Z
			  frame.setLayout(null);

				frame.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});


				frame.setSize(1010,510);

				Font f = new Font("JSL Ancient", Font.ITALIC, 12);
				Font fbi = new Font("JSL Ancient", Font.BOLD | Font.ITALIC,  12);
				Font fp = new Font("JSL Ancient", Font.PLAIN,  12);
		  		Font fb = new Font("JSL Ancient", Font.BOLD ,  16);

				//frame.getContentPane();


		      // get content pane and set its layout
		      //Container container = getContentPane();
		      //container.setLayout( null );

		      v[0] =  new JLabel( "Input Base (2 to 36)", SwingConstants.LEFT);
			  v[0].setFont(fb);
			  v[0].setForeground(Color.BLACK);
			  v[0].setBounds(1,1,200,40);
			  frame.getContentPane().add( v[0]);



			  outputField = new JTextField();
			  outputField.setFont(fb);
			  outputField.setBounds(202,1,400,40);
		      frame.getContentPane().add( outputField );

		      resetButton=new JButton("Clear Radix");
		      resetButton.setBackground(Color.MAGENTA);
			  resetButton.setBounds(602,1,200,40);
			  frame.getContentPane().add(resetButton);

			  resetButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  output1=0;


							outputField.setText("");


					  }
				}
			  );



			  //namer2.addActionListener(this);
			  //namer2.addKeyListener(aug);

			  v[1] =  new JLabel( "First The Desired Number ", SwingConstants.LEFT);
			  v[1].setFont(fb);
			  v[1].setForeground(Color.BLACK);
			  v[1].setBounds(1,41,200,40);
			  frame.getContentPane().add( v[1]);


			  firstnum = new JTextField();
			  firstnum.setFont(fb);
			  firstnum.setBounds(202,41,400,40);
		      frame.getContentPane().add( firstnum );

		      save1Button=new JButton("Convert to Decimal");
		      save1Button.setBackground(Color.YELLOW);
			  save1Button.setBounds(802,41,200,40);
			  frame.getContentPane().add(save1Button);

			  save1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  try
						  {
							  String res21="";
							  String base=outputField.getText();
							  int x=Integer.parseInt(base);
							  if(x<2||x>36)
							  {
								JOptionPane.showMessageDialog(null,"Invalid Radix Value","Error",JOptionPane.INFORMATION_MESSAGE);
							  }
							  else
							  {

								  String nm1=firstnum.getText();

								  if(isValidInput(nm1, x))
								  {
									  //String nm2=secondnum.getText();
									  //String nm2=secondnum.getText();
									  res21=p33.format(getDecimal2(nm1,Integer.parseInt(base)));
									  JOptionPane.showMessageDialog(null,"The Decimal Equivalent is: "+res21,"Any Radix Number(2 to 36) to Decimal",JOptionPane.INFORMATION_MESSAGE);
									  secondnum.setText(res21);

								  	  firstnum.setText(nm1.toUpperCase());
							  	  }
							  	  else
							  	  {
									 JOptionPane.showMessageDialog(null,"Invalid Input Number Value","Error",JOptionPane.INFORMATION_MESSAGE);
								  }
						      }
					  	  }
					  	  catch(Exception e)
					  	  {
								JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
						  }


					  }
				}
			  );

			  clear1Button=new JButton("Clear first number");
			  clear1Button.setBackground(Color.CYAN);
			  clear1Button.setBounds(602,41,200,40);
			  frame.getContentPane().add(clear1Button);

			  clear1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  num1=0;
						  firstnum.setText("");

					  }
				}
			  );

			  v[2] =  new JLabel( "Decimal Equivalent ", SwingConstants.LEFT);
			  v[2].setFont(fb);
			  v[2].setForeground(Color.BLACK);
			  v[2].setBounds(1,81,200,40);
			  frame.getContentPane().add( v[2]);


			  secondnum = new JTextField();
			  secondnum.setFont(fb);
			  secondnum.setBounds(202,81,400,40);
		      frame.getContentPane().add( secondnum );

		      save2Button=new JButton("Convert to Desired Base");
		      save2Button.setBackground(Color.CYAN);
			  save2Button.setBounds(802,81,200,40);
			  frame.getContentPane().add(save2Button);

			  save2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  try
						  {
							  String res21="";
							  String base=outputField.getText();
							  int x=Integer.parseInt(base);
							  if(x<2||x>36)
							  {
								JOptionPane.showMessageDialog(null,"Invalid Radix Value","Error",JOptionPane.INFORMATION_MESSAGE);
							  }
							  else
							  {
								  //String nm1=firstnum.getText();
								  String nm2=secondnum.getText();

								  if(isValidInput(nm2, x))
								  {

									  res21=DecToChosenRadix(Long.parseLong(nm2), Integer.parseInt(base));

									  JOptionPane.showMessageDialog(null,"The Base "+x+" Equivalent is: "+res21,"Decimal to Any Radix Number(2 to 36)",JOptionPane.INFORMATION_MESSAGE);
									  firstnum.setText(res21);
							  	  }
							  	  else
								  {
									 JOptionPane.showMessageDialog(null,"Invalid Input Number Value","Error",JOptionPane.INFORMATION_MESSAGE);
								  }
						  	  }
						  }
						  catch(Exception e)
						  {
							  JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
						  }

					  }
				}
			  );

			  clear2Button=new JButton("Clear second number");
			  clear2Button.setBackground(Color.YELLOW);
			  clear2Button.setBounds(602,81,200,40);
			  frame.getContentPane().add(clear2Button);

			  clear2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num2=0;
   						 secondnum.setText("");

					  }
				}
			  );

			  //Letters
			  //Top Letters
			  qButton=new JButton("Q");
			  qButton.setBackground(Color.CYAN);
			  qButton.setBounds(170,161,50,40);
			  frame.getContentPane().add(qButton);

			  qButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="Q";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  wButton=new JButton("W");
			  wButton.setBackground(Color.CYAN);
			  wButton.setBounds(220,161,50,40);
			  frame.getContentPane().add(wButton);

			  qButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="W";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  eButton=new JButton("E");
			  eButton.setBackground(Color.CYAN);
			  eButton.setBounds(270,161,50,40);
			  frame.getContentPane().add(eButton);

			  eButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="E";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  rButton=new JButton("R");
			  rButton.setBackground(Color.CYAN);
			  rButton.setBounds(320,161,50,40);
			  frame.getContentPane().add(rButton);

			  rButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="R";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  tButton=new JButton("T");
			  tButton.setBackground(Color.CYAN);
			  tButton.setBounds(370,161,50,40);
			  frame.getContentPane().add(tButton);

			  tButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="T";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  yButton=new JButton("Y");
			  yButton.setBackground(Color.CYAN);
			  yButton.setBounds(420,161,50,40);
			  frame.getContentPane().add(yButton);

			  yButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="Y";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  uButton=new JButton("U");
			  uButton.setBackground(Color.CYAN);
			  uButton.setBounds(470,161,50,40);
			  frame.getContentPane().add(uButton);

			  uButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="U";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  iButton=new JButton("I");
			  iButton.setBackground(Color.CYAN);
			  iButton.setBounds(520,161,50,40);
			  frame.getContentPane().add(iButton);

			  iButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="I";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  oButton=new JButton("O");
			  oButton.setBackground(Color.CYAN);
			  oButton.setBounds(570,161,50,40);
			  frame.getContentPane().add(oButton);

			  oButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="O";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  pButton=new JButton("P");
			  pButton.setBackground(Color.CYAN);
			  pButton.setBounds(620,161,50,40);
			  frame.getContentPane().add(pButton);

			  pButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="P";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  backspaceButton=new JButton("BackSpace");
			  backspaceButton.setBackground(Color.CYAN);
			  backspaceButton.setBounds(670,161,200,40);
			  frame.getContentPane().add(backspaceButton);

			  backspaceButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  /*
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="Q";
						  firstnum.setText(namer21);*/

						  String news = null;

						  if (firstnum.getText().length() > 0)
						  { 	//TextArea is a textfield

							  StringBuilder strB = new StringBuilder(firstnum.getText());

							  int strlen = strB.length();

							  strB.deleteCharAt(strlen-1);

							  news = strB.toString();

							  firstnum.setText(news);/////set the updated text
						  }

					  }
				}
			  );


				//middle letters
			  aButton=new JButton("A");
			  aButton.setBackground(Color.YELLOW);
			  aButton.setBounds(170,201,50,40);
			  frame.getContentPane().add(aButton);

			  aButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="A";
						  firstnum.setText(namer21);

					  }
				 }
				);

			sButton=new JButton("S");
			  sButton.setBackground(Color.YELLOW);
			  sButton.setBounds(220,201,50,40);
			  frame.getContentPane().add(sButton);

			  sButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="S";
						  firstnum.setText(namer21);

					  }
				 }
				);

				dButton=new JButton("D");
			  dButton.setBackground(Color.YELLOW);
			  dButton.setBounds(270,201,50,40);
			  frame.getContentPane().add(dButton);

			  dButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="D";
						  firstnum.setText(namer21);

					  }
				 }
				);

			fButton=new JButton("F");
			  fButton.setBackground(Color.YELLOW);
			  fButton.setBounds(320,201,50,40);
			  frame.getContentPane().add(fButton);

			  fButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="F";
						  firstnum.setText(namer21);

					  }
				 }
				);

			gButton=new JButton("G");
			  gButton.setBackground(Color.YELLOW);
			  gButton.setBounds(370,201,50,40);
			  frame.getContentPane().add(gButton);

			  gButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="G";
						  firstnum.setText(namer21);

					  }
				 }
				);

			hButton=new JButton("H");
			  hButton.setBackground(Color.YELLOW);
			  hButton.setBounds(420,201,50,40);
			  frame.getContentPane().add(hButton);

			  hButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="H";
						  firstnum.setText(namer21);

					  }
				 }
				);

			jButton=new JButton("J");
			  jButton.setBackground(Color.YELLOW);
			  jButton.setBounds(470,201,50,40);
			  frame.getContentPane().add(jButton);

			  jButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="J";
						  firstnum.setText(namer21);

					  }
				 }
				);

			kButton=new JButton("K");
			  kButton.setBackground(Color.YELLOW);
			  kButton.setBounds(520,201,50,40);
			  frame.getContentPane().add(kButton);

			  kButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="K";
						  firstnum.setText(namer21);

					  }
				 }
				);

			lButton=new JButton("L");
			  lButton.setBackground(Color.YELLOW);
			  lButton.setBounds(570,201,50,40);
			  frame.getContentPane().add(lButton);

			  lButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="L";
						  firstnum.setText(namer21);

					  }
				 }
				);




			 //bottom letters
			 zButton=new JButton("Z");
			 zButton.setBackground(Color.CYAN);
			  zButton.setBounds(170,241,50,40);
			  frame.getContentPane().add(zButton);

			  zButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="Z";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			 xButton=new JButton("X");
			 xButton.setBackground(Color.CYAN);
			  xButton.setBounds(220,241,50,40);
			  frame.getContentPane().add(xButton);

			  xButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="X";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			cButton=new JButton("C");
			 cButton.setBackground(Color.CYAN);
			  cButton.setBounds(270,241,50,40);
			  frame.getContentPane().add(cButton);

			  cButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="C";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			vButton=new JButton("V");
			 vButton.setBackground(Color.CYAN);
			  vButton.setBounds(320,241,50,40);
			  frame.getContentPane().add(vButton);

			  vButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="V";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			bButton=new JButton("B");
			 bButton.setBackground(Color.CYAN);
			  bButton.setBounds(370,241,50,40);
			  frame.getContentPane().add(bButton);

			  bButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="B";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			nButton=new JButton("N");
			 nButton.setBackground(Color.CYAN);
			  nButton.setBounds(420,241,50,40);
			  frame.getContentPane().add(nButton);

			  nButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="N";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			mButton=new JButton("M");
			 mButton.setBackground(Color.CYAN);
			  mButton.setBounds(470,241,50,40);
			  frame.getContentPane().add(mButton);

			  mButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=firstnum.getText();
						 namer21+="M";
						  firstnum.setText(namer21);

					  }
				 }
		  		);



			  //digits
			  sevenButton=new JButton("7");
			  sevenButton.setBackground(Color.CYAN);
			  sevenButton.setBounds(170,285,150,20);
			  frame.getContentPane().add(sevenButton);

			  sevenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="7";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  fourButton=new JButton("4");
			  fourButton.setBackground(Color.YELLOW);
			  fourButton.setBounds(170,310,150,20);
			  frame.getContentPane().add(fourButton);

			  fourButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="4";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			 oneButton=new JButton("1");
			 oneButton.setBackground(Color.CYAN);
			  oneButton.setBounds(170,335,150,20);
			  frame.getContentPane().add(oneButton);

			  oneButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
					   	 namer21=firstnum.getText();
					     namer21+="1";
						  firstnum.setText(namer21);

					  }
				 }
		  		);
		  	  zeroButton=new JButton("0");
		  	  zeroButton.setBackground(Color.YELLOW);
			  	  zeroButton.setBounds(170,360,150,20);
			  	  frame.getContentPane().add(zeroButton);

			  	  zeroButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {
			  				  String namer21="";
							  namer21=firstnum.getText();
							  namer21+="0";
						      firstnum.setText(namer21);

			  			  }
			  		 }
		  		);

			  eightButton=new JButton("8");
			  eightButton.setBackground(Color.YELLOW);
			  eightButton.setBounds(325,285,150,20);
			  frame.getContentPane().add(eightButton);

			  eightButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="8";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  fiveButton=new JButton("5");
			  fiveButton.setBackground(Color.CYAN);
			  fiveButton.setBounds(325,310,150,20);
			  frame.getContentPane().add(fiveButton);

			  fiveButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="5";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			 twoButton=new JButton("2");
			 twoButton.setBackground(Color.YELLOW);
			  twoButton.setBounds(325,335,150,20);
			  frame.getContentPane().add(twoButton);

			  twoButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="2";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

		  	  clearallButton=new JButton("Clear all");
		  	  clearallButton.setBackground(Color.MAGENTA);
			  	  clearallButton.setBounds(325,360,305,20);
			  	  frame.getContentPane().add(clearallButton);

			  	  clearallButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {
			  				  //clearer();
			  				 num1=0;
			  				 num2=0;
			  				 output1=0;


			  				 outputField.setText("");
			  				 firstnum.setText("");
			  				 secondnum.setText("");

			  			  }
			  		 }
		  		);

			  nineButton=new JButton("9");
			  nineButton.setBackground(Color.CYAN);
			  nineButton.setBounds(480,285,150,20);
			  frame.getContentPane().add(nineButton);

			  nineButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="9";
						  firstnum.setText(namer21);

					  }
				}
			  );

			  sixButton=new JButton("6");
			  sixButton.setBackground(Color.YELLOW);
			  sixButton.setBounds(480,310,150,20);
			  frame.getContentPane().add(sixButton);

			  sixButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=firstnum.getText();
						  namer21+="6";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			  threeButton=new JButton("3");
			  threeButton.setBackground(Color.CYAN);
			  threeButton.setBounds(480,335,150,20);
			  frame.getContentPane().add(threeButton);

			  threeButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=firstnum.getText();
						  namer21+="3";
						  firstnum.setText(namer21);

					  }
				 }
		  		);

			  exitButton=new JButton("Quit Application");
			  exitButton.setBackground(Color.GREEN);
			  exitButton.setBounds(170,385,460,20);
			  frame.getContentPane().add(exitButton);

			  exitButton.addActionListener(

			  	new ActionListener()
			  	{
			  		  public void actionPerformed(ActionEvent event)
			  		  {
						  System.gc();
						  System.exit(0);
			  		  }
			  	}
			  );

				/*
			  squareButton=new JButton("square of the sum");
			  squareButton.setBackground(Color.YELLOW);
			  squareButton.setBounds(1,185,150,20);
			  frame.getContentPane().add(squareButton);
			  squareButton.addActionListener(this);*/

			  //computeButton.addActionListener(this);


			  firstnum.setEditable(!false);
			  secondnum.setEditable(!false);
			  outputField.setEditable(!false);

		      //setSize( 900, 750 );
		      frame.setVisible( true );
      		frame.setResizable(false);

	}

	public void actionPerformed( ActionEvent event )
	   {


	   }

	   public long getDecimal2(String hex36, int base)
	   	{
	   		   String digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	   		   hex36 = hex36.toUpperCase();
	   		   long val = 0;
	   		   for (int i = 0; i < hex36.length(); i++)
	   		   {
	   			   char c = hex36.charAt(i);
	   			   long d = digits.indexOf(c);
	   			   val = base*val + d;
	   		   }
	   		   return val;
	   	}

	   	private boolean isValidInput(String number, int base)
	   	{
	   	    	String digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	   			String ValidDigits="";
	   	    	number=number.toUpperCase();

	   	    	for (int i = 0; i <base; i++)
	   	    	{
	   				ValidDigits=ValidDigits+digits.charAt(i);
	   			}


	   			boolean valid=true;
	   			int i,j;
	   			for(i=0;i<ValidDigits.length();i++)
	   			{
	   				for(j=0;j<number.length();j++)
	   				{
	   					if((ValidDigits.charAt(i)<number.charAt(j))&&base<i+2)
	   					{
	   						valid=false;
	   						break;
	   					}
	   				}
	   			}

	   			return valid;

		}

		public static String DecToChosenRadix(long decimal, int radix)
		{
			 long rem;
			 String hex="";
			 char hexchars[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
			while(decimal>0)
			 {
			   rem=decimal%radix;
			   hex=hexchars[(int)rem]+hex;
			   decimal=decimal/radix;
			 }
			return hex;
		}

		public boolean isNumeric(String str) {
				return str != null && str.matches("[-+]?\\d*\\.?\\d+");
		}

	   public double sum1(double uno, double dos)
	   {
			return uno+dos;
	   }
	   public double diff1(double uno, double dos)
	   {
	   		return uno-dos;
	   }
	   public double prod1(double uno, double dos)
	   {
	   		return uno*dos;
	   }
	   public double square1(double uno)
	   {
			return uno*uno;
   	}

	// execute application
	   public static void main( String args[] )
	   {
	      RadixCalculatorYahagi application = new RadixCalculatorYahagi();

	      application.setDefaultCloseOperation(
	         JFrame.EXIT_ON_CLOSE );
   }

}