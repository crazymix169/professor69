import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.io.*;
public class group2 extends JFrame{

	BufferedReader read;

	//primary panel
	private JToggleButton recursive, iterative;
	public JButton gcd, factorial, ackermann, multi;
	private ButtonGroup how, problem;
	private TextField answer;
	private TextArea method;
	private JLabel fxn, ans, bck;
	private JPanel cont, container;
	int selected;

	//pop-up
	private JButton ok, cancel;
	private TextField one, two;
	private JLabel label0, label1, label2, label3;
	private JPanel panel2;

	//answer
	double answers;
	int X, Y;

	public group2(double answers, int number, int select){
		super ("Group 2");

		container = (JPanel)this.getContentPane();
		cont = new JPanel();
		panel2 = new JPanel();

		panel2.setLayout(null);
		cont.setVisible(true);
		cont.setLayout(null);
		panel2.setVisible(false);

		addComponent(container, cont, 0, 0, 700, 450);
		addComponent(container, panel2, 0, 0, 700, 450);

		//recursive or iterative
		recursive=new JToggleButton("RECURSIVE"); recursive.setOpaque(false);
		iterative=new JToggleButton("ITERATIVE"); iterative.setOpaque(false);
		how = new ButtonGroup();
		how.add(recursive);
		how.add(iterative);

		//problem 1-4
		gcd = new JButton("Greatest Common Divisor");
		gcd.setVisible(false);
		factorial = new JButton("Factorial");
		factorial.setVisible(false);
		ackermann = new JButton("Ackerman's function");
		ackermann.setVisible(false);
		multi = new JButton("Multiplication of Natural Nos.");
		multi.setVisible(false);
		problem = new ButtonGroup();
		problem.add(gcd);
		problem.add(factorial);
		problem.add(ackermann);
		problem.add(multi);

		//Others
		ans = new JLabel("Answer:");
		fxn = new JLabel("Function:");
		answer = new TextField(); answer.setBackground(Color.pink);
		if(answers!='\0' && answers>0)
			answer.setText(""+answers);
		else{
			answer.setText(""); answers=0;}
		answer.setEditable(false);
		method = new TextArea(); method.setBackground(Color.pink);
		try{ if(answers!='\0'){
			FileReader reader= new FileReader("group2.java");
			BufferedReader buff = new BufferedReader(reader);

			JScrollPane scroll = new JScrollPane(method);
			scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setViewportView(method);

			if(number==1 && select==1){
				for(int aa=1; aa<428; aa++){buff.readLine();}
				method.setText("Ackerman's Function\nRecursive\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine());}
			else if(number==1 && select==0){
				for(int aa=1; aa<438; aa++){buff.readLine();}
				method.setText("Ackerman's Function\nIterative\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==2 && select==1){
				for(int aa=1; aa<386; aa++){buff.readLine();}
				method.setText("Greatest Common Factor\nRecursive\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==2 && select==0){
				for(int aa=1; aa<371; aa++){buff.readLine();}
				method.setText("Greatest Common Factor\nIterative\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==3 && select==1){
				for(int aa=1; aa<406; aa++){buff.readLine();}
				method.setText("Factorial\nRecursive\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==3 && select==0){
				for(int aa=1; aa<395; aa++){buff.readLine();}
				method.setText("Factorial\nIterative\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==4 && select==1){
				for(int aa=1; aa<421; aa++){buff.readLine();}
				method.setText("Multiplication of Natural Numbers\nRecursive\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else if(number==4 && select==0){
				for(int aa=1; aa<413; aa++){buff.readLine();}
				method.setText("Multiplication of Natural Numbers\nIterative\n\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n"+buff.readLine()+"\n");}
			else
				method.setText("");

			}}
		catch(FileNotFoundException e){
			JOptionPane.showMessageDialog(null,"File not Found","File Not Found",JOptionPane.ERROR_MESSAGE);
	 		}
		catch(IOException exception){
			JOptionPane.showMessageDialog(null,"File Cannot Be Read","ERROR",JOptionPane.ERROR_MESSAGE);
		}

		method.setEditable(false);

		Icon front= new ImageIcon("bck.png");
		bck = new JLabel();
		bck.setIcon(front);

		//locations in Container

		addComponent(cont, recursive, 50, 50, 200, 40);
		addComponent(cont, iterative, 50, 100, 200, 40);
		addComponent(cont, ackermann, 50, 180, 200, 40);
		addComponent(cont, gcd, 50, 230, 200,40);
		addComponent(cont, factorial, 50, 280, 200, 40);
		addComponent(cont, multi, 50, 330, 200,40);
		addComponent(cont, answer, 370, 50, 280, 40);
		addComponent(cont, method, 370, 100, 280, 270);
		addComponent(cont, ans, 300, 40, 100, 40);
		addComponent(cont, fxn, 300, 90, 100, 40);
		addComponent(cont, bck, 0, 0, 700, 450);


		recursive.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				factorial.setVisible(true); factorial.setBackground(Color.pink);
				gcd.setVisible(true); gcd.setBackground(Color.pink);
				ackermann.setVisible(true); ackermann.setBackground(Color.pink);
				multi.setVisible(true); multi.setBackground(Color.pink);
				method.setText("");
				answer.setText("");
			}
		});
		iterative.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				factorial.setVisible(true); factorial.setBackground(Color.pink);
				gcd.setVisible(true); gcd.setBackground(Color.pink);
				ackermann.setVisible(true); ackermann.setBackground(Color.pink);
				multi.setVisible(true); multi.setBackground(Color.pink);
				method.setText("");
				answer.setText("");
			}
		});

		ackermann.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				int num=1;
				if(recursive.isSelected())
					selected=1;
				else
					selected=0;
				gcd.setEnabled(false);
				factorial.setEnabled(false);
				multi.setEnabled(false);
				cont.setVisible(false);
				pop(num, selected);

			}
		});
		gcd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				int num=2;
				if(recursive.isSelected())
					selected=1;
				else
					selected=0;
				ackermann.setEnabled(false);
				factorial.setEnabled(false);
				multi.setEnabled(false);
				cont.setVisible(false);
				pop(num, selected);
			}
		});
		factorial.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				int num=3;
				if(recursive.isSelected())
					selected=1;
				else
					selected=0;
				ackermann.setEnabled(false);
				gcd.setEnabled(false);
				multi.setEnabled(false);
				cont.setVisible(false);
				pop(num, selected);

			}
		});
		multi.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				int num=4;
				if(recursive.isSelected())
					selected=1;
				else
					selected=0;
				ackermann.setEnabled(false);
				gcd.setEnabled(false);
				factorial.setEnabled(false);
				cont.setVisible(false);
				pop(num, selected);
				}
		});
		this.setLocation(new Point(50,50));
		this.setSize(new Dimension(700, 450));
		this.setVisible(true);
 		setResizable(false);
	}

	private void addComponent(Container container,Component c,int x,int y,int width,int height){
			c.setBounds(x,y,width,height);
			container.add(c);
 	}

	public static void main(String args[]){
		JFrame.setDefaultLookAndFeelDecorated(false);
		double answer='\0';
		int number=0;
		int select=2;
		group2 okay=new group2(answer, number, select);
		okay.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void pop(int num, int selected){
		final int number=num;
		final int select = selected;
		if(num==1)
			label0=new JLabel("Ackerman's function");
		else if(num==2)
			label0=new JLabel("Greatest Common Divisor");
		else if(num==3)
			label0=new JLabel("Factorial");
		else if(num==4)
			label0=new JLabel("Multiplication of Natural Numbers");
		addComponent(panel2, label0, 10, 05, 200, 40);

		if(selected==1)
			label1=new JLabel("Recursive");
		else
			label1=new JLabel("Iterative");
		addComponent(panel2, label1, 10, 25, 200, 40);

		if(num==1 || num ==2 || num==4){
			one = new TextField();
			two = new TextField();
			label2 = new JLabel("X");
			label3 = new JLabel("Y");
			addComponent(panel2, one, 100, 70, 100, 30);
			addComponent(panel2, two, 100, 120, 100, 30);
			addComponent(panel2, label2, 80, 70, 20, 20);
			addComponent(panel2, label3, 80, 120, 20, 20);
		}
		else{
			one = new TextField();
			label2 = new JLabel("X");
			addComponent(panel2, one, 100, 70, 100, 30);
			addComponent(panel2, label2, 80, 70, 20, 20);
		}

		ok = new JButton("Calculate");
		cancel = new JButton("Cancel");
		addComponent(panel2, ok, 40, 170, 100, 30);
		addComponent(panel2, cancel, 160, 170, 100, 30);

		Icon front= new ImageIcon("bck.png");
		bck = new JLabel();
		bck.setIcon(front);
		addComponent(panel2, bck, 0, 0, 300, 250);

		cancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				dispose();
				long answer='\0';
				int X=0;
				int Y=2;
				group2 okay=new group2(answer, X, Y);
				okay.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
		ok.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				try{
					X= Integer.parseInt(one.getText());{
						if(number!=3){
							try{
								Y=Integer.parseInt(two.getText());{
								}
							}
							catch(NumberFormatException e){
								throw new NumberFormatException();
							}
						}
					}
					if(number==1){
						if(select==0){
							if(X>3 || Y>20)
								JOptionPane.showMessageDialog(null,"X<=3 and Y<=20","ERROR",JOptionPane.ERROR_MESSAGE);
							else
								answers=iterative_ack(X, Y);
						}
						else{
							if(X>3 || Y>8)
								JOptionPane.showMessageDialog(null,"Stack Overflow.\nX<=3 and Y<=8","ERROR",JOptionPane.ERROR_MESSAGE);
							else
								answers=recursive_ack(X, Y);
						}
					}
					else if(number==2){
						if(X==0 && Y!=0)
							answers=Y;
						else if(Y==0 && X!=0)
							answers=X;
						else if(X==0 && Y==0)
							answers=0;
						else if(select==0)
							answers=iterative_gcd(X, Y);
						else
							answers=recursive_gcd(X, Y);
					}
					else if(number==3){
						if(X>50)
							JOptionPane.showMessageDialog(null,"Please enter a number less than or equal to 50.","ERROR",JOptionPane.ERROR_MESSAGE);
						else if(select ==0)
							answers=iterative_factorial(X);
						else
							answers=recursive_factorial(X);
					}
					else if(number==4){
						if (X<=0 || Y<=0)
							JOptionPane.showMessageDialog(null,"Zero (0) is not a natural number.\nPlease enter a non-negative number.","ERROR",JOptionPane.ERROR_MESSAGE);
						else if(select==0)
							answers=iterative_multi(X, Y);
						else{if((X>4000 && Y>4000) || Y>4000) JOptionPane.showMessageDialog(null,"Stack Overflow. Y>=4000.","ERROR",JOptionPane.ERROR_MESSAGE);
							else answers=recursive_multi(X, Y);}
					}
					dispose();
					group2 okay=new group2(answers, number, select);
					okay.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}
				catch(NumberFormatException e){
					JOptionPane.showMessageDialog(null,"Please fill up all fields with valid numbers.","ERROR",JOptionPane.ERROR_MESSAGE);
			 	}
			 	catch(Exception e){
					JOptionPane.showMessageDialog(null,"Stack Overflow.\nX<=3 and Y<=8","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		this.setLocation(new Point(250,150));
		this.setSize(new Dimension(300, 250));
		panel2.setVisible(true);
 		setResizable(false);
	}

  double iterative_gcd(int x, int y){
    if(y<=0 && x%y==0)
      return y;
    else if(x<y){
      int tmp=x;
      x=y;
      y=tmp;
    }
    for(int i=y; i>=1; i--){
      if(x%i==0 && y%i==0)
        return i;
      }
    return 1;
  }

  double recursive_gcd(int x, int y){
    if(y>=0 && x%y==0)
      return y;
    else if(x<y)
      return recursive_gcd(y, x);
    else
      return recursive_gcd(y, x%y);
  }

  double iterative_factorial( int x ){
    double ans = 1;
      if( x == 0)
        return 1;
      else{
        for(int i = 1; i<=x; i++)
          ans*=i;
      }
    return ans;
  }

  double recursive_factorial(int x){
    if( x == 0 || x == 1 )
      return 1;
    else
      return x * recursive_factorial( x - 1 );
  }

  double iterative_multi(int x, int y){
    answers=0;
    for(int i =1; i<=y; i++){
      answers=answers+x;
    }
    return answers;
  }

  double recursive_multi(int x, int y){
    if(y==1)
      return x;
    else
      return x+recursive_multi(x, y-1);
  }

  double recursive_ack(double x, double y){
    if (x==0)
      return y+1;
    else if (x>0 && y==0)
      return recursive_ack(x-1, 1);
    else
      return  recursive_ack(x-1, recursive_ack(x, y-1));
  }

  double iterative_ack(int x, int y){
    int a[];
    int i,k,l;
    a=new int[100];
    a[0]=5;
    if(x==0)
      return y+1;
    else if(x==1)
      return y+2;
    else if(x==2)
      return y*2+3;
    for(i=1; i<=y; i++){
      a[i]=a[i]+i*3+5;
      for(k=0; k<i; k++)
        a[i]=a[k]+a[i];
    }
    return a[y];
  }
}