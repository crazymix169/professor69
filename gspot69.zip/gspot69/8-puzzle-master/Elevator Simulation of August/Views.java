import java.lang.reflect.Field;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class Views extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.view);
            final ScrollTextView scrolltext=(ScrollTextView) findViewById(R.id.scrolltext);
                if(MainActivity.bold.isChecked())
                    {
                    scrolltext.setTypeface(null, Typeface.BOLD);
                    };
                if(MainActivity.italic.isChecked())
                    {
                    scrolltext.setTypeface(null, Typeface.ITALIC);
                    };
                if((MainActivity.italic.isChecked())&&(MainActivity.bold.isChecked()))
                    {
                    scrolltext.setTypeface(null, Typeface.BOLD_ITALIC);
                    };
            scrolltext.setTextSize(Integer.parseInt(MainActivity.tSize[MainActivity.Size.getSelectedItemPosition()]));
            scrolltext.setText(MainActivity.text);
            scrolltext.setTextColor(Integer.parseInt(MainActivity.colour[MainActivity.TextColour.getSelectedItemPosition()]));
            scrolltext.startScroll();
            scrolltext.setBackgroundColor(Integer.parseInt(MainActivity.colour[MainActivity.BackgroundColour.getSelectedItemPosition()]));
                Thread thread = new Thread()
                    {
                    public void run()
                        {
                        if(MainActivity.random.isChecked())
                            {
                            int delay = 0; // delay for 5 sec.
                            int period = 1000; // repeat every sec.
                            Timer timer = new Timer();
                            timer.scheduleAtFixedRate(new TimerTask() {
                            int n=1;
                                public void run() {if (n==9)n=1;
                                scrolltext.setBackgroundColor(Integer.parseInt(MainActivity.colour[n]));
                                }
                            }, delay, period);
                                        /*int n=1;
                                        boolean constant=true;
                                        while (constant==true){
                                        if (n==10) n=1;
                                        //   int randInt = new Random().nextInt(2);
                                        //   scrolltext.setBackgroundColor(Integer.parseInt(MainActivity.colour[randInt]));
                                        scrolltext.setBackgroundColor(Integer.parseInt(MainActivity.colour[n]));
                                        n=n+1;
                                        try
                                        {
                                        Thread.sleep(2000); // 1 second
                                        } catch (Exception e)
                                        {
                                        e.printStackTrace();
                                        }
                                        }*/ 
                            }
                        }
                    };
                thread.start();
                                        //      TextView textview=(TextView) findViewById (R.id.textView1); 
                                        //          textview.setText(MainActivity.text);
                                        //  textview.setTextColor(Integer.parseInt(MainActivity.colour[MainActivity.TextColour.getSelectedItemPosition()]));
                                        //          textview.setBackgroundColor(Integer.parseInt(MainActivity.colour[MainActivity.BackgroundColour.getSelectedItemPosition()]));
                                        //     textview.setTextSize(Integer.parseInt(MainActivity.tSize[MainActivity.Size.getSelectedItemPosition()]));
                                        //    textview.setSelected(true);
    }
}