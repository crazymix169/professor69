# 8-puzzle
Java program to solve the 8 puzzle problem (using branch and bound algorithm)
 
### Problem:
http://artificialintelligence-notes.blogspot.com/2010/07/8-puzzle-problem.html
 
### Compile and run
``` 
$ javac Puzzle.java
$ java Puzzle
```
 
### References
http://www.geeksforgeeks.org/branch-bound-set-3-8-puzzle-problem/
