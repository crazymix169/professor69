-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2020 at 02:15 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_billingervinn`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `employeeid` int(11) NOT NULL,
  `firstname` varchar(1000) NOT NULL,
  `middlename` varchar(1000) NOT NULL,
  `lastname` varchar(1000) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `hobbies` varchar(1000) NOT NULL,
  `birthdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`employeeid`, `firstname`, `middlename`, `lastname`, `address`, `sex`, `hobbies`, `birthdate`) VALUES
(1, 'august', 'rosito', 'tabucanon', 'san pablo, ormoc city', 'Male', 'Chess', '1987-08-25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logtrail`
--

CREATE TABLE `tbl_logtrail` (
  `logtrailid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `logtype` varchar(1000) NOT NULL,
  `logdate` date NOT NULL,
  `logtime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_logtrail`
--

INSERT INTO `tbl_logtrail` (`logtrailid`, `userid`, `logtype`, `logdate`, `logtime`) VALUES
(1, 1, 'login', '2020-02-11', '16:52:10'),
(2, 1, 'login', '2020-02-11', '16:52:59'),
(3, 1, 'login', '2020-02-11', '16:53:21'),
(4, 1, 'login', '2020-02-11', '16:55:56'),
(5, 1, 'login', '2020-02-11', '17:02:46'),
(6, 1, 'login', '2020-02-11', '17:03:29'),
(7, 1, 'logout', '2020-02-11', '17:03:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salary`
--

CREATE TABLE `tbl_salary` (
  `salaryid` int(11) NOT NULL,
  `employeeid` int(11) NOT NULL,
  `hourlyrate` double NOT NULL,
  `minutes` double NOT NULL,
  `hoursworked` double NOT NULL,
  `timeofday` varchar(100) NOT NULL,
  `sssorgsis` double NOT NULL,
  `pagibig` double NOT NULL,
  `philhealth` double NOT NULL,
  `tax` double NOT NULL,
  `bonus` double NOT NULL,
  `otherdeductions` double NOT NULL,
  `totalsalary` double NOT NULL,
  `salarydate` date NOT NULL,
  `salarytimein` time NOT NULL,
  `salarytimeout` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `userid` int(11) NOT NULL,
  `username` varchar(1000) NOT NULL,
  `userpassword` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`userid`, `username`, `userpassword`) VALUES
(1, 'august', 'aya69');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`employeeid`);

--
-- Indexes for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  ADD PRIMARY KEY (`logtrailid`);

--
-- Indexes for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  ADD PRIMARY KEY (`salaryid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `employeeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_logtrail`
--
ALTER TABLE `tbl_logtrail`
  MODIFY `logtrailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  MODIFY `salaryid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
