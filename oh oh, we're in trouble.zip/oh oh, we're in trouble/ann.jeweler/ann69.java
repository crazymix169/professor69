/**
 * @(#)ann69.java
 *
 *
 * @author
 * @version 1.00 2019/10/9
 */


public class ann69 {

    public ann69() {
    }

    public static void main(String args[])
    {
    	String x="Hello",name="ann";
    	System.out.println(x+"\n"+name);

    	int a=56,b=13;
    	System.out.println(a+b);

    	System.out.println(-5+8*6);
    	System.out.println((55+9)%9);
    	System.out.println(20+3*5/8);
    	System.out.println(5+15/3*2-8%3);

    	System.out.println(a+b);
    	System.out.println(a-b);
    	System.out.println(a*b);
    	System.out.println(a/b);
    	System.out.println(a%b);

    	double pi=3.1416, r=7.5;

    	System.out.println("The Circle:");
    	System.out.println("The Area is: "+pi*r*r);
    	System.out.println("The Circumference is: "+pi*r*2);

    	double num[]=new double[3];

    	num[0]=4.5;
    	num[1]=6.7;
    	num[2]=7.7;
    	double sum=0;

    	int i;

    	for(i=0;i<3;i++)
    	{
    		sum+=num[i];
    	}

    	System.out.println("The average is: "+sum/i);

    	double w=5.5, l=8.5;

    	System.out.println("The Rectangle:");
    	System.out.println("The Area is: "+l*w);
    	System.out.println("The Perimeter is: "+(l+w)*2);

    	System.out.println("Odd or Even number");

    	int n1=66;

    	if(n1%2==0)
    	{
    		System.out.println("1");
    	}
    	else
    	{
    		System.out.println("0");
    	}

    	System.out.println("Sum of two integers equal or not to the third integer");

    	n1=12;
    	int n2=14, n3=18;

    	System.out.println("Sum of two integers: " + n1 +" and "+ n2 +" equal or not to the third integer: "+ n3);
    	if((n1+n2)==n3)
    	{
    		System.out.println("true");
    	}
    	else
    	{
    		System.out.println("false");
    	}

    	double num1[]=new double[5];

    	num1[0]=4.5;
    	num1[1]=6.7;
    	num1[2]=7.7;
    	num1[3]=11.7;
    	num1[4]=17.7;

    	double smallest=num[0];
    	double largest=smallest;

    	i=0;
    	System.out.println("the five integers:");

    	for(i=0;i<5;i++)
    	{
    		System.out.print(num1[i]+" ");
    	}

    	System.out.println("");

    	for(i=1;i<5;i++)
    	{
    		if(num1[i]<smallest)
    		{
    			smallest=num1[i];
    		}

    	}

    	System.out.println("");
    	System.out.println("the smallest is: "+smallest);

    	for(i=1;i<5;i++)
    	{
    		if(num1[i]>largest)
    		{
    			largest=num1[i];
    		}

    	}
    	System.out.println("the largest is: "+largest);

    }


}