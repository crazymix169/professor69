package cpuschedulingjava;

import javax.swing.JOptionPane;

public class Process
{
    int pr=0;
    int at=0;
    int atx=0;
    int bt=0;
    int rt=0;
    int pt=0;
    
    public Process(int pr,int at,int atx,int bt,int rt,int pt)
    {
        this.pr=pr;
        this.at=at;
        this.atx=atx;
        this.bt=bt;
        this.rt=rt;
        this.pt=pt;    
    }
    
    public Process()
    {
            
    }
    
    //CPU Scheduling Simulator: FCFS, SJF, NPP, RR, SRTF, PP, Show All
    
    private String FCFSgantt="",SJFgantt="",NPPgantt="",RRgantt="",RRquantum="",SRTFgantt="",PPgantt="",ShowAllGantt="";
    double sum_wait2=0,sum_turnaround2=0,sum_bt=0,sum_bt2=0;
    //Begin FCFS
    
    public String fcfs(Process[] FCFS, int n, int ts)
    {
        FCFSgantt="";
        String xx="";

        try
        {

            int i=0;
            int j=0;
            int FCFSn=n;
            int time=0;
            int remain=0;
            int flag=0;
            int ts1=ts;
            int endTime=0;
            int smallest=20;
            int IdleTime=0;
            //int[] processGantt=new int[100];
            int sum_wait2=0;
            int sum_turnaround2=0;
            //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                  //int time=0,n,i,smallest,count=0;
            double FCFSsum_bt;
            int cnt=0;
            double sum_bt2;
            int count1=0;

            //Process[] FCFS=new Process[n];
            
            int[] FCFSat=new int[21];
            int[] FCFSbt =new int[21];

            int[] FCFSrt = new int[21];
            int[] FCFSpr=new int[21];
            int[] FCFSpt=new int[21];

            //int ctr;
            //int op;
            FCFSsum_bt=0;

            for(i=0;i<20;i++)
            {
                FCFSpr[i]=0;//process
                FCFSat[i]=0;//arrival time

                FCFSbt[i]=0;//burst time

                //FCFSsum_bt+=bt[i1];//total sum of burst times
                FCFSrt[i]=0;//burst time

                FCFSpt[i]=0;//priority

            }

            for(i=0;i<FCFSn;i++)
            {
                FCFSpr[i]=FCFS[i].pr;//process
                FCFSat[i]=FCFS[i].at;//arrival time

                FCFSbt[i]=FCFS[i].bt;//burst time

                FCFSsum_bt+=FCFS[i].bt;//total sum of burst times
                FCFSrt[i]=FCFS[i].rt;//burst time

                FCFSpt[i]=FCFS[i].pt;//priority

            }

            //JOptionPane.showMessageDialog(null, "number of proceses: "+Integer.toString(FCFSn) );
            //FCFS

            count1=0;

            while(count1!=FCFSn)  /*End the loop when n process finish*/
            {
                smallest=20; /* Checking For index of Process with smallest Arrival Time*/
                FCFSat[20]=9999;
                for(i=0;i<FCFSn;i++)
                {

                if(FCFSat[i]<FCFSat[smallest] && FCFSbt[i]>0)
                {
                    smallest=i;
                }

                }

                // JOptionPane.showMessageDialog(null, "gamay: "+Integer.toString(smallest) );
                int xxx=0;
                xxx=smallest;
                //JOptionPane.showMessageDialog(null, "process ID: "+Integer.toString(pr1[xxx]+1) );    
                //computing idle time
                while(time<FCFSat[smallest])
                {
                    time++;
                    IdleTime++;
                    System.out.print("*");
                    xx+="*";

                }




                for(i=1;i<=FCFSbt[smallest];i++)
                {
                        System.out.print(FCFSpr[smallest]+1);
                        int v=FCFSpr[smallest]+64;
                        char dd=(char)v;
                        xx+=Character.toString(dd);
                }
                /*Index of Smallest  Arrival Time stored in `smallest`*/
                time+=FCFSbt[smallest];  /*Incrementing Current Time*/
                sum_wait2+=time-FCFSat[smallest]-FCFSbt[smallest];
                sum_turnaround2+=time-FCFSat[smallest];

                endTime=time;
                /*
                private JLabel PID[]=new JLabel[20];	
                private JTextField processID[]=new JTextField[20];
                private JTextField atID[]=new JTextField[20];
                private JTextField btID[]=new JTextField[20];
                private JTextField tatID[]=new JTextField[20];
                private JTextField wtID[]=new JTextField[20];*/

                //tatID[smallest].setText(Integer.toString(endTime-FCFSat[smallest]));
                //wtID[smallest].setText(Integer.toString(endTime-FCFSbt[smallest]-FCFSat[smallest]));

                //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime-FCFSat[smallest])+" WT: "+(endTime-FCFSbt[smallest]-FCFSat[smallest]));

                //printf("P[%d]\t|\t%d\t|\t%d\n",smallest+1,time-at[smallest],time-at[smallest]-bt[smallest]);

                FCFSbt[smallest]=0;  /*Making burst time of current Process 0 so that it won't run again*/
                count1++;
            }

            //System.out.println("Average Turn Around Time: "+sum_turnaround2/n);
            //System.out.println("Average Wait Time: "+sum_wait2/n);

            //textAvgTAT.setText(Double.toString(sum_turnaround2/n));
            //textAvgWT.setText(Double.toString(sum_wait2/n));

            //System.out.println("Gantt Chart: ");

            FCFSgantt+="FCFS Gantt Chart\n";
            //i=0;
            FCFSgantt+="<-"+"0"+"-> ";


            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    FCFSgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    FCFSgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }
                if(i%5!=4)
                {
                    FCFSgantt+=Character.toString(xx.charAt(i));
                }
            }
            FCFSgantt+="<-"+Integer.toString(xx.length())+"-> ";

            FCFSgantt+="\n";
            FCFSgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/n)+"\n";
            FCFSgantt+="Average Waiting Time: "+Double.toString(sum_wait2/n)+"\n";
            FCFSgantt+="Total Idle Time: "+Double.toString(IdleTime)+"\n";
            double xxx=FCFSsum_bt,ggg=FCFSsum_bt+IdleTime;
            FCFSgantt+="Total burst Time: "+Double.toString(FCFSsum_bt)+"\n";
            FCFSgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            //JOptionPane.showMessageDialog(null,"total burst time: "+xxx+" ;cputime: "+ggg,"Error",JOptionPane.INFORMATION_MESSAGE);
            FCFSgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";




        }
        catch(Exception e)
        {
            FCFSgantt="FCFS Error:\n"+e.getMessage(); 
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);

        }
        
        FCFSgantt+="\n\n";

        return FCFSgantt;	  


    }
     
    //End FCFS
    
    //Begin SJF
    
    public String sjf(Process[] SJF, int n, int ts)
    {
        SJFgantt="";
        String xx="";


        try
        {
            int i=0;
            int j=0;
            int SJFn=n;
            int time=0;
            int remain=0;
            int flag=0;
            int ts1=ts;
            int endTime=0;
            int smallest=20;
            int IdleTime=0;
            //int[] processGantt=new int[100];
            sum_wait2=0;
            sum_turnaround2=0;
            //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                  //int time=0,n,i,smallest,count=0;
            double SJFsum_bt=sum_bt;
            int cnt=0;
            sum_bt2=sum_bt;
            int count=0;

            int[] SJFat=new int[21];
            int[] SJFbt =new int[21];

            int[] SJFrt = new int[21];

            int[] SJFpr=new int[21];
            int[] SJFpt=new int[21];

            //int ctr;
            //int op;

            for(i=0;i<20;i++)
            {
                SJFpr[i]=0;//process
                SJFat[i]=0;//arrival time

                SJFbt[i]=0;//burst time

                //SJFsum_bt+=bt[i];//total sum of burst times
                SJFrt[i]=0;//burst time

                SJFpt[i]=0;//priority

            }

            SJFsum_bt=0;
            for(i=0;i<n;i++)
            {
                SJFpr[i]=SJF[i].pr;//process
                SJFat[i]=SJF[i].at;//arrival time

                SJFbt[i]=SJF[i].bt;//burst time

                SJFsum_bt+=SJFbt[i];//total sum of burst times
                SJFrt[i]=SJF[i].rt;//burst time

                SJFpt[i]=SJF[i].pt;//priority

            }

            //SJF
            sum_bt2=SJFsum_bt;

            //JOptionPane.showMessageDialog(null, "Process: "+1+" burst: "+SJFbt[0]);

            SJFbt[20]=9999;
            //printf("\n\nProcess\t|Turnaround Time| Waiting Time\n\n");
            for(time=0;time<SJFsum_bt;)
            {
                smallest=20;
                for(i=0;i<n;i++)
                {
                    if(SJFat[i]<=time && SJFbt[i]>0 && SJFbt[i]<SJFbt[smallest])
                        smallest=i;
                }
                if(smallest==20)
                {
                    time++;
                    IdleTime++;
                    SJFsum_bt++;
                    xx+="*";
                    continue;
                }
                //printf("P[%d]\t|\t%d\t|\t%d\n",smallest+1,time+bt[smallest]-at[smallest],time-at[smallest]);
                endTime=time;
                //tatID[smallest].setText(Integer.toString(endTime-SJFat[smallest]+SJFbt[smallest]));
                //wtID[smallest].setText(Integer.toString(endTime-SJFat[smallest]));
                //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime+SJFbt[smallest]-SJFat[smallest])+" WT: "+(endTime-SJFat[smallest]));
                //sum_turnaround2+=time+-at[smallest];
                sum_turnaround2+=time+SJFbt[smallest]-SJFat[smallest];
                sum_wait2+=time-SJFat[smallest];
                time+=SJFbt[smallest];

                for(i=1;i<=SJFbt[smallest];i++)
                {
                    System.out.print(SJFpr[smallest]+1);
                    int v=SJFpr[smallest]+64;
                    char dd=(char)v;
                    xx+=Character.toString(dd);
                }

                SJFbt[smallest]=0;
            }
            //System.out.println("Average Turn Around Time: "+sum_turnaround2/n);
            //System.out.println("Average Wait Time: "+sum_wait2/n);
            //textAvgTAT.setText(Double.toString(sum_turnaround2/n));
            //textAvgWT.setText(Double.toString(sum_wait2/n));
                  //System.out.println("Total Idle Time: "+IdleTime);	
           // System.out.println("Gantt Chart:\n"+SJFgantt);
            SJFgantt+="SJF Gantt Chart\n";
            SJFgantt+="<-"+"0"+"-> ";
            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    SJFgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    SJFgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }
                if(i%5!=4)
                {
                    SJFgantt+=Character.toString(xx.charAt(i));
                }		
            }
            //SJFgantt+=xx;
            SJFgantt+="<-"+Integer.toString(xx.length())+"-> ";
            SJFgantt+="\n";
            SJFgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/n)+"\n";
            SJFgantt+="Average Waiting Time: "+Double.toString(sum_wait2/n)+"\n";
            SJFgantt+="Total Idle Time: "+Double.toString(IdleTime)+"\n";
            double xxx=SJFsum_bt,ggg=xxx+IdleTime;
            SJFgantt+="Total burst Time: "+Double.toString(SJFsum_bt)+"\n";
            SJFgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            SJFgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";


        }
        catch(Exception e)
        {
            //System.out.println("SJF Error");
            SJFgantt="SJF Error!";

        }

        SJFgantt+="\n\n";

        return SJFgantt;

    }
    
    //End SJF
    
    //Begin NPP
    
    public String npp(Process[] NPP, int n, int ts)
    {
        NPPgantt="";
        String xx="";

        try
        {
            int i=0;
            int j=0;
            int NPPn=n;
            //n=m;
            int time=0;
            int NPPremain=n;
            int flag=0;
            //ts=ts;
            int endTime=0;
            int smallest=20;
            int IdleTime=0;
            //int[] processGantt=new int[100];
            sum_wait2=0;
            sum_turnaround2=0;
            //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                  //int time=0,n,i,smallest,count=0;
            //sum_bt=sum_bt;
            int cnt=0;

            int count=0;

            int[] NPPat=new int[21];
            int[] NPPbt =new int[21];


            int[] NPPrt = new int[21];

            int[] NPPpr=new int[21];
            int[] NPPpt=new int[21];

            //int ctr;
            //int op;
            sum_bt=0;


            double SJFsum_bt=0;
            for(i=0;i<NPPn;i++)
            {
                NPPpr[i]=NPP[i].pr;//process
                NPPat[i]=NPP[i].at;//arrival time

                NPPbt[i]=NPP[i].bt;//burst time

                SJFsum_bt+=NPPbt[i];//total sum of burst times
                NPPrt[i]=NPP[i].rt;//burst time

                NPPpt[i]=NPP[i].pt;//priority

            }

            sum_bt2=SJFsum_bt;

            //npp

            NPPpt[20]=31;
            NPPat[20]=9999;
            //printf("\n\nProcess\t|Turnaround time|waiting time Arrival time Burst Time\n");
            for(time=0;NPPremain!=0;)
            {

                smallest=20; /* Checking For index of Process with smallest Arrival Time*/
                for(i=0;i<NPPn;i++)
                {
                    if(NPPat[i]<NPPat[smallest] && NPPbt[i]>0)
                    {
                        smallest=i;
                    }
                }
                while(time<NPPat[smallest])
                {
                    time++;
                    IdleTime++;
                    System.out.print("*");
                    xx+="*";

                }

                smallest=20;
                for(i=0;i<NPPn;i++)
                {
                    if(NPPat[i]<=time && NPPpt[i]<NPPpt[smallest] && NPPbt[i]>0)
                    {
                        smallest=i;

                    }

                }


                for(i=1;i<=NPPbt[smallest];i++)
                {
                    //System.out.print(NPPpr[smallest]+1);
                    int v=NPPpr[smallest]+64;
                    char dd=(char)v;
                    xx+=Character.toString(dd);
                }

                time+=NPPbt[smallest];
                NPPremain--;
                endTime=time;
                //tatID[smallest].setText(Integer.toString(endTime-NPPat[smallest]));
                //wtID[smallest].setText(Integer.toString(endTime-NPPat[smallest]-NPPbt[smallest]));
                //printf("P[%d]\t|\t%d\t|\t%d\n",smallest+1,time+1-at[smallest],time+1-at[smallest]-bt[smallest]);
                //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime-NPPat[smallest])+" WT: "+(endTime-NPPat[smallest]-NPPbt[smallest]));

                //printf("P[%d]\t|\t%d\t|\t%d|\t%d\t|\t%d\n",smallest+1,time-at[smallest],time-at[smallest]-bt[smallest],at[smallest],bt[smallest]);

                sum_wait2+=time-NPPat[smallest]-NPPbt[smallest];
                sum_turnaround2+=time-NPPat[smallest];
                NPPbt[smallest]=0;
            }

            NPPgantt+="NPP Gantt Chart\n";

            NPPgantt+="<-"+"0"+"-> ";
            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    NPPgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    NPPgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }
                if(i%5!=4)
                {
                    NPPgantt+=Character.toString(xx.charAt(i));
                }		
            }
            //textAvgTAT.setText(Double.toString(sum_turnaround2/NPPn));
            //textAvgWT.setText(Double.toString(sum_wait2/NPPn));

            NPPgantt+="<-"+Integer.toString(xx.length())+"-> ";
            NPPgantt+="\n";
            NPPgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/NPPn)+"\n";
            NPPgantt+="Average Waiting Time: "+Double.toString(sum_wait2/NPPn)+"\n";
            NPPgantt+="Total Idle Time: "+Double.toString(IdleTime)+"\n";
            double xxx=sum_bt2,ggg=xxx+IdleTime;
            NPPgantt+="Total Burst Time: "+Double.toString(xxx)+"\n";
            NPPgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            NPPgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";



        }
        catch(Exception e)
        {
            NPPgantt="NPP Error:\n"+e.getMessage();
            //JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }

        NPPgantt+="\n\n";

        return NPPgantt;


    }
    
    //End NPP
    
    //Begin RR
    
    public String rr(Process[] RR, int n, int ts)
    {
        RRgantt="";
        String xx="";



        try
        {
            int i=0;
            int j=0;
            int RRn=n;
            //n=m;
            int time=0;
            //remain=n;
            int flag=0;
            int RRts=ts;
            //ts=ts2;
            int endTime=0;
            int smallest=20;
            int IdleTime=0;
            //int[] processGantt=new int[100];
            sum_wait2=0;
            sum_turnaround2=0;
            //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                  //int time=0,n,i,smallest,count=0;
            //sum_bt=sum_bt;
            int cnt=0;

            int count=0;

            int[] RRat=new int[21];
            int[] RRatx=new int[21];
            int[] RRbt =new int[21];

            int[] RRrt = new int[21];

            int[] RRpr=new int[21];
            int[] RRpt=new int[21];

            int ctr;
            //int op;
            double RRnsum_bt=0;
            for(i=0;i<20;i++)
            {
                RRpr[i]=0;//process
                RRat[i]=0;//arrival time
                RRatx[i]=0;//arrival time

                RRbt[i]=0;//burst time

                //RRnsum_bt+=bt[i];//total sum of burst times
                RRrt[i]=0;//burst time

                RRpt[i]=0;//priority

            }


            double SJFsum_bt=0;
            for(i=0;i<RRn;i++)
            {
                RRpr[i]=RR[i].pr;//process
                RRat[i]=RR[i].at;//arrival time
                RRatx[i]=RR[i].at;//arrival time

                RRbt[i]=RR[i].bt;//burst time

                RRnsum_bt+=RRbt[i];//total sum of burst times
                RRrt[i]=RR[i].rt;//burst time

                RRpt[i]=RR[i].pt;//priority

            }

            //sum_bt2=sum_bt;
            //JOptionPane.showMessageDialog(null, "The value of n= "+n+" Time slice: "+RRts);
            int RRremain=n;

            for(time=0,i=0;RRremain!=0;)
            {	
                if(RRatx[i]>time&&RRrt[i]>0)
                {
                    int a,b;
                    RRatx[20]=9999;
                    smallest=20;	 
                    //int b;
                    smallest=20;
                    for(j=0;j<n;j++)
                    {
                        if(RRatx[j]<RRatx[smallest] && RRrt[j]>0)
                        {
                            smallest=j;
                        }
                    }


                    b=smallest;
                    i=b;
                    //JOptionPane.showMessageDialog(null, "The value of the arrival time of the current process= "+RRat[i]+" Total Execution Time "+time);					
                    while(RRatx[i]>time)
                    {
                        time++;

                        //time+=b;
                        IdleTime++;
                        //System.out.print("*");
                        //for(a=1;a<=b;a++)        
                        xx+="*";
                        //continue;
                    }
                    RRatx[i]=time;
                    //b=smallest;
                    //i=b;
                    //JOptionPane.showMessageDialog(null, "The value of the arrival time of the current process= "+RRat[i]+" Total execution time: "+time);
                    continue;
                    //i--;
                }	    
                if(RRrt[i]<=RRts && RRrt[i]>0&&RRatx[i]<=time)
                {
                    for(ctr=1;ctr<=RRrt[i];ctr++)
                    {
                        //System.out.print(RRpr[i]+1);
                        int v=RRpr[i]+64;
                        char dd=(char)v;
                        xx+=Character.toString(dd);
                    }
                    time+=RRrt[i];
                    RRatx[i]=time;
                    RRrt[i]=0;
                    flag=1;
                }
                if(RRrt[i]>RRts&&RRrt[i]>0&&RRatx[i]<=time)
                {			
                    for(ctr=1;ctr<=RRts;ctr++)
                    {
                        //System.out.print(RRpr[i]+1);
                        int v=RRpr[i]+64;
                        char dd=(char)v;
                        xx+=Character.toString(dd);
                    }
                    RRrt[i]-=RRts;
                    time+=RRts;
                    RRatx[i]=time;
                }				
                

                if(RRrt[i]==0 && flag==1)
                {
                    RRremain--;
                    endTime=time;
                    //printf("P[%d]\t|\t%d\t|\t%d\n",i+1,time-at[i],time-at[i]-bt[i]);
                    //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime-SRTFat[smallest])+" WT: "+(endTime-SRTFat[smallest]-SRTFbt[smallest]));
                    //System.out.println("Process number: "+(RRpr[i]+1)+" TAT: "+(endTime-RRat[i])+" WT: "+(endTime-RRat[i]-RRbt[i]));
                    //tatID[i].setText(Integer.toString(endTime-RRat[i]));
                    //wtID[i].setText(Integer.toString(endTime-RRat[i]-RRbt[i]));
                    sum_wait2+=endTime-RRat[i]-RRbt[i];
                    sum_turnaround2+=endTime-RRat[i];
                    flag=0;
                }
                if(i==n-1)
                    i=0;
                else if(RRatx[i+1]<=time)
                    i++;
                else
                    i=0;
            }
            
            RRgantt+="RR Gantt Chart: Quantum Time= "+Integer.toString(ts)+"\n";

            RRgantt+="<-"+"0"+"-> ";
            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    RRgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    RRgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }
                if(i%5!=4)
                {
                    RRgantt+=Character.toString(xx.charAt(i));
                }		
            }
            //textAvgTAT.setText(Double.toString(sum_turnaround2/RRn));
            //textAvgWT.setText(Double.toString(sum_wait2/RRn));
            RRgantt+="<-"+Integer.toString(xx.length())+"-> ";
            RRgantt+="\n";
            RRgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/RRn)+"\n";
            RRgantt+="Average Waiting Time: "+Double.toString(sum_wait2/RRn)+"\n";
            RRgantt+="Total Idle Time: "+Integer.toString(IdleTime)+"\n";
            double xxx=RRnsum_bt,ggg=xxx+IdleTime;
            RRgantt+="Total Burst Time: "+Double.toString(xxx)+"\n";
            RRgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            RRgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";
            RRgantt+="Total Running Processes: "+Integer.toString(RRn)+"\n";
            /*
            printf("\nAvg sum_wait = %f\n",sum_wait*1.0/n);
            printf("Avg sum_turnaround = %f",sum_turnaround*1.0/n);
            printf("\n\nGantt Chart\n");*/
            //System.out.println("Average Turn Around Time: "+sum_turnaround2/n);
            //System.out.println("Average Wait Time: "+sum_wait2/n);

            //System.out.println("Total Idle Time: "+IdleTime);
            //System.out.println("Gantt Chart:\n"+RRgantt);

        }
        catch(Exception e)
        {
            RRgantt="RR Error:\n";
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);

        }
        
        RRgantt+="\n\n";

        return RRgantt;

    }
    
    //End RR
    
    //Begin SRTF
    
    public String srtf(Process[] SRTF, int n, int ts)
    {
        SRTFgantt="";
        String xx="";

        try
        {
            int i=0;
            int j=0;
            int SRTFn=n;
            //n=m;
            int time=0;
            int SRTFremain=0;
            int flag=0;
            ts=ts;
            int endTime=0;
            int smallest=20;
            int IdleTime=0;
            //int[] processGantt=new int[100];
            sum_wait2=0;
            sum_turnaround2=0;
            //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                  //int time=0,n,i,smallest,count=0;
            sum_bt=sum_bt;
            int cnt=0;

            int count=0;

            int[] SRTFat=new int[21];
            int[] SRTFbt =new int[21];


            int[] SRTFrt = new int[21];

            int[] SRTFpr=new int[21];
            int[] SRTFpt=new int[21];

            sum_bt=0;

            for(i=0;i<SRTFn;i++)
            {
                SRTFpr[i]=SRTF[i].pr;//process
                SRTFat[i]=SRTF[i].at;//arrival time

                SRTFbt[i]=SRTF[i].bt;//burst time

                sum_bt+=SRTFbt[i];//total sum of burst times
                SRTFrt[i]=SRTF[i].rt;//burst time

                SRTFpt[i]=SRTF[i].pt;//priority

            }

            double SRTFsum_bt2=sum_bt;


            //SRTF
            SRTFrt[20]=9999;

            for(time=0;SRTFremain!=SRTFn;time++)
            {
                smallest=20;
                SRTFrt[20]=9999;
                for(i=0;i<SRTFn;i++)
                {
                    if(SRTFat[i]<=time && SRTFrt[i]<SRTFrt[smallest] && SRTFrt[i]>0)
                    {
                        //processGantt[time]=i;
                        smallest=i;
                    }
                }
                if(smallest==20)
                {
                    SRTFat[20]=9999;
                    smallest=20;
                    for(j=0;j<SRTFn;j++)
                    {
                        if(SRTFat[j]<SRTFat[smallest] && SRTFrt[j]>0)
                        {
                            smallest=j;
                        }
                    }


                    while(time<SRTFat[smallest])
                    {
                        time++;
                        IdleTime++;
                        //System.out.print("*");
                        xx+="*";
                        //continue;
                    }

                }	
                SRTFrt[smallest]--;
                //System.out.print(pr[smallest]+1);
                //xx+=Integer.toString(SRTFpr[smallest]+1);

                System.out.print(SRTFpr[smallest]+1);
                int v=SRTFpr[smallest]+64;
                char dd=(char)v;
                xx+=Character.toString(dd);

                if(SRTFrt[smallest]==0)
                {
                    SRTFremain++;
                    endTime=time+1;
                    //printf("\nP[%d]\t|\t%d\t|\t%d",smallest+1,endTime-at[smallest],endTime-bt[smallest]-at[smallest]);
                    //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime-SRTFat[smallest])+" WT: "+(endTime-SRTFat[smallest]-SRTFbt[smallest]));
                    //System.out.println("Process number: "+(SRTFpr[smallest]+1)+" TAT: "+(endTime-SRTFat[smallest])+" WT: "+(endTime-SRTFat[smallest]-SRTFbt[smallest]));
                    //tatID[smallest].setText(Integer.toString(endTime-SRTFat[smallest]));
                    //wtID[smallest].setText(Integer.toString(endTime-SRTFat[smallest]-SRTFbt[smallest]));
                    sum_wait2=sum_wait2+(endTime-SRTFbt[smallest]-SRTFat[smallest]);
                    sum_turnaround2=sum_turnaround2+(endTime-SRTFat[smallest]);
                }
            }

            SRTFgantt+="SRTF Gantt Chart\n";

            SRTFgantt+="<-"+"0"+"-> ";
            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    SRTFgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    SRTFgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }/*
                else if((i%5)==0 && (i % 250)!=0&&i!=0)
                {
                        FCFSgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }*/
                if(i%5!=4)
                {
                    SRTFgantt+=Character.toString(xx.charAt(i));
                }		
            }
            //textAvgTAT.setText(Double.toString(sum_turnaround2/SRTFn));
            //textAvgWT.setText(Double.toString(sum_wait2/SRTFn));
            SRTFgantt+="<-"+Integer.toString(xx.length())+"-> ";
            SRTFgantt+="\n";
            SRTFgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/SRTFn)+"\n";
            SRTFgantt+="Average Waiting Time: "+Double.toString(sum_wait2/SRTFn)+"\n";
            SRTFgantt+="Total Idle Time: "+Double.toString(IdleTime)+"\n";
            double xxx=SRTFsum_bt2,ggg=xxx+IdleTime;
            SRTFgantt+="Total Burst Time: "+Double.toString(xxx)+"\n";
            SRTFgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            SRTFgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";
            /*
            printf("\nAvg sum_wait = %f\n",sum_wait*1.0/n);
            printf("Avg sum_turnaround = %f",sum_turnaround*1.0/n);
            printf("\n\nGantt Chart\n");
            System.out.println("Average Turn Around Time: "+sum_turnaround2/SRTFn);
            System.out.println("Average Wait Time: "+sum_wait2/SRTFn);

            System.out.println("Total Idle Time: "+IdleTime);
            System.out.println("Gantt Chart:\n"+RRgantt);

            System.out.println("Average Turn Around Time: "+sum_turnaround2/SRTFn);
            System.out.println("Average Wait Time: "+sum_wait2/SRTFn);
            System.out.println("Total Idle Time:\n"+IdleTime);

            System.out.println("Gantt Chart:\n"+SRTFgantt);*/

        }
        catch(Exception e)
        {
                SRTFgantt="SRTF Error:\n"+e.getMessage();
                JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
        SRTFgantt+="\n\n";

        return SRTFgantt;

    }
    
    //End SRTF
    
    //Begin PP
    
    public String pp(Process[] PP, int n, int ts)
    {
            String PPgantt="";
            String xx="";


            try
            {
                int i=0;
                int j=0;
                //n=n;
                int time=0;
                int PPremain=n;
                int flag=0;
                ts=ts;
                int endTime=0;
                int smallest=20;
                int IdleTime=0;
                //int[] processGantt=new int[100];
                sum_wait2=0;
                sum_turnaround2=0;
                //int bt[10],at[10],bt2[10],at2[10],pr[10],cnt,wait_Time_Sum=0,turn_Time_Sum=0;
                      //int time=0,n,i,smallest,count=0;
                sum_bt=sum_bt;
                int cnt=0;
                int PPn=n;
                //n=m;

                int count=0;

                int[] PPat=new int[21];
                int[] PPbt =new int[21];

                int[] PPrt = new int[21];

                int[] PPpr=new int[21];
                int[] PPpt=new int[21];

                //int ctr;
                //int op;
                double PPsum_bt2=0;

                sum_bt=0;
                for(i=0;i<PPn;i++)
                {
                      PPpr[i]=PP[i].pr;//process
                      PPat[i]=PP[i].at;//arrival time

                      PPbt[i]=PP[i].bt;//burst time

                      sum_bt+=PPbt[i];//total sum of burst times
                      PPrt[i]=PP[i].rt;//burst time

                      PPpt[i]=PP[i].pt;//priority

                }

                PPsum_bt2=sum_bt;


                //PP
                PPpt[20]=31;
                PPat[20]=9999;
                //printf("\n\nProcess\t|Turnaround time|waiting time\n");
                for(time=0;PPremain!=0;time++)
                {
                    smallest=20;
                    for(j=0;j<PPn;j++)
                    {
                        if(PPat[j]<PPat[smallest] && PPrt[j]>0)
                        {
                            smallest=j;
                        }
                    }


                    while(time<PPat[smallest])
                    {
                        time++;
                        IdleTime++;
                        //System.out.print("*");
                        xx+="*";
                        //continue;

                    }

                    smallest=20;
                    for(i=0;i<PPn;i++)
                    {
                        if(PPat[i]<=time && PPpt[i]<PPpt[smallest] && PPrt[i]>0)
                        {
                            smallest=i;
                        }
                    }

                    if(smallest==20)
                    {
                        PPat[20]=9999;
                        smallest=20;
                        for(j=0;j<PPn;j++)
                        {
                            if(PPat[j]<PPat[smallest] && PPrt[j]>0)
                            {
                                smallest=j;
                            }
                        }


                        while(time<PPat[smallest])
                        {
                            time++;
                            IdleTime++;
                            //System.out.print("*");
                            xx+="*";
                            //continue;

                        }

                    }
                    //System.out.print(pr[smallest]+1);
                    PPrt[smallest]--;
                    //xx+=Integer.toString(PPpr[smallest]+1);

                    System.out.print(PPpr[smallest]+1);
                    int v=PPpr[smallest]+64;
                    char dd=(char)v;
                    xx+=Character.toString(dd);

                    if(PPrt[smallest]==0)
                    {
                        PPremain--;
                        endTime=time+1;
                        //printf("P[%d]\t|\t%d\t|\t%d\n",smallest+1,time+1-at[smallest],time+1-at[smallest]-bt[smallest]);
                        //System.out.println("Process number: "+(smallest+1)+" TAT: "+(endTime-PPat[smallest])+" WT: "+(endTime-PPat[smallest]-PPbt[smallest]));
                        System.out.println("Process number: "+PPpr[smallest]+1+" TAT: "+(endTime-PPat[smallest])+" WT: "+(endTime-PPat[smallest]-PPbt[smallest]));
                        //tatID[smallest].setText(Integer.toString(endTime-PPat[smallest]));
                        //wtID[smallest].setText(Integer.toString(endTime-PPat[smallest]-PPbt[smallest]));
                        sum_wait2+=time+1-PPat[smallest]-PPbt[smallest];
                        sum_turnaround2+=time+1-PPat[smallest];
                    }
                }


            PPgantt+="PP Gantt Chart\n";

            PPgantt+="<-"+"0"+"-> ";
            for(i=0;i<xx.length();i++)
            {
                if(i%5==4 && i % 250!=249)
                {
                    PPgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }
                if(i% 250==249)
                {
                    PPgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i))+"\n"+"<-"+Integer.toString(i+1)+"-> ";
                }/*
                else if((i%5)==0 && (i % 250)!=0&&i!=0)
                {
                        FCFSgantt+="<-"+Integer.toString(i)+"-> "+Character.toString(xx.charAt(i));
                }*/
                if(i%5!=4)
                {
                    PPgantt+=Character.toString(xx.charAt(i));
                }		
            }
            //textAvgTAT.setText(Double.toString(sum_turnaround2/PPn));
            //textAvgWT.setText(Double.toString(sum_wait2/PPn));
            PPgantt+="<-"+Integer.toString(xx.length())+"-> ";
            PPgantt+="\n";
            PPgantt+="Average Turn Around Time: "+Double.toString(sum_turnaround2/PPn)+"\n";
            PPgantt+="Average Waiting Time: "+Double.toString(sum_wait2/PPn)+"\n";
            PPgantt+="Total Idle Time: "+Double.toString(IdleTime)+"\n";
            double xxx=PPsum_bt2,ggg=xxx+IdleTime;
            PPgantt+="Total Burst Time: "+Double.toString(xxx)+"\n";
            PPgantt+="Total CPU Time: "+Double.toString(ggg)+"\n";
            PPgantt+="CPU Utilization Rate: "+Double.toString(xxx/ggg)+"\n";
            /*
            printf("\nAvg sum_wait = %f\n",sum_wait*1.0/n);
            printf("Avg sum_turnaround = %f",sum_turnaround*1.0/n);
            printf("\n\nGantt Chart\n");
            System.out.println("Average Turn Around Time: "+sum_turnaround2/n);
            System.out.println("Average Wait Time: "+sum_wait2/n);

            System.out.println("Total Idle Time: "+IdleTime);
            System.out.println("Gantt Chart:\n"+RRgantt);

            System.out.println("Average Turn Around Time: "+sum_turnaround2/n);
            System.out.println("Average Wait Time: "+sum_wait2/n);
            System.out.println("Total Idle Time:\n"+IdleTime);

            System.out.println("Gantt Chart:\n"+xx);*/

        }
        catch(Exception e)
        {
            SRTFgantt="PP Error:\n"+e.getMessage();
            JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.INFORMATION_MESSAGE);
        }
        PPgantt+="\n\n";

        return PPgantt;


    }
    
    //End PP
    
    //Begin Show All
    //End Show All
}        
