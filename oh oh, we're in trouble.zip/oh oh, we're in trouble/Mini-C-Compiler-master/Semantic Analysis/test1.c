//no error
#include<stdio.h>

int foo(int a)
{
	a=a+1;
	return a;
}

void main()
{
        int a,b,c;
	int b;
	b=5;
	int c;
	c=foo(b);
	return;
}
