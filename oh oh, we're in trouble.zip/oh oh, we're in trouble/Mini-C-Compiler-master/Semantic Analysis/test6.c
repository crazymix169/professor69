#include <stdio.h>
int main()
{
	int a=5;
	return 0;
}
void scanf()		//error - standard function redeclared
{
	return;
}
