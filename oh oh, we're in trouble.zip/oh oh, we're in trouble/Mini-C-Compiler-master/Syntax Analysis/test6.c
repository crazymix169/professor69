//with error - for loop syntax error
#include<stdio.h>
int main()
{
	int a=4, i;
	for(i=0;i<10)
	{
		printf("%d",i);
	}
}
