//with error - missing multiple semicolon
#include<stdio.h>
#define x 3
int main()
{
	//int c=4;
	int b=5
	/* multiline
	comment*/
	printf("%d",b);
        printf("this is for checking git commit");
	while(b<10)
	{
		printf("%d", b)
		b++;
	}
}
