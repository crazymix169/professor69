#include<stdio.h>
void foo()
{
	return;
}
void main()
{
	int a;
	foo();
	//user defined function
}
