# Mini C Compiler
The project aims to build a mini compiler for C language
#### The project team:
* Shivananda D (15CO148)
* Yeshwanth R (15CO154)

The front-end of compiler consisting of the following four phases is built:
1) Lexical Analysis
2) Syntax Analysis
3) Semantic Analysis
4) Intermediate Code Generation
