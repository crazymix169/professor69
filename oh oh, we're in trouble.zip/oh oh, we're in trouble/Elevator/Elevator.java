import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;


public class Elevator
{
	int x=0;
	int y=653;
	int sum,xx;
	JFrame frame = new JFrame();
	JPanel p = new JPanel();
	JPanel pSouth = new JPanel();//makes the pCenterSouth a grid layout
	JPanel pCenter = new JPanel(new BorderLayout());//makes a center panel thats border layout
	JPanel pWest = new JPanel(new GridLayout(10, 1));//Creates a panel that has grid format

	private static final int MAX = 11;//for my string of buttons

	public Elevator()
	{

		MoveLvlsActionListener buttonListener = new MoveLvlsActionListener();
		for(int i = 1; i < MAX ; i++)
                {
			String text = String.valueOf(i);
			JButton levels = new JButton("Level " + text);
			levels.addActionListener(buttonListener);
			pSouth.add(levels);
		}
	}
	/*
	 * Create View makes my labels buttons and the elevator visible
	 * */
	public void createView()
	{
		frame.setTitle("Elevator Simulation");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setSize(1000,800);
		frame.add(p);

		p.setLayout(new BorderLayout());//makes frame sized panel in border layout
		p.add(pWest, BorderLayout.WEST);//pWest will go on the west side of p

		//Draws my labels on the left side of p panel
		//one under the other


		p.add(pCenter);
		p.add(pSouth, BorderLayout.SOUTH);//makes the pSouth panel on the south border of p

		//Creates two rows of buttons at the south side  of the pCenter panel
			pCenter.add(drawPanel);
	}

	private class MoveLvlsActionListener implements ActionListener
	{
		private String baseFloor = "Level 1";
		private String curFloor = baseFloor;
	      private boolean firstClick = true;

	      public void actionPerformed(ActionEvent e)
              {
	         // here actionCommand is the button's text
	         String nFloor = e.getActionCommand();
	        //int nFloor = Integer.parseInt(actionCommand);

	         if (firstClick)
                 {


	            if(curFloor.equals(baseFloor))
	            {

	            	if(nFloor.equals("Level 10"))
                        {

	            	 String neFloor = nFloor;
	            	 String delims = "[ ]+";
	   	       		 String[] token = neFloor.split(delims);
	   	       		 int topFloor = Integer.parseInt(token[1]);
	   	       		 System.out.println(topFloor);
	   	       		 String[]token2 = curFloor.split(delims);
	   	       		 int basFloor = Integer.parseInt(token2[1]);
	   	       		 System.out.println("curFloor token " + basFloor);
	   	       		 if (topFloor>basFloor)
                                 {
	   	       			 int sum1 = topFloor - basFloor;
	   	       			 System.out.println(sum1);
	   	       			 goUp(sum1);
	   	       		 }
	            	}
                        else
                        {
	            		int re = nFloor.compareTo(curFloor);
		            	System.out.println("new " +nFloor);
		            	System.out.println("first " +curFloor);
		            	System.out.println(re);
		            	if (re>0)
		            		goUp(re);
		            	else
		            		goDown(Math.abs(re));
	            	}
	            }

	             curFloor = nFloor;
	            System.out.println("First Number is: " + curFloor);

	            firstClick = false;
	         }
                 else
                 {

	           String newFloor = nFloor;
	           System.out.println("first " +curFloor);
	           System.out.println("new " +newFloor);

	           if(newFloor.equals("Level 10")){
	        	 String delims = "[ ]+";
	       		 String[] token = newFloor.split(delims);
	       		 int topFloor = Integer.parseInt(token[1]);
	       		 System.out.println(topFloor);

	       		 String[] token2 = curFloor.split(delims);
	       		 int numCurFloor = Integer.parseInt(token2[1]);
	       		 System.out.println(numCurFloor);

	       		 if (topFloor > numCurFloor)
                         {
	       			 int sum = topFloor - numCurFloor;
                     //for(int j=numCurFloor;j<=sum;j++)
	       			 goUp(sum);
	       		 }

	           }else if(curFloor.equals("Level 10")){
		        	 String delims2 = "[ ]+";
		        	 String[] tok = curFloor.split(delims2);
		        	 int topaFloor = Integer.parseInt(tok[1]);

		        	 String[] tok2 = newFloor.split(delims2);
		        	 int nuFloor = Integer.parseInt(tok2[1]);

		        	   if(nuFloor < topaFloor){
		        		   sum = topaFloor - nuFloor;
/*
		        		   for(xx=10;xx>=nuFloor;xx--)
		        		   {
		        			   //System.out.println(sum);
		        			   //goDown(sum);
		        			   //System.out.println(xx);
		        			   //goDown(xx);



					   	   }*/
					   	   System.out.println(sum);
					   	   goDown(sum);

		        	   }

	       		}
	           if(!(curFloor.equals("Level 10")) && !(newFloor.equalsIgnoreCase("Level 10"))){

	           int r = newFloor.compareTo(curFloor);

	           System.out.println(r);

	              if(r>0)
	        	      goUp(r);
	             else
	             	  goDown(Math.abs(r));

	       		}
	              curFloor = newFloor;
	              System.out.println("new first " +curFloor);
	             firstClick = false;
	        }
	}
}

	MyDrawPanel drawPanel=new MyDrawPanel();

	public void goDown(int a){
		int num = 72*a;
		for (int i=0; i<num;i++){
			y++;

				drawPanel.repaint();


			try{


						Thread.sleep(1);


		}catch(Exception ex){}



		 }
	}


	public void goUp(int a){
		int num = 72*a;
		for (int i=num; i>0;i--){
			y--;
				drawPanel.repaint();



			try{

				Thread.sleep(1);

			}catch(Exception ex){} }

	}

	class MyDrawPanel extends JPanel
	{
		public void paintComponent(Graphics g)
		{
			g.setColor(Color.white);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			g.setColor(Color.green);
			g.fillRect(x, y, 60, 70);
		}
	}


	public static void main(String[]args)
	 {
		 Elevator i= new Elevator();
		 i.createView();

	}
}