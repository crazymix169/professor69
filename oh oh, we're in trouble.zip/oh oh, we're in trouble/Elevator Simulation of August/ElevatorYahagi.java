
import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

// Java extension packages
import javax.swing.*;

public class ElevatorYahagi extends JFrame
   implements ActionListener
{
	private JTextField textStart,textRider,textEnd,textCurrLevel;
	   //private JTextField in[]=new JTextField[20];

	   private JButton resetButton,clear1Button,clear2Button,clearallButton;
	   private JButton save1Button,save2Button,exitButton;
	   //private JButton sumButton,diffButton,productButton,quotientButton,squareButton;

	   private JButton qButton,wButton,eButton,rButton,tButton,yButton,uButton,iButton,oButton,pButton,backspaceButton;
	   private JButton aButton,sButton,dButton,fButton,gButton,hButton,jButton,kButton,lButton;
	   private JButton zButton,xButton,cButton,vButton,bButton,nButton,mButton;

	   private JButton zeroButton,oneButton,twoButton,threeButton,fourButton;
	   private JButton fiveButton,sixButton,sevenButton,eightButton,nineButton;
	   private JButton tenButton,elevenButton,twelveButton,thirteenButton,forteenButton;
	   private JButton fifteenButton,sixteenButton,seventeenButton,eighteenButton,nineteenButton;

	   private JLabel v[]=new JLabel[3];

	   private JTextField vfloor[]=new JTextField[20];


	   private double num;
	   int yyyy=26;

	    DecimalFormat p33 = new DecimalFormat( "0" );

	double num1,num2,output1;

	public ElevatorYahagi()
	{
		JFrame frame=new JFrame("Elevator Simulation");
		      //super( "Computing the values of different bases from base 2 to 36" --> 0-9 and A to Z
			  frame.setLayout(null);

				frame.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						System.exit(0);
					}
				});


				frame.setSize(1010,810);

				Font f = new Font("JSL Ancient", Font.ITALIC, 12);
				Font fbi = new Font("JSL Ancient", Font.BOLD | Font.ITALIC,  12);
				Font fp = new Font("JSL Ancient", Font.PLAIN,  12);
		  		Font fb = new Font("JSL Ancient", Font.BOLD ,  16);

				//frame.getContentPane();


		      // get content pane and set its layout
		      //Container container = getContentPane();
		      //container.setLayout( null );

		      int xx=521;
		      int i=0;

		      for(i=0;i<20;i++)
		      {
				  vfloor[i] =  new JTextField( Integer.toString(i), SwingConstants.LEFT);
				  vfloor[i].setFont(fb);
				  vfloor[i].setForeground(Color.BLACK);
				  vfloor[i].setBackground(Color.MAGENTA);
				  vfloor[i].setBounds(21,xx,25,20);
			  	  frame.getContentPane().add( vfloor[i]);
			  	  xx-=20;

			  }

			  vfloor[0].setBackground(Color.CYAN);

		      v[0] =  new JLabel( "Starting Floor:", SwingConstants.LEFT);
			  v[0].setFont(fb);
			  v[0].setForeground(Color.BLACK);
			  v[0].setBounds(1,1,200,40);
			  frame.getContentPane().add( v[0]);



			  textStart = new JTextField("0");
			  textStart.setFont(fb);
			  textStart.setBounds(202,1,400,40);
		      frame.getContentPane().add( textStart );

		      resetButton=new JButton("Clear Starting Floor");
		      resetButton.setBackground(Color.MAGENTA);
			  resetButton.setBounds(602,1,200,40);
			  frame.getContentPane().add(resetButton);

			  resetButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  output1=0;


							textStart.setText("");


					  }
				}
			  );



			  //namer2.addActionListener(this);
			  //namer2.addKeyListener(aug);

			  v[1] =  new JLabel( "Name of Rider:", SwingConstants.LEFT);
			  v[1].setFont(fb);
			  v[1].setForeground(Color.BLACK);
			  v[1].setBounds(1,41,200,40);
			  frame.getContentPane().add( v[1]);


			  textRider = new JTextField();
			  textRider.setFont(fb);
			  textRider.setBounds(202,41,400,40);
		      frame.getContentPane().add( textRider );

			  clear1Button=new JButton("Clear Rider Name");
			  clear1Button.setBackground(Color.CYAN);
			  clear1Button.setBounds(602,41,200,40);
			  frame.getContentPane().add(clear1Button);

			  clear1Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						  num1=0;
						  textRider.setText("");

					  }
				}
			  );

			  v[2] =  new JLabel( "Desired Floor:", SwingConstants.LEFT);
			  v[2].setFont(fb);
			  v[2].setForeground(Color.BLACK);
			  v[2].setBounds(1,81,200,40);
			  frame.getContentPane().add( v[2]);


			  textEnd = new JTextField();
			  textEnd.setFont(fb);
			  textEnd.setBounds(202,81,400,40);
		      frame.getContentPane().add( textEnd );



			  clear2Button=new JButton("Clear End Floor");
			  clear2Button.setBackground(Color.YELLOW);
			  clear2Button.setBounds(602,81,200,40);
			  frame.getContentPane().add(clear2Button);

			  clear2Button.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

						 num2=0;
   						 textEnd.setText("");

					  }
				}
			  );




			  //Letters
			  //Top Letters
			  qButton=new JButton("Q");
			  qButton.setBackground(Color.CYAN);
			  qButton.setBounds(170,161,50,40);
			  frame.getContentPane().add(qButton);

			  qButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="Q";
						  textRider.setText(namer21);

					  }
				}
			  );

			  wButton=new JButton("W");
			  wButton.setBackground(Color.CYAN);
			  wButton.setBounds(220,161,50,40);
			  frame.getContentPane().add(wButton);

			  qButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="W";
						  textRider.setText(namer21);

					  }
				}
			  );

			  eButton=new JButton("E");
			  eButton.setBackground(Color.CYAN);
			  eButton.setBounds(270,161,50,40);
			  frame.getContentPane().add(eButton);

			  eButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="E";
						  textRider.setText(namer21);

					  }
				}
			  );

			  rButton=new JButton("R");
			  rButton.setBackground(Color.CYAN);
			  rButton.setBounds(320,161,50,40);
			  frame.getContentPane().add(rButton);

			  rButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="R";
						  textRider.setText(namer21);

					  }
				}
			  );

			  tButton=new JButton("T");
			  tButton.setBackground(Color.CYAN);
			  tButton.setBounds(370,161,50,40);
			  frame.getContentPane().add(tButton);

			  tButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="T";
						  textRider.setText(namer21);

					  }
				}
			  );

			  yButton=new JButton("Y");
			  yButton.setBackground(Color.CYAN);
			  yButton.setBounds(420,161,50,40);
			  frame.getContentPane().add(yButton);

			  yButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="Y";
						  textRider.setText(namer21);

					  }
				}
			  );

			  uButton=new JButton("U");
			  uButton.setBackground(Color.CYAN);
			  uButton.setBounds(470,161,50,40);
			  frame.getContentPane().add(uButton);

			  uButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="U";
						  textRider.setText(namer21);

					  }
				}
			  );

			  iButton=new JButton("I");
			  iButton.setBackground(Color.CYAN);
			  iButton.setBounds(520,161,50,40);
			  frame.getContentPane().add(iButton);

			  iButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="I";
						  textRider.setText(namer21);

					  }
				}
			  );

			  oButton=new JButton("O");
			  oButton.setBackground(Color.CYAN);
			  oButton.setBounds(570,161,50,40);
			  frame.getContentPane().add(oButton);

			  oButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="O";
						  textRider.setText(namer21);

					  }
				}
			  );

			  pButton=new JButton("P");
			  pButton.setBackground(Color.CYAN);
			  pButton.setBounds(620,161,50,40);
			  frame.getContentPane().add(pButton);

			  pButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="P";
						  textRider.setText(namer21);

					  }
				}
			  );

			  backspaceButton=new JButton("BackSpace");
			  backspaceButton.setBackground(Color.CYAN);
			  backspaceButton.setBounds(670,161,200,40);
			  frame.getContentPane().add(backspaceButton);

			  backspaceButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						  /*
						  String namer21="";
						  namer21=textRider.getText();
						  namer21+="Q";
						  textRider.setText(namer21);*/

						  String news = null;

						  if (textRider.getText().length() > 0)
						  { 	//TextArea is a textfield

							  StringBuilder strB = new StringBuilder(textRider.getText());

							  int strlen = strB.length();

							  strB.deleteCharAt(strlen-1);

							  news = strB.toString();

							  textRider.setText(news);/////set the updated text
						  }

					  }
				}
			  );


				//middle letters
			  aButton=new JButton("A");
			  aButton.setBackground(Color.YELLOW);
			  aButton.setBounds(170,201,50,40);
			  frame.getContentPane().add(aButton);

			  aButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="A";
						  textRider.setText(namer21);

					  }
				 }
				);

			sButton=new JButton("S");
			  sButton.setBackground(Color.YELLOW);
			  sButton.setBounds(220,201,50,40);
			  frame.getContentPane().add(sButton);

			  sButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="S";
						  textRider.setText(namer21);

					  }
				 }
				);

				dButton=new JButton("D");
			  dButton.setBackground(Color.YELLOW);
			  dButton.setBounds(270,201,50,40);
			  frame.getContentPane().add(dButton);

			  dButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="D";
						  textRider.setText(namer21);

					  }
				 }
				);

			fButton=new JButton("F");
			  fButton.setBackground(Color.YELLOW);
			  fButton.setBounds(320,201,50,40);
			  frame.getContentPane().add(fButton);

			  fButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="F";
						  textRider.setText(namer21);

					  }
				 }
				);

			gButton=new JButton("G");
			  gButton.setBackground(Color.YELLOW);
			  gButton.setBounds(370,201,50,40);
			  frame.getContentPane().add(gButton);

			  gButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="G";
						  textRider.setText(namer21);

					  }
				 }
				);

			hButton=new JButton("H");
			  hButton.setBackground(Color.YELLOW);
			  hButton.setBounds(420,201,50,40);
			  frame.getContentPane().add(hButton);

			  hButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="H";
						  textRider.setText(namer21);

					  }
				 }
				);

			jButton=new JButton("J");
			  jButton.setBackground(Color.YELLOW);
			  jButton.setBounds(470,201,50,40);
			  frame.getContentPane().add(jButton);

			  jButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="J";
						  textRider.setText(namer21);

					  }
				 }
				);

			kButton=new JButton("K");
			  kButton.setBackground(Color.YELLOW);
			  kButton.setBounds(520,201,50,40);
			  frame.getContentPane().add(kButton);

			  kButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="K";
						  textRider.setText(namer21);

					  }
				 }
				);

			lButton=new JButton("L");
			  lButton.setBackground(Color.YELLOW);
			  lButton.setBounds(570,201,50,40);
			  frame.getContentPane().add(lButton);

			  lButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						  namer21=textRider.getText();
						  namer21+="L";
						  textRider.setText(namer21);

					  }
				 }
				);




			 //bottom letters
			 zButton=new JButton("Z");
			 zButton.setBackground(Color.CYAN);
			  zButton.setBounds(170,241,50,40);
			  frame.getContentPane().add(zButton);

			  zButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="Z";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			 xButton=new JButton("X");
			 xButton.setBackground(Color.CYAN);
			  xButton.setBounds(220,241,50,40);
			  frame.getContentPane().add(xButton);

			  xButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="X";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			cButton=new JButton("C");
			 cButton.setBackground(Color.CYAN);
			  cButton.setBounds(270,241,50,40);
			  frame.getContentPane().add(cButton);

			  cButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="C";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			vButton=new JButton("V");
			 vButton.setBackground(Color.CYAN);
			  vButton.setBounds(320,241,50,40);
			  frame.getContentPane().add(vButton);

			  vButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="V";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			bButton=new JButton("B");
			 bButton.setBackground(Color.CYAN);
			  bButton.setBounds(370,241,50,40);
			  frame.getContentPane().add(bButton);

			  bButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="B";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			nButton=new JButton("N");
			 nButton.setBackground(Color.CYAN);
			  nButton.setBounds(420,241,50,40);
			  frame.getContentPane().add(nButton);

			  nButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="N";
						  textRider.setText(namer21);

					  }
				 }
		  		);

			mButton=new JButton("M");
			 mButton.setBackground(Color.CYAN);
			  mButton.setBounds(470,241,50,40);
			  frame.getContentPane().add(mButton);

			  mButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {
						 String namer21="";
						 namer21=textRider.getText();
						 namer21+="M";
						  textRider.setText(namer21);

					  }
				 }
		  		);



			  //digits

		  	  zeroButton=new JButton("0");
		  	  zeroButton.setBackground(Color.YELLOW);
			  	  zeroButton.setBounds(100,300,60,40);
			  	  frame.getContentPane().add(zeroButton);

			  	  zeroButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {




							String namer21=textRider.getText();
							textEnd.setText("0");
							String end=textEnd.getText();

							start(namer21, end);


			  			  }
			  		 }
		  		);
                                  oneButton=new JButton("1");
			 oneButton.setBackground(Color.CYAN);
			  oneButton.setBounds(165,300,60,40);
			  frame.getContentPane().add(oneButton);

			  oneButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("1");
							String end=textEnd.getText();

							start(namer21, end);


					  }
				 }
		  		);
                          twoButton=new JButton("2");
			 twoButton.setBackground(Color.YELLOW);
			  twoButton.setBounds(230,300,60,40);
			  frame.getContentPane().add(twoButton);

			  twoButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

							String namer21=textRider.getText();
							textEnd.setText("2");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);
                          threeButton=new JButton("3");
			  threeButton.setBackground(Color.CYAN);
			  threeButton.setBounds(295,300,60,40);
			  frame.getContentPane().add(threeButton);

			  threeButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

							String namer21=textRider.getText();
							textEnd.setText("3");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          fourButton=new JButton("4");
			  fourButton.setBackground(Color.YELLOW);
			  fourButton.setBounds(360,300,60,40);
			  frame.getContentPane().add(fourButton);

			  fourButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("4");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          fiveButton=new JButton("5");
			  fiveButton.setBackground(Color.CYAN);
			  fiveButton.setBounds(425,300,60,40);
			  frame.getContentPane().add(fiveButton);

			  fiveButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("5");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          sixButton=new JButton("6");
			  sixButton.setBackground(Color.YELLOW);
			  sixButton.setBounds(490,300,60,40);
			  frame.getContentPane().add(sixButton);

			  sixButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("6");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          sevenButton=new JButton("7");
			  sevenButton.setBackground(Color.CYAN);
			  sevenButton.setBounds(555,300,60,40);
			  frame.getContentPane().add(sevenButton);

			  sevenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("7");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				}
			  );

			  eightButton=new JButton("8");
			  eightButton.setBackground(Color.YELLOW);
			  eightButton.setBounds(620,300,60,40);
			  frame.getContentPane().add(eightButton);

			  eightButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

							String namer21=textRider.getText();
							textEnd.setText("8");
							String end=textEnd.getText();

							start(namer21, end);




					  }
				}
			  );

                          nineButton=new JButton("9");
			  nineButton.setBackground(Color.CYAN);
			  nineButton.setBounds(685,300,60,40);
			  frame.getContentPane().add(nineButton);

			  nineButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("9");
							String end=textEnd.getText();

							start(namer21, end);


					  }
				}
			  );




                          tenButton=new JButton("10");
		  	  tenButton.setBackground(Color.YELLOW);
			  	  tenButton.setBounds(100,350,60,40);
			  	  frame.getContentPane().add(tenButton);

			  	  tenButton.addActionListener(

			  		new ActionListener()
			  		{
			  			  public void actionPerformed(ActionEvent event)
			  			  {




							String namer21=textRider.getText();
							textEnd.setText("10");
							String end=textEnd.getText();

							start(namer21, end);


			  			  }
			  		 }
		  		);
                                  elevenButton=new JButton("11");
			 elevenButton.setBackground(Color.CYAN);
			  elevenButton.setBounds(165,350,60,40);
			  frame.getContentPane().add(elevenButton);

			  elevenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {

							String namer21=textRider.getText();
							textEnd.setText("11");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);
                          twelveButton=new JButton("12");
			 twelveButton.setBackground(Color.YELLOW);
			  twelveButton.setBounds(230,350,60,40);
			  frame.getContentPane().add(twelveButton);

			  twelveButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


						String namer21=textRider.getText();
						textEnd.setText("12");
						String end=textEnd.getText();

						start(namer21, end);



					  }
				 }
		  		);
                          thirteenButton=new JButton("13");
			  thirteenButton.setBackground(Color.CYAN);
			  thirteenButton.setBounds(295,350,60,40);
			  frame.getContentPane().add(thirteenButton);

			  thirteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("13");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          forteenButton=new JButton("14");
			  forteenButton.setBackground(Color.YELLOW);
			  forteenButton.setBounds(360,350,60,40);
			  frame.getContentPane().add(forteenButton);

			  forteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("14");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          fifteenButton=new JButton("15");
			  fifteenButton.setBackground(Color.CYAN);
			  fifteenButton.setBounds(425,350,60,40);
			  frame.getContentPane().add(fifteenButton);

			  fifteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("15");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				 }
		  		);

                          sixteenButton=new JButton("16");
			  sixteenButton.setBackground(Color.YELLOW);
			  sixteenButton.setBounds(490,350,60,40);
			  frame.getContentPane().add(sixteenButton);

			  sixteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


						String namer21=textRider.getText();
						textEnd.setText("16");
						String end=textEnd.getText();

						start(namer21, end);



					  }
				 }
		  		);

                          seventeenButton=new JButton("17");
			  seventeenButton.setBackground(Color.CYAN);
			  seventeenButton.setBounds(555,350,60,40);
			  frame.getContentPane().add(seventeenButton);

			  seventeenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("17");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				}
			  );

			  eighteenButton=new JButton("18");
			  eighteenButton.setBackground(Color.YELLOW);
			  eighteenButton.setBounds(620,350,60,40);
			  frame.getContentPane().add(eighteenButton);

			  eighteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


                                            String namer21=textRider.getText();
                                            textEnd.setText("18");
                                            String end=textEnd.getText();

                                            start(namer21, end);




					  }
				}
			  );

                          nineteenButton=new JButton("19");
			  nineteenButton.setBackground(Color.CYAN);
			  nineteenButton.setBounds(685,350,60,40);
			  frame.getContentPane().add(nineteenButton);

			  nineteenButton.addActionListener(

				new ActionListener()
				{
					  public void actionPerformed(ActionEvent event)
					  {


							String namer21=textRider.getText();
							textEnd.setText("19");
							String end=textEnd.getText();

							start(namer21, end);



					  }
				}
			  );

                          clearallButton=new JButton("Clear all");
		  	  clearallButton.setBackground(Color.MAGENTA);
                            clearallButton.setBounds(170,465,460,40);
                            frame.getContentPane().add(clearallButton);

                            clearallButton.addActionListener(

                                  new ActionListener()
                                  {
                                            public void actionPerformed(ActionEvent event)
                                            {
                                                    //clearer();
                                                   num1=0;
                                                   num2=0;
                                                   output1=0;


                                                   textStart.setText("");
                                                   textRider.setText("");
                                                   textEnd.setText("");

                                            }
                                   }
		  		);

			  exitButton=new JButton("Quit Application");
			  exitButton.setBackground(Color.GREEN);
			  exitButton.setBounds(170,510,460,40);
			  frame.getContentPane().add(exitButton);

			  exitButton.addActionListener(

			  	new ActionListener()
			  	{
			  		  public void actionPerformed(ActionEvent event)
			  		  {
						  System.gc();
						  System.exit(0);
			  		  }
			  	}
			  );

			  textCurrLevel=new JTextField("");
			  textCurrLevel.setBackground(Color.GREEN);
			  textCurrLevel.setBounds(170,555,460,40);
			  frame.getContentPane().add(textCurrLevel);



			  //computeButton.addActionListener(this);


			  textRider.setEditable(!false);
			  textEnd.setEditable(!false);
			  textStart.setEditable(!false);

		      //setSize( 900, 750 );
		      frame.setVisible( true );
      		frame.setResizable(false);

	}

	public void actionPerformed( ActionEvent event )
	   {


	   }






	   private void start(String name,String endLevel)
	   {
			Thread worker;
			worker = new Thread()
			{
				public void run()
				{




					try
					{
							String namer21=name;

							String startLevel=textStart.getText();
							if(startLevel.equals(""))
							{
								textStart.setText("0");
								startLevel=textStart.getText();

							}
							int start1=Integer.parseInt(startLevel);
							int end1=Integer.parseInt(endLevel);

							int i=0;
							int j=0;
							for(i=0;i<10;i++)
								  {
									vfloor[i].setBackground(Color.MAGENTA);
								  }

						    textCurrLevel.setBackground(Color.GREEN);
						    Thread.sleep(3000);

							textCurrLevel.setText("Starting Level is: "+ Integer.toString(start1)+" Ridden by: "+name);
							textCurrLevel.setBackground(Color.MAGENTA);
							Thread.sleep(3000);

							if(end1-start1>0)
							{


								for(j=start1;j<=end1;j++)
								{
									vfloor[j].setBackground(Color.CYAN);
									textCurrLevel.setText("Current Level is: "+ Integer.toString(j)+" Ridden by: "+name);
									textCurrLevel.setBackground(Color.CYAN);
									Thread.sleep(1000);
									vfloor[j].setBackground(Color.MAGENTA);
									textCurrLevel.setBackground(Color.MAGENTA);
									Thread.sleep(1000);
									//Thread.sleep(100);
									System.out.println(j);
									if(j==end1)
									{
										vfloor[j].setBackground(Color.CYAN);
										textCurrLevel.setText("We arrived at the desired Level which is: "+ Integer.toString(j)+" Ridden by: "+name);
										textCurrLevel.setBackground(Color.RED);
									}
								}
							 }
							else if(end1-start1==0)
							{
								textCurrLevel.setText("Current Level is: "+ Integer.toString(start1)+" Ridden by: "+name);

								Thread.sleep(1000);

								System.out.println(end1);

								vfloor[end1].setBackground(Color.CYAN);
								textCurrLevel.setText("We arrived at the desired Level which is: "+ Integer.toString(end1)+" Ridden by: "+name);

							}
							else if(end1-start1<0)
							{


								for(j=start1;j>=end1;j--)
								{
									vfloor[j].setBackground(Color.CYAN);
									textCurrLevel.setText("Current Level is: "+ Integer.toString(j)+" Ridden by: "+name);
									textCurrLevel.setBackground(Color.CYAN);
									Thread.sleep(1000);
									vfloor[j].setBackground(Color.MAGENTA);
									textCurrLevel.setBackground(Color.MAGENTA);
									Thread.sleep(1000);
									//Thread.sleep(100);
									System.out.println(j);
									if(j==end1)
									{
										vfloor[j].setBackground(Color.CYAN);
										textCurrLevel.setText("We arrived at the desired Level which is: "+ Integer.toString(j)+" Ridden by: "+name);
										textCurrLevel.setBackground(Color.RED);
									}
								}
							}


						  textStart.setText(endLevel);


				  }
				  catch (Exception e)
				  {

				  }

				}
			};

			worker.start();
	   }



	// execute application
	   public static void main( String args[] )
	   {
               SwingUtilities.invokeLater(new Runnable() {

                @Override
                public void run() {
                 ElevatorYahagi application = new ElevatorYahagi();

                application.setDefaultCloseOperation(
	         JFrame.EXIT_ON_CLOSE );
                }
               });

   }

}