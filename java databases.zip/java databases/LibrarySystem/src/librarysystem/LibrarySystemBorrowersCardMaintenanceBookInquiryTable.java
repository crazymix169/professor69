/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LibrarySystemBorrowersCardMaintenanceBookInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int bookid;
    String booktitle;
    String description;
    String authors;
    
    
    public LibrarySystemBorrowersCardMaintenanceBookInquiryTable
    (            
        int bookid,
        String booktitle,
        String description,
        String authors
        
    )
            
    {
        this.bookid=bookid;   
        this.booktitle=booktitle;
        this.description=description;
        this.authors=authors;        
           
              
    }
    
    public int getBookID()
    {
        return bookid;
    }
    
    public String getBookTitle()
    {
        return booktitle;
    }
    public String getDescription()
    {
        return description;
    }
    public String getAuthors()
    {
        return authors;
    }
    
    
}
