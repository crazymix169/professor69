/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LibrarySystemBorrowersCardTable {

    /**
     * @param args the command line arguments
     */
      
    int borrowerscardid;
    int bookid;
    int borrowerid;
    int librarianid;
    String bookquality;
    String bookstatus;
    String dateandtimeupdated;
    String comments;
    
       
    
    public LibrarySystemBorrowersCardTable
    (            
        int borrowerscardid,
        int bookid,
        int borrowerid,
        int librarianid,
        String bookquality,
        String bookstatus,
        String dateandtimeupdated,
        String comments
        
    )
            
    {
        this.borrowerscardid=borrowerscardid;        
        this.bookid=bookid;
        this.borrowerid=borrowerid;
        this.librarianid=librarianid;
        this.bookquality=bookquality;        
        this.bookstatus=bookstatus;
        this.dateandtimeupdated=dateandtimeupdated;
        this.comments=comments;
            
    }
    
    public int getBorrowersCardID()
    {
        return borrowerscardid;
    }
    
    public int getBookID()
    {
        return bookid;
    }
    
    public int getBorrowerID()
    {
        return borrowerid;
    }
    public int getLibrarianID()
    {
        return librarianid;
    }
    public String getBookQuality()
    {
        return bookquality;
    }    
    public String getBookStatus()
    {
        return bookstatus;
    }
    public String getDateAndTimeUpdated()
    {
        return dateandtimeupdated;
    }
    public String getComments()
    {
        return comments;
    }
    
}
