/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LibrarySystemAuthorTable {

    /**
     * @param args the command line arguments
     */
      
    

                
    int authorid;
    String education;
    String suffix;
    String role;
    String comment;
    String firstname;
    String middlename;
    String lastname;
    String sex;
    String birthdate;               
    String address;
    String hobby;
       
    
    public LibrarySystemAuthorTable
    (            
        int authorid,
        String education,
        String suffix,
        String role,
        String comment,
        String firstname,
        String middlename,
        String lastname,
        String sex,
        String birthdate,            
        String address,
        String hobby
    )
            
    {
        this.authorid=authorid;        
        this.education=education;
        this.suffix=suffix;
        this.role=role;
        this.comment=comment;        
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.sex=sex;
        this.birthdate=birthdate;       
        this.address=address;
        this.hobby=hobby;       
    }
    
    public int getAuthorID()
    {
        return authorid;
    }
    
    public String getEducation()
    {
        return education;
    }
    
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }
    public String getComment()
    {
        return comment;
    }    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getSex()
    {
        return sex;
    }
    public String getBirthDate()
    {
        return birthdate;
    }    
    
    public String getAddress()
    {
        return address;
    }
    public String getHobby()
    {
        return hobby;
    }   
}
