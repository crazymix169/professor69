/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

import java.awt.Component;
import java.beans.PropertyVetoException;
import java.lang.System.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author crazymix69
 */
public class InternalFrameDemo extends javax.swing.JFrame { 
    


    /**
     * Creates new form InternalFrameDemo
     */
    
    JDesktopPane desktop;
    String Username;
    String Userid;
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    //labelUserID=new javax.swing.JLabel();
    /*
    public InternalFrameDemo(String username, String userid) {
        
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        initComponents();
        labelUserID.setVisible(false);
        labelUserName.setVisible(false);
        labelUserID.setText(userid);
        labelUserName.setText(username);
        Userid=userid;
        Username=username;
        JOptionPane.showMessageDialog(null, labelUserName.getText(), labelUserID.getText(), HEIGHT);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }*/
    public void setID(String userid, String username) 
    {
        Userid = userid;
        Username=username;
    }
    
    public void enabler()
    {
        fileMenu.setEnabled(!false);
        TransactionMaintenanceMenu.setEnabled(!false);
        helpMenu.setEnabled(!false);
        jMenuLogger.setEnabled(!false);
        jMenuItemLogout.setVisible(!false);
        jMenuItemLoginForm.setVisible(false);
    }
    
    public void disabler()
    {
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuLogger.setEnabled(false);
        jMenuItemLogout.setVisible(false);
        jMenuItemLoginForm.setVisible(false);
        
    }       
    
    public void Logz()
    {
        jMenuItemLoginForm.setVisible(!false);
        jMenuItemLogout.setVisible(false);
        jMenuLogger.setEnabled(false);
    }      
    
    public void LogzBack()
    {
        jMenuItemLoginForm.setVisible(false);
        jMenuItemLogout.setVisible(!false);
        jMenuLogger.setEnabled(!false);
        
    }
    
    
    public InternalFrameDemo()
    {
        
        super("Library System");
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        
        initComponents();
        
        
        
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuItemLogout.setVisible(false);
        //jMenuLogger.setEnabled(false);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }
    
    /*
    User Login, Logtrail and User maintenance Forms
    */
    
    protected void createUserMaintenanceFrame()
    {
        LibrarySystemUserMaintenance frame = new LibrarySystemUserMaintenance();
       
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //login form
    protected void createFrameLoginForm()
    {
        
        
        
        LibrarySystemLoginForm frame = new LibrarySystemLoginForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //logtrail maintenance
    protected void createFrameUserLogtrailMaintenance()
    {
        
        
        
        LibrarySystemUserLogtrailMaintenance frame = new LibrarySystemUserLogtrailMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    /*
    Transaction of Library System
    */
    
    //Author maintenance
    protected void createFrameAuthorMaintenance()
    {
        
        
        
        LibrarySystemAuthorMaintenance frame = new LibrarySystemAuthorMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Book maintenance
    protected void createFrameBookMaintenance()
    {
        
        
        
        LibrarySystemBookMaintenance frame = new LibrarySystemBookMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Borrower Maintenance
    protected void createFrameBorrowerMaintenance()
    {
        
        
        
        LibrarySystemBorrowerMaintenance frame = new LibrarySystemBorrowerMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //librarian Maintenance
    protected void createFrameLibrarianMaintenance()
    {
        
        
        
        LibrarySystemLibrarianMaintenance frame = new LibrarySystemLibrarianMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    
    
    
    
    
    
    //Borrower's Card Form Maintenance
    protected void createFrameBorrowersCardMaintenance()
    {
        
        
        
        LibrarySystemBorrowersCardMaintenance frame = new LibrarySystemBorrowersCardMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Borrower's Card Trail Form Maintenance
    protected void createFrameBorrowersCardTrailMaintenance()
    {
        
        
        
        LibrarySystemBorrowersCardTrailMaintenance frame = new LibrarySystemBorrowersCardTrailMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
   
    
    
        
    
    
    
    
    
    
    
    //content and about the author
    
    /*
    Content Form
    */
    protected void createFrameContentForm()
    {
        
        
        
        LibrarySystemContentForm frame = new LibrarySystemContentForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //about the authoer
    protected void createFrameAboutTheAuthorForm()
    {
        
        
        
        LibrarySystemTheAuthorForm frame = new LibrarySystemTheAuthorForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        UserMaintenanceMenuItem = new javax.swing.JMenuItem();
        LogtrailMaintenanceMenuItem = new javax.swing.JMenuItem();
        TransactionMaintenanceMenu = new javax.swing.JMenu();
        AuthorMaintenanceMenuItem = new javax.swing.JMenuItem();
        BookMaintenanceMenuItem = new javax.swing.JMenuItem();
        BorrowerMaintenanceMenuItem = new javax.swing.JMenuItem();
        LibrarianMaintenanceMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        BorrowersCardMaintenanceMenuItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        BorrowersCardTrailMaintenanceMenuItem = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        helpMenu = new javax.swing.JMenu();
        contentMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();
        jMenuLogger = new javax.swing.JMenu();
        jMenuItemLoginForm = new javax.swing.JMenuItem();
        jMenuItemLogout = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        desktopPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        desktopPane.setName(""); // NOI18N

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        UserMaintenanceMenuItem.setMnemonic('o');
        UserMaintenanceMenuItem.setText("User Maintenance");
        UserMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                UserMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(UserMaintenanceMenuItem);

        LogtrailMaintenanceMenuItem.setMnemonic('s');
        LogtrailMaintenanceMenuItem.setText("Log Trail Maintenance");
        LogtrailMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                LogtrailMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(LogtrailMaintenanceMenuItem);

        menuBar.add(fileMenu);

        TransactionMaintenanceMenu.setMnemonic('e');
        TransactionMaintenanceMenu.setText("Transaction");

        AuthorMaintenanceMenuItem.setText("Author Maintenance");
        AuthorMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                AuthorMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(AuthorMaintenanceMenuItem);

        BookMaintenanceMenuItem.setMnemonic('y');
        BookMaintenanceMenuItem.setText("Book Maintenance");
        BookMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                BookMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(BookMaintenanceMenuItem);

        BorrowerMaintenanceMenuItem.setMnemonic('d');
        BorrowerMaintenanceMenuItem.setText("Borrower Maintenance");
        BorrowerMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                BorrowerMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(BorrowerMaintenanceMenuItem);

        LibrarianMaintenanceMenuItem.setMnemonic('t');
        LibrarianMaintenanceMenuItem.setText("Librarian Maintenance");
        LibrarianMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                LibrarianMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(LibrarianMaintenanceMenuItem);
        TransactionMaintenanceMenu.add(jSeparator1);

        BorrowersCardMaintenanceMenuItem.setMnemonic('p');
        BorrowersCardMaintenanceMenuItem.setText("Borrowers Card Maintenance");
        BorrowersCardMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                BorrowersCardMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(BorrowersCardMaintenanceMenuItem);
        TransactionMaintenanceMenu.add(jSeparator2);

        BorrowersCardTrailMaintenanceMenuItem.setText("Borrower's Card Trail Maintenance");
        BorrowersCardTrailMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                BorrowersCardTrailMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(BorrowersCardTrailMaintenanceMenuItem);
        TransactionMaintenanceMenu.add(jSeparator3);

        menuBar.add(TransactionMaintenanceMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        contentMenuItem.setMnemonic('c');
        contentMenuItem.setText("Contents");
        contentMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                contentMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(contentMenuItem);

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        jMenuLogger.setText("Login or Logout");

        jMenuItemLoginForm.setText("Show Login Form");
        jMenuItemLoginForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemLoginFormActionPerformed(evt);
            }
        });
        jMenuLogger.add(jMenuItemLoginForm);

        jMenuItemLogout.setText("Logout");
        jMenuItemLogout.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemLogoutActionPerformed(evt);
            }
        });
        jMenuLogger.add(jMenuItemLogout);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                exitMenuItemActionPerformed(evt);
            }
        });
        jMenuLogger.add(exitMenuItem);

        menuBar.add(jMenuLogger);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        desktopPane.getAccessibleContext().setAccessibleName("Sales and Inventory System");
        desktopPane.getAccessibleContext().setAccessibleParent(desktopPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/librarysystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            

            con.close();
            stmt.close();
            rs.close();
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        JOptionPane.showMessageDialog(InternalFrameDemo.this, "Exiting Application!");
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    //user maintenance
    private void UserMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        createUserMaintenanceFrame();
        
         
        
    }//GEN-LAST:event_UserMaintenanceMenuItemActionPerformed

    private void jMenuItemLoginFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLoginFormActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        
        createFrameLoginForm();
        jMenuItemLogout.setVisible(false);
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuLogger.setEnabled(false);
        
        
    }//GEN-LAST:event_jMenuItemLoginFormActionPerformed

    private void LogtrailMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogtrailMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        createFrameUserLogtrailMaintenance();
        
        
    }//GEN-LAST:event_LogtrailMaintenanceMenuItemActionPerformed

    //Librarian Maintenance
    private void LibrarianMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LibrarianMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameLibrarianMaintenance();
    }//GEN-LAST:event_LibrarianMaintenanceMenuItemActionPerformed

    //Book maintenance
    private void BookMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BookMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        createFrameBookMaintenance();
    }//GEN-LAST:event_BookMaintenanceMenuItemActionPerformed

    //borrowerscard maintenance
    private void BorrowersCardMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrowersCardMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //createFrameSalesMaintenance();
        createFrameBorrowersCardMaintenance();
    }//GEN-LAST:event_BorrowersCardMaintenanceMenuItemActionPerformed

    //Borrower maintenance
    private void BorrowerMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrowerMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        
        createFrameBorrowerMaintenance();
    }//GEN-LAST:event_BorrowerMaintenanceMenuItemActionPerformed

    //content form
    private void contentMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contentMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameContentForm();
    }//GEN-LAST:event_contentMenuItemActionPerformed

    //about the author
    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameAboutTheAuthorForm();
    }//GEN-LAST:event_aboutMenuItemActionPerformed
    
    //Logout
    private void jMenuItemLogoutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemLogoutActionPerformed
    {//GEN-HEADEREND:event_jMenuItemLogoutActionPerformed
        // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/librarysystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            
            con.close();
            stmt.close();
            rs.close();
            
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuItemLoginForm.setVisible(!false);
    }//GEN-LAST:event_jMenuItemLogoutActionPerformed

    //Borrower's Card Trail maintenance
    private void BorrowersCardTrailMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_BorrowersCardTrailMaintenanceMenuItemActionPerformed
    {//GEN-HEADEREND:event_BorrowersCardTrailMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameBorrowersCardTrailMaintenance();
    }//GEN-LAST:event_BorrowersCardTrailMaintenanceMenuItemActionPerformed

    //Author Maintenance
    private void AuthorMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_AuthorMaintenanceMenuItemActionPerformed
    {//GEN-HEADEREND:event_AuthorMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameAuthorMaintenance();
    }//GEN-LAST:event_AuthorMaintenanceMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InternalFrameDemo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AuthorMaintenanceMenuItem;
    private javax.swing.JMenuItem BookMaintenanceMenuItem;
    private javax.swing.JMenuItem BorrowerMaintenanceMenuItem;
    private javax.swing.JMenuItem BorrowersCardMaintenanceMenuItem;
    private javax.swing.JMenuItem BorrowersCardTrailMaintenanceMenuItem;
    private javax.swing.JMenuItem LibrarianMaintenanceMenuItem;
    private javax.swing.JMenuItem LogtrailMaintenanceMenuItem;
    private javax.swing.JMenu TransactionMaintenanceMenu;
    private javax.swing.JMenuItem UserMaintenanceMenuItem;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JMenuItem contentMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem jMenuItemLoginForm;
    private javax.swing.JMenuItem jMenuItemLogout;
    private javax.swing.JMenu jMenuLogger;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JMenuBar menuBar;
    // End of variables declaration//GEN-END:variables

}
