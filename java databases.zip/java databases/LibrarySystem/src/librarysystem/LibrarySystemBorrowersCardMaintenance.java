/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class LibrarySystemBorrowersCardMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall6=0,viewall3=0,viewall7=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String borrowerscardid;
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public LibrarySystemBorrowersCardMaintenance() {
        super("Legal Person Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_BorrowersCard_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/librarysystem";
            host="jdbc:mysql://localhost:3306/librarysystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_borrowerscard`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int borrowerscardid = rs.getInt("borrowerscardid");                
                int bookid = rs.getInt("bookid");
                int borrowerid=rs.getInt("borrowerid");
                int librarianid=rs.getInt("librarianid");
                String bookquality=rs.getString("bookquality");
                String bookstatus=rs.getString("bookstatus");              
                String dateandtimeupdated=rs.getString("dateandtimeupdated");
                String comments=rs.getString("comments");                
                
                textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
                textBookID.setText(Integer.toString(bookid));
                textBorrowerID.setText(Integer.toString(borrowerid));
                textLibrarianID.setText(Integer.toString(librarianid));
                textBookQuality.setText(bookquality);
                textBookStatus.setText(bookstatus);
                textDateAndTimeUpdated.setText(dateandtimeupdated);
                textComments.setText(comments);             
                
            
            }           
            
            viewall=0;           
            
            Show_BorrowersCard_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/librarysystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<LibrarySystemBorrowersCardTable> getBorrowersCardList()
    {
        ArrayList<LibrarySystemBorrowersCardTable> borrowerscardList= new ArrayList<LibrarySystemBorrowersCardTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_borrowerscard`";;
            }
            else if(viewall==1)
            {
                
                
                int bookid=Integer.parseInt(textBookID.getText().trim());
                //String dateandtimeupdated=textTotalDamagedQuantity.getText().trim();
                
                                
                // query ="SELECT * FROM `tbl_borrowerscard` WHERE "                       
                //        +" bookstatus like '%"+bookstatus+"%' or dateandtimeupdated like '%"+dateandtimeupdated+"%' ";
                        
                query ="SELECT * FROM `tbl_borrowerscard` WHERE bookid = "+bookid+"";
                
            }
            else if(viewall==3) 
            {
                
                               
                
                String borrowerscardid=textBorrowersCardID.getText().trim();
                int borrowerscardid1=Integer.parseInt(borrowerscardid);
                
                query ="SELECT * FROM `tbl_borrowerscard` WHERE borrowerscardid = "+borrowerscardid1+"";
            }
            else if(viewall==2) 
            {
                
                int borrowerid=Integer.parseInt(textBorrowerID.getText().trim());
                //String bookid=textBookID.getText();
                
                //query ="SELECT * FROM `tbl_borrowerscard` WHERE librarianid like '%"+librarianid+"%' or "
                //        + "bookid like '%"+bookid+"%'";
                query ="SELECT * FROM `tbl_borrowerscard` WHERE borrowerid = "+borrowerid+"";
            }
            else if(viewall==4) 
            {
                
                               
                
                //String borrowerscardid=textBorrowersCardID.getText().trim();
                //int borrowerscardid1=Integer.parseInt(borrowerscardid);
                int librarianid=Integer.parseInt(textLibrarianID.getText().trim());
                
                query ="SELECT * FROM `tbl_borrowerscard` WHERE librarianid = "+librarianid+"";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LibrarySystemBorrowersCardTable book1;
            
            while(rs.next())
            {
                book1 = new  LibrarySystemBorrowersCardTable(
                        rs.getInt("borrowerscardid"),rs.getInt("bookid"),
                        rs.getInt("borrowerid"),
                        rs.getInt("librarianid"),rs.getString("bookquality"),
                        rs.getString("bookstatus"),rs.getString("dateandtimeupdated"),
                        rs.getString("comments"));
                borrowerscardList.add(book1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return borrowerscardList;
     
    }
    
    public void Show_BorrowersCard_In_JTable()
    {
        ArrayList<LibrarySystemBorrowersCardTable> list = getBorrowersCardList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[8];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getBorrowersCardID();
            row[1]=list.get(i).getBookID();
            row[2]=list.get(i).getBorrowerID();
            row[3]=list.get(i).getLibrarianID();
            row[4]=list.get(i).getBookQuality();            
            row[5]=list.get(i).getBookStatus();
            row[6]=list.get(i).getDateAndTimeUpdated(); 
            row[7]=list.get(i).getComments();
                                                
            model.addRow(row);
            
        }
        
    }
    
    /*
    Book Inquiry
    */
    public ArrayList<LibrarySystemBorrowersCardMaintenanceBookInquiryTable> getBookList()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceBookInquiryTable> bookList= new ArrayList<LibrarySystemBorrowersCardMaintenanceBookInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall6==0)
            {
                query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book`";
            }            
            else if(viewall6==3) 
            {               
                               
                
                String bookid=textBookIDInquiry.getText().trim();
                int bookid1=Integer.parseInt(bookid);
                
                query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book` WHERE bookid= "+bookid1+"";
            }
            else if(viewall6==2) 
            {
                
                
                String authors=textAuthorNameInquiry.getText();
                
                query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book` WHERE "
                        + "authors like '%"+authors+"%'";
            }
            else if(viewall6==4) 
            {
                String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book` WHERE "
                        + "booktitle like '%"+booktitle+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book` WHERE "
                        + "booktitle = '"+booktitle+"'";
                }    
                
                
                
                
            }
            else if(viewall6==5) 
            {
                
                
                String description=textAuthorNameInquiry.getText();
                
                query ="SELECT `bookid`, `booktitle`, `description`, `authors` FROM `tbl_book` WHERE "
                        + "description like '%"+description+"%'";
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            LibrarySystemBorrowersCardMaintenanceBookInquiryTable bookinquiry1;
            
            while(rs2.next())
            {
                bookinquiry1 = new  LibrarySystemBorrowersCardMaintenanceBookInquiryTable(
                        rs2.getInt("bookid"),rs2.getString("booktitle"),rs2.getString("description"),
                        rs2.getString("authors")
                        );
                bookList.add(bookinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return bookList;
     
    }
    
    public void Show_BookInquiry_In_JTable()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceBookInquiryTable> list = getBookList();
        DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
               
        Object[] row = new Object[4];
        
        //model.addColumn("blade");
        
        model.setRowCount(0);
        
            
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getBookID();
            row[1]=list.get(i).getBookTitle();
            row[2]=list.get(i).getDescription();
            row[3]=list.get(i).getAuthors();           
                                
            model.addRow(row);
            
        }
        
    } 
    
    /*
    Borrower Inquiry
    */
    public ArrayList<LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable> getBorrowerList()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable> borrowerList= new ArrayList<LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall3==0)
            {
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower`";
            }            
            else if(viewall3==3) 
            {               
                               
                
                String borrowerid=textBorrowerIDInquiry.getText().trim();
                int borrowerid1=Integer.parseInt(borrowerid);
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE bookid= "+borrowerid1+"";
            }
            else if(viewall3==2) 
            {
                
                
                String firstname=textBorrowerFirstNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "firstname like '%"+firstname+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "firstname like '%"+firstname+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "firstname = '"+firstname+"'";
                }    
            }
            else if(viewall3==4) 
            {
                String middlename=textBorrowerMiddleNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "middlename like '%"+middlename+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "middlename like '%"+middlename+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "middlename = '"+middlename+"'";
                }        
                
                
                
                
            }
            else if(viewall3==5) 
            {
                
                
                String lastname=textBorrowerLastNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "lastname like '%"+lastname+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "lastname like '%"+lastname+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "lastname = '"+lastname+"'";
                }
            }
            else if(viewall3==6) 
            {
                
                
                String suffix=textBorrowerSuffixInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "suffix like '%"+suffix+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "suffix like '%"+suffix+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "suffix = '"+suffix+"'";
                }
            }
            else if(viewall3==7) 
            {
                
                
                String role=textBorrowerRoleInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "role like '%"+role+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "role like '%"+role+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_borrower` WHERE "
                        + "role = '"+role+"'";
                }
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable borrowerinquiry1;
            
            while(rs2.next())
            {
                borrowerinquiry1 = new  LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable(
                        rs2.getInt("borrowerid"),rs2.getString("firstname"),rs2.getString("middlename"),
                        rs2.getString("lastname"),rs2.getString("suffix"),rs2.getString("role")
                        );
                borrowerList.add(borrowerinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return borrowerList;
     
    }
    
    public void Show_BorrowerInquiry_In_JTable()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceBorrowerInquiryTable> list = getBorrowerList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[6];
        
        //model.addColumn("blade");
        
        model.setRowCount(0);
        
            
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getBorrowerID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();  
            row[2]=list.get(i).getSuffix();
            row[3]=list.get(i).getRole();  
                                
            model.addRow(row);
            
        }
        
    } 
    
    /*
    Librarian Inquiry
    */
    public ArrayList<LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable> getLibrarianList()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable> librarianList= new ArrayList<LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall7==0)
            {
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian`";
            }            
            else if(viewall7==3) 
            {               
                               
                
                String librarianid=textLibrarianIDInquiry.getText().trim();
                int librarianid1=Integer.parseInt(librarianid);
                
                query ="SELECT `librarianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE bookid= "+librarianid1+"";
            }
            else if(viewall7==2) 
            {
                
                
                String firstname=textLibrarianFirstNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "firstname like '%"+firstname+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "firstname like '%"+firstname+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "firstname = '"+firstname+"'";
                }    
            }
            else if(viewall7==4) 
            {
                String middlename=textBorrowerMiddleNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "middlename like '%"+middlename+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "middlename like '%"+middlename+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "middlename = '"+middlename+"'";
                }        
                
                
                
                
            }
            else if(viewall7==5) 
            {
                
                
                String lastname=textBorrowerLastNameInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "lastname like '%"+lastname+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "lastname like '%"+lastname+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "lastname = '"+lastname+"'";
                }
            }
            else if(viewall7==6) 
            {
                
                
                String suffix=textBorrowerSuffixInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "suffix like '%"+suffix+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "suffix like '%"+suffix+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "suffix = '"+suffix+"'";
                }
            }
            else if(viewall7==7) 
            {
                
                
                String role=textBorrowerRoleInquiry.getText();
                
                query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "role like '%"+role+"%'";
                
                //String booktitle=textBookTitleInquiry.getText();
                if(optBookInquiryGeneralSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "role like '%"+role+"%'";
                }
                else if(optBookInquirySpecificSearch.isSelected()==true)
                {
                    query ="SELECT `borrowerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_librarian` WHERE "
                        + "role = '"+role+"'";
                }
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable librarianinquiry1;
            
            while(rs2.next())
            {
                librarianinquiry1 = new  LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable(
                        rs2.getInt("borrowerid"),rs2.getString("firstname"),rs2.getString("middlename"),
                        rs2.getString("lastname"),rs2.getString("suffix"),rs2.getString("role")
                        );
                librarianList.add(librarianinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return librarianList;
     
    }
    
    public void Show_LibrarianInquiry_In_JTable()
    {
        ArrayList<LibrarySystemBorrowersCardMaintenanceLibrarianInquiryTable> list = getLibrarianList();
        DefaultTableModel model = (DefaultTableModel)jTable7.getModel();
               
        Object[] row = new Object[6];
        
        //model.addColumn("blade");
        
        model.setRowCount(0);
        
            
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getLibrarianID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();  
            row[2]=list.get(i).getSuffix();
            row[3]=list.get(i).getRole();  
                                
            model.addRow(row);
            
        }
        
    } 
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textBookID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textComments = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByBorrowerID = new javax.swing.JButton();
        btnSearchByBorrowersCardID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textBorrowersCardID = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        textDateAndTimeUpdated = new javax.swing.JTextArea();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        textBookIDInquiry = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        btnBookIDInquiry = new javax.swing.JButton();
        btnAuthorNameInquiry = new javax.swing.JButton();
        btnViewAllBooks = new javax.swing.JButton();
        btnClearAllBooks = new javax.swing.JButton();
        btnBookIDInquiryAdd = new javax.swing.JButton();
        textBookTitleInquiry = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        btnBookTitleInquiry = new javax.swing.JButton();
        optBookInquiryGeneralSearch = new javax.swing.JRadioButton();
        optBookInquirySpecificSearch = new javax.swing.JRadioButton();
        jLabel57 = new javax.swing.JLabel();
        btnBookDescriptionInquiry = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        textAuthorNameInquiry = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        textBookDescriptionInquiry1 = new javax.swing.JTextArea();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        textBorrowerIDInquiry = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        textBorrowerFirstNameInquiry = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnBorrowerIDInquiry = new javax.swing.JButton();
        btnBorrowerFirstNameInquiry = new javax.swing.JButton();
        btnViewAllBorrowers = new javax.swing.JButton();
        btnClearAllBorrowers = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        textAuthorInquiryPut = new javax.swing.JTextArea();
        btnBorrowerInquiryAdd = new javax.swing.JButton();
        textBorrowerMiddleNameInquiry = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        textBorrowerLastNameInquiry = new javax.swing.JTextField();
        textBorrowerSuffixInquiry = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        btnBorrowerMiddleNameInquiry = new javax.swing.JButton();
        btnBorrowerLastNameInquiry = new javax.swing.JButton();
        textBorrowerRoleInquiry = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        btnBorrowerSuffixInquiry = new javax.swing.JButton();
        btnBorrowerRoleInquiry = new javax.swing.JButton();
        optBorrowerInquirySpecificSearch = new javax.swing.JRadioButton();
        optBorrowerInquiryGeneralSearch = new javax.swing.JRadioButton();
        jTabbedPane7 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        textLibrarianIDInquiry = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        textLibrarianFirstNameInquiry = new javax.swing.JTextField();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        btnLibrarianIDInquiry = new javax.swing.JButton();
        btnLibrarianFirstNameInquiry = new javax.swing.JButton();
        btnViewAllLibrarians = new javax.swing.JButton();
        btnClearAllLibrarians = new javax.swing.JButton();
        jLabel52 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        textAuthorInquiryPut4 = new javax.swing.JTextArea();
        btnLibrarianInquiryAdd = new javax.swing.JButton();
        textLibrarianMiddleNameInquiry = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        textLibrarianLastNameInquiry = new javax.swing.JTextField();
        textLibrarianSuffixInquiry = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        btnLibrarianMiddleNameInquiry = new javax.swing.JButton();
        btnLibrarianLastNameInquiry = new javax.swing.JButton();
        textLibrarianRoleInquiry = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        btnLibrarianSuffixInquiry = new javax.swing.JButton();
        btnLibrarianRoleInquiry = new javax.swing.JButton();
        optAuthorInquirySpecificSearch2 = new javax.swing.JRadioButton();
        optAuthorInquiryGeneralSearch2 = new javax.swing.JRadioButton();
        btnSearchByBookID = new javax.swing.JButton();
        textBorrowerID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        textLibrarianID = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        textBookQuality = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        textBookStatus = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        btnSearchByLibrarianID = new javax.swing.JButton();
        checkboxEnableDisableIDs = new javax.swing.JCheckBox();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Borrower's Card ID", "Book ID", "Borrower ID", "Librarian ID", "Book Quality", "Book Quality", "Book Status", "Date And Time Updated", "Comments"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Comments");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Date and Time Updated");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Book ID");

        textComments.setBackground(new java.awt.Color(51, 255, 255));
        textComments.setColumns(20);
        textComments.setRows(5);
        jScrollPane1.setViewportView(textComments);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByBorrowerID.setText("Search by Borrower ID");
        btnSearchByBorrowerID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByBorrowerIDActionPerformed(evt);
            }
        });

        btnSearchByBorrowersCardID.setText("Search by Borrower's Card ID ");
        btnSearchByBorrowersCardID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByBorrowersCardIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Borrower's Card ID");

        textDateAndTimeUpdated.setBackground(new java.awt.Color(51, 255, 255));
        textDateAndTimeUpdated.setColumns(20);
        textDateAndTimeUpdated.setRows(5);
        jScrollPane2.setViewportView(textDateAndTimeUpdated);

        jLabel43.setText("Book ID");

        jLabel44.setText("Author Name ");

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String []
            {
                "Book ID", "Book Title", "Description", "Authors"
            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable6MouseClicked(evt);
            }
        });
        jTable6.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable6KeyPressed(evt);
            }
        });
        jScrollPane11.setViewportView(jTable6);

        btnBookIDInquiry.setText("Search by Book ID ");
        btnBookIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBookIDInquiryActionPerformed(evt);
            }
        });

        btnAuthorNameInquiry.setText("Search by Author Name");
        btnAuthorNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnAuthorNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllBooks.setText("View All Books");
        btnViewAllBooks.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllBooksActionPerformed(evt);
            }
        });

        btnClearAllBooks.setText("Clear All Books");
        btnClearAllBooks.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllBooksActionPerformed(evt);
            }
        });

        btnBookIDInquiryAdd.setText("Add to Book ID Textbox");
        btnBookIDInquiryAdd.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBookIDInquiryAddActionPerformed(evt);
            }
        });

        jLabel47.setText("Book Title");

        btnBookTitleInquiry.setText("Search by Book Title");
        btnBookTitleInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBookTitleInquiryActionPerformed(evt);
            }
        });

        optBookInquiryGeneralSearch.setSelected(true);
        optBookInquiryGeneralSearch.setText("General Search");

        optBookInquirySpecificSearch.setText("Specific Search");

        jLabel57.setText("Description");

        btnBookDescriptionInquiry.setText("Search by Book Description");
        btnBookDescriptionInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBookDescriptionInquiryActionPerformed(evt);
            }
        });

        textAuthorNameInquiry.setColumns(20);
        textAuthorNameInquiry.setRows(5);
        jScrollPane3.setViewportView(textAuthorNameInquiry);

        textBookDescriptionInquiry1.setColumns(20);
        textBookDescriptionInquiry1.setRows(5);
        jScrollPane7.setViewportView(textBookDescriptionInquiry1);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel44)
                            .addComponent(jLabel43)
                            .addComponent(jLabel47)
                            .addComponent(jLabel57))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                            .addComponent(textBookTitleInquiry)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(textBookIDInquiry))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBookTitleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnBookDescriptionInquiry)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnAuthorNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 179, Short.MAX_VALUE)
                                        .addComponent(btnBookIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(optBookInquiryGeneralSearch)
                                    .addComponent(optBookInquirySpecificSearch))
                                .addGap(39, 39, 39)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnViewAllBooks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnClearAllBooks, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE))
                                    .addComponent(btnBookIDInquiryAdd))))))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel43)
                            .addComponent(textBookIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(optBookInquiryGeneralSearch)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(optBookInquirySpecificSearch)))
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(textBookTitleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel47)
                                            .addComponent(btnBookTitleInquiry))
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGap(73, 73, 73)
                                                .addComponent(jLabel57))
                                            .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnBookDescriptionInquiry)
                                        .addGap(49, 49, 49))))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBookIDInquiry)
                            .addComponent(btnViewAllBooks))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAuthorNameInquiry)
                            .addComponent(btnClearAllBooks))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBookIDInquiryAdd)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(57, 57, 57)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(184, 184, 184))
        );

        jTabbedPane6.addTab("Book Inquiry Panel", jPanel5);

        jTabbedPane1.addTab("Book Inquiry", jTabbedPane6);

        jLabel22.setText("Borrower ID");

        jLabel23.setText("Borrower First Name ");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String []
            {
                "Author ID", "FirstName", "MiddleName", "LastName", "Suffix"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(jTable3);

        btnBorrowerIDInquiry.setText("Search by Borrower ID ");
        btnBorrowerIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerIDInquiryActionPerformed(evt);
            }
        });

        btnBorrowerFirstNameInquiry.setText("Search by Borrower First Name");
        btnBorrowerFirstNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerFirstNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllBorrowers.setText("View All Borrowers");
        btnViewAllBorrowers.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllBorrowersActionPerformed(evt);
            }
        });

        btnClearAllBorrowers.setText("Clear All Borrowers");
        btnClearAllBorrowers.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllBorrowersActionPerformed(evt);
            }
        });

        jLabel24.setText("Clicked Author Name");

        textAuthorInquiryPut.setColumns(20);
        textAuthorInquiryPut.setRows(5);
        jScrollPane6.setViewportView(textAuthorInquiryPut);

        btnBorrowerInquiryAdd.setText("Add to Borrower ID Text Box");
        btnBorrowerInquiryAdd.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerInquiryAddActionPerformed(evt);
            }
        });

        jLabel25.setText("Borrower Suffix");

        jLabel26.setText("Borrower Middle Name ");

        jLabel27.setText("Borrower LastName ");

        btnBorrowerMiddleNameInquiry.setText("Search by Borrower Middle Name");
        btnBorrowerMiddleNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerMiddleNameInquiryActionPerformed(evt);
            }
        });

        btnBorrowerLastNameInquiry.setText("Search by Borrower Last Name");
        btnBorrowerLastNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerLastNameInquiryActionPerformed(evt);
            }
        });

        jLabel28.setText("Borrower Role");

        btnBorrowerSuffixInquiry.setText("Search by Borrower Suffix");
        btnBorrowerSuffixInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerSuffixInquiryActionPerformed(evt);
            }
        });

        btnBorrowerRoleInquiry.setText("Search by Borrower Role");
        btnBorrowerRoleInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBorrowerRoleInquiryActionPerformed(evt);
            }
        });

        optBorrowerInquirySpecificSearch.setText("Specific Search");

        optBorrowerInquiryGeneralSearch.setSelected(true);
        optBorrowerInquiryGeneralSearch.setText("General Search");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(jLabel24))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel28))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textBorrowerFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textBorrowerIDInquiry)
                                    .addComponent(textBorrowerMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textBorrowerLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textBorrowerSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textBorrowerRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnBorrowerFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnBorrowerIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnBorrowerMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnBorrowerLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnBorrowerSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnBorrowerRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAllBorrowers, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAllBorrowers, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(optBorrowerInquiryGeneralSearch)
                            .addComponent(optBorrowerInquirySpecificSearch)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBorrowerInquiryAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(textBorrowerIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBorrowerIDInquiry)
                    .addComponent(btnViewAllBorrowers))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textBorrowerFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBorrowerFirstNameInquiry)
                            .addComponent(btnClearAllBorrowers))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(btnBorrowerMiddleNameInquiry)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBorrowerLastNameInquiry))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(optBorrowerInquiryGeneralSearch)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(optBorrowerInquirySpecificSearch)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBorrowerSuffixInquiry)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBorrowerRoleInquiry))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textBorrowerMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel26))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textBorrowerLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textBorrowerSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel28)
                                    .addComponent(textBorrowerRoleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLabel23))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 199, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBorrowerInquiryAdd))
                .addGap(23, 23, 23)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane5.addTab("Borrower Inquiry Panel", jPanel2);

        jTabbedPane1.addTab("Borrower Inquiry", jTabbedPane5);

        jLabel50.setText("Librarian ID");

        jLabel51.setText("Librarian First Name ");

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String []
            {
                "Author ID", "FirstName", "MiddleName", "LastName", "Suffix"
            }
        ));
        jTable7.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable7MouseClicked(evt);
            }
        });
        jTable7.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable7KeyPressed(evt);
            }
        });
        jScrollPane13.setViewportView(jTable7);

        btnLibrarianIDInquiry.setText("Search by Librarian ID ");
        btnLibrarianIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianIDInquiryActionPerformed(evt);
            }
        });

        btnLibrarianFirstNameInquiry.setText("Search by Librarian First Name");
        btnLibrarianFirstNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianFirstNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllLibrarians.setText("View All Librarians");
        btnViewAllLibrarians.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllLibrariansActionPerformed(evt);
            }
        });

        btnClearAllLibrarians.setText("Clear All Librarians");
        btnClearAllLibrarians.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllLibrariansActionPerformed(evt);
            }
        });

        jLabel52.setText("Clicked Author Name");

        textAuthorInquiryPut4.setColumns(20);
        textAuthorInquiryPut4.setRows(5);
        jScrollPane14.setViewportView(textAuthorInquiryPut4);

        btnLibrarianInquiryAdd.setText("Add to Librarian ID Text Box");
        btnLibrarianInquiryAdd.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianInquiryAddActionPerformed(evt);
            }
        });

        jLabel53.setText("Librarian Suffix");

        jLabel54.setText("Librarian Middle Name ");

        jLabel55.setText("Librarian Last Name ");

        btnLibrarianMiddleNameInquiry.setText("Search by Librarian Middle Name");
        btnLibrarianMiddleNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianMiddleNameInquiryActionPerformed(evt);
            }
        });

        btnLibrarianLastNameInquiry.setText("Search by Librarian Last Name");
        btnLibrarianLastNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianLastNameInquiryActionPerformed(evt);
            }
        });

        jLabel56.setText("Librarian Role");

        btnLibrarianSuffixInquiry.setText("Search by Librarian Suffix");
        btnLibrarianSuffixInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianSuffixInquiryActionPerformed(evt);
            }
        });

        btnLibrarianRoleInquiry.setText("Search by Librarian Role");
        btnLibrarianRoleInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLibrarianRoleInquiryActionPerformed(evt);
            }
        });

        optAuthorInquirySpecificSearch2.setText("Specific Search");

        optAuthorInquiryGeneralSearch2.setSelected(true);
        optAuthorInquiryGeneralSearch2.setText("General Search");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(jLabel52))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel51)
                                    .addComponent(jLabel50)
                                    .addComponent(jLabel53)
                                    .addComponent(jLabel54)
                                    .addComponent(jLabel55)
                                    .addComponent(jLabel56))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textLibrarianFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textLibrarianIDInquiry)
                                    .addComponent(textLibrarianMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textLibrarianLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textLibrarianSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textLibrarianRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnLibrarianFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLibrarianIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLibrarianMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLibrarianLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLibrarianSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnLibrarianRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAllLibrarians, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAllLibrarians, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(optAuthorInquiryGeneralSearch2)
                            .addComponent(optAuthorInquirySpecificSearch2)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLibrarianInquiryAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50)
                    .addComponent(textLibrarianIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLibrarianIDInquiry)
                    .addComponent(btnViewAllLibrarians))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textLibrarianFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLibrarianFirstNameInquiry)
                            .addComponent(btnClearAllLibrarians))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(btnLibrarianMiddleNameInquiry)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnLibrarianLastNameInquiry))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(optAuthorInquiryGeneralSearch2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(optAuthorInquirySpecificSearch2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLibrarianSuffixInquiry)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLibrarianRoleInquiry))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textLibrarianMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel54))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textLibrarianLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textLibrarianSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel53))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel56)
                                    .addComponent(textLibrarianRoleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLabel51))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 199, Short.MAX_VALUE)
                .addComponent(jLabel52)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLibrarianInquiryAdd))
                .addGap(23, 23, 23)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane7.addTab("Librarian Inquiry Panel", jPanel6);

        jTabbedPane1.addTab("Librarian Book  Inquiry", jTabbedPane7);

        btnSearchByBookID.setText("Search by Book ID");
        btnSearchByBookID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByBookIDActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Borrower ID");

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Librarian ID");

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Book Quality");

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Book Status");

        btnSearchByLibrarianID.setText("Search by Librarian ID");
        btnSearchByLibrarianID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLibrarianIDActionPerformed(evt);
            }
        });

        checkboxEnableDisableIDs.setText("Enable or Disable Book ID, Borrower ID and Librarian ID");
        checkboxEnableDisableIDs.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                checkboxEnableDisableIDsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSaveRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancelNewRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(435, 435, 435)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(142, 142, 142)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textBorrowerID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textLibrarianID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textBookQuality, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textBookStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnSearchByBorrowerID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnSearchByBorrowersCardID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnSearchByLibrarianID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnSearchByBookID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(checkboxEnableDisableIDs)
                                    .addComponent(textBorrowersCardID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 799, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(256, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByBorrowersCardID)
                            .addComponent(btnSearchByBookID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByBorrowerID)
                            .addComponent(btnSearchByLibrarianID))
                        .addGap(18, 18, 18)
                        .addComponent(checkboxEnableDisableIDs)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel14)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel15)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel17)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel18)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel19))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textBorrowersCardID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textBookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textBorrowerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textLibrarianID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textBookQuality, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textBookStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEdit)
                                .addComponent(btnNewRecord)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnCancelNewRecord)
                                .addComponent(btnClearAll))
                            .addComponent(btnSaveRecord))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jTabbedPane1)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textBorrowersCardID.setText(model.getValueAt(i, 0).toString());
        textBookID.setText(model.getValueAt(i, 1).toString());
        textBorrowerID.setText(model.getValueAt(i, 2).toString());
        textLibrarianID.setText(model.getValueAt(i, 3).toString());
        textBookQuality.setText(model.getValueAt(i, 4).toString());
        textBookStatus.setText(model.getValueAt(i, 5).toString());
        textDateAndTimeUpdated.setText(model.getValueAt(i, 6).toString());            
        textComments.setText(model.getValueAt(i, 7).toString());   
               
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textBorrowersCardID.setText(model.getValueAt(i, 0).toString());
            textBookID.setText(model.getValueAt(i, 1).toString());
            textBorrowerID.setText(model.getValueAt(i, 2).toString());
            textLibrarianID.setText(model.getValueAt(i, 3).toString());
            textBookQuality.setText(model.getValueAt(i, 4).toString());
            textBookStatus.setText(model.getValueAt(i, 5).toString());
            textDateAndTimeUpdated.setText(model.getValueAt(i, 6).toString());            
            textComments.setText(model.getValueAt(i, 7).toString());        
            
            
            
           
            
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/librarysystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String borrowerscardid=textBorrowersCardID.getText().trim();
                int borrowerscardid2=Integer.parseInt(borrowerscardid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_borrowerscard` where borrowerscardid="+borrowerscardid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_borrowerscard"
                    + " where borrowerscardid="+borrowerscardid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall6=0;
        //();
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/librarysystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                /**
             int borrowerscardid = rs.getInt("borrowerscardid");                
            int bookid = rs.getInt("bookid");
            int borrowerid=rs.getInt("borrowerid");
            int librarianid=rs.getInt("librarianid");
            String bookquality=rs.getString("bookquality");
            String bookstatus=rs.getString("bookstatus");              
            String dateandtimeupdated=rs.getString("dateandtimeupdated");
            String comments=rs.getString("comments");                

            textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
            textBookID.setText(Integer.toString(bookid));
            textBorrowerID.setText(Integer.toString(borrowerid));
            textLibrarianID.setText(Integer.toString(librarianid));
            textBookQuality.setText(bookquality);
            textBookStatus.setText(bookstatus);
            textDateAndTimeUpdated.setText(dateandtimeupdated);
            textComments.setText(comments); 
             */               
                
                String borrowerscardid = textBorrowersCardID.getText().trim();
                int borrowerscardid2=Integer.parseInt(borrowerscardid);
                String bookid=textBookID.getText().trim();
                int bookid2=Integer.parseInt(borrowerscardid);
                String borrowerid=textDateAndTimeUpdated.getText().trim();
                int borrowerid2=Integer.parseInt(borrowerscardid);
                String librarianid=textLibrarianID.getText().trim();
                int librarianid2=Integer.parseInt(borrowerscardid);
                String bookquality=textBookQuality.getText().trim();                
                String bookstatus=textBookStatus.getText().trim();                
                String dateandtimeupdated=textDateAndTimeUpdated.getText().trim();                
                String comments=textComments.getText().trim();
                
              
                
                
                
                
                                               

                if(borrowerscardid.equals("")||bookid.equals("")||bookstatus.equals("")
                   || dateandtimeupdated.equals("")|| borrowerid.equals("")|| librarianid.equals("")|| bookquality.equals("")
                   )
                {
                    JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_borrowerscard` where "
                            + "borrowerscardid="+borrowerscardid+" or (bookid='"+bookid+"' ";
                       
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        sql="UPDATE `tbl_borrowerscard` "
                                + "SET `bookid`='"+bookid+"',"
                                + "`borrowerid`='"+borrowerid+"',`librarianid`='"+librarianid+"',"
                                + "`bookquality`='"+bookquality+"',`bookstatus`='"+bookstatus+"',"
                                + "`dateandtimeupdated`='"+dateandtimeupdated+"',`comments`='"+comments+"'"
                                + " WHERE `borrowerscardid`="+borrowerscardid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_borrowerscard` where "
                            + "borrowerscardid="+borrowerscardid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            borrowerscardid2 = rs.getInt("borrowerscardid");
                            bookid2=rs.getInt("bookid");
                            borrowerid2=rs.getInt("borrowerid");
                            librarianid2=rs.getInt("librarianid");
                            bookquality=rs.getString("bookquality");
                            bookstatus=rs.getString("bookstatus");
                            dateandtimeupdated=rs.getString("dateandtimeupdated");
                            comments=rs.getString("comments");

                            
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textBorrowersCardID.setText(Integer.toString(borrowerscardid2));
                                textBookID.setText(Integer.toString(bookid2));
                                textBorrowerID.setText(Integer.toString(borrowerid2));
                                textLibrarianID.setText(Integer.toString(librarianid2));
                                textBookQuality.setText(bookquality);
                                textBookStatus.setText(bookstatus);
                                textDateAndTimeUpdated.setText(borrowerid);                                  
                                textComments.setText(librarianid);                             
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/librarysystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            /**
             int borrowerscardid = rs.getInt("borrowerscardid");                
            int bookid = rs.getInt("bookid");
            int borrowerid=rs.getInt("borrowerid");
            int librarianid=rs.getInt("librarianid");
            String bookquality=rs.getString("bookquality");
            String bookstatus=rs.getString("bookstatus");              
            String dateandtimeupdated=rs.getString("dateandtimeupdated");
            String comments=rs.getString("comments");                

            textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
            textBookID.setText(Integer.toString(bookid));
            textBorrowerID.setText(Integer.toString(borrowerid));
            textLibrarianID.setText(Integer.toString(librarianid));
            textBookQuality.setText(bookquality);
            textBookStatus.setText(bookstatus);
            textDateAndTimeUpdated.setText(dateandtimeupdated);
            textComments.setText(comments); 
             */
            
            //String borrowerscardid = textLegalPersonID.getText().trim();
            //int borrowerscardid2=Integer.parseInt(borrowerscardid);
            
            int bookid=Integer.parseInt(textBookID.getText().trim());
            int borrowerid=Integer.parseInt(textBorrowerID.getText().trim());
            int librarianid=Integer.parseInt(textLibrarianID.getText().trim());
            String bookquality=textBookQuality.getText().trim();
            String bookstatus=textBookStatus.getText().trim();              
            String dateandtimeupdated=textDateAndTimeUpdated.getText().trim();
            String comments=textComments.getText().trim();  
            
            
                   
            

           if(bookstatus.equals("")|| 
                   comments.equals("")|| bookquality.equals("")
                   || dateandtimeupdated.equals(""))
            {
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_borrowerscard` where bookid='"+bookid+"' ";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="INSERT INTO `tbl_borrowerscard`(`borrowerscardid`, `bookid`, `borrowerid`, `librarianid`, `bookquality`, "
                            + "`bookstatus`, `dateandtimeupdated`,`comments`) "
                            + "VALUES (NULL,'"+bookid+"','"+borrowerid+"','"+librarianid+"','"+bookquality+"',"
                            + "'"+bookstatus+"','"+dateandtimeupdated+"','"+comments+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_borrowerscard`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int borrowerscardid = rs.getInt("borrowerscardid");                
                    bookid = rs.getInt("bookid");
                    borrowerid=rs.getInt("borrowerid");
                    librarianid=rs.getInt("librarianid");
                    bookquality=rs.getString("bookquality");
                    bookstatus=rs.getString("bookstatus");              
                    dateandtimeupdated=rs.getString("dateandtimeupdated");
                    comments=rs.getString("comments");                

                    textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
                    textBookID.setText(Integer.toString(bookid));
                    textBorrowerID.setText(Integer.toString(borrowerid));
                    textLibrarianID.setText(Integer.toString(librarianid));
                    textBookQuality.setText(bookquality);
                    textBookStatus.setText(bookstatus);
                    textDateAndTimeUpdated.setText(dateandtimeupdated);
                    textComments.setText(comments);             
                    

                    JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " new inserted record item: "+Double.toString(borrowerscardid));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_BorrowersCard_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textBorrowersCardID.setText("");                
            textBookID.setText("");
            textBorrowerID.setText("");
            textLibrarianID.setText("");
            textBookQuality.setText("");
            textBookStatus.setText("");
            textDateAndTimeUpdated.setText("");
            textComments.setText("");
           

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int borrowerscardid = rs.getInt("borrowerscardid");                
            int bookid = rs.getInt("bookid");
            int borrowerid=rs.getInt("borrowerid");
            int librarianid=rs.getInt("librarianid");
            String bookquality=rs.getString("bookquality");
            String bookstatus=rs.getString("bookstatus");              
            String dateandtimeupdated=rs.getString("dateandtimeupdated");
            String comments=rs.getString("comments");                

            textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
            textBookID.setText(Integer.toString(bookid));
            textBorrowerID.setText(Integer.toString(borrowerid));
            textLibrarianID.setText(Integer.toString(librarianid));
            textBookQuality.setText(bookquality);
            textBookStatus.setText(bookstatus);
            textDateAndTimeUpdated.setText(dateandtimeupdated);
            textComments.setText(comments);             
            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int borrowerscardid = rs.getInt("borrowerscardid");                
                int bookid = rs.getInt("bookid");
                int borrowerid=rs.getInt("borrowerid");
                int librarianid=rs.getInt("librarianid");
                String bookquality=rs.getString("bookquality");
                String bookstatus=rs.getString("bookstatus");              
                String dateandtimeupdated=rs.getString("dateandtimeupdated");
                String comments=rs.getString("comments");                
                
                textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
                textBookID.setText(Integer.toString(bookid));
                textBorrowerID.setText(Integer.toString(borrowerid));
                textLibrarianID.setText(Integer.toString(librarianid));
                textBookQuality.setText(bookquality);
                textBookStatus.setText(bookstatus);
                textDateAndTimeUpdated.setText(dateandtimeupdated);
                textComments.setText(comments);                          
                

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textBorrowersCardID.setText("");                
                textBookID.setText("");
                textBorrowerID.setText("");
                textLibrarianID.setText("");
                textBookQuality.setText("");
                textBookStatus.setText("");
                textDateAndTimeUpdated.setText("");
                textComments.setText("");
                
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:            

        textBorrowersCardID.setText("");                
        textBookID.setText("");
        textBorrowerID.setText("");
        textLibrarianID.setText("");
        textBookQuality.setText("");
        textBookStatus.setText("");
        textDateAndTimeUpdated.setText("");
        textComments.setText("");             
        

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {               
                

                int borrowerscardid = rs.getInt("borrowerscardid");                
                int bookid = rs.getInt("bookid");
                int borrowerid=rs.getInt("borrowerid");
                int librarianid=rs.getInt("librarianid");
                String bookquality=rs.getString("bookquality");
                String bookstatus=rs.getString("bookstatus");              
                String dateandtimeupdated=rs.getString("dateandtimeupdated");
                String comments=rs.getString("comments");                
                
                textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
                textBookID.setText(Integer.toString(bookid));
                textBorrowerID.setText(Integer.toString(borrowerid));
                textLibrarianID.setText(Integer.toString(librarianid));
                textBookQuality.setText(bookquality);
                textBookStatus.setText(bookstatus);
                textDateAndTimeUpdated.setText(dateandtimeupdated);
                textComments.setText(comments);             
                

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int borrowerscardid = rs.getInt("borrowerscardid");                
            int bookid = rs.getInt("bookid");
            int borrowerid=rs.getInt("borrowerid");
            int librarianid=rs.getInt("librarianid");
            String bookquality=rs.getString("bookquality");
            String bookstatus=rs.getString("bookstatus");              
            String dateandtimeupdated=rs.getString("dateandtimeupdated");
            String comments=rs.getString("comments");                

            textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
            textBookID.setText(Integer.toString(bookid));
            textBorrowerID.setText(Integer.toString(borrowerid));
            textLibrarianID.setText(Integer.toString(librarianid));
            textBookQuality.setText(bookquality);
            textBookStatus.setText(bookstatus);
            textDateAndTimeUpdated.setText(dateandtimeupdated);
            textComments.setText(comments);             

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int borrowerscardid = rs.getInt("borrowerscardid");                
                int bookid = rs.getInt("bookid");
                int borrowerid=rs.getInt("borrowerid");
                int librarianid=rs.getInt("librarianid");
                String bookquality=rs.getString("bookquality");
                String bookstatus=rs.getString("bookstatus");              
                String dateandtimeupdated=rs.getString("dateandtimeupdated");
                String comments=rs.getString("comments");                
                
                textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
                textBookID.setText(Integer.toString(bookid));
                textBorrowerID.setText(Integer.toString(borrowerid));
                textLibrarianID.setText(Integer.toString(librarianid));
                textBookQuality.setText(bookquality);
                textBookStatus.setText(bookstatus);
                textDateAndTimeUpdated.setText(dateandtimeupdated);
                textComments.setText(comments);             

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int borrowerscardid = rs.getInt("borrowerscardid");                
            int bookid = rs.getInt("bookid");
            int borrowerid=rs.getInt("borrowerid");
            int librarianid=rs.getInt("librarianid");
            String bookquality=rs.getString("bookquality");
            String bookstatus=rs.getString("bookstatus");              
            String dateandtimeupdated=rs.getString("dateandtimeupdated");
            String comments=rs.getString("comments");                

            textBorrowersCardID.setText(Integer.toString(borrowerscardid));                
            textBookID.setText(Integer.toString(bookid));
            textBorrowerID.setText(Integer.toString(borrowerid));
            textLibrarianID.setText(Integer.toString(librarianid));
            textBookQuality.setText(bookquality);
            textBookStatus.setText(bookstatus);
            textDateAndTimeUpdated.setText(dateandtimeupdated);
            textComments.setText(comments);             

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LibrarySystemBorrowersCardMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search borrower ID
    private void btnSearchByBorrowerIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByBorrowerIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_BorrowersCard_In_JTable();
        
    }//GEN-LAST:event_btnSearchByBorrowerIDActionPerformed

    //search by Borrower's Card ID
    private void btnSearchByBorrowersCardIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByBorrowersCardIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByBorrowersCardIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnSearchByBorrowersCardIDActionPerformed

    //search by Book ID
    private void btnSearchByBookIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByBookIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByBookIDActionPerformed
        // TODO add your handling code here:

        viewall=1;
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnSearchByBookIDActionPerformed

    //Borrower Role Inquiry
    private void btnBorrowerRoleInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerRoleInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerRoleInquiryActionPerformed
        // TODO add your handling code here:        
        
        viewall3=7;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerRoleInquiryActionPerformed

    //Borrower Suffix Inquiry
    private void btnBorrowerSuffixInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerSuffixInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerSuffixInquiryActionPerformed
        // TODO add your handling code here:        
        
        viewall3=6;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerSuffixInquiryActionPerformed

    //Borrower Last name inquiry
    private void btnBorrowerLastNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerLastNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerLastNameInquiryActionPerformed
        // TODO add your handling code here:
        
        
        viewall3=5;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerLastNameInquiryActionPerformed

    //Borrower Middle Name inquiry
    private void btnBorrowerMiddleNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerMiddleNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerMiddleNameInquiryActionPerformed
        // TODO add your handling code here:
        
        viewall3=4;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerMiddleNameInquiryActionPerformed

    private void btnBorrowerInquiryAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerInquiryAddActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerInquiryAddActionPerformed
        // TODO add your handling code here:
        //textComments.setText("\n"+textAuthorInquiryPut.getText());
        String x=textBorrowerIDInquiry.getText().trim();
        if(x.equals(""))
            return;
        
        textBorrowerID.setText(x);
    }//GEN-LAST:event_btnBorrowerInquiryAddActionPerformed

    private void btnClearAllBorrowersActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllBorrowersActionPerformed
    {//GEN-HEADEREND:event_btnClearAllBorrowersActionPerformed
        // TODO add your handling code here:
        textBorrowerIDInquiry.setText("");
        textBorrowerFirstNameInquiry.setText("");
        textBorrowerMiddleNameInquiry.setText("");
        textBorrowerLastNameInquiry.setText("");
        textBorrowerSuffixInquiry.setText("");
        textBorrowerRoleInquiry.setText("");
    }//GEN-LAST:event_btnClearAllBorrowersActionPerformed

    //View All borrower inquiry
    private void btnViewAllBorrowersActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllBorrowersActionPerformed
    {//GEN-HEADEREND:event_btnViewAllBorrowersActionPerformed
        // TODO add your handling code here:        
        
        viewall3=0;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnViewAllBorrowersActionPerformed

    //Borrower First Name Inquiry
    private void btnBorrowerFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerFirstNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall3=2;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerFirstNameInquiryActionPerformed

    //Borrower ID Inquiry
    private void btnBorrowerIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBorrowerIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBorrowerIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall3=3;
        Show_BorrowerInquiry_In_JTable();
    }//GEN-LAST:event_btnBorrowerIDInquiryActionPerformed

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:
        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable3.getSelectedRow();
                TableModel model=jTable3.getModel();

                //textAuthorIDInquiry.setText(model.getValueAt(i, 0).toString());
                //textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
                String author="";
                author+=model.getValueAt(i, 1).toString()+" ";
                author+=model.getValueAt(i, 2).toString()+" ";
                author+=model.getValueAt(i, 3).toString()+" ";
                author+=model.getValueAt(i, 4).toString()+"";
                textAuthorInquiryPut.setText(author);

            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            //textAuthorIDInquiry.setText(model.getValueAt(i, 0).toString());
            //textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
            String author="";
            author+="";
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable6MouseClicked
    {//GEN-HEADEREND:event_jTable6MouseClicked
        // TODO add your handling code here:
        int i=jTable6.getSelectedRow();
        TableModel model=jTable6.getModel();           

        textBookIDInquiry.setText(model.getValueAt(i, 0).toString());
        textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
        textBookTitleInquiry.setText(model.getValueAt(i, 2).toString());
        textBookDescriptionInquiry1.setText(model.getValueAt(i, 3).toString()); 
    }//GEN-LAST:event_jTable6MouseClicked

    private void jTable6KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable6KeyPressed
    {//GEN-HEADEREND:event_jTable6KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable6.getSelectedRow();
            TableModel model=jTable6.getModel();           
            
            textBookIDInquiry.setText(model.getValueAt(i, 0).toString());
            textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
            textBookTitleInquiry.setText(model.getValueAt(i, 2).toString());
            textBookDescriptionInquiry1.setText(model.getValueAt(i, 3).toString());            
  
        }
    }//GEN-LAST:event_jTable6KeyPressed

    private void btnBookIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBookIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBookIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=3;
        Show_BookInquiry_In_JTable();
    }//GEN-LAST:event_btnBookIDInquiryActionPerformed

    private void btnAuthorNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=2;
        Show_BookInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorNameInquiryActionPerformed

    private void btnViewAllBooksActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllBooksActionPerformed
    {//GEN-HEADEREND:event_btnViewAllBooksActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnViewAllBooksActionPerformed

    private void btnClearAllBooksActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllBooksActionPerformed
    {//GEN-HEADEREND:event_btnClearAllBooksActionPerformed
        // TODO add your handling code here:
        textBookIDInquiry.setText("");
        textAuthorNameInquiry.setText("");
        textBookTitleInquiry.setText("");
        textBookDescriptionInquiry1.setText("");
    }//GEN-LAST:event_btnClearAllBooksActionPerformed

    //adds the book ID to the main textbox
    private void btnBookIDInquiryAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBookIDInquiryAddActionPerformed
    {//GEN-HEADEREND:event_btnBookIDInquiryAddActionPerformed
        // TODO add your handling code here:
        String x=textBookIDInquiry.getText().trim();
        if(x.equals(""))
            return;
        
        textBookID.setText(x);
        
    }//GEN-LAST:event_btnBookIDInquiryAddActionPerformed

    private void btnBookTitleInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBookTitleInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBookTitleInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=4;
        Show_BookInquiry_In_JTable();
    }//GEN-LAST:event_btnBookTitleInquiryActionPerformed

    private void jTable7MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable7MouseClicked
    {//GEN-HEADEREND:event_jTable7MouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTable7MouseClicked

    private void jTable7KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable7KeyPressed
    {//GEN-HEADEREND:event_jTable7KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable7KeyPressed

    //Librarian ID Inquiry
    private void btnLibrarianIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=3;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianIDInquiryActionPerformed

    //Librarian First Name Inquiry
    private void btnLibrarianFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianFirstNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=2;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianFirstNameInquiryActionPerformed

    //View all Librarians Inquiry
    private void btnViewAllLibrariansActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllLibrariansActionPerformed
    {//GEN-HEADEREND:event_btnViewAllLibrariansActionPerformed
        // TODO add your handling code here:
        viewall7=0;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnViewAllLibrariansActionPerformed

    //clear librarian textboxes
    private void btnClearAllLibrariansActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllLibrariansActionPerformed
    {//GEN-HEADEREND:event_btnClearAllLibrariansActionPerformed
        // TODO add your handling code here:
        textLibrarianIDInquiry.setText("");
        textLibrarianFirstNameInquiry.setText("");
        textLibrarianMiddleNameInquiry.setText("");
        textLibrarianLastNameInquiry.setText("");
        textLibrarianSuffixInquiry.setText("");
        textLibrarianRoleInquiry.setText("");
    }//GEN-LAST:event_btnClearAllLibrariansActionPerformed

    private void btnLibrarianInquiryAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianInquiryAddActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianInquiryAddActionPerformed
        // TODO add your handling code here:
        String x=textLibrarianIDInquiry.getText().trim();
        if(x.equals(""))
            return;
        
        textLibrarianID.setText(x);
    }//GEN-LAST:event_btnLibrarianInquiryAddActionPerformed

    //Librarian Middle Name Inquiry
    private void btnLibrarianMiddleNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianMiddleNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianMiddleNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=4;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianMiddleNameInquiryActionPerformed

    //Librarian Last Name Inquiry
    private void btnLibrarianLastNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianLastNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianLastNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=5;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianLastNameInquiryActionPerformed

    //Librarian Suffix Inquiry
    private void btnLibrarianSuffixInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianSuffixInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianSuffixInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=6;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianSuffixInquiryActionPerformed

    //Librarian Role Inquiry
    private void btnLibrarianRoleInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLibrarianRoleInquiryActionPerformed
    {//GEN-HEADEREND:event_btnLibrarianRoleInquiryActionPerformed
        // TODO add your handling code here:
        viewall7=7;
        Show_LibrarianInquiry_In_JTable();
    }//GEN-LAST:event_btnLibrarianRoleInquiryActionPerformed

    //Search By Librarian ID
    private void btnSearchByLibrarianIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLibrarianIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLibrarianIDActionPerformed
        // TODO add your handling code here:
        viewall=4;
        Show_BorrowersCard_In_JTable();
    }//GEN-LAST:event_btnSearchByLibrarianIDActionPerformed

    private void btnBookDescriptionInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBookDescriptionInquiryActionPerformed
    {//GEN-HEADEREND:event_btnBookDescriptionInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=5;
        Show_BookInquiry_In_JTable();
    }//GEN-LAST:event_btnBookDescriptionInquiryActionPerformed

    private void checkboxEnableDisableIDsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_checkboxEnableDisableIDsActionPerformed
    {//GEN-HEADEREND:event_checkboxEnableDisableIDsActionPerformed
        // TODO add your handling code here:
        if(checkboxEnableDisableIDs.isSelected())
        {
            //JOptionPane.showMessageDialog(null, "on");
            textBookID.setEnabled(true);
            textBorrowerID.setEnabled(true);
            textLibrarianID.setEnabled(true);
        }
        else
        {    
            //JOptionPane.showMessageDialog(null, "off");
            textBookID.setEnabled(!true);
            textBorrowerID.setEnabled(!true);
            textLibrarianID.setEnabled(!true);
        }
        
    }//GEN-LAST:event_checkboxEnableDisableIDsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAuthorNameInquiry;
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnBookDescriptionInquiry;
    private javax.swing.JButton btnBookIDInquiry;
    private javax.swing.JButton btnBookIDInquiryAdd;
    private javax.swing.JButton btnBookTitleInquiry;
    private javax.swing.JButton btnBorrowerFirstNameInquiry;
    private javax.swing.JButton btnBorrowerIDInquiry;
    private javax.swing.JButton btnBorrowerInquiryAdd;
    private javax.swing.JButton btnBorrowerLastNameInquiry;
    private javax.swing.JButton btnBorrowerMiddleNameInquiry;
    private javax.swing.JButton btnBorrowerRoleInquiry;
    private javax.swing.JButton btnBorrowerSuffixInquiry;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnClearAllBooks;
    private javax.swing.JButton btnClearAllBorrowers;
    private javax.swing.JButton btnClearAllLibrarians;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLibrarianFirstNameInquiry;
    private javax.swing.JButton btnLibrarianIDInquiry;
    private javax.swing.JButton btnLibrarianInquiryAdd;
    private javax.swing.JButton btnLibrarianLastNameInquiry;
    private javax.swing.JButton btnLibrarianMiddleNameInquiry;
    private javax.swing.JButton btnLibrarianRoleInquiry;
    private javax.swing.JButton btnLibrarianSuffixInquiry;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByBookID;
    private javax.swing.JButton btnSearchByBorrowerID;
    private javax.swing.JButton btnSearchByBorrowersCardID;
    private javax.swing.JButton btnSearchByLibrarianID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JButton btnViewAllBooks;
    private javax.swing.JButton btnViewAllBorrowers;
    private javax.swing.JButton btnViewAllLibrarians;
    private javax.swing.JCheckBox checkboxEnableDisableIDs;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTabbedPane jTabbedPane7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JRadioButton optAuthorInquiryGeneralSearch2;
    private javax.swing.JRadioButton optAuthorInquirySpecificSearch2;
    private javax.swing.JRadioButton optBookInquiryGeneralSearch;
    private javax.swing.JRadioButton optBookInquirySpecificSearch;
    private javax.swing.JRadioButton optBorrowerInquiryGeneralSearch;
    private javax.swing.JRadioButton optBorrowerInquirySpecificSearch;
    private javax.swing.JTextArea textAuthorInquiryPut;
    private javax.swing.JTextArea textAuthorInquiryPut4;
    private javax.swing.JTextArea textAuthorNameInquiry;
    private javax.swing.JTextArea textBookDescriptionInquiry1;
    private javax.swing.JTextField textBookID;
    private javax.swing.JTextField textBookIDInquiry;
    private javax.swing.JTextField textBookQuality;
    private javax.swing.JTextField textBookStatus;
    private javax.swing.JTextField textBookTitleInquiry;
    private javax.swing.JTextField textBorrowerFirstNameInquiry;
    private javax.swing.JTextField textBorrowerID;
    private javax.swing.JTextField textBorrowerIDInquiry;
    private javax.swing.JTextField textBorrowerLastNameInquiry;
    private javax.swing.JTextField textBorrowerMiddleNameInquiry;
    private javax.swing.JTextField textBorrowerRoleInquiry;
    private javax.swing.JTextField textBorrowerSuffixInquiry;
    private javax.swing.JTextField textBorrowersCardID;
    private javax.swing.JTextArea textComments;
    private javax.swing.JTextArea textDateAndTimeUpdated;
    private javax.swing.JTextField textLibrarianFirstNameInquiry;
    private javax.swing.JTextField textLibrarianID;
    private javax.swing.JTextField textLibrarianIDInquiry;
    private javax.swing.JTextField textLibrarianLastNameInquiry;
    private javax.swing.JTextField textLibrarianMiddleNameInquiry;
    private javax.swing.JTextField textLibrarianRoleInquiry;
    private javax.swing.JTextField textLibrarianSuffixInquiry;
    // End of variables declaration//GEN-END:variables
}
