/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import java.time.LocalDateTime; // Import the LocalDateTime class
import java.time.format.DateTimeFormatter; // Import the DateTimeFormatter class
import java.time.LocalDate;
import java.sql.PreparedStatement;

import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 *
 * @author owner
 */
public class SalesAndInventoryAugustUserLogtrailMaintenance extends javax.swing.JInternalFrame {
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    PreparedStatement stmt2;
    
    int curRow = 0,viewall=0;
    String query;
    
    String logtrailid;
    String userid;
    String username;

    /**
     * Creates new form SalesAndInventoryCristalUserLogtrailMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public SalesAndInventoryAugustUserLogtrailMaintenance(String Userid, String Username) {
        
        super("Log Trail Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Users_In_JTable();
    }
    
    public SalesAndInventoryAugustUserLogtrailMaintenance() {
        initComponents();
        
        DoConnect();
        Show_Users_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_logtrail";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 

            int id_col2 = rs.getInt("userid");
            
            String logtrailid2 = rs.getString("logtrailid");
            Date date2 = rs.getDate("date");
            Date time2=rs.getTime("time");
            //SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
            System.out.println("Format 2:   " + dateFormatter.format(date2));
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
            System.out.println("Format 2:   " + dateFormatter2.format(time2));

            textUserID.setText(Integer.toString(id_col2));
           
            textLogtrailID.setText(logtrailid2);
            textDate.setText(dateFormatter.format(date2));
            textTime.setText(dateFormatter2.format(time2));
            
            comboLogtype.removeAllItems();
            comboLogtype.addItem("Login");
            comboLogtype.addItem("Logout");
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
                        
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustUserLogtrailTable> getUsersLogtrailList()
    {
        
            
            ArrayList<SalesAndInventoryAugustUserLogtrailTable> ChurchInfoList= new ArrayList<SalesAndInventoryAugustUserLogtrailTable>();
        Connection connection = getConnection();
            
            
            try
            {
                
        
       
        
        
            if(viewall==0)
            {
                query = "Select * from tbl_logtrail";
            }
            else
            {
                logtrailid=textLogtrailID.getText();
                query = "Select * from tbl_logtrail where logtype like '%"+comboLogtype.toString()+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            //st= connection.createStatement();
            //rs=st.executeQuery(query);
                String frmDate1=textDate.getText();
            String toDate1=textTime.getText();
              frmDate1="2020-05-28";
              toDate1="2020-05-30";
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date from = sdf.parse(frmDate1);
            java.util.Date to = sdf.parse(toDate1);
            
            java.sql.Date from1 = new java.sql.Date(from.getTime());
            java.sql.Date to1 = new java.sql.Date(to.getTime());
            
            //String query1="select * from tbl_logtrail "
            //                + "where date >= '"+frmDate1+"' and date <= '"+toDate1+"'";
            //String query1="select * from tbl_logtrail where dateandtime >= '2020-05-28' and dateandtime <= '2020-05-30'";
            String query1="select * from tbl_logtrail ";
            stmt = connection.createStatement();
            /*
            stmt2.setDate(1, from1);
            stmt2.setDate(2, to1);*/
            
            rs = stmt.executeQuery(query1);
            SalesAndInventoryAugustUserLogtrailTable logtrail1;
            
            while(rs.next())
            {
                logtrail1 = new  SalesAndInventoryAugustUserLogtrailTable(rs.getInt("logtrailid"),rs.getInt("userid"), rs.getString("logtype"), rs.getDate("date"), rs.getTime("time"));
                ChurchInfoList.add(logtrail1);
            }
            
            
            
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
            
            
            
            
           
            
            
            
            
            return ChurchInfoList;
       
        
        
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustUserLogtrailTable> list = getUsersLogtrailList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[5];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getLogtrailID();
            row[1]=list.get(i).getUserID();
            row[2]=list.get(i).getLogtype();
            row[3]=list.get(i).getDate();
            row[4]=list.get(i).getTime();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * Creates new form SalesAndInventoryAugustUserLogtrailMaintenance
     */
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNewRecord = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        comboLogtype = new javax.swing.JComboBox<>();
        textCurDateTime = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnLast = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textDate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        textUserID = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        btnSearchByUserID = new javax.swing.JButton();
        textLogtrailID = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        textLogtype = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textTime = new javax.swing.JTextField();
        btnDisplayCurentDateTime = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to MDI Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText(" Date");

        comboLogtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboLogtype.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboLogtypeMouseClicked(evt);
            }
        });
        comboLogtype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboLogtypeActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Display Current Date and Time");

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("User ID");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Logtrail ID", "User ID", "Logtype", "Date", "Time"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Logtrail ID");

        btnDelete.setText("Delete this User");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSearchByUserID.setText("Search by User ID");
        btnSearchByUserID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUserIDActionPerformed(evt);
            }
        });

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Logtype");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        btnDisplayCurentDateTime.setText("Display Current Date and Time");
        btnDisplayCurentDateTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayCurentDateTimeActionPerformed(evt);
            }
        });

        btnClear.setText("Clear Textboxes");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(22, 22, 22)
                        .addComponent(btnFanAdminWelcome)
                        .addGap(165, 165, 165))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(212, 212, 212)
                        .addComponent(btnSaveRecord)
                        .addGap(36, 36, 36)
                        .addComponent(btnCancelNewRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane5)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(382, 382, 382))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textLogtrailID))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textDate))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(comboLogtype, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(textUserID)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textTime)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnSearchByUserID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnViewAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(textCurDateTime)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnDisplayCurentDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(218, 218, 218)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textLogtrailID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByUserID)
                    .addComponent(jLabel13)
                    .addComponent(textUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(textLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewAll))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDisplayCurentDateTime)
                    .addComponent(textCurDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete)
                        .addComponent(btnNewRecord))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnFanAdminWelcome)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord)
                    .addComponent(btnClear))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:

        try
        {

            curRow = rs.getRow( );
            textUserID.setText("");
            textLogtrailID.setText("");
            textDate.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        //new SalesAndInventoryAugustAdminWelcome(userid,logtrailid).setVisible(true);
        //this.dispose();
        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        //xx.setID(userid, uname);
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("userid");

            String logtrailid2 = rs.getString("logtrailid");
            String date2 = rs.getString("dateandtime");

            textUserID.setText(Integer.toString(id_col2));

            textLogtrailID.setText(logtrailid2);
            textDate.setText(date2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("userid");

                String logtrailid2 = rs.getString("logtrailid");
                String date2 = rs.getString("dateandtime");

                textUserID.setText(Integer.toString(id_col2));
                textLogtrailID.setText(logtrailid2);
                textDate.setText(logtrailid2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int id_col2 = rs.getInt("userid");
                int id_col3 = rs.getInt("logtrailid");
                String logtype2 = rs.getString("logtype");
                String date2 = rs.getString("dateandtime");

                //String date1=date2.toString().trim();
                textLogtrailID.setText(Integer.toString(id_col3));
                textUserID.setText(Integer.toString(id_col2));
                textLogtype.setText(logtype2);
                textDate.setText(date2);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int id_col2 = rs.getInt("userid");
            int id_col3 = rs.getInt("logtrailid");
            String logtype2 = rs.getString("logtype");
            String date2 = rs.getString("date");

            /*
            LocalDateTime myDateObj = LocalDateTime.now();
            DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
            String formattedDate = myDateObj.format(myFormatObj);*/

            //String date1=date2.toString().trim();
            textLogtrailID.setText(Integer.toString(id_col3));
            textUserID.setText(Integer.toString(id_col2));
            textLogtype.setText(logtype2);
            textDate.setText(date2);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int id_col2 = rs.getInt("userid");
                int id_col3 = rs.getInt("logtrailid");
                String logtype2 = rs.getString("logtype");
                String date2 = rs.getString("dateandtime");

                //String date1=date2.toString().trim();
                textLogtrailID.setText(Integer.toString(id_col3));
                textUserID.setText(Integer.toString(id_col2));
                textLogtype.setText(logtype2);
                textDate.setText(date2);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void comboLogtypeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboLogtypeMouseClicked
        // TODO add your handling code here:
        textLogtype.setText(comboLogtype.getItemAt(comboLogtype.getSelectedIndex()).trim());
    }//GEN-LAST:event_comboLogtypeMouseClicked

    private void comboLogtypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboLogtypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboLogtypeActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col2 = rs.getInt("userid");
            int id_col3 = rs.getInt("logtrailid");
            String logtype2 = rs.getString("logtype");
            String date2 = rs.getString("date");
            String time2 = rs.getString("time");

            //String date1=date2.toString().trim();
            textLogtrailID.setText(Integer.toString(id_col3));
            textUserID.setText(Integer.toString(id_col2));
            textLogtype.setText(logtype2);
            textDate.setText(date2);
            textTime.setText(time2);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textUserID.setText(model.getValueAt(i, 0).toString());
        textLogtrailID.setText(model.getValueAt(i, 1).toString());
        textLogtype.setText(model.getValueAt(i, 2).toString());
        textDate.setText(model.getValueAt(i, 3).toString());
        textTime.setText(model.getValueAt(i, 4).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textUserID.setText(model.getValueAt(i, 0).toString());
            textLogtrailID.setText(model.getValueAt(i, 1).toString());
            textLogtype.setText(model.getValueAt(i, 2).toString());
            textDate.setText(model.getValueAt(i, 3).toString());
            textTime.setText(model.getValueAt(i, 4).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=textUserID.getText().trim();
                int userid2=Integer.parseInt(userid);

                String logtrailid=textLogtrailID.getText().trim();
                int logtrailid2= Integer.parseInt(logtrailid);

                String date=textDate.getText().trim();

                stmt = con.createStatement( );
                String sql="Select * from tbl_logtrail where logtrailid="+logtrailid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                    sql="DELETE FROM  tbl_logtrail"
                    + " where logtrailid="+logtrailid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Fan Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid3=textUserID.getText().trim();
                int userid2=Integer.parseInt(userid3);

                String logtrailid=textLogtrailID.getText().trim();
                int logtrailid2=Integer.parseInt(logtrailid);
                Date date2= new Date();
                SimpleDateFormat ft =  new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss");
                String date=ft.format(date2).toString().trim();
                //String date=textDate.getText().trim();

                if(logtrailid.equals("")|| date.equals("")||userid3.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_logtrail where userid="+userid2+" or logtrailid='"+logtrailid+"' ";
                    String sql="Select * from tbl_logtrail where logtrailid='"+logtrailid+"' ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        rowCount++;
                    }

                    if(rowCount>1)
                    {
                        JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " Sorry, There Will be a Duplicate Record! ");
                    }
                    else
                    {

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                        sql="Update tbl_logtrail"
                        + " SET  logtype='"+comboLogtype.getItemAt(comboLogtype.getSelectedIndex()).trim()+"',dateandtime='"+date+"'"
                        + " where logtrailid="+logtrailid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Admin User Successfully Modified!");

                        Show_Users_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSearchByUserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUserIDActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSearchByUserIDActionPerformed

    private void btnDisplayCurentDateTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayCurentDateTimeActionPerformed
        // TODO add your handling code here:

        Date dNow = new Date( );
        SimpleDateFormat ft =
        new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss");

        //System.out.println("Current Date: " + ft.format(dNow));
        textCurDateTime.setText(ft.format(dNow));
    }//GEN-LAST:event_btnDisplayCurentDateTimeActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        textUserID.setText("");
        textLogtrailID.setText("");
        textLogtype.setText("");
        textDate.setText("");
        textTime.setText("");
        textCurDateTime.setText("");
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String logtrailID=textLogtrailID.getText().trim();
            int LogtrailID=Integer.parseInt(logtrailID);
            String userID=textUserID.getText().trim();
            int UserID=Integer.parseInt(userID);
            String logtype=comboLogtype.getItemAt(comboLogtype.getSelectedIndex());
            String date=textDate.getText().trim();

            if(logtrailID.equals("")|| date.equals("")||userID.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " Sorry, Either the logtrailid or password field/s is/are empty! ");
            }
            else
            {

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                String sql ="INSERT INTO tbl_logtrail " + "VALUES (NULL,"+userID+",'"+logtype+"', '"+date+"')";

                stmt.executeUpdate(sql);

                JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this,"A New Username is Added!");
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

                Show_Users_In_JTable();

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDisplayCurentDateTime;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUserID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JComboBox<String> comboLogtype;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textCurDateTime;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextField textLogtrailID;
    private javax.swing.JTextField textLogtype;
    private javax.swing.JTextField textTime;
    private javax.swing.JTextField textUserID;
    // End of variables declaration//GEN-END:variables
}
