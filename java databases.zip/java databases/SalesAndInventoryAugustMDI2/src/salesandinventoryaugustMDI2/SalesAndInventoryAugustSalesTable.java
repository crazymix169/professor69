/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustSalesTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int salesid;
    int stocksid;
    int goodsid;
    String goodsname;
    String goodsdescription;
    int quantityordered;
    double totalpayable;
    double totalpayment;
    double totalchange;
    String salesstatus;
    Date dateofsales;
    Date timeofsales;
    
    
    public SalesAndInventoryAugustSalesTable
    (
    int salesid,
    int stocksid,
    int goodsid,
    String goodsname,
    String goodsdescription,
    int quantityordered,
    double totalpayable,
    double totalpayment,
    double totalchange,
    String salesstatus,
    Date dateofsales,
    Date timeofsales
    )
    {
        
       
        this.salesid=salesid;
        this.stocksid=stocksid;
        this.goodsid=goodsid;
        this.goodsname=goodsname;
        this.goodsdescription=goodsdescription;
        this.quantityordered=quantityordered;
        this.totalpayable=totalpayable;
        this.totalpayment=totalpayment;
        this.totalchange=totalchange;
        this.salesstatus=salesstatus;
        this.dateofsales=dateofsales;
        this.timeofsales=timeofsales;
               
        
    }
    
    public int getSalesID()
    {
        return salesid;
    }
    
    public int getStocksID()
    {
        return stocksid;
    }
    public int getGoodsID()
    {
        return goodsid;
    }
    public String getGoodsName()
    {
        return goodsname;
    }
    public String getGoodsDescription()
    {
        return goodsdescription;
    }
    public int getQuantityOrdered()
    {
        return goodsid;
    }
    public double getTotalPayable()
    {
        return totalpayable;
    }
    public double getTotalPayment()
    {
        return totalpayment;
    }
    public double getTotalChange()
    {
        return totalchange;
    }
    public String getSalesStatus()
    {
        return salesstatus;
    }
    
    public Date getDateofSales()
    {
        return dateofsales;
    }
    
    public Date getTimeofSales()
    {
        return timeofsales;
    }
    
}
