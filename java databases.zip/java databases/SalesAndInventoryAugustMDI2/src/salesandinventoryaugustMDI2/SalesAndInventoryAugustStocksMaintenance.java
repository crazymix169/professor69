/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class SalesAndInventoryAugustStocksMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form SalesAndInventoryAugustStocksMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String goodsname;
    String goodsid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public SalesAndInventoryAugustStocksMaintenance(String Userid, String Username) {
        
        super("Stocks Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }
    
    public SalesAndInventoryAugustStocksMaintenance() {
        initComponents();
        
        DoConnect();
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            
            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_stocks";
            sql="";
            sql = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 
            
            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));
            
            textDate.setText(date);
            textTime.setText(time);
            
            viewall=0;
            viewall2=0;
            Show_Goods_In_JTable();
            Show_Stocks_In_JTable();
            
            //stmt.close();
            //con.close();
            /*
            stmt2 = con.createStatement( );
            sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            rowCount=0;

            rs2.next( ); 
            
            int id_col2 = rs2.getInt("goodsid");
            
            String goodsname2 = rs2.getString("goodsname");
            String goodsdescription2 = rs2.getString("goodsdescription");
            

            //textGoodsID.setText(Integer.toString(id_col2));
           
            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);*/
            
            //stmt.close();
            //con.close();
            
            
            
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustStocksTable> getStocksList()
    {
        ArrayList<SalesAndInventoryAugustStocksTable> stocksList= new ArrayList<SalesAndInventoryAugustStocksTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid";
            }
            else if(viewall==1)
            {
                
                
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid and tbl_stocks.goodsname like '%"+goodsname+"%' ";
            
            }
            else 
            {
                
                /*
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid and tbl_stocks.goodsid = "+goodsid+" ";*/
                
                //query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
                //query = "Select * from tbl_stocks where goodsid = "+goodsid+"";
                
                goodsid=textGoodsID.getText();
                int goodsid1=Integer.parseInt(goodsid);
                query = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                        +" tbl_stocks.quantity,tbl_stocks.price,"
                        +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                        +"tbl_gooods.goodsid=tbl_stocks.goodsid and tbl_stocks.goodsid= "+goodsid1+" ";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustStocksTable stocks1;
            
            while(rs.next())
            {
                stocks1 = new  SalesAndInventoryAugustStocksTable(rs.getInt("stocksid"),rs.getInt("goodsid"),
                        rs.getString("goodsname"),rs.getString("goodsdescription"),rs.getInt("quantity"),rs.getDouble("price"),rs.getDate("date")
                        , rs.getTime("time"));
                stocksList.add(stocks1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return stocksList;
     
    }
    
    public void Show_Stocks_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustStocksTable> list = getStocksList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[8];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getStocksID();
            row[1]=list.get(i).getGoodsID();
            row[2]=list.get(i).getGoodsname();
            row[3]=list.get(i).getGoodsDescription();
            row[4]=list.get(i).getQuantity();
            row[5]=list.get(i).getPrice();
            row[6]=list.get(i).getDateofStocks();
            row[7]=list.get(i).getTimeofStocks();
                        
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustGoodsTable> getGoodsList()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> goodsList= new ArrayList<SalesAndInventoryAugustGoodsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from tbl_goods";
            }
            else if(viewall==1)
            {
                goodsname=textGoodsName1.getText();
                query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
            
            }
            else
            {
                goodsid=textGoodsID1.getText();
                int gg=Integer.parseInt(goodsid);
                query="Select * from tbl_goods where goodsid= "+gg+"";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustGoodsTable goods1;
            
            while(rs2.next())
            {
                goods1 = new  SalesAndInventoryAugustGoodsTable(rs2.getInt("goodsid"), rs2.getString("goodsname"), 
                              rs2.getString("goodsdescription"));
                goodsList.add(goods1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return goodsList;
     
    }
    
    public void Show_Goods_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> list = getGoodsList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getGoodsID();
            row[1]=list.get(i).getGoodsName();
            row[2]=list.get(i).getGoodsDescription();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textPrice = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        textDate = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        btnSaveRecord = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnNewRecord = new javax.swing.JButton();
        textTime = new javax.swing.JTextField();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textGoodsID = new javax.swing.JTextField();
        textGoodsName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByGoodsname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textStocksID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textGoodsDescription = new javax.swing.JTextArea();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnLast = new javax.swing.JButton();
        textQuantity = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textGoodsID1 = new javax.swing.JTextField();
        textGoodsName1 = new javax.swing.JTextField();
        btnSearchByGoodsname1 = new javax.swing.JButton();
        btnSearchByGoodsID = new javax.swing.JButton();
        btnSearchByGoodsID1 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Stocks ID", "Goods ID", "Goods Name", "Goods Description", "Price", "Quantity", "Date", "Time"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Price");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText(" Date");

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Goods ID", "Goods Name", "Goods Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Goods Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        textGoodsName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Goods ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Goods Name");

        btnSearchByGoodsname.setText("Search by Goods Name in Stocks Available");
        btnSearchByGoodsname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Stocks ID");

        textGoodsDescription.setBackground(new java.awt.Color(51, 255, 255));
        textGoodsDescription.setColumns(20);
        textGoodsDescription.setRows(5);
        jScrollPane1.setViewportView(textGoodsDescription);

        btnFanAdminWelcome.setText("Back to MDI Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Quantity");

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Goods ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Goods Name");

        textGoodsName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByGoodsname1.setText("Search by Goods Name");
        btnSearchByGoodsname1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsname1ActionPerformed(evt);
            }
        });

        btnSearchByGoodsID.setText("Search by Goods ID in Stocks Available");
        btnSearchByGoodsID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsIDActionPerformed(evt);
            }
        });

        btnSearchByGoodsID1.setText("Search by Goods ID");
        btnSearchByGoodsID1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsID1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(92, 92, 92))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(14, 14, 14)
                                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(16, 16, 16)
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(textGoodsID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                                        .addComponent(textGoodsName, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textStocksID))
                                    .addComponent(btnSearchByGoodsname)
                                    .addComponent(btnSearchByGoodsID))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(10, 10, 10))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(btnSearchByGoodsID1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnSearchByGoodsname1))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(textGoodsID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(textGoodsName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(textPrice, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                            .addComponent(textQuantity))
                        .addContainerGap(572, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textTime)
                            .addComponent(textDate))
                        .addGap(467, 467, 467))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(btnFanAdminWelcome)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByGoodsname1)
                    .addComponent(btnSearchByGoodsID1)
                    .addComponent(btnFanAdminWelcome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textGoodsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addGap(136, 136, 136))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textGoodsID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textGoodsName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                                .addComponent(btnSearchByGoodsID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textGoodsName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchByGoodsname)
                                .addGap(16, 16, 16)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textDate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textStocksID.setText(model.getValueAt(i, 0).toString());
        textGoodsID.setText(model.getValueAt(i, 1).toString());
        textGoodsName.setText(model.getValueAt(i, 2).toString());
        textGoodsDescription.setText(model.getValueAt(i, 3).toString());
        textPrice.setText(model.getValueAt(i, 4).toString());
        textQuantity.setText(model.getValueAt(i, 5).toString());

        textDate.setText(model.getValueAt(i, 6).toString());
        textTime.setText(model.getValueAt(i, 7).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textStocksID.setText(model.getValueAt(i, 0).toString());
            textGoodsID.setText(model.getValueAt(i, 1).toString());
            textGoodsName.setText(model.getValueAt(i, 2).toString());
            textGoodsDescription.setText(model.getValueAt(i, 3).toString());
            textPrice.setText(model.getValueAt(i, 4).toString());
            textQuantity.setText(model.getValueAt(i, 5).toString());

            textDate.setText(model.getValueAt(i, 6).toString());
            textTime.setText(model.getValueAt(i, 7).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {                   

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                    

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql="DELETE FROM  tbl_stocks"
                    + " where stocksid="+stocksid2+"";
                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String goodsid=textGoodsID.getText().trim();
                int goodsid2=Integer.parseInt(goodsid);

                String price=textPrice.getText().trim();
                double price2=Double.parseDouble(price);

                String quantity=textQuantity.getText().trim();
                int quantity2=Integer.parseInt(quantity);
                

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(dNow);
                String time = ft.format(dNow2);

               

                if(stocksid.equals("")|| goodsid.equals("")|| price.equals("")|| quantity.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else if(price2<=0||quantity2<=0)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Price or Quantity should be greater than zero! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_stocks where stocksid="+stocksid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        

                        rowCount++;
                    }
                    
                    stmt = con.createStatement( );
                    sql="Select * from tbl_goods where goodsid="+goodsid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount2=0;

                    while ( rs.next( ) )
                    {
                        

                        rowCount2++;
                    }

                    if(rowCount==0||rowCount2==0)
                    {
                        JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, No Record Found! ");
                    }
                    else
                    {                        

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        

                        sql="Update tbl_stocks,tbl_sales"
                        + " SET  tbl_stocks.goodsid="+goodsid2+",tbl_stocks.price="+price2+",tbl_stocks.quantity="+quantity2+","
                        + " tbl_sales.totalpayable=tbl_sales.quantityordered*"+price2+", date=CURDATE(),time=CURTIME()"
                        + " where tbl_stocks.stocksid="+stocksid2+" and tbl_sales.stocksid=tbl_stocks.stocksid";

                        stmt.executeUpdate(sql);

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_sales"
                        + " SET  salesstatus='unsold', date=CURDATE(),time=CURTIME()"
                        + " where stocksid="+stocksid2+" and actualsales<=0";

                        stmt.executeUpdate(sql);

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_sales"
                        + " SET  salesstatus='partially sold', date=CURDATE(),time=CURTIME()"
                        + " where stocksid="+stocksid2+" and actualsales>0 and actualsales<totalpayable";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_sales"
                        + " SET  salesstatus='sold', date=CURDATE(),time=CURTIME()"
                        + " where stocksid="+stocksid2+" and actualsales>0 and actualsales>=totalpayable";

                        stmt.executeUpdate(sql);

                        stmt = con.createStatement( );
                        sql="Select * from tbl_stocks where stocksid="+stocksid2+" ";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            
                            rowCount++;
                            if(rowCount==1)
                            {

                                textStocksID.setText(Integer.toString(stocksid2));
                                textGoodsID.setText(Integer.toString(goodsid2));
                                textPrice.setText(Double.toString(price2));
                                textQuantity.setText(Integer.toString(quantity2));

                                textDate.setText(date);
                                textTime.setText(time);

                                stmt2 = con.createStatement( );
                                sql="Select * from tbl_goods where goodsid="+goodsid+"";
                                rs2 = stmt2.executeQuery(sql);

                                rowCount=0;
                                goodsid2 = 0;

                                String goodsname2 = "";
                                String goodsdescription2 = "";

                                while(rs2.next( ))
                                {
                                    if(goodsid2==rs2.getInt("goodsid"))
                                    {
                                        goodsid2 = rs2.getInt("goodsid");

                                        goodsname2 = rs2.getString("goodsname");
                                        goodsdescription2 = rs2.getString("goodsdescription");

                                        textGoodsID.setText(Integer.toString(goodsid2));

                                        textGoodsName.setText(goodsname2);
                                        textGoodsDescription.setText(goodsdescription2);
                                        break;
                                    }
                                }
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Record Successfully Modified!");
                       

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //String stocksid=textStocksID.getText().trim();
            //int stocksid2=Integer.parseInt(stocksid);

            String goodsid=textGoodsID.getText().trim();
            int goodsid2=Integer.parseInt(goodsid);

            String price=textPrice.getText().trim();
            double price2=Double.parseDouble(price);

            String quantity=textQuantity.getText().trim();
            int quantity2=Integer.parseInt(quantity);

            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft =
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 =
            new SimpleDateFormat (" hh:mm:ss ");

            String salesstatus="unsold";//textSalesStatus.getText().trim();

            String date=ft.format(dNow);//textDate.getText().trim();
            String time = ft2.format(dNow2);//textTime.getText().trim();

            if(goodsid.equals("")|| price.equals("")|| quantity.equals("")||
                salesstatus.equals("")|| date.equals("") || time.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Either the goodsname or password field/s is/are empty! ");
            }
            else if(price2<=0||quantity2<=0)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Price or Quantity should be greater than zero! ");
            }    
            else
            {
                stmt = con.createStatement( );
                //String sql="Select * from tbl_stocks where goodsid="+goodsid2+" ";
                String sql="Select * from tbl_goods where goodsid="+goodsid2+" ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    

                    rowCount++;
                }

                if(rowCount==0)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " Sorry, Good Item does not exists! ");
                }
                else
                {
                    

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_stocks " + "VALUES (NULL,"+goodsid2+", "+price2+","+quantity2+","
                    +"CURDATE(),CURTIME())";
                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );                    
                    sql = "Select tbl_stocks.stocksid,tbl_gooods.goodsid,tbl_goods.goodsname,"
                    +" tbl_stocks.quantity,tbl_stocks.price,"
                    +" tbl_stocks.date, tbl_stocks.time from tbl_stocks,tbl_goods where"
                    +"tbl_gooods.goodsid=tbl_stocks.goodsid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int stocksid2=rs.getInt("stocksid");

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " new inserted stocktrail item: "+Double.toString(stocksid2));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Goods_In_JTable();
                    Show_Stocks_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            textGoodsID.setText("");
            textGoodsName.setText("");
            textGoodsDescription.setText("");
            //textStocksID.setText("");
            //textGoodsID.setText("");
            textPrice.setText("");
            textQuantity.setText("");

            textDate.setText("");
            textTime.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");

            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));

            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");

                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();

        textGoodsID.setText(model.getValueAt(i, 0).toString());
        textGoodsName.setText(model.getValueAt(i, 1).toString());
        textGoodsDescription.setText(model.getValueAt(i, 2).toString());
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable2KeyTyped

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textGoodsID.setText("");
        textGoodsName.setText("");
        textGoodsDescription.setText("");

        textStocksID.setText("");
        textGoodsID.setText("");
        textPrice.setText("");
        textQuantity.setText("");

        textDate.setText("");
        textTime.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnSearchByGoodsnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsnameActionPerformed
        // TODO add your handling code here:
        
        viewall2=1;
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsnameActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int stocksid = rs.getInt("stocksid");
                int goodsid = rs.getInt("goodsid");
                String goodsname=rs.getString("goodsname");
                String goodsdescription=rs.getString("goodsdescription");
                double price=rs.getDouble("price");
                int quantity=rs.getInt("quantity");

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(rs.getDate("date"));
                String time = ft.format(rs.getTime("time"));

                textStocksID.setText(Integer.toString(stocksid));
                textGoodsID.setText(Integer.toString(goodsid));
                textPrice.setText(Double.toString(price));
                textQuantity.setText(Integer.toString(quantity));

                textDate.setText(date);
                textTime.setText(time);

                stmt2 = con.createStatement( );
                String sql="Select * from tbl_goods where goodsid="+goodsid+"";
                rs2 = stmt2.executeQuery(sql);

                int rowCount=0;
                int goodsid2 = 0;

                String goodsname2 = "";
                String goodsdescription2 = "";

                while(rs2.next( ))
                {
                    if(goodsid==rs2.getInt("goodsid"))
                    {
                        goodsid2 = rs2.getInt("goodsid");

                        goodsname2 = rs2.getString("goodsname");
                        goodsdescription2 = rs2.getString("goodsdescription");

                        textGoodsID.setText(Integer.toString(goodsid2));

                        textGoodsName.setText(goodsname2);
                        textGoodsDescription.setText(goodsdescription2);
                        break;
                    }
                }

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Goods_In_JTable();
        Show_Stocks_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");

            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft =
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 =
            new SimpleDateFormat (" hh:mm:ss ");

            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));

            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));

            textDate.setText(date);
            textTime.setText(time);

            stmt2 = con.createStatement( );
            String sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            int rowCount=0;
            int goodsid2 = 0;

            String goodsname2 = "";
            String goodsdescription2 = "";

            while(rs2.next( ))
            {
                if(goodsid==rs2.getInt("goodsid"))
                {
                    goodsid2 = rs2.getInt("goodsid");

                    goodsname2 = rs2.getString("goodsname");
                    goodsdescription2 = rs2.getString("goodsdescription");

                    textGoodsID.setText(Integer.toString(goodsid2));

                    textGoodsName.setText(goodsname2);
                    textGoodsDescription.setText(goodsdescription2);
                    break;
                }
            }

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        //new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        //this.dispose();
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        //xx.setID(userid, uname);
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int stocksid = rs.getInt("stocksid");
                int goodsid = rs.getInt("goodsid");
                String goodsname=rs.getString("goodsname");
                String goodsdescription=rs.getString("goodsdescription");
                double price=rs.getDouble("price");
                int quantity=rs.getInt("quantity");

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(rs.getDate("date"));
                String time = ft.format(rs.getTime("time"));

                textStocksID.setText(Integer.toString(stocksid));
                textGoodsID.setText(Integer.toString(goodsid));
                textPrice.setText(Double.toString(price));
                textQuantity.setText(Integer.toString(quantity));

                textDate.setText(date);
                textTime.setText(time);

                stmt2 = con.createStatement( );
                String sql="Select * from tbl_goods where goodsid="+goodsid+"";
                rs2 = stmt2.executeQuery(sql);

                int rowCount=0;
                int goodsid2 = 0;

                String goodsname2 = "";
                String goodsdescription2 = "";

                while(rs2.next( ))
                {
                    if(goodsid==rs2.getInt("goodsid"))
                    {
                        goodsid2 = rs2.getInt("goodsid");

                        goodsname2 = rs2.getString("goodsname");
                        goodsdescription2 = rs2.getString("goodsdescription");

                        textGoodsID.setText(Integer.toString(goodsid2));

                        textGoodsName.setText(goodsname2);
                        textGoodsDescription.setText(goodsdescription2);
                        break;
                    }
                }

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int stocksid = rs.getInt("stocksid");
            int goodsid = rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double price=rs.getDouble("price");
            int quantity=rs.getInt("quantity");

            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft =
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 =
            new SimpleDateFormat (" hh:mm:ss ");

            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));

            textStocksID.setText(Integer.toString(stocksid));
            textGoodsID.setText(Integer.toString(goodsid));
            textPrice.setText(Double.toString(price));
            textQuantity.setText(Integer.toString(quantity));

            textDate.setText(date);
            textTime.setText(time);

            stmt2 = con.createStatement( );
            String sql="Select * from tbl_goods where goodsid="+goodsid+"";
            rs2 = stmt2.executeQuery(sql);

            int rowCount=0;
            int goodsid2 = 0;

            String goodsname2 = "";
            String goodsdescription2 = "";

            while(rs2.next( ))
            {
                if(goodsid==rs2.getInt("goodsid"))
                {
                    goodsid2 = rs2.getInt("goodsid");

                    goodsname2 = rs2.getString("goodsname");
                    goodsdescription2 = rs2.getString("goodsdescription");

                    textGoodsID.setText(Integer.toString(goodsid2));

                    textGoodsName.setText(goodsname2);
                    textGoodsDescription.setText(goodsdescription2);
                    break;
                }
            }

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustStocksMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnSearchByGoodsname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsname1ActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Goods_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsname1ActionPerformed

    private void btnSearchByGoodsIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsIDActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Stocks_In_JTable();
        
    }//GEN-LAST:event_btnSearchByGoodsIDActionPerformed

    private void btnSearchByGoodsID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsID1ActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Goods_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsID1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByGoodsID;
    private javax.swing.JButton btnSearchByGoodsID1;
    private javax.swing.JButton btnSearchByGoodsname;
    private javax.swing.JButton btnSearchByGoodsname1;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextArea textGoodsDescription;
    private javax.swing.JTextField textGoodsID;
    private javax.swing.JTextField textGoodsID1;
    private javax.swing.JTextField textGoodsName;
    private javax.swing.JTextField textGoodsName1;
    private javax.swing.JTextField textPrice;
    private javax.swing.JTextField textQuantity;
    private javax.swing.JTextField textStocksID;
    private javax.swing.JTextField textTime;
    // End of variables declaration//GEN-END:variables
}
