/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.awt.Component;
import java.beans.PropertyVetoException;
import java.lang.System.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author crazymix69
 */
public class InternalFrameDemo extends javax.swing.JFrame { 
    


    /**
     * Creates new form InternalFrameDemo
     */
    
    JDesktopPane desktop;
    String Username;
    String Userid;
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    //labelUserID=new javax.swing.JLabel();
    /*
    public InternalFrameDemo(String username, String userid) {
        
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        initComponents();
        labelUserID.setVisible(false);
        labelUserName.setVisible(false);
        labelUserID.setText(userid);
        labelUserName.setText(username);
        Userid=userid;
        Username=username;
        JOptionPane.showMessageDialog(null, labelUserName.getText(), labelUserID.getText(), HEIGHT);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }*/
    public void setID(String userid, String username) 
    {
        Userid = userid;
        Username=username;
    }
    
    public void enabler()
    {
        fileMenu.setEnabled(!false);
        editMenu.setEnabled(!false);
        helpMenu.setEnabled(!false);
        jMenuLogger.setEnabled(!false);
    }
    
    public void disabler()
    {
        fileMenu.setEnabled(false);
        editMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuLogger.setEnabled(!false);
    }        
    
    public InternalFrameDemo() {
        
        super("Sales and Inventory System");
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        
        initComponents();
        
        
        
        fileMenu.setEnabled(false);
        editMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        //jMenuLogger.setEnabled(false);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }
    
    /*
    User Login, Logtrail and User maintenance Forms
    */
    
    protected void createUserMaintenanceFrame()
    {
        SalesAndInventoryAugustUserMaintenance frame = new SalesAndInventoryAugustUserMaintenance();
       
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    protected void createFrameLoginForm()
    {
        
        
        
        SalesAndInventoryAugustLoginForm frame = new SalesAndInventoryAugustLoginForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    protected void createFrameLogtrailMaintenance()
    {
        
        
        
        SalesAndInventoryAugustUserLogtrailMaintenance frame = new SalesAndInventoryAugustUserLogtrailMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    /*
    Transaction of Sales and Inventory
    */
    
    protected void createFrameGoodsMaintenance()
    {
        
        
        
        SalesAndInventoryAugustGoodsMaintenance frame = new SalesAndInventoryAugustGoodsMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    protected void createFrameStocksMaintenance()
    {
        
        
        
        SalesAndInventoryAugustStocksMaintenance frame = new SalesAndInventoryAugustStocksMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    protected void createFrameSalesMaintenance()
    {
        
        
        
        SalesAndInventoryAugustSalesMaintenance frame = new SalesAndInventoryAugustSalesMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    protected void createFramePaymentMaintenance()
    {
        
        
        
        SalesAndInventoryAugustPaymentMaintenance frame = new SalesAndInventoryAugustPaymentMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    /*
    Content Form
    */
    protected void createFrameContentForm()
    {
        
        
        
        SalesAndInventoryAugustContentForm frame = new SalesAndInventoryAugustContentForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    protected void createFrameAboutTheAuthorForm()
    {
        
        
        
        SalesAndInventoryAugustAboutTheAuthorForm frame = new SalesAndInventoryAugustAboutTheAuthorForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        UserMaintenanceMenuItem = new javax.swing.JMenuItem();
        LogtrailMaintenanceMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        GoodsMaintenanceMenuItem = new javax.swing.JMenuItem();
        StocksMaintenanceMenuItem = new javax.swing.JMenuItem();
        SalesMaintenanceMenuItem = new javax.swing.JMenuItem();
        PaymentMaintenanceMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        contentMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();
        jMenuLogger = new javax.swing.JMenu();
        jMenuItemLoginForm = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        desktopPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        desktopPane.setName(""); // NOI18N

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        UserMaintenanceMenuItem.setMnemonic('o');
        UserMaintenanceMenuItem.setText("User Maintenance");
        UserMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(UserMaintenanceMenuItem);

        LogtrailMaintenanceMenuItem.setMnemonic('s');
        LogtrailMaintenanceMenuItem.setText("Log Trail Maintenance");
        LogtrailMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogtrailMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(LogtrailMaintenanceMenuItem);

        menuBar.add(fileMenu);

        editMenu.setMnemonic('e');
        editMenu.setText("Transaction");

        GoodsMaintenanceMenuItem.setMnemonic('t');
        GoodsMaintenanceMenuItem.setText("Goods Maintenance");
        GoodsMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GoodsMaintenanceMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(GoodsMaintenanceMenuItem);

        StocksMaintenanceMenuItem.setMnemonic('y');
        StocksMaintenanceMenuItem.setText("Stocks Maintenance");
        StocksMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StocksMaintenanceMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(StocksMaintenanceMenuItem);

        SalesMaintenanceMenuItem.setMnemonic('p');
        SalesMaintenanceMenuItem.setText("Sales Maintenance");
        SalesMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalesMaintenanceMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(SalesMaintenanceMenuItem);

        PaymentMaintenanceMenuItem.setMnemonic('d');
        PaymentMaintenanceMenuItem.setText("Payment Maintenance");
        PaymentMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymentMaintenanceMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(PaymentMaintenanceMenuItem);

        menuBar.add(editMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        contentMenuItem.setMnemonic('c');
        contentMenuItem.setText("Contents");
        contentMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contentMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(contentMenuItem);

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        jMenuLogger.setText("Logger");

        jMenuItemLoginForm.setText("Show Login Form Or Logout");
        jMenuItemLoginForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLoginFormActionPerformed(evt);
            }
        });
        jMenuLogger.add(jMenuItemLoginForm);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        jMenuLogger.add(exitMenuItem);

        menuBar.add(jMenuLogger);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        desktopPane.getAccessibleContext().setAccessibleName("Sales and Inventory System");
        desktopPane.getAccessibleContext().setAccessibleParent(desktopPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_logtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            

            con.close();
            stmt.close();
            rs.close();
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        editMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        JOptionPane.showMessageDialog(InternalFrameDemo.this, "Exiting Application!");
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void UserMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        createUserMaintenanceFrame();
        
         
        
    }//GEN-LAST:event_UserMaintenanceMenuItemActionPerformed

    private void jMenuItemLoginFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLoginFormActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_logtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            

            con.close();
            stmt.close();
            rs.close();
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        editMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        //jMenuLogger.setEnabled(false);
        
        
    }//GEN-LAST:event_jMenuItemLoginFormActionPerformed

    private void LogtrailMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogtrailMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //Username=labelUserName.getText();
        //Userid=labelUserID.getText();
        createFrameLogtrailMaintenance();
        //JOptionPane.showMessageDialog(null, Username, Userid, HEIGHT);
        
    }//GEN-LAST:event_LogtrailMaintenanceMenuItemActionPerformed

    private void GoodsMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GoodsMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameGoodsMaintenance();
    }//GEN-LAST:event_GoodsMaintenanceMenuItemActionPerformed

    private void StocksMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StocksMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameStocksMaintenance();
    }//GEN-LAST:event_StocksMaintenanceMenuItemActionPerformed

    private void SalesMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalesMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameSalesMaintenance();
    }//GEN-LAST:event_SalesMaintenanceMenuItemActionPerformed

    private void PaymentMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymentMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFramePaymentMaintenance();
    }//GEN-LAST:event_PaymentMaintenanceMenuItemActionPerformed

    private void contentMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contentMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameContentForm();
    }//GEN-LAST:event_contentMenuItemActionPerformed

    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameAboutTheAuthorForm();
    }//GEN-LAST:event_aboutMenuItemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InternalFrameDemo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem GoodsMaintenanceMenuItem;
    private javax.swing.JMenuItem LogtrailMaintenanceMenuItem;
    private javax.swing.JMenuItem PaymentMaintenanceMenuItem;
    private javax.swing.JMenuItem SalesMaintenanceMenuItem;
    private javax.swing.JMenuItem StocksMaintenanceMenuItem;
    private javax.swing.JMenuItem UserMaintenanceMenuItem;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JMenuItem contentMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem jMenuItemLoginForm;
    private javax.swing.JMenu jMenuLogger;
    private javax.swing.JMenuBar menuBar;
    // End of variables declaration//GEN-END:variables

}
