/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author owner
 */
public class SalesAndInventoryAugustGoodsMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form NewJInternalFrame
     */
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    int curRow = 0,viewall=0;
    String query;
    
    String username;
    String userid;
    String goodsname;

    /**
     * Creates new form SalesAndInventoryCristalGoodsMaintenance
     */
    
    static int openFrameCount = 1;
    static final int xOffset = 30, yOffset = 30;
    
    public SalesAndInventoryAugustGoodsMaintenance(String Userid, String Username) {
        
        super("Goods Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Users_In_JTable();
    }
    
    public SalesAndInventoryAugustGoodsMaintenance() {
        initComponents();
        
        DoConnect();
        Show_Users_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_goods";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 

            int id_col2 = rs.getInt("goodsid");
            
            String goodsname2 = rs.getString("goodsname");
            String goodsdescription2 = rs.getString("goodsdescription");
            

            textGoodsID.setText(Integer.toString(id_col2));
           
            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
           Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustGoodsTable> getGoodsList()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> idolList= new ArrayList<SalesAndInventoryAugustGoodsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from tbl_goods";
            }
            else
            {
                goodsname=textGoodsName.getText();
                query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustGoodsTable users1;
            
            while(rs.next())
            {
                users1 = new  SalesAndInventoryAugustGoodsTable(rs.getInt("goodsid"), rs.getString("goodsname"), rs.getString("goodsdescription"));
                idolList.add(users1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return idolList;
     
    }
    
    public void Show_Users_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustGoodsTable> list = getGoodsList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getGoodsID();
            row[1]=list.get(i).getGoodsName();
            row[2]=list.get(i).getGoodsDescription();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCancelNewRecord = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        textGoodsDescription = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        textGoodsName = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnSaveRecord = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btnNewRecord = new javax.swing.JButton();
        textGoodsID = new javax.swing.JTextField();
        btnSearchByUsername = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to MDI Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        textGoodsDescription.setColumns(20);
        textGoodsDescription.setRows(5);
        jScrollPane1.setViewportView(textGoodsDescription);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Goods ID", "Goods Name", "Goods Description"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Goods Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Goods ID");

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Goods Name");

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnSearchByUsername.setText("Search by Goods Name");
        btnSearchByUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByUsernameActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnFanAdminWelcome)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(242, 242, 242))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textGoodsID))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textGoodsName)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSearchByUsername)
                    .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(686, 686, 686))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(textGoodsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(textGoodsName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchByUsername))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewAll))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete)
                        .addComponent(btnNewRecord)
                        .addComponent(btnFanAdminWelcome))
                    .addComponent(btnEdit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord)
                    .addComponent(btnClearAll))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");

            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));

            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");

                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");
                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int id_col2 = rs.getInt("goodsid");

            String goodsname2=rs.getString("goodsname");
            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));
            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsname2);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        //new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        //this.dispose();
        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        //xx.setID(userid, uname);
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int id_col2 = rs.getInt("goodsid");
                String goodsname2=rs.getString("goodsname");
                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");
            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));
            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsname2);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textGoodsID.setText(model.getValueAt(i, 0).toString());
        textGoodsName.setText(model.getValueAt(i, 1).toString());
        textGoodsDescription.setText(model.getValueAt(i, 2).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textGoodsID.setText("");
        textGoodsName.setText("");
        textGoodsDescription.setText("");
    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String goodsid=textGoodsID.getText().trim();
                int goodsid2=Integer.parseInt(goodsid);

                String goodsname=textGoodsName.getText().trim();
                String goodsdescription=textGoodsDescription.getText().trim();

                stmt = con.createStatement( );
                String sql="Select * from tbl_goods where goodsid="+goodsid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("goodsid");
                    String goodsname2 = rs.getString("goodsname");
                    String goodsdescription2 = rs.getString("goodsdescription");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*
                    sql="Update table_idolinformation"
                    + " SET  fangoodsname='"+goodsname+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                    + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                    + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                    + " where idolinformationid="+goodsid2+"";*/
                    /*
                    sql="DELETE [QUICK] FROM tbl_goods[.*], [,tbl_stocks[.*]] [,tbl_stocktrail[.*]] [,tbl_sales[.*]] USING  tbl_goods"
                    //+ " INNER JOIN tbl_stocks INNER JOIN tbl_stocktrail INNER JOIN tbl_sales  "
                    +"WHERE tbl_goods.goodsid="+goodsid2+" AND "
                    +"tbl_stocks.goodsid=tbl_goods.goodsid AND tbl_stocktrail.stocksid=tbl_stocks.stocksid"
                    +"AND tbl_sales.stocksid=tbl_stocks.stocksid";*/

                    sql="DELETE FROM  tbl_goods"
                    + " where goodsid="+goodsid2+"";

                    stmt.executeUpdate(sql);

                    /*
                    DELETE employee, benefits FROM employee
                    INNER JOIN benefits INNER JOIN contractor
                    WHERE employee.id=benefits.id AND benefits.id=contractor.id;
                    */

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Fan Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String goodsid3=textGoodsID.getText().trim();
                int goodsid2=Integer.parseInt(goodsid3);

                String goodsname=textGoodsName.getText().trim();
                String goodsdescription=textGoodsDescription.getText().trim();

                if(goodsname.equals("")|| goodsdescription.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_goods where goodsid="+goodsid2+" or goodsname='"+goodsname+"' ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("goodsid");
                        String goodsname2 = rs.getString("goodsname");
                        String goodsdescription2 = rs.getString("goodsdescription");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==2)
                    {
                        JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " Sorry, There Will be a Duplicate Record! ");
                    }
                    else
                    {

                        /*
                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        /*
                        sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */

                        sql="Update tbl_goods"
                        + " SET  goodsname='"+goodsname+"',goodsdescription='"+goodsdescription+"'"
                        + " where goodsid="+goodsid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Admin User Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        Show_Users_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String goodsname=textGoodsName.getText().trim();
            String goodsdescription=textGoodsDescription.getText().trim();

            if(goodsname.equals("")|| goodsdescription.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " Sorry, Either the goodsname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
                String sql="Select * from tbl_goods where goodsname='"+goodsname+"' ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("goodsid");
                    String goodsname2 = rs.getString("goodsname");
                    String goodsdescription2 = rs.getString("goodsdescription");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_goods " + "VALUES (NULL,'"+goodsname+"', '"+goodsdescription+"')";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this,"A New Username is Added!");
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Users_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            textGoodsID.setText("");
            textGoodsName.setText("");
            textGoodsDescription.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustGoodsMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnSearchByUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUsernameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnSearchByUsernameActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Users_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUsername;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea textGoodsDescription;
    private javax.swing.JTextField textGoodsID;
    private javax.swing.JTextField textGoodsName;
    // End of variables declaration//GEN-END:variables
}
