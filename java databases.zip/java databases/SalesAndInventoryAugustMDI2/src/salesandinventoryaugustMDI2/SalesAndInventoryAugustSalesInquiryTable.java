/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustSalesInquiryTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    String goodsname;
    String goodsdescription;
    int stocksid;
    double price;
    int quantity;
    double totalamountpayable;
    
    
    
    public SalesAndInventoryAugustSalesInquiryTable
    (
    String goodsname,
    String goodsdescription,
    int stocksid,
    double price,
    int quantity,
    double totalamountpayable
    )
    {
        
       
        this.goodsname=goodsname;
        this.goodsdescription=goodsdescription;
        this.stocksid=stocksid;
        this.price=price;
        this.quantity=quantity;
        this.totalamountpayable=totalamountpayable;
               
        
    }
    
    public String getGoodsName()
    {
        return goodsname;
    }
    
    public String getGoodsDescription()
    {
        return goodsdescription;
    }
    
    public int getStocksID()
    {
        return stocksid;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public int getQuantity()
    {
        return quantity;
    }
    
    public double getTotalAmountPayable()
    {
        return totalamountpayable;
    }
    
}