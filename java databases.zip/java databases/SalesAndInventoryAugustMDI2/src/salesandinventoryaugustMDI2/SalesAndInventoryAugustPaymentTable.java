/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventoryaugustMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustPaymentTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int paymentid;
    int salesid;
    int stocksid;
    int goodsid;
    String goodsname;
    String goodsdescription;
    double amountpaid;
    
    String remarks;
    Date dateofpayment;
    Date timeofpayment;
    
    
    public SalesAndInventoryAugustPaymentTable
    (
    int paymentid,
    int salesid,
    int stocksid,
    int goodsid,
    String goodsname,
    String goodsdescription,
    double amountpaid,
    
    String remarks,
    Date dateofpayment,
    Date timeofpayment
    )
    {
        
        this.paymentid=paymentid;
        this.salesid=salesid;
        this.stocksid=stocksid;
        this.goodsid=goodsid;
        this.goodsname=goodsname;
        this.goodsdescription=goodsdescription;
        this.amountpaid=amountpaid;
        
        this.remarks=remarks;
        this.dateofpayment=dateofpayment;
        this.timeofpayment=timeofpayment;
               
        
    }
    
    public int getPaymentID()
    {
        return paymentid;
    }
    
    public int getSalesID()
    {
        return salesid;
    }
    
    public int getStocksID()
    {
        return stocksid;
    }
    public int getGoodsID()
    {
        return goodsid;
    }
    public String getGoodsName()
    {
        return goodsname;
    }
    public String getGoodsDescription()
    {
        return goodsdescription;
    }
    
    public double getAmountPaid()
    {
        return amountpaid;
    }
    public String getRemarks()
    {
        return remarks;
    }
    
    public Date getDateofPayment()
    {
        return dateofpayment;
    }
    
    public Date getTimeofPayment()
    {
        return timeofpayment;
    }
    
}
