/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class CableSalesInformationSystemCashierMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    
    // tbl_area fieldvarialbes
    private static final String TBL_CASHIER_CASHIERID = "cashierid";  // Compliant
    private static final String TBL_CASHIER_FIRSTNAME = "firstname";  // Compliant
    private static final String TBL_CASHIER_MIDDLENAME = "middlename";  // Compliant
    private static final String TBL_CASHIER_LASTNAME = "lastname";  // Compliant
    private static final String TBL_CASHIER_SUFFIX = "suffix";  // Compliant
    private static final String TBL_CASHIER_ROLE = "role";  // Compliant
    private static final String TBL_CASHIER_SEX = "sex";  // Compliant
    private static final String TBL_CASHIER_BIRTHDATE = "birthdate";  // Compliant
    private static final String TBL_CASHIER_ADDRESS = "address";  // Compliant
    private static final String TBL_CASHIER_HOBBY = "hobby";  // Compliant
    private static final String TBL_CASHIER_SKILLS = "skills";  // Compliant
    private static final String TBL_CASHIER_EDUCATIONALATTAINMENT = "educationalattainment";  // Compliant
    
    
    

    /**
     * Creates new form Cashier Maintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public CableSalesInformationSystemCashierMaintenance() {
        super("Cashier Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Cashier_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_cashier`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                textSex.setText(rs.getString(TBL_CASHIER_SEX));
                textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));                            
                
                
            
            }           
            
            viewall=0;           
            
            Show_Cashier_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<CableSalesInformationSystemCashierTable> getCashierList()
    {
        ArrayList<CableSalesInformationSystemCashierTable> cashierList= new ArrayList<CableSalesInformationSystemCashierTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_cashier`";
            }
            else if(viewall==1)
            {
                
                
                String firstname=textFirstName.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_cashier` WHERE "                       
                        +" firstname like '%"+firstname+"%' ";
            
                
            }
            else if(viewall==4)
            {
                
                
                String middlename=textMiddleName.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_cashier` WHERE "                       
                        +" middlename like '%"+middlename+"%' ";
            
                
            }
            else if(viewall==5)
            {
                
                String lastname=textLastName.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_cashier` WHERE "                       
                        +" lastname like '%"+lastname+"%' ";
                
                
            
                
            }
            else if(viewall==6)
            {
                
                String suffix=textSuffix.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_cashier` WHERE "                       
                        +" suffix like '%"+suffix+"%' ";
                
                
            
                
            }            
            else if(viewall==3) 
            {
                
                               
                
                String cashierid=textCashierID.getText().trim();
                int cashierid1=Integer.parseInt(cashierid);
                
                query ="SELECT * FROM `tbl_cashier` WHERE cashierid = "+cashierid1+"";
            }
            else if(viewall==2) 
            {
                
                String role=textRole.getText();
                
                
                query ="SELECT * FROM `tbl_cashier` WHERE role like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemCashierTable cashier;
            
            while(rs.next())
            {
                cashier = new  CableSalesInformationSystemCashierTable(
                        rs.getInt(TBL_CASHIER_CASHIERID),
                        rs.getString(TBL_CASHIER_FIRSTNAME),rs.getString(TBL_CASHIER_MIDDLENAME),
                        rs.getString(TBL_CASHIER_LASTNAME),
                        rs.getString(TBL_CASHIER_SUFFIX),
                        rs.getString(TBL_CASHIER_ROLE),
                        rs.getString(TBL_CASHIER_SEX),
                        rs.getString(TBL_CASHIER_BIRTHDATE), 
                        rs.getString(TBL_CASHIER_ADDRESS),rs.getString(TBL_CASHIER_HOBBY),
                        rs.getString(TBL_CASHIER_SKILLS),rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT)
                );
                cashierList.add(cashier);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " error269: "+e.getMessage());
        }
        
        return cashierList;
     
    }
    
    public void Show_Cashier_In_JTable()
    {
        ArrayList<CableSalesInformationSystemCashierTable> list = getCashierList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCashierID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();
            row[4]=list.get(i).getSuffix();
            row[5]=list.get(i).getRole();          
            row[6]=list.get(i).getSex();
            row[7]=list.get(i).getBirthDate();            
            row[8]=list.get(i).getAddress();
            row[9]=list.get(i).getHobby();   
            row[10]=list.get(i).getSkills(); 
            row[11]=list.get(i).getEducationalAttainment();
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        textSuffix = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByFirstName = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        textRole = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByRole = new javax.swing.JButton();
        btnSearchByCashierID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textCashierID = new javax.swing.JTextField();
        textFirstName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textMiddleName = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textLastName = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textBirthdate = new javax.swing.JTextField();
        textSex = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textHobby = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        textSkills = new javax.swing.JTextArea();
        jLabel22 = new javax.swing.JLabel();
        btnSearchByMiddleName = new javax.swing.JButton();
        btnSearchByLastName = new javax.swing.JButton();
        btnSearchBySuffix = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        textAddress = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        textEducationalAttainment = new javax.swing.JTextArea();
        jLabel23 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Cashier ID", "First Name", "Middle Name", "Last Name", "Suffix", "Role", "Sex", "Birthdate", "Address", "Hobby", "Skills", "Educational Attainment"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Suffix");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Role");

        btnSearchByFirstName.setText("Search by First Name");
        btnSearchByFirstName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByFirstNameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        textRole.setBackground(new java.awt.Color(51, 255, 255));
        textRole.setColumns(20);
        textRole.setRows(5);
        jScrollPane1.setViewportView(textRole);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByRole.setText("Search by Role");
        btnSearchByRole.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRoleActionPerformed(evt);
            }
        });

        btnSearchByCashierID.setText("Search by Cashier ID ");
        btnSearchByCashierID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCashierIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Cashier ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Middle Name");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText(" Last Name");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Birthdate");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Sex");

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Hobby");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("First Name");

        textHobby.setBackground(new java.awt.Color(51, 255, 255));
        textHobby.setColumns(20);
        textHobby.setRows(5);
        jScrollPane2.setViewportView(textHobby);

        textSkills.setBackground(new java.awt.Color(51, 255, 255));
        textSkills.setColumns(20);
        textSkills.setRows(5);
        jScrollPane3.setViewportView(textSkills);

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("Skills");

        btnSearchByMiddleName.setText("Search by Middle Name");
        btnSearchByMiddleName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByMiddleNameActionPerformed(evt);
            }
        });

        btnSearchByLastName.setText("Search by Last Name");
        btnSearchByLastName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLastNameActionPerformed(evt);
            }
        });

        btnSearchBySuffix.setText("Search by Suffix");
        btnSearchBySuffix.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySuffixActionPerformed(evt);
            }
        });

        textAddress.setBackground(new java.awt.Color(51, 255, 255));
        textAddress.setColumns(20);
        textAddress.setRows(5);
        jScrollPane4.setViewportView(textAddress);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Address");

        textEducationalAttainment.setBackground(new java.awt.Color(51, 255, 255));
        textEducationalAttainment.setColumns(20);
        textEducationalAttainment.setRows(5);
        jScrollPane6.setViewportView(textEducationalAttainment);

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Educational Attainment");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(435, 435, 435)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textCashierID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textBirthdate, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textSex, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(4, 4, 4))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnPrevious)
                                        .addGap(25, 25, 25)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnDelete)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchByCashierID))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnSearchByFirstName)
                            .addComponent(btnSearchByLastName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchByMiddleName))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnSearchBySuffix, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textSuffix))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(4, 4, 4))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(6, 6, 6)
                                            .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(106, 106, 106)
                                            .addComponent(btnSearchByRole)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel23)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByCashierID))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(textCashierID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByFirstName)
                            .addComponent(btnSearchByMiddleName))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByLastName)
                            .addComponent(btnSearchBySuffix)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(textBirthdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel22))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23)
                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel20)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel21)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(textSuffix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addComponent(btnSearchByRole)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textCashierID.setText(model.getValueAt(i, 0).toString());
        textFirstName.setText(model.getValueAt(i, 1).toString());
        textMiddleName.setText(model.getValueAt(i, 2).toString());
        textLastName.setText(model.getValueAt(i, 3).toString());
        textSuffix.setText(model.getValueAt(i, 4).toString());
        textRole.setText(model.getValueAt(i, 5).toString());
        textSex.setText(model.getValueAt(i, 6).toString());
        textBirthdate.setText(model.getValueAt(i, 7).toString());        
        textAddress.setText(model.getValueAt(i, 8).toString());
        textHobby.setText(model.getValueAt(i, 9).toString());       
        textSkills.setText(model.getValueAt(i, 10).toString()); 
        textEducationalAttainment.setText(model.getValueAt(i, 11).toString()); 
               
        
               
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textCashierID.setText(model.getValueAt(i, 0).toString());
            textFirstName.setText(model.getValueAt(i, 1).toString());
            textMiddleName.setText(model.getValueAt(i, 2).toString());
            textLastName.setText(model.getValueAt(i, 3).toString());
            textSuffix.setText(model.getValueAt(i, 4).toString());
            textRole.setText(model.getValueAt(i, 5).toString());
            textSex.setText(model.getValueAt(i, 6).toString());
            textBirthdate.setText(model.getValueAt(i, 7).toString());        
            textAddress.setText(model.getValueAt(i, 8).toString());
            textHobby.setText(model.getValueAt(i, 9).toString());       
            textSkills.setText(model.getValueAt(i, 10).toString());
            textEducationalAttainment.setText(model.getValueAt(i, 11).toString());
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    
    //delete record   
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String cashierid=textCashierID.getText().trim();
                int cashierid2=Integer.parseInt(cashierid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_cashier` where cashierid="+cashierid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_cashier"
                    + " where cashierid="+cashierid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String cashierid = textCashierID.getText().trim();
                int cashierid2=Integer.parseInt(cashierid);
                String firstname=textFirstName.getText().trim();
                String middlename=textMiddleName.getText().trim();
                String lastname=textLastName.getText().trim();
                String suffix=textSuffix.getText().trim();
                String role=textRole.getText().trim();
                String sex=textSex.getText().trim();
                String birthdate=textBirthdate.getText().trim();               
                String address=textAddress.getText().trim();
                String hobby=textHobby.getText().trim();              
                String skills=textSkills.getText().trim();
                String educationalattainment=textEducationalAttainment.getText().trim();
              
                if(cashierid.equals("")||firstname.equals("")
                   || middlename.equals("")|| lastname.equals("")|| birthdate.equals("")
                   || sex.equals("")|| suffix.equals("")|| role.equals("")|| skills.equals("")
                   || address.equals("")|| hobby.equals("")||educationalattainment.equals(""))
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_cashier` where "
                            + "cashierid="+cashierid+"  "
                        + "and suffix='"+suffix+"' and firstname='"+firstname+"' "
                        + "and middlename='"+middlename+"' and lastname='"+lastname+"')";;
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        sql="UPDATE `tbl_cashier` "
                                + "SET "
                                + "`suffix`='"+suffix+"',`role`='"+role+"',"
                                + "`skills`='"+skills+"',`firstname`='"+firstname+"',"
                                + "`middlename`='"+middlename+"',`lastname`='"+lastname+"',"
                                + "`sex`='"+sex+"',`birthdate`='"+birthdate+"',"
                                + "`address`='"+address+"',`hobby`='"+hobby+"',"
                                + " `educationalattainment`='"+educationalattainment+"'"
                                + " WHERE `cashierid`="+cashierid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_cashier` where "
                            + "cashierid="+cashierid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {   
                            rowCount++;
                            if(rowCount==1)
                            {
                                textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                                textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                                textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                                textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                                textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                                textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                                textSex.setText(rs.getString(TBL_CASHIER_SEX));
                                textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                                textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                                textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                                textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                                textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));
                                
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            //String cashierid = textCashierID.getText().trim();
            //int cashierid2=Integer.parseInt(cashierid);
            //StringtextPositionrsontype=textLegalPersonType.getText().trim();
            String firstname=textFirstName.getText().trim();
            String middlename=textMiddleName.getText().trim();
            String lastname=textLastName.getText().trim();
            String suffix=textSuffix.getText().trim();
            String role=textRole.getText().trim();
            String sex=textSex.getText().trim();
            String birthdate=textBirthdate.getText().trim();               
            String address=textAddress.getText().trim();
            String hobby=textHobby.getText().trim();
            String skills=textSkills.getText().trim();
            String educationalattainment=textEducationalAttainment.getText().trim();
            
            
                   
            

           if(firstname.equals("")|| suffix.equals("")|| 
                   role.equals("")|| skills.equals("")
                   || middlename.equals("")|| lastname.equals("")|| birthdate.equals("")
                   || sex.equals("")
                   || address.equals("")|| hobby.equals("")|| educationalattainment.equals(""))
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_cashier` where  "
                        + " suffix='"+suffix+"' and firstname='"+firstname+"' "
                        + "and middlename='"+middlename+"' and lastname='"+lastname+"'";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="INSERT INTO `tbl_cashier`(`cashierid`,`firstname`, `middlename`, `lastname`,"
                            + " `suffix`, `role`, `sex`, "
                            + ", `birthdate`, `address`, `hobby`, `skills`,"
                            + " `educationalattainment`) "
                            + "VALUES (NULL,'"+firstname+"','"+middlename+"','"+lastname+"','"+suffix+"',"
                            + "'"+role+"','"+sex+"','"+birthdate+"','"+address+"',"
                            + "'"+hobby+"','"+skills+"','"+educationalattainment+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_cashier`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                    textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                    textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                    textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                    textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                    textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                    textSex.setText(rs.getString(TBL_CASHIER_SEX));
                    textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                    textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                    textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                    textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                    textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));               
                    
                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " new inserted record item: "+textCashierID.getText());

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_Cashier_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textCashierID.setText("");
            textFirstName.setText("");
            textMiddleName.setText("");
            textLastName.setText("");
            textSuffix.setText("");
            textRole.setText("");
            textSex.setText(""); 
            textBirthdate.setText("");
            textAddress.setText("");
            textHobby.setText("");    
            textSkills.setText(""); 
            textEducationalAttainment.setText("");
          
            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this," Error: "+ err.getMessage());
            
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
            textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
            textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
            textRole.setText(rs.getString(TBL_CASHIER_ROLE));
            textSex.setText(rs.getString(TBL_CASHIER_SEX));
            textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
            textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
            textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
            textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
            textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));
            
             
            
            
              
            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                textSex.setText(rs.getString(TBL_CASHIER_SEX));
                textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));     

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textCashierID.setText("");
                textFirstName.setText("");
                textMiddleName.setText("");
                textLastName.setText("");
                textSuffix.setText("");
                textRole.setText("");
                textSex.setText(""); 
                textBirthdate.setText("");
                textAddress.setText("");
                textHobby.setText("");    
                textSkills.setText("");  
                textEducationalAttainment.setText(""); 
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handlitextPositionhere:
        textCashierID.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textSuffix.setText("");
        textRole.setText("");
        textSex.setText(""); 
        textBirthdate.setText("");
        textAddress.setText("");
        textHobby.setText("");    
        textSkills.setText(""); 
        textEducationalAttainment.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search borrower first Name
    private void btnSearchByFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByFirstNameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSearchByFirstNameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                textSex.setText(rs.getString(TBL_CASHIER_SEX));
                textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;       
        
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
            textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
            textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
            textRole.setText(rs.getString(TBL_CASHIER_ROLE));
            textSex.setText(rs.getString(TBL_CASHIER_SEX));
            textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
            textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
            textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
            textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
            textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {
                textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
                textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
                textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
                textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
                textRole.setText(rs.getString(TBL_CASHIER_ROLE));
                textSex.setText(rs.getString(TBL_CASHIER_SEX));
                textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
                textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
                textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
                textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
                textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            textCashierID.setText(Integer.toString(rs.getInt(TBL_CASHIER_CASHIERID)));
            textFirstName.setText(rs.getString(TBL_CASHIER_FIRSTNAME));
            textMiddleName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textLastName.setText(rs.getString(TBL_CASHIER_MIDDLENAME));
            textSuffix.setText(rs.getString(TBL_CASHIER_SUFFIX));
            textRole.setText(rs.getString(TBL_CASHIER_ROLE));
            textSex.setText(rs.getString(TBL_CASHIER_SEX));
            textBirthdate.setText(rs.getString(TBL_CASHIER_BIRTHDATE));
            textAddress.setText(rs.getString(TBL_CASHIER_ADDRESS));
            textHobby.setText(rs.getString(TBL_CASHIER_HOBBY));
            textSkills.setText(rs.getString(TBL_CASHIER_SKILLS));  
            textEducationalAttainment.setText(rs.getString(TBL_CASHIER_EDUCATIONALATTAINMENT));

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemCashierMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search role 
    private void btnSearchByRoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByRoleActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Cashier_In_JTable();
        
    }//GEN-LAST:event_btnSearchByRoleActionPerformed

    //search Cashier ID
    private void btnSearchByCashierIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCashierIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCashierIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSearchByCashierIDActionPerformed

    //search by middle name
    private void btnSearchByMiddleNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByMiddleNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByMiddleNameActionPerformed
        // TODO add your handling code here:
        viewall=4;
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSearchByMiddleNameActionPerformed

    //Search by last name
    private void btnSearchByLastNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLastNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLastNameActionPerformed
        // TODO add your handling code here:
        viewall=5;
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSearchByLastNameActionPerformed

    //search by suffix
    private void btnSearchBySuffixActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySuffixActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySuffixActionPerformed
        // TODO add your handling code here:
        viewall=6;
        Show_Cashier_In_JTable();
    }//GEN-LAST:event_btnSearchBySuffixActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByCashierID;
    private javax.swing.JButton btnSearchByFirstName;
    private javax.swing.JButton btnSearchByLastName;
    private javax.swing.JButton btnSearchByMiddleName;
    private javax.swing.JButton btnSearchByRole;
    private javax.swing.JButton btnSearchBySuffix;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea textAddress;
    private javax.swing.JTextField textBirthdate;
    private javax.swing.JTextField textCashierID;
    private javax.swing.JTextArea textEducationalAttainment;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextArea textHobby;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextArea textRole;
    private javax.swing.JTextField textSex;
    private javax.swing.JTextArea textSkills;
    private javax.swing.JTextField textSuffix;
    // End of variables declaration//GEN-END:variables
}
