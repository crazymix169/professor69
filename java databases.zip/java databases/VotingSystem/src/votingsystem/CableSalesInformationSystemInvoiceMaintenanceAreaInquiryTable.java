/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemInvoiceMaintenanceAreaInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int areaid;
    String city;
    String district;
    String barangay;
    String comments;
    
    
    public CableSalesInformationSystemInvoiceMaintenanceAreaInquiryTable
    (            
        int areaid,
        String city,
        String district,
        String barangay,
        String comments
        
    )
            
    {
        this.areaid=areaid;   
        this.city=city;
        this.district=district;
        this.barangay=barangay;        
        this.comments=comments;
          
              
    }
    
    public int getAreaID()
    {
        return areaid;
    }
    
    public String getCity()
    {
        return city;
    }
    public String getDistrict()
    {
        return district;
    }
    public String getBarangay()
    {
        return barangay;
    }
    
    public String getComments()
    {
        return comments;
    }
    
}
