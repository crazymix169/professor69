/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class CableSalesInformationSystemInvoiceMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs11,rs3,rs4,rs5,rs6,rs2;
    
    int curRow = 0,viewall=0,viewall11=0,viewall3=0,viewall4=0,viewall5=0,viewall6=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    
    // tbl_customer fieldvariables inquiry
    private static final String TBL_CUSTOMER_CUSTOMERID = "customerid";  // Compliant
    private static final String TBL_CUSTOMER_FIRSTNAME = "firstname";  // Compliant
    private static final String TBL_CUSTOMER_MIDDLENAME = "middlename";  // Compliant
    private static final String TBL_CUSTOMER_LASTNAME = "lastname";  // Compliant
    private static final String TBL_CUSTOMER_SUFFIX = "suffix";  // Compliant
    private static final String TBL_CUSTOMER_ROLE = "role";  // Compliant
    
    // tbl_subscription fieldvariables
    private static final String TBL_SUBSCRIPTION_SUBSCRIPTIONID = "subscriptionid";  // Compliant
    private static final String TBL_SUBSCRIPTION_SUBSCRIBEDPLAN = "subscribedplan";  // Compliant
    private static final String TBL_SUBSCRIPTION_MONTHLYPAYABLE = "monthlypayable";  // Compliant    
    private static final String TBL_SUBSCRIPTION_COMMENTS = "comments";  // Compliant
    
    // tbl_area fieldvariables inquiry
    private static final String TBL_AREA_AREAID = "areaid";  // Compliant
    private static final String TBL_AREA_CITY = "city";  // Compliant
    private static final String TBL_AREA_DISTRICT = "district";  // Compliant
    private static final String TBL_AREA_BARANGAY = "barangay";  // Compliant
    private static final String TBL_AREA_COMMENTS = "comments";  // Compliant
    
    // tbl_technician fieldvariables
    private static final String TBL_TECHNICIAN_TECHNICIANID = "technicianid";  // Compliant
    private static final String TBL_TECHNICIAN_FIRSTNAME = "firstname";  // Compliant
    private static final String TBL_TECHNICIAN_MIDDLENAME = "middlename";  // Compliant
    private static final String TBL_TECHNICIAN_LASTNAME = "lastname";  // Compliant
    private static final String TBL_TECHNICIAN_SUFFIX = "suffix";  // Compliant
    private static final String TBL_TECHNICIAN_ROLE = "role";  // Compliant
    
       
    // tbl_invoice fieldvarialbes
    private static final String TBL_INVOICE_INVOICEID = "invoiceid";  // Compliant
    private static final String TBL_INVOICE_CUSTOMERID = "firstname";  // Compliant
    private static final String TBL_INVOICE_SUBSCRIPTIONID = "middlename";  // Compliant
    private static final String TBL_INVOICE_AREAID = "lastname";  // Compliant
    private static final String TBL_INVOICE_LEADTECHNICIANID = "suffix";  // Compliant
    private static final String TBL_INVOICE_SECONDARYTECHNICIANS = "role";  // Compliant
    
    
    
    

    /**
     * Creates new form Cashier Maintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public CableSalesInformationSystemInvoiceMaintenance() {
        super("Invoice Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Invoice_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_invoice`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));
                                            
                
                
            
            }           
            
            viewall=0;           
            
            Show_Invoice_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    //Invoice maintenance
    public ArrayList<CableSalesInformationSystemInvoiceTable> getInvoiceList()
    {
        ArrayList<CableSalesInformationSystemInvoiceTable> invoiceList= new ArrayList<CableSalesInformationSystemInvoiceTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_invoice`";
            }
            else if(viewall==1)
            {
                
                
                String firstname=textCustomerID.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_invoice` WHERE "                       
                        +" firstname like '%"+firstname+"%' ";
            
                
            }
            else if(viewall==4)
            {
                
                
                String middlename=textSubscriptionID.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_invoice` WHERE "                       
                        +" middlename like '%"+middlename+"%' ";
            
                
            }
            else if(viewall==5)
            {
                
                String lastname=textAreaID.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_invoice` WHERE "                       
                        +" lastname like '%"+lastname+"%' ";
                
                
            
                
            }
            else if(viewall==6)
            {
                
                String suffix=textLeadTechnicianID.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_invoice` WHERE "                       
                        +" suffix like '%"+suffix+"%' ";
                
                
            
                
            }            
            else if(viewall==3) 
            {
                
                               
                
                String invoiceid=textInvoiceID.getText().trim();
                int invoiceid1=Integer.parseInt(invoiceid);
                
                query ="SELECT * FROM `tbl_invoice` WHERE invoiceid = "+invoiceid1+"";
            }
            else if(viewall==2) 
            {
                
                String role=textSecondaryTechnicians.getText();
                
                
                query ="SELECT * FROM `tbl_invoice` WHERE role like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemInvoiceTable invoice;
            
            while(rs.next())
            {
                invoice = new  CableSalesInformationSystemInvoiceTable(
                        rs.getInt(TBL_INVOICE_CUSTOMERID),
                        rs.getInt(TBL_INVOICE_INVOICEID),
                        rs.getInt(TBL_INVOICE_SUBSCRIPTIONID),
                        rs.getInt(TBL_INVOICE_AREAID),
                        rs.getInt(TBL_INVOICE_LEADTECHNICIANID),
                        rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS)
                );
                invoiceList.add(invoice);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, e.getMessage());
        }
        
        return invoiceList;
     
    }
    
    public void Show_Invoice_In_JTable()
    {
        ArrayList<CableSalesInformationSystemInvoiceTable> list = getInvoiceList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getInvoiceID();
            row[1]=list.get(i).getCustomerID();
            row[2]=list.get(i).getSubscriptionID();
            row[3]=list.get(i).getAreaID();
            row[4]=list.get(i).getLeadTechnicianID();
            row[5]=list.get(i).getSecondaryTechnicians();          
          
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    //Customer Inquiry
    public ArrayList<CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable> getCustomerList()
    {
        ArrayList<CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable> customerList= new ArrayList<CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall3==0)
            {
                query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer`";
            }
            else if(viewall3==1)
            {
                
                
                String firstname=textCustomerFirstNameInquiry.getText().trim();
                
                                
                 query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE "                       
                        +" firstname like '%"+firstname+"%' ";
            
                
            }
            else if(viewall3==4)
            {
                
                
                String middlename=textCustomerMiddleNameInquiry.getText().trim();
                
                                
                 query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE "                       
                        +" middlename like '%"+middlename+"%' ";
            
                
            }
            else if(viewall3==5)
            {
                
                String lastname=textCustomerLastNameInquiry.getText().trim();
                
                                
                 query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE "                       
                        +" lastname like '%"+lastname+"%' ";
                
                
            
                
            }
            else if(viewall3==6)
            {
                
                String suffix=textCustomerSuffixInquiry.getText().trim();
                
                                
                 query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE "                       
                        +" suffix like '%"+suffix+"%' ";
                
                
            
                
            }            
            else if(viewall3==3) 
            {
                
                               
                
                String customerid=textCustomerIDInquiry.getText().trim();
                int customerid1=Integer.parseInt(customerid);
                
                query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE customerid = "+customerid1+"";
            }
            else if(viewall3==2) 
            {
                
                String role=textCustomerRoleInquiry.getText();
                
                
                query ="SELECT `customerid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_customer` WHERE role like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs3=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable customer;
            
            while(rs3.next())
            {
                customer = new  CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable(
                        rs3.getInt(TBL_CUSTOMER_CUSTOMERID),
                        rs3.getString(TBL_CUSTOMER_FIRSTNAME),rs.getString(TBL_CUSTOMER_MIDDLENAME),
                        rs3.getString(TBL_CUSTOMER_LASTNAME),
                        rs3.getString(TBL_CUSTOMER_SUFFIX),
                        rs3.getString(TBL_CUSTOMER_ROLE)
                       
                );
                customerList.add(customer);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, e.getMessage());
        }
        
        return customerList;
     
    }
    
    public void Show_Customer_In_JTable()
    {
        ArrayList<CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable> list = getCustomerList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCustomerID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();
            row[4]=list.get(i).getSuffix();
            row[5]=list.get(i).getRole();          
          
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    //Subscription Inquiry
    public ArrayList<CableSalesInformationSystemSubscriptionTable> getSubscriptionList()
    {
        ArrayList<CableSalesInformationSystemSubscriptionTable> subscriptionList= new ArrayList<CableSalesInformationSystemSubscriptionTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall11==0)
            {
                query ="SELECT * FROM `tbl_subscription`";
            }
            else if(viewall11==1)
            {
                
                
                String subscribedplan=textSubscribedPlan.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_subscription` WHERE "                       
                        +" subscribedplan like '%"+subscribedplan+"%' ";
            
                
            }
            else if(viewall11==4)
            {
                
                
                String monthlypayable=textMonthlyPayable.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_subscription` WHERE "                       
                        +" monthlypayable like '%"+monthlypayable+"%' ";
            
                
            }
            
            else if(viewall11==6)
            {
                
                String comments=textComments.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_subscription` WHERE "                       
                        +" comments like '%"+comments+"%' ";
                
                
            
                
            }
            
            else if(viewall11==3) 
            {
                
                               
                
                String subscriptionid=textSubscriptionID.getText().trim();
                int subscriptionid1=Integer.parseInt(subscriptionid);
                
                query ="SELECT * FROM `tbl_subscription` WHERE subscriptionid = "+subscriptionid1+"";
            }
            else if(viewall11==2) 
            {
                
                String role=textComments.getText();
                
                
                query ="SELECT * FROM `tbl_subscription` WHERE role like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs11=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemSubscriptionTable subscription;
            
            while(rs11.next())
            {
                subscription = new  CableSalesInformationSystemSubscriptionTable(
                        rs11.getInt(TBL_SUBSCRIPTION_SUBSCRIPTIONID),
                        rs11.getString(TBL_SUBSCRIPTION_SUBSCRIBEDPLAN),rs11.getDouble(TBL_SUBSCRIPTION_MONTHLYPAYABLE),                        
                        rs11.getString(TBL_SUBSCRIPTION_COMMENTS)
                       
                );
                subscriptionList.add(subscription);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+e.getMessage());
        }
        
        return subscriptionList;
     
    }
    
    public void Show_Subscription_In_JTable()
    {
        ArrayList<CableSalesInformationSystemSubscriptionTable> list = getSubscriptionList();
        DefaultTableModel model = (DefaultTableModel)jTable11.getModel();
               
        Object[] row = new Object[4];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSubscriptonID();
            row[1]=list.get(i).getSubscribedPlan();
            row[2]=list.get(i).getMonthlyPayable();            
            row[3]=list.get(i).getComments();
            
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    //technician Inquiry
    public ArrayList<CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable> getTechnicianList()
    {
        ArrayList<CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable> technicianList= new ArrayList<CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall5==0)
            {
                query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician`";
            }
            else if(viewall5==1)
            {
                
                
                String firstname=textFirstNameTechnicianInquiry5.getText().trim();
                
                                
                 query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE "                       
                        +" firstname like '%"+firstname+"%' ";
            
                
            }
            else if(viewall5==4)
            {
                
                
                String middlename=textMiddleNameTechnicianInquiry5.getText().trim();
                
                                
                 query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE "                       
                        +" middlename like '%"+middlename+"%' ";
            
                
            }
            else if(viewall5==5)
            {
                
                String lastname=textLastNameTechnicianInquiry5.getText().trim();
                
                                
                 query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE "                       
                        +" lastname like '%"+lastname+"%' ";
                
                
            
                
            }
            else if(viewall5==6)
            {
                
                String suffix=textSuffixTechnicianInquiry5.getText().trim();
                
                                
                 query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE "                       
                        +" suffix like '%"+suffix+"%' ";
                
                
            
                
            }            
            else if(viewall5==3) 
            {
                
                               
                
                String technicianid=textTechnicianIDInquiry5.getText().trim();
                int technicianid1=Integer.parseInt(technicianid);
                
                query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE technicianid = "+technicianid1+"";
            }
            else if(viewall5==2) 
            {
                
                String role=textRoleTechnicianInquiry5.getText();
                
                
                query ="SELECT `technicianid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_technician` WHERE role like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs5=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable technician;
            
            while(rs5.next())
            {
                technician = new  CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable(
                        rs5.getInt(TBL_TECHNICIAN_TECHNICIANID),
                        rs5.getString(TBL_TECHNICIAN_FIRSTNAME),rs5.getString(TBL_TECHNICIAN_MIDDLENAME),
                        rs5.getString(TBL_TECHNICIAN_LASTNAME),
                        rs5.getString(TBL_TECHNICIAN_SUFFIX),
                        rs5.getString(TBL_TECHNICIAN_ROLE)
                        
                );
                technicianList.add(technician);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+e.getMessage());
        }
        
        return technicianList;
     
    }
    
    public void Show_Technician_In_JTable()
    {
        ArrayList<CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable> list = getTechnicianList();
        DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getTechnicianID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();
            row[4]=list.get(i).getSuffix();
            row[5]=list.get(i).getRole();          
            
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    //area inquiry
    public ArrayList<CableSalesInformationSystemAreaTable> getAreaList()
    {
        ArrayList<CableSalesInformationSystemAreaTable> areaList= new ArrayList<CableSalesInformationSystemAreaTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query ="SELECT * FROM `tbl_area`";
            }
            else if(viewall2==1)
            {
                String city=textCity.getText().trim();
                
                if(jCheckBoxExactSearch.isSelected())
                {
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city = '"+city+"' ";
                }
                else
                {
                    
                
                                
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city like '%"+city+"%' ";
                }
                        
                
            
                
            }
            else if(viewall2==4)
            {
                String district=textDistrict.getText().trim();
                
                if(jCheckBoxExactSearch.isSelected())
                {
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" district = '"+district+"' ";
                }
                else
                {
                    
                
                                
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" district like '%"+district+"%' ";
                }
                
                
                                
                 
            
                
            }
            else if(viewall2==5)
            {      
                String barangay=textBarangay.getText().trim();
                
                if(jCheckBoxExactSearch.isSelected())
                {
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" barangay = '"+barangay+"' ";
                }
                else
                {
                    
                
                                
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" barangay like '%"+barangay+"%' ";
                }
          
            }
            else if(viewall2==6)
            {
                
                String comments=textComments.getText().trim();
                
                if(jCheckBoxExactSearch.isSelected())
                {
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" comments = '"+comments+"' ";
                }
                else
                {                    
                      
                    query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" comments like '%"+comments+"%' ";
                }
                                
                 query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" comments like '%"+comments+"%' ";
                
                
            
                
            }
            
            else if(viewall2==3) 
            {
                
                               
                
                String areaid=textAreaID.getText().trim();
                int areaid1=Integer.parseInt(areaid);
                
                query ="SELECT * FROM `tbl_area` WHERE areaid = "+areaid1+"";
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemAreaTable area;
           
            while(rs2.next())
            {
                area = new  CableSalesInformationSystemAreaTable(
                        rs2.getInt(TBL_AREA_AREAID),
                        rs2.getString(TBL_AREA_CITY),rs2.getString(TBL_AREA_DISTRICT),
                        rs2.getString(TBL_AREA_BARANGAY),
                        rs2.getString(TBL_AREA_COMMENTS)
                       
                );
                areaList.add(area);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+e.getMessage());
        }
        
        return areaList;
     
    }
    
    public void Show_Area_In_JTable()
    {
        ArrayList<CableSalesInformationSystemAreaTable> list = getAreaList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[5];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getAreaID();
            row[1]=list.get(i).getCity();
            row[2]=list.get(i).getDistrict();
            row[3]=list.get(i).getBarangay();
            row[4]=list.get(i).getComments();
            
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        textLeadTechnicianID = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByFirstName = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        textSecondaryTechnicians = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchBySecondaryTechnicians = new javax.swing.JButton();
        btnSearchByInvoiceID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textInvoiceID = new javax.swing.JTextField();
        textCustomerID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textSubscriptionID = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textAreaID = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        btnSearchByMiddleName = new javax.swing.JButton();
        btnSearchByLastName = new javax.swing.JButton();
        jTabbedPaneInvoiceMaintenanceInquiry = new javax.swing.JTabbedPane();
        jTabbedPaneInvoiceMaintenanceInquiry1 = new javax.swing.JTabbedPane();
        jPanelCustomerInquiry = new javax.swing.JPanel();
        btnSearchByCustomerID = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        textCustomerIDInquiry = new javax.swing.JTextField();
        btnSearchByFirstName2 = new javax.swing.JButton();
        btnSearchByMiddleName2 = new javax.swing.JButton();
        btnSearchByLastName2 = new javax.swing.JButton();
        btnSearchBySuffix2 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        textCustomerFirstNameInquiry = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        textCustomerMiddleNameInquiry = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        textCustomerLastNameInquiry = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        textCustomerSuffixInquiry = new javax.swing.JTextField();
        btnSearchByRole3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        textCustomerRoleInquiry = new javax.swing.JTextArea();
        btnFirst3 = new javax.swing.JButton();
        btnPrevious3 = new javax.swing.JButton();
        btnNext3 = new javax.swing.JButton();
        btnLast3 = new javax.swing.JButton();
        btnViewAllCustomerInquiry3 = new javax.swing.JButton();
        btnClearAllCustomerInquiry3 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jCheckBoxExactSearch3 = new javax.swing.JCheckBox();
        jPanelSubscriptionInquiry = new javax.swing.JPanel();
        btnSearchBySubscriptionID = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        textSubscriptionID1 = new javax.swing.JTextField();
        btnSearchByCity1 = new javax.swing.JButton();
        btnSearchBySpecificCity1 = new javax.swing.JButton();
        jCheckBoxExactSearch11 = new javax.swing.JCheckBox();
        jLabel33 = new javax.swing.JLabel();
        textSubscribedPlan = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textMonthlyPayable = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        textComments1 = new javax.swing.JTextArea();
        btnSearchByComments1 = new javax.swing.JButton();
        btnFirst11 = new javax.swing.JButton();
        btnPrevious11 = new javax.swing.JButton();
        btnNext11 = new javax.swing.JButton();
        btnLast11 = new javax.swing.JButton();
        btnViewAll11 = new javax.swing.JButton();
        btnClearAll11 = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        jPanelAreaInquiry = new javax.swing.JPanel();
        btnSearchByAreaID = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        textAreaID2 = new javax.swing.JTextField();
        btnSearchByCity = new javax.swing.JButton();
        btnSearchByBarangay = new javax.swing.JButton();
        btnSearchByDistrict = new javax.swing.JButton();
        btnSearchBySpecificCity = new javax.swing.JButton();
        jCheckBoxExactSearch = new javax.swing.JCheckBox();
        jLabel28 = new javax.swing.JLabel();
        textCity = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        textDistrict = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        textBarangay = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textComments = new javax.swing.JTextArea();
        btnSearchByComments = new javax.swing.JButton();
        btnFirst2 = new javax.swing.JButton();
        btnPrevious2 = new javax.swing.JButton();
        btnNext2 = new javax.swing.JButton();
        btnLast2 = new javax.swing.JButton();
        btnViewAll2 = new javax.swing.JButton();
        btnClearAll2 = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanelTechnicianInquiry = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        textTechnicianIDInquiry5 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        textFirstNameTechnicianInquiry5 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        textMiddleNameTechnicianInquiry5 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        textLastNameTechnicianInquiry5 = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        textSuffixTechnicianInquiry5 = new javax.swing.JTextField();
        btnSearchByTechnicianIDInquiry5 = new javax.swing.JButton();
        btnSearchByFirstNameTechnicianInquiry5 = new javax.swing.JButton();
        btnSearchByLastNameTechnicianInquiry5 = new javax.swing.JButton();
        btnSearchBySuffixTechnicianInquiry5 = new javax.swing.JButton();
        btnSearchByMiddleNameTechnicianInquiry5 = new javax.swing.JButton();
        jCheckBoxExactSearch5 = new javax.swing.JCheckBox();
        btnFirst5 = new javax.swing.JButton();
        btnPrevious5 = new javax.swing.JButton();
        btnNext5 = new javax.swing.JButton();
        btnLast5 = new javax.swing.JButton();
        btnViewAll5 = new javax.swing.JButton();
        btnClearAll5 = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        btnSearchByRole5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        textRoleTechnicianInquiry5 = new javax.swing.JTextArea();
        btnSearchByLeadTechnician = new javax.swing.JButton();
        btnSearchByMiddleName3 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Invoice D", "Customer ID", "Subscription ID", "Area ID", "Lead Technician ID", "Secondary Technicians"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Lead Technician ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Secondary Technicians");

        btnSearchByFirstName.setText("Search by First Name");
        btnSearchByFirstName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByFirstNameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        textSecondaryTechnicians.setBackground(new java.awt.Color(51, 255, 255));
        textSecondaryTechnicians.setColumns(20);
        textSecondaryTechnicians.setRows(5);
        jScrollPane1.setViewportView(textSecondaryTechnicians);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchBySecondaryTechnicians.setText("Search by Secondary Technicians");
        btnSearchBySecondaryTechnicians.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySecondaryTechniciansActionPerformed(evt);
            }
        });

        btnSearchByInvoiceID.setText("Search by Invoice ID ");
        btnSearchByInvoiceID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByInvoiceIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Invoice ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Subscription ID");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Area ID");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Customer ID");

        btnSearchByMiddleName.setText("Search by Middle Name");
        btnSearchByMiddleName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByMiddleNameActionPerformed(evt);
            }
        });

        btnSearchByLastName.setText("Search by Last Name");
        btnSearchByLastName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLastNameActionPerformed(evt);
            }
        });

        btnSearchByCustomerID.setText("Search by Customer ID ");
        btnSearchByCustomerID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCustomerIDActionPerformed(evt);
            }
        });

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Customer ID");

        btnSearchByFirstName2.setText("Search by First Name");
        btnSearchByFirstName2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByFirstName2ActionPerformed(evt);
            }
        });

        btnSearchByMiddleName2.setText("Search by Middle Name");
        btnSearchByMiddleName2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByMiddleName2ActionPerformed(evt);
            }
        });

        btnSearchByLastName2.setText("Search by Last Name");
        btnSearchByLastName2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLastName2ActionPerformed(evt);
            }
        });

        btnSearchBySuffix2.setText("Search by Suffix");
        btnSearchBySuffix2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySuffix2ActionPerformed(evt);
            }
        });

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("First Name");

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Middle Name");

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText(" Last Name");

        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel32.setText("Suffix");

        btnSearchByRole3.setText("Search by Role");
        btnSearchByRole3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRole3ActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Role");

        textCustomerRoleInquiry.setBackground(new java.awt.Color(51, 255, 255));
        textCustomerRoleInquiry.setColumns(20);
        textCustomerRoleInquiry.setRows(5);
        jScrollPane3.setViewportView(textCustomerRoleInquiry);

        btnFirst3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst3.setText("first");
        btnFirst3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirst3ActionPerformed(evt);
            }
        });

        btnPrevious3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious3.setText("previous");
        btnPrevious3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPrevious3ActionPerformed(evt);
            }
        });

        btnNext3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext3.setText("next");
        btnNext3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNext3ActionPerformed(evt);
            }
        });

        btnLast3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast3.setText("last");
        btnLast3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLast3ActionPerformed(evt);
            }
        });

        btnViewAllCustomerInquiry3.setText("View All Records");
        btnViewAllCustomerInquiry3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllCustomerInquiry3ActionPerformed(evt);
            }
        });

        btnClearAllCustomerInquiry3.setText("Clear All Text Boxes");
        btnClearAllCustomerInquiry3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllCustomerInquiry3ActionPerformed(evt);
            }
        });

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Customer ID", "First Name", "Middle Name", "Last Name", "Suffix", "Role"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable3KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable3KeyTyped(evt);
            }
        });
        jScrollPane7.setViewportView(jTable3);

        jCheckBoxExactSearch3.setText("Exact Search");

        javax.swing.GroupLayout jPanelCustomerInquiryLayout = new javax.swing.GroupLayout(jPanelCustomerInquiry);
        jPanelCustomerInquiry.setLayout(jPanelCustomerInquiryLayout);
        jPanelCustomerInquiryLayout.setHorizontalGroup(
            jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textCustomerIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                .addGap(148, 148, 148)
                                .addComponent(btnSearchByCustomerID))
                            .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                            .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(textCustomerSuffixInquiry))
                                        .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelCustomerInquiryLayout.createSequentialGroup()
                                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textCustomerMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelCustomerInquiryLayout.createSequentialGroup()
                                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textCustomerLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(4, 4, 4))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelCustomerInquiryLayout.createSequentialGroup()
                                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(6, 6, 6)
                                                .addComponent(textCustomerFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                                .addGap(106, 106, 106)
                                                .addComponent(btnSearchByRole3)))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelCustomerInquiryLayout.createSequentialGroup()
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByFirstName2)
                                    .addComponent(btnSearchByLastName2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByMiddleName2))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelCustomerInquiryLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnSearchBySuffix2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBoxExactSearch3))
                            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                        .addComponent(btnFirst3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnPrevious3)
                                        .addGap(25, 25, 25)
                                        .addComponent(btnNext3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnViewAllCustomerInquiry3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                                        .addGap(276, 276, 276)
                                        .addComponent(btnClearAllCustomerInquiry3, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 633, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanelCustomerInquiryLayout.setVerticalGroup(
            jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSearchByCustomerID)
                .addGap(18, 18, 18)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(textCustomerIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByFirstName2)
                    .addComponent(btnSearchByMiddleName2)
                    .addComponent(jCheckBoxExactSearch3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByLastName2)
                    .addComponent(btnSearchBySuffix2))
                .addGap(16, 16, 16)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textCustomerFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel22)))
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelCustomerInquiryLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel15))
                    .addComponent(textCustomerMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(textCustomerLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32)
                    .addComponent(textCustomerSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(btnSearchByRole3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelCustomerInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAllCustomerInquiry3)))
                .addGap(31, 31, 31)
                .addComponent(btnClearAllCustomerInquiry3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(384, Short.MAX_VALUE))
        );

        jTabbedPaneInvoiceMaintenanceInquiry1.addTab("Customer Inquiry", jPanelCustomerInquiry);

        btnSearchBySubscriptionID.setText("Search by Subscription ID ");
        btnSearchBySubscriptionID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySubscriptionIDActionPerformed(evt);
            }
        });

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Subscription ID");

        btnSearchByCity1.setText("Search by City");
        btnSearchByCity1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCity1ActionPerformed(evt);
            }
        });

        btnSearchBySpecificCity1.setText("Search by Specific City");
        btnSearchBySpecificCity1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySpecificCity1ActionPerformed(evt);
            }
        });

        jCheckBoxExactSearch11.setText("Exact Search");

        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel33.setText("Subscribed Plan");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Monthly Payable");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Comments");

        textComments1.setBackground(new java.awt.Color(51, 255, 255));
        textComments1.setColumns(20);
        textComments1.setRows(5);
        jScrollPane4.setViewportView(textComments1);

        btnSearchByComments1.setText("Search by Comments");
        btnSearchByComments1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByComments1ActionPerformed(evt);
            }
        });

        btnFirst11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst11.setText("first");
        btnFirst11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirst11ActionPerformed(evt);
            }
        });

        btnPrevious11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious11.setText("previous");
        btnPrevious11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPrevious11ActionPerformed(evt);
            }
        });

        btnNext11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext11.setText("next");
        btnNext11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNext11ActionPerformed(evt);
            }
        });

        btnLast11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast11.setText("last");
        btnLast11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLast11ActionPerformed(evt);
            }
        });

        btnViewAll11.setText("View All Records");
        btnViewAll11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAll11ActionPerformed(evt);
            }
        });

        btnClearAll11.setText("Clear All Text Boxes");
        btnClearAll11.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAll11ActionPerformed(evt);
            }
        });

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Subscription ID", "Subscribed Plan", "Monthly Payable", "Comments"
            }
        ));
        jTable11.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable11MouseClicked(evt);
            }
        });
        jTable11.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable11KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable11KeyTyped(evt);
            }
        });
        jScrollPane8.setViewportView(jTable11);

        javax.swing.GroupLayout jPanelSubscriptionInquiryLayout = new javax.swing.GroupLayout(jPanelSubscriptionInquiry);
        jPanelSubscriptionInquiry.setLayout(jPanelSubscriptionInquiryLayout);
        jPanelSubscriptionInquiryLayout.setHorizontalGroup(
            jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textSubscriptionID1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(btnSearchBySubscriptionID))
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                                .addComponent(btnSearchByCity1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchBySpecificCity1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBoxExactSearch11))
                            .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSubscriptionInquiryLayout.createSequentialGroup()
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textMonthlyPayable, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSubscriptionInquiryLayout.createSequentialGroup()
                                    .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(6, 6, 6)
                                    .addComponent(textSubscribedPlan, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchByComments1)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSubscriptionInquiryLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFirst11, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnPrevious11)
                .addGap(18, 18, 18)
                .addComponent(btnNext11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLast11, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnViewAll11, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(146, 146, 146))
            .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane8)
                        .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                            .addGap(276, 276, 276)
                            .addComponent(btnClearAll11, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 273, Short.MAX_VALUE)))
                    .addContainerGap()))
        );
        jPanelSubscriptionInquiryLayout.setVerticalGroup(
            jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnSearchBySubscriptionID)
                .addGap(18, 18, 18)
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(textSubscriptionID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(btnSearchByCity1))
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchBySpecificCity1)
                            .addComponent(jCheckBoxExactSearch11))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textSubscribedPlan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel33)))
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel11))
                    .addComponent(textMonthlyPayable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchByComments1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLast11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewAll11)
                    .addComponent(btnNext11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFirst11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(735, Short.MAX_VALUE))
            .addGroup(jPanelSubscriptionInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanelSubscriptionInquiryLayout.createSequentialGroup()
                    .addGap(301, 301, 301)
                    .addComponent(btnClearAll11)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(561, Short.MAX_VALUE)))
        );

        jTabbedPaneInvoiceMaintenanceInquiry1.addTab("Subscription Inquiry", jPanelSubscriptionInquiry);

        btnSearchByAreaID.setText("Search by Area ID ");
        btnSearchByAreaID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByAreaIDActionPerformed(evt);
            }
        });

        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel27.setText("Area ID");

        btnSearchByCity.setText("Search by City");
        btnSearchByCity.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCityActionPerformed(evt);
            }
        });

        btnSearchByBarangay.setText("Search by Barangay");
        btnSearchByBarangay.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByBarangayActionPerformed(evt);
            }
        });

        btnSearchByDistrict.setText("Search by District");
        btnSearchByDistrict.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByDistrictActionPerformed(evt);
            }
        });

        btnSearchBySpecificCity.setText("Search by Specific City");
        btnSearchBySpecificCity.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySpecificCityActionPerformed(evt);
            }
        });

        jCheckBoxExactSearch.setText("Exact Search");

        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel28.setText("City");

        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel29.setText("District");

        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel30.setText("Barangay");

        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31.setText("Comments");

        textComments.setBackground(new java.awt.Color(51, 255, 255));
        textComments.setColumns(20);
        textComments.setRows(5);
        jScrollPane2.setViewportView(textComments);

        btnSearchByComments.setText("Search by Comments");
        btnSearchByComments.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCommentsActionPerformed(evt);
            }
        });

        btnFirst2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst2.setText("first");
        btnFirst2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirst2ActionPerformed(evt);
            }
        });

        btnPrevious2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious2.setText("previous");
        btnPrevious2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPrevious2ActionPerformed(evt);
            }
        });

        btnNext2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext2.setText("next");
        btnNext2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNext2ActionPerformed(evt);
            }
        });

        btnLast2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast2.setText("last");
        btnLast2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLast2ActionPerformed(evt);
            }
        });

        btnViewAll2.setText("View All Records");
        btnViewAll2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAll2ActionPerformed(evt);
            }
        });

        btnClearAll2.setText("Clear All Text Boxes");
        btnClearAll2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAll2ActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Area ID", "City", "District", "Barangay", "Comments"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        javax.swing.GroupLayout jPanelAreaInquiryLayout = new javax.swing.GroupLayout(jPanelAreaInquiry);
        jPanelAreaInquiry.setLayout(jPanelAreaInquiryLayout);
        jPanelAreaInquiryLayout.setHorizontalGroup(
            jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textAreaID2, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(btnSearchByAreaID))
                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAreaInquiryLayout.createSequentialGroup()
                                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textDistrict, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAreaInquiryLayout.createSequentialGroup()
                                            .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(4, 4, 4))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAreaInquiryLayout.createSequentialGroup()
                                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(6, 6, 6)
                                            .addComponent(textCity, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                        .addGap(106, 106, 106)
                                        .addComponent(btnSearchByComments)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnClearAll2, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByCity)
                                    .addComponent(btnSearchByBarangay, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByDistrict))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelAreaInquiryLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnSearchBySpecificCity, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(93, 93, 93)
                                .addComponent(jCheckBoxExactSearch))
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 673, Short.MAX_VALUE)
                            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                .addComponent(btnFirst2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious2)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11)
                                .addComponent(btnViewAll2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanelAreaInquiryLayout.setVerticalGroup(
            jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnSearchByAreaID)
                .addGap(18, 18, 18)
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(textAreaID2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByCity)
                    .addComponent(btnSearchByDistrict)
                    .addComponent(jCheckBoxExactSearch))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByBarangay)
                    .addComponent(btnSearchBySpecificCity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelAreaInquiryLayout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByComments)
                            .addComponent(btnClearAll2)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanelAreaInquiryLayout.createSequentialGroup()
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel28)))
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelAreaInquiryLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel29))
                            .addComponent(textDistrict, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(textBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelAreaInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll2)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(491, Short.MAX_VALUE))
        );

        jTabbedPaneInvoiceMaintenanceInquiry1.addTab("Area Inquiry", jPanelAreaInquiry);

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("Technician ID");

        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel38.setText("First Name");

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel24.setText("Middle Name");

        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel25.setText(" Last Name");

        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel26.setText("Suffix");

        btnSearchByTechnicianIDInquiry5.setText("Search by Technician ID ");
        btnSearchByTechnicianIDInquiry5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByTechnicianIDInquiry5ActionPerformed(evt);
            }
        });

        btnSearchByFirstNameTechnicianInquiry5.setText("Search by First Name");
        btnSearchByFirstNameTechnicianInquiry5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByFirstNameTechnicianInquiry5ActionPerformed(evt);
            }
        });

        btnSearchByLastNameTechnicianInquiry5.setText("Search by Last Name");
        btnSearchByLastNameTechnicianInquiry5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLastNameTechnicianInquiry5ActionPerformed(evt);
            }
        });

        btnSearchBySuffixTechnicianInquiry5.setText("Search by Suffix");
        btnSearchBySuffixTechnicianInquiry5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySuffixTechnicianInquiry5ActionPerformed(evt);
            }
        });

        btnSearchByMiddleNameTechnicianInquiry5.setText("Search by Middle Name");
        btnSearchByMiddleNameTechnicianInquiry5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByMiddleNameTechnicianInquiry5ActionPerformed(evt);
            }
        });

        jCheckBoxExactSearch5.setText("Exact Search");

        btnFirst5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst5.setText("first");
        btnFirst5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirst5ActionPerformed(evt);
            }
        });

        btnPrevious5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious5.setText("previous");
        btnPrevious5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPrevious5ActionPerformed(evt);
            }
        });

        btnNext5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext5.setText("next");
        btnNext5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNext5ActionPerformed(evt);
            }
        });

        btnLast5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast5.setText("last");
        btnLast5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLast5ActionPerformed(evt);
            }
        });

        btnViewAll5.setText("View All Records");
        btnViewAll5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAll5ActionPerformed(evt);
            }
        });

        btnClearAll5.setText("Clear All Text Boxes");
        btnClearAll5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAll5ActionPerformed(evt);
            }
        });

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Technician ID", "First Name", "Middle Name", "Last Name", "Suffix", "Role"
            }
        ));
        jTable5.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable5MouseClicked(evt);
            }
        });
        jTable5.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable5KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable5KeyTyped(evt);
            }
        });
        jScrollPane9.setViewportView(jTable5);

        btnSearchByRole5.setText("Search by Role");
        btnSearchByRole5.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRole5ActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Role");

        textRoleTechnicianInquiry5.setBackground(new java.awt.Color(51, 255, 255));
        textRoleTechnicianInquiry5.setColumns(20);
        textRoleTechnicianInquiry5.setRows(5);
        jScrollPane17.setViewportView(textRoleTechnicianInquiry5);

        javax.swing.GroupLayout jPanelTechnicianInquiryLayout = new javax.swing.GroupLayout(jPanelTechnicianInquiry);
        jPanelTechnicianInquiry.setLayout(jPanelTechnicianInquiryLayout);
        jPanelTechnicianInquiryLayout.setHorizontalGroup(
            jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByLastNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSearchByFirstNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByMiddleNameTechnicianInquiry5)
                                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnSearchBySuffixTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textLastNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(textMiddleNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(6, 6, 6)
                                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(textTechnicianIDInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(textFirstNameTechnicianInquiry5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textSuffixTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByTechnicianIDInquiry5))
                                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(jCheckBoxExactSearch5)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addComponent(jScrollPane9)
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGap(70, 70, 70)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnClearAll5, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSearchByRole5)))
                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(btnFirst5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPrevious5)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll5, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 58, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanelTechnicianInquiryLayout.setVerticalGroup(
            jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSearchByTechnicianIDInquiry5)
                        .addComponent(textTechnicianIDInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel23))
                .addGap(18, 18, 18)
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textFirstNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel38)))
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel24))
                            .addComponent(textMiddleNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByFirstNameTechnicianInquiry5)
                            .addComponent(btnSearchByMiddleNameTechnicianInquiry5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByLastNameTechnicianInquiry5)
                            .addComponent(btnSearchBySuffixTechnicianInquiry5))))
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(textLastNameTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26)
                            .addComponent(textSuffixTechnicianInquiry5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jCheckBoxExactSearch5)))
                .addGap(18, 18, 18)
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))
                    .addGroup(jPanelTechnicianInquiryLayout.createSequentialGroup()
                        .addComponent(btnSearchByRole5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnClearAll5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnPrevious5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnFirst5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnNext5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelTechnicianInquiryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(560, Short.MAX_VALUE))
        );

        jTabbedPaneInvoiceMaintenanceInquiry1.addTab("Technician Inquiry", jPanelTechnicianInquiry);

        jTabbedPaneInvoiceMaintenanceInquiry.addTab("Customer Maintenance Inquiry", jTabbedPaneInvoiceMaintenanceInquiry1);

        btnSearchByLeadTechnician.setText("Search by Lead Technician");
        btnSearchByLeadTechnician.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLeadTechnicianActionPerformed(evt);
            }
        });

        btnSearchByMiddleName3.setText("Search by Middle Name");
        btnSearchByMiddleName3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByMiddleName3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textInvoiceID, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(btnSearchByLeadTechnician, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(137, 137, 137)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(textCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSearchBySecondaryTechnicians)
                                    .addComponent(textSubscriptionID, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textLeadTechnicianID, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDelete))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addComponent(btnPrevious)
                                    .addGap(25, 25, 25)
                                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btnSearchByFirstName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnSearchByLastName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnSearchByMiddleName))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(85, 85, 85)
                                            .addComponent(btnSearchByMiddleName3)))))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 577, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addComponent(jTabbedPaneInvoiceMaintenanceInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchByInvoiceID)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByInvoiceID))
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(textInvoiceID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPaneInvoiceMaintenanceInquiry)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByFirstName)
                            .addComponent(btnSearchByMiddleName))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSearchByMiddleName3)
                            .addComponent(btnSearchByLastName))
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(textCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(textSubscriptionID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(textLeadTechnicianID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addComponent(btnSearchBySecondaryTechnicians)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel4)))
                        .addGap(58, 58, 58)
                        .addComponent(btnSearchByLeadTechnician)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEdit)
                                .addComponent(btnNewRecord)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnCancelNewRecord)
                                .addComponent(btnClearAll))
                            .addComponent(btnSaveRecord))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textInvoiceID.setText(model.getValueAt(i, 0).toString());
        textCustomerID.setText(model.getValueAt(i, 1).toString());
        textSubscriptionID.setText(model.getValueAt(i, 2).toString());
        textAreaID.setText(model.getValueAt(i, 3).toString());
        textLeadTechnicianID.setText(model.getValueAt(i, 4).toString());
        textSecondaryTechnicians.setText(model.getValueAt(i, 5).toString());
        
               
        
               
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textInvoiceID.setText(model.getValueAt(i, 0).toString());
            textCustomerID.setText(model.getValueAt(i, 1).toString());
            textSubscriptionID.setText(model.getValueAt(i, 2).toString());
            textAreaID.setText(model.getValueAt(i, 3).toString());
            textLeadTechnicianID.setText(model.getValueAt(i, 4).toString());
            textSecondaryTechnicians.setText(model.getValueAt(i, 5).toString());
            
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    
    private void btnSearchByTechnicianIDInquiry5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByTechnicianIDInquiry5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByTechnicianIDInquiry5ActionPerformed
        // TODO add your handling code here:
        viewall5=3;
        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnSearchByTechnicianIDInquiry5ActionPerformed

    private void btnSearchByFirstNameTechnicianInquiry5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByFirstNameTechnicianInquiry5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByFirstNameTechnicianInquiry5ActionPerformed
        // TODO add your handling code here:
        viewall5=1;
        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnSearchByFirstNameTechnicianInquiry5ActionPerformed

    private void btnSearchByLastNameTechnicianInquiry5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLastNameTechnicianInquiry5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLastNameTechnicianInquiry5ActionPerformed
        // TODO add your handling code here:
        viewall5=5;
        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnSearchByLastNameTechnicianInquiry5ActionPerformed

    private void btnSearchBySuffixTechnicianInquiry5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySuffixTechnicianInquiry5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySuffixTechnicianInquiry5ActionPerformed
        // TODO add your handling code here:
        viewall5=6;
        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnSearchBySuffixTechnicianInquiry5ActionPerformed

    private void btnSearchByMiddleNameTechnicianInquiry5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByMiddleNameTechnicianInquiry5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByMiddleNameTechnicianInquiry5ActionPerformed
        // TODO add your handling code here:
        viewall5=4;
        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnSearchByMiddleNameTechnicianInquiry5ActionPerformed

    //customer ID Inquiry
    private void btnSearchByCustomerIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCustomerIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCustomerIDActionPerformed
        // TODO add your handling code here:
        viewall3=3;
        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnSearchByCustomerIDActionPerformed

    //customer First Name
    private void btnSearchByFirstName2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByFirstName2ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByFirstName2ActionPerformed
        // TODO add your handling code here:

        viewall3=1;
        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnSearchByFirstName2ActionPerformed

    private void btnSearchByMiddleName2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByMiddleName2ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByMiddleName2ActionPerformed
        // TODO add your handling code here:
        viewall3=4;
        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnSearchByMiddleName2ActionPerformed

    private void btnSearchByLastName2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLastName2ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLastName2ActionPerformed
        // TODO add your handling code here:
        viewall3=5;
        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnSearchByLastName2ActionPerformed

    private void btnSearchBySuffix2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySuffix2ActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySuffix2ActionPerformed
        // TODO add your handling code here:
        viewall3=6;
        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnSearchBySuffix2ActionPerformed

    private void btnSearchByRole3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByRole3ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByRole3ActionPerformed
        // TODO add your handling code here:
        viewall3=2;
        Show_Customer_In_JTable();

    }//GEN-LAST:event_btnSearchByRole3ActionPerformed

    private void btnFirst3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirst3ActionPerformed
    {//GEN-HEADEREND:event_btnFirst3ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs3.first();
            
            textCustomerIDInquiry.setText(Integer.toString(rs3.getInt(TBL_CUSTOMER_CUSTOMERID)));
                textCustomerFirstNameInquiry.setText(rs3.getString(TBL_CUSTOMER_FIRSTNAME));
                textCustomerMiddleNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerLastNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerSuffixInquiry.setText(rs3.getString(TBL_CUSTOMER_SUFFIX));
                textCustomerRoleInquiry.setText(rs3.getString(TBL_CUSTOMER_ROLE));
            

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirst3ActionPerformed

    private void btnPrevious3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrevious3ActionPerformed
    {//GEN-HEADEREND:event_btnPrevious3ActionPerformed
        // TODO add your handling code here:
        try
        {
            if ( rs3.previous() )
            {
                textCustomerIDInquiry.setText(Integer.toString(rs3.getInt(TBL_CUSTOMER_CUSTOMERID)));
                textCustomerFirstNameInquiry.setText(rs3.getString(TBL_CUSTOMER_FIRSTNAME));
                textCustomerMiddleNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerLastNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerSuffixInquiry.setText(rs3.getString(TBL_CUSTOMER_SUFFIX));
                textCustomerRoleInquiry.setText(rs3.getString(TBL_CUSTOMER_ROLE));
                

            }
            else
            {
                rs3.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPrevious3ActionPerformed

    private void btnNext3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNext3ActionPerformed
    {//GEN-HEADEREND:event_btnNext3ActionPerformed
        // TODO add your handling code here:

        try
        {

            if (rs3.next())
            {

                textCustomerIDInquiry.setText(Integer.toString(rs3.getInt(TBL_CUSTOMER_CUSTOMERID)));
                textCustomerFirstNameInquiry.setText(rs3.getString(TBL_CUSTOMER_FIRSTNAME));
                textCustomerMiddleNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerLastNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
                textCustomerSuffixInquiry.setText(rs3.getString(TBL_CUSTOMER_SUFFIX));
                textCustomerRoleInquiry.setText(rs3.getString(TBL_CUSTOMER_ROLE));
            }
            else
            {
                rs3.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "End of File");
            }
        } catch (SQLException err )
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNext3ActionPerformed

    private void btnLast3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLast3ActionPerformed
    {//GEN-HEADEREND:event_btnLast3ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs3.last();

            textCustomerIDInquiry.setText(Integer.toString(rs3.getInt(TBL_CUSTOMER_CUSTOMERID)));
            textCustomerFirstNameInquiry.setText(rs3.getString(TBL_CUSTOMER_FIRSTNAME));
            textCustomerMiddleNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
            textCustomerLastNameInquiry.setText(rs3.getString(TBL_CUSTOMER_MIDDLENAME));
            textCustomerSuffixInquiry.setText(rs3.getString(TBL_CUSTOMER_SUFFIX));
            textCustomerRoleInquiry.setText(rs3.getString(TBL_CUSTOMER_ROLE));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLast3ActionPerformed

    //View all customer Inquiry
    private void btnViewAllCustomerInquiry3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllCustomerInquiry3ActionPerformed
    {//GEN-HEADEREND:event_btnViewAllCustomerInquiry3ActionPerformed
        // TODO add your handling code here:
        viewall3=0;

        Show_Customer_In_JTable();
    }//GEN-LAST:event_btnViewAllCustomerInquiry3ActionPerformed

    private void btnClearAllCustomerInquiry3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllCustomerInquiry3ActionPerformed
    {//GEN-HEADEREND:event_btnClearAllCustomerInquiry3ActionPerformed
        // TODO add your handlitextPositionhere:
        textCustomerIDInquiry.setText("");
        textCustomerFirstNameInquiry.setText("");
        textCustomerMiddleNameInquiry.setText("");
        textCustomerLastNameInquiry.setText("");
        textCustomerSuffixInquiry.setText("");
        textCustomerRoleInquiry.setText("");
        
    }//GEN-LAST:event_btnClearAllCustomerInquiry3ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable3.getSelectedRow();
        TableModel model=jTable3.getModel();

        textCustomerIDInquiry.setText(model.getValueAt(i, 0).toString());
        textCustomerFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
        textCustomerMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
        textCustomerLastNameInquiry.setText(model.getValueAt(i, 3).toString());
        textCustomerSuffixInquiry.setText(model.getValueAt(i, 4).toString());
        textCustomerRoleInquiry.setText(model.getValueAt(i, 5).toString());
        

    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            textCustomerIDInquiry.setText(model.getValueAt(i, 0).toString());
            textCustomerFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
            textCustomerMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
            textCustomerLastNameInquiry.setText(model.getValueAt(i, 3).toString());
            textCustomerSuffixInquiry.setText(model.getValueAt(i, 4).toString());
            textCustomerRoleInquiry.setText(model.getValueAt(i, 5).toString());
            
            

        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyTyped
    {//GEN-HEADEREND:event_jTable3KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable3KeyTyped

    private void btnSearchBySubscriptionIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySubscriptionIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySubscriptionIDActionPerformed
        // TODO add your handling code here:
        viewall11=3;
        Show_Subscription_In_JTable();
    }//GEN-LAST:event_btnSearchBySubscriptionIDActionPerformed

    private void btnSearchByCity1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCity1ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCity1ActionPerformed
        // TODO add your handling code here:

        viewall11=1;
        Show_Subscription_In_JTable();
        jCheckBoxExactSearch11.setSelected(!true);
    }//GEN-LAST:event_btnSearchByCity1ActionPerformed

    private void btnSearchBySpecificCity1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySpecificCity1ActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySpecificCity1ActionPerformed
        // TODO add your handling code here:
        viewall11=1;
        Show_Subscription_In_JTable();
        jCheckBoxExactSearch11.setSelected(true);
    }//GEN-LAST:event_btnSearchBySpecificCity1ActionPerformed

    private void btnSearchByComments1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByComments1ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByComments1ActionPerformed
        // TODO add your handling code here:
        viewall11=2;
        Show_Subscription_In_JTable();

    }//GEN-LAST:event_btnSearchByComments1ActionPerformed

    private void btnFirst11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirst11ActionPerformed
    {//GEN-HEADEREND:event_btnFirst11ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs11.first();

            textSubscriptionID.setText(Integer.toString(rs11.getInt(TBL_SUBSCRIPTION_SUBSCRIPTIONID)));
            textSubscribedPlan.setText(rs11.getString(TBL_SUBSCRIPTION_SUBSCRIBEDPLAN));
            textMonthlyPayable.setText(rs11.getString(TBL_SUBSCRIPTION_MONTHLYPAYABLE));
            textComments.setText(rs11.getString(TBL_SUBSCRIPTION_COMMENTS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirst11ActionPerformed

    private void btnPrevious11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrevious11ActionPerformed
    {//GEN-HEADEREND:event_btnPrevious11ActionPerformed
        // TODO add your handling code here:
        try
        {
            if ( rs11.previous() )
            {

                textSubscriptionID.setText(Integer.toString(rs11.getInt(TBL_SUBSCRIPTION_SUBSCRIPTIONID)));
                textSubscribedPlan.setText(rs11.getString(TBL_SUBSCRIPTION_SUBSCRIBEDPLAN));
                textMonthlyPayable.setText(rs11.getString(TBL_SUBSCRIPTION_MONTHLYPAYABLE));
                textComments.setText(rs11.getString(TBL_SUBSCRIPTION_COMMENTS));

            }
            else
            {
                rs11.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPrevious11ActionPerformed

    private void btnNext11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNext11ActionPerformed
    {//GEN-HEADEREND:event_btnNext11ActionPerformed
        // TODO add your handling code here:

        try
        {

            if (rs11.next())
            {

                textSubscriptionID.setText(Integer.toString(rs11.getInt(TBL_SUBSCRIPTION_SUBSCRIPTIONID)));
                textSubscribedPlan.setText(rs11.getString(TBL_SUBSCRIPTION_SUBSCRIBEDPLAN));
                textMonthlyPayable.setText(rs11.getString(TBL_SUBSCRIPTION_MONTHLYPAYABLE));
                textComments.setText(rs11.getString(TBL_SUBSCRIPTION_COMMENTS));

            }
            else
            {
                rs11.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "End of File");
            }
        } catch (SQLException err )
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNext11ActionPerformed

    private void btnLast11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLast11ActionPerformed
    {//GEN-HEADEREND:event_btnLast11ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs11.last();

            textSubscriptionID.setText(Integer.toString(rs11.getInt(TBL_SUBSCRIPTION_SUBSCRIPTIONID)));
            textSubscribedPlan.setText(rs11.getString(TBL_SUBSCRIPTION_SUBSCRIBEDPLAN));
            textMonthlyPayable.setText(rs11.getString(TBL_SUBSCRIPTION_MONTHLYPAYABLE));
            textComments.setText(rs11.getString(TBL_SUBSCRIPTION_COMMENTS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLast11ActionPerformed

    private void btnViewAll11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAll11ActionPerformed
    {//GEN-HEADEREND:event_btnViewAll11ActionPerformed
        // TODO add your handling code here:
        viewall11=0;

        Show_Subscription_In_JTable();
    }//GEN-LAST:event_btnViewAll11ActionPerformed

    private void btnClearAll11ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAll11ActionPerformed
    {//GEN-HEADEREND:event_btnClearAll11ActionPerformed
        // TODO add your handlitextPositionhere:
        textSubscriptionID.setText("");
        textSubscribedPlan.setText("");
        textMonthlyPayable.setText("");
        textComments.setText("");

    }//GEN-LAST:event_btnClearAll11ActionPerformed

    private void jTable11MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable11MouseClicked
    {//GEN-HEADEREND:event_jTable11MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable11.getSelectedRow();
        TableModel model=jTable11.getModel();

        textSubscriptionID.setText(model.getValueAt(i, 0).toString());
        textSubscribedPlan.setText(model.getValueAt(i, 1).toString());
        textMonthlyPayable.setText(model.getValueAt(i, 2).toString());
        textComments.setText(model.getValueAt(i, 3).toString());

    }//GEN-LAST:event_jTable11MouseClicked

    private void jTable11KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable11KeyPressed
    {//GEN-HEADEREND:event_jTable11KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable11.getSelectedRow();
            TableModel model=jTable11.getModel();

            textSubscriptionID.setText(model.getValueAt(i, 0).toString());
            textSubscribedPlan.setText(model.getValueAt(i, 1).toString());
            textMonthlyPayable.setText(model.getValueAt(i, 2).toString());
            textComments.setText(model.getValueAt(i, 3).toString());

        }
    }//GEN-LAST:event_jTable11KeyPressed

    private void jTable11KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable11KeyTyped
    {//GEN-HEADEREND:event_jTable11KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable11KeyTyped

    private void btnFirst5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirst5ActionPerformed
    {//GEN-HEADEREND:event_btnFirst5ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs5.first();

            textTechnicianIDInquiry5.setText(Integer.toString(rs5.getInt(TBL_TECHNICIAN_TECHNICIANID)));
            textFirstNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_FIRSTNAME));
            textMiddleNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
            textLastNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
            textSuffixTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_SUFFIX));
            textRoleTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_ROLE));
            

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirst5ActionPerformed

    private void btnPrevious5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrevious5ActionPerformed
    {//GEN-HEADEREND:event_btnPrevious5ActionPerformed
        // TODO add your handling code here:
        try
        {
            if ( rs5.previous() )
            {
                textTechnicianIDInquiry5.setText(Integer.toString(rs5.getInt(TBL_TECHNICIAN_TECHNICIANID)));
                textFirstNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_FIRSTNAME));
                textMiddleNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
                textLastNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
                textSuffixTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_SUFFIX));
                textRoleTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_ROLE));

            }
            else
            {
                rs5.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPrevious5ActionPerformed

    private void btnNext5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNext5ActionPerformed
    {//GEN-HEADEREND:event_btnNext5ActionPerformed
        // TODO add your handling code here:

        try
        {

            if (rs5.next())
            {

                textTechnicianIDInquiry5.setText(Integer.toString(rs5.getInt(TBL_TECHNICIAN_TECHNICIANID)));
                textFirstNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_FIRSTNAME));
                textMiddleNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
                textLastNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
                textSuffixTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_SUFFIX));
                textRoleTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_ROLE));

            }
            else
            {
                rs5.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "End of File");
            }
        } catch (SQLException err )
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNext5ActionPerformed

    private void btnLast5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLast5ActionPerformed
    {//GEN-HEADEREND:event_btnLast5ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs5.last();

            textTechnicianIDInquiry5.setText(Integer.toString(rs5.getInt(TBL_TECHNICIAN_TECHNICIANID)));
            textFirstNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_FIRSTNAME));
            textMiddleNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
            textLastNameTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_MIDDLENAME));
            textSuffixTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_SUFFIX));
            textRoleTechnicianInquiry5.setText(rs5.getString(TBL_TECHNICIAN_ROLE));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLast5ActionPerformed

    private void btnViewAll5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAll5ActionPerformed
    {//GEN-HEADEREND:event_btnViewAll5ActionPerformed
        // TODO add your handling code here:
        viewall5=0;

        Show_Technician_In_JTable();
    }//GEN-LAST:event_btnViewAll5ActionPerformed

    private void btnClearAll5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAll5ActionPerformed
    {//GEN-HEADEREND:event_btnClearAll5ActionPerformed
        // TODO add your handlitextPositionhere:
        textTechnicianIDInquiry5.setText("");
        textFirstNameTechnicianInquiry5.setText("");
        textMiddleNameTechnicianInquiry5.setText("");
        textLastNameTechnicianInquiry5.setText("");
        textSuffixTechnicianInquiry5.setText("");
        textRoleTechnicianInquiry5.setText("");
    }//GEN-LAST:event_btnClearAll5ActionPerformed

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable5MouseClicked
    {//GEN-HEADEREND:event_jTable5MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable5.getSelectedRow();
        TableModel model=jTable5.getModel();

        textTechnicianIDInquiry5.setText(model.getValueAt(i, 0).toString());
        textFirstNameTechnicianInquiry5.setText(model.getValueAt(i, 1).toString());
        textMiddleNameTechnicianInquiry5.setText(model.getValueAt(i, 2).toString());
        textLastNameTechnicianInquiry5.setText(model.getValueAt(i, 3).toString());
        textSuffixTechnicianInquiry5.setText(model.getValueAt(i, 4).toString());
        textRoleTechnicianInquiry5.setText(model.getValueAt(i, 5).toString());

    }//GEN-LAST:event_jTable5MouseClicked

    private void jTable5KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable5KeyPressed
    {//GEN-HEADEREND:event_jTable5KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable5.getSelectedRow();
            TableModel model=jTable5.getModel();

            textTechnicianIDInquiry5.setText(model.getValueAt(i, 0).toString());
            textFirstNameTechnicianInquiry5.setText(model.getValueAt(i, 1).toString());
            textMiddleNameTechnicianInquiry5.setText(model.getValueAt(i, 2).toString());
            textLastNameTechnicianInquiry5.setText(model.getValueAt(i, 3).toString());
            textSuffixTechnicianInquiry5.setText(model.getValueAt(i, 4).toString());
            textRoleTechnicianInquiry5.setText(model.getValueAt(i, 5).toString());
            

        }
    }//GEN-LAST:event_jTable5KeyPressed

    private void jTable5KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable5KeyTyped
    {//GEN-HEADEREND:event_jTable5KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable5KeyTyped

    private void btnSearchByRole5ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByRole5ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByRole5ActionPerformed
        // TODO add your handling code here:
        viewall5=2;
        Show_Technician_In_JTable();

    }//GEN-LAST:event_btnSearchByRole5ActionPerformed

    //search by suffix
    private void btnSearchByLeadTechnicianActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLeadTechnicianActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLeadTechnicianActionPerformed
        // TODO add your handling code here:
        viewall=6;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSearchByLeadTechnicianActionPerformed

    //Search by last name
    private void btnSearchByLastNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLastNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLastNameActionPerformed
        // TODO add your handling code here:
        viewall=5;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSearchByLastNameActionPerformed

    //search by middle name
    private void btnSearchByMiddleNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByMiddleNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByMiddleNameActionPerformed
        // TODO add your handling code here:
        viewall=4;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSearchByMiddleNameActionPerformed

    //search Cashier ID
    private void btnSearchByInvoiceIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByInvoiceIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByInvoiceIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSearchByInvoiceIDActionPerformed

    //search role 
    private void btnSearchBySecondaryTechniciansActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySecondaryTechniciansActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySecondaryTechniciansActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Invoice_In_JTable();

    }//GEN-LAST:event_btnSearchBySecondaryTechniciansActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLastActionPerformed
    {//GEN-HEADEREND:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
            textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
            textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
            textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPreviousActionPerformed
    {//GEN-HEADEREND:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try
        {
            if ( rs.previous() )
            {
                textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

            }
            else
            {
                rs.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnBackToMDIFormActionPerformed
    {//GEN-HEADEREND:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();

        xx.enabler();

        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirstActionPerformed
    {//GEN-HEADEREND:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
            textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
            textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
            textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllActionPerformed
    {//GEN-HEADEREND:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;

        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNextActionPerformed
    {//GEN-HEADEREND:event_btnNextActionPerformed
        // TODO add your handling code here:

        try
        {

            if (rs.next())
            {

                textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

            }
            else
            {
                rs.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "End of File");
            }
        } catch (SQLException err )
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //search borrower first Name
    private void btnSearchByFirstNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByFirstNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByFirstNameActionPerformed
        // TODO add your handling code here:

        viewall=1;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSearchByFirstNameActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllActionPerformed
    {//GEN-HEADEREND:event_btnClearAllActionPerformed
        // TODO add your handlitextPositionhere:
        textInvoiceID.setText("");
        textCustomerID.setText("");
        textSubscriptionID.setText("");
        textAreaID.setText("");
        textLeadTechnicianID.setText("");
        textSecondaryTechnicians.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCancelNewRecordActionPerformed
    {//GEN-HEADEREND:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:

        try
        {
            rs.absolute( curRow );

            textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
            textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
            textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
            textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
            textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());

            try
            {
                rs.first();

                textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {

                textInvoiceID.setText("");
                textCustomerID.setText("");
                textSubscriptionID.setText("");
                textAreaID.setText("");
                textLeadTechnicianID.setText("");
                textSecondaryTechnicians.setText("");

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNewRecordActionPerformed
    {//GEN-HEADEREND:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();

            textInvoiceID.setText("");
            textCustomerID.setText("");
            textSubscriptionID.setText("");
            textAreaID.setText("");
            textLeadTechnicianID.setText("");
            textSecondaryTechnicians.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this," Error: "+ err.getMessage());

        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSaveRecordActionPerformed
    {//GEN-HEADEREND:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;

            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //String invoiceid = textCashierID.getText().trim();
            //int invoiceid2=Integer.parseInt(invoiceid);
            //StringtextPositionrsontype=textLegalPersonType.getText().trim();
            String firstname=textCustomerID.getText().trim();
            String middlename=textSubscriptionID.getText().trim();
            String lastname=textAreaID.getText().trim();
            String suffix=textLeadTechnicianID.getText().trim();
            String role=textSecondaryTechnicians.getText().trim();

            if(firstname.equals("")|| suffix.equals("")||
                role.equals("")||
                middlename.equals("")|| lastname.equals("")

            )
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );

                query = "SELECT * FROM `tbl_invoice` where  "
                + " suffix='"+suffix+"' and firstname='"+firstname+"' "
                + "and middlename='"+middlename+"' and lastname='"+lastname+"'";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {

                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                    String sql="INSERT INTO `tbl_invoice`(`invoiceid`,`firstname`, `middlename`, `lastname`,"
                    + " `suffix`, `role`, "
                    + ""
                    + " ) "
                    + "VALUES (NULL,'"+firstname+"','"+middlename+"','"+lastname+"','"+suffix+"',"
                    + "'"+role+"'"
                    + ")";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );

                    sql ="SELECT * FROM `tbl_invoice`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                    textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                    textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                    textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                    textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                    textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

                    JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " new inserted record item: "+textInvoiceID.getText());

                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Invoice_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+ex.getMessage());

        }
        viewall=0;
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnEditActionPerformed
    {//GEN-HEADEREND:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;

                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String invoiceid = textInvoiceID.getText().trim();
                int invoiceid2=Integer.parseInt(invoiceid);
                String firstname=textCustomerID.getText().trim();
                String middlename=textSubscriptionID.getText().trim();
                String lastname=textAreaID.getText().trim();
                String suffix=textLeadTechnicianID.getText().trim();
                String role=textSecondaryTechnicians.getText().trim();

                if(invoiceid.equals("")||firstname.equals("")
                    || middlename.equals("")|| lastname.equals("")||  suffix.equals("")|| role.equals("")
                )
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_invoice` where "
                    + "invoiceid="+invoiceid+"  "
                    + "and suffix='"+suffix+"' and firstname='"+firstname+"' "
                    + "and middlename='"+middlename+"' and lastname='"+lastname+"')";;

                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {

                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                        sql="UPDATE `tbl_invoice` "
                        + "SET "
                        + "`suffix`='"+suffix+"',`role`='"+role+"',"
                        + "`firstname`='"+firstname+"',"
                        + "`middlename`='"+middlename+"',`lastname`='"+lastname+"',"
                        + ""
                        + ""
                        + ""
                        + " WHERE `invoiceid`="+invoiceid2+"";
                        stmt.executeUpdate(sql);

                        stmt = con.createStatement( );

                        sql ="SELECT * FROM `tbl_invoice` where "
                        + "invoiceid="+invoiceid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            rowCount++;
                            if(rowCount==1)
                            {
                                textInvoiceID.setText(Integer.toString(rs.getInt(TBL_INVOICE_INVOICEID)));
                                textCustomerID.setText(rs.getString(TBL_INVOICE_CUSTOMERID));
                                textSubscriptionID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                                textAreaID.setText(rs.getString(TBL_INVOICE_SUBSCRIPTIONID));
                                textLeadTechnicianID.setText(rs.getString(TBL_INVOICE_LEADTECHNICIANID));
                                textSecondaryTechnicians.setText(rs.getString(TBL_INVOICE_SECONDARYTECHNICIANS));

                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Record Successfully Modified!");

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " error269: "+ex.getMessage());

            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Nothing is modified!");
        }
        viewall=0;

        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //delete record   
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnDeleteActionPerformed
    {//GEN-HEADEREND:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;

                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String invoiceid=textInvoiceID.getText().trim();
                int invoiceid2=Integer.parseInt(invoiceid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_invoice` where invoiceid="+invoiceid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                    sql="DELETE FROM  tbl_invoice"
                    + " where invoiceid="+invoiceid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, ex.getMessage());

            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_Invoice_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnSearchByMiddleName3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByMiddleName3ActionPerformed
    {//GEN-HEADEREND:event_btnSearchByMiddleName3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchByMiddleName3ActionPerformed

    private void btnSearchByAreaIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByAreaIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByAreaIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnSearchByAreaIDActionPerformed

    private void btnSearchByCityActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCityActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCityActionPerformed
        // TODO add your handling code here:

        viewall2=1;
        Show_Area_In_JTable();
        jCheckBoxExactSearch.setSelected(!true);
    }//GEN-LAST:event_btnSearchByCityActionPerformed

    private void btnSearchByBarangayActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByBarangayActionPerformed
    {//GEN-HEADEREND:event_btnSearchByBarangayActionPerformed
        // TODO add your handling code here:
        viewall2=5;
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnSearchByBarangayActionPerformed

    private void btnSearchByDistrictActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByDistrictActionPerformed
    {//GEN-HEADEREND:event_btnSearchByDistrictActionPerformed
        // TODO add your handling code here:
        viewall2=4;
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnSearchByDistrictActionPerformed

    private void btnSearchBySpecificCityActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySpecificCityActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySpecificCityActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Area_In_JTable();
        jCheckBoxExactSearch.setSelected(true);
    }//GEN-LAST:event_btnSearchBySpecificCityActionPerformed

    private void btnSearchByCommentsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCommentsActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCommentsActionPerformed
        // TODO add your handling code here:
        viewall2=6;
        Show_Area_In_JTable();

    }//GEN-LAST:event_btnSearchByCommentsActionPerformed

    private void btnFirst2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnFirst2ActionPerformed
    {//GEN-HEADEREND:event_btnFirst2ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs2.first();

            textAreaID2.setText(Integer.toString(rs2.getInt(TBL_AREA_AREAID)));
            textCity.setText(rs2.getString(TBL_AREA_CITY));
            textDistrict.setText(rs2.getString(TBL_AREA_DISTRICT));
            textBarangay.setText(rs2.getString(TBL_AREA_BARANGAY));
            textComments.setText(rs2.getString(TBL_AREA_COMMENTS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirst2ActionPerformed

    private void btnPrevious2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPrevious2ActionPerformed
    {//GEN-HEADEREND:event_btnPrevious2ActionPerformed
        // TODO add your handling code here:
        try
        {
            if ( rs2.previous() )
            {

                textAreaID2.setText(Integer.toString(rs2.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs2.getString(TBL_AREA_CITY));
                textDistrict.setText(rs2.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs2.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs2.getString(TBL_AREA_COMMENTS));

            }
            else
            {
                rs2.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPrevious2ActionPerformed

    private void btnNext2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnNext2ActionPerformed
    {//GEN-HEADEREND:event_btnNext2ActionPerformed
        // TODO add your handling code here:

        try
        {

            if (rs2.next())
            {

                textAreaID2.setText(Integer.toString(rs2.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs2.getString(TBL_AREA_CITY));
                textDistrict.setText(rs2.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs2.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs2.getString(TBL_AREA_COMMENTS));

            }
            else
            {
                rs2.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "End of File");
            }
        } catch (SQLException err )
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNext2ActionPerformed

    private void btnLast2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLast2ActionPerformed
    {//GEN-HEADEREND:event_btnLast2ActionPerformed
        // TODO add your handling code here:
        try
        {
            rs2.last();

            textAreaID2.setText(Integer.toString(rs2.getInt(TBL_AREA_AREAID)));
            textCity.setText(rs2.getString(TBL_AREA_CITY));
            textDistrict.setText(rs2.getString(TBL_AREA_DISTRICT));
            textBarangay.setText(rs2.getString(TBL_AREA_BARANGAY));
            textComments.setText(rs2.getString(TBL_AREA_COMMENTS));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemInvoiceMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLast2ActionPerformed

    private void btnViewAll2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAll2ActionPerformed
    {//GEN-HEADEREND:event_btnViewAll2ActionPerformed
        // TODO add your handling code here:
        viewall2=0;

        Show_Area_In_JTable();
    }//GEN-LAST:event_btnViewAll2ActionPerformed

    private void btnClearAll2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAll2ActionPerformed
    {//GEN-HEADEREND:event_btnClearAll2ActionPerformed
        // TODO add your handlitextPositionhere:
        textAreaID2.setText("");
        textCity.setText("");
        textDistrict.setText("");
        textBarangay.setText("");
        textComments.setText("");

    }//GEN-LAST:event_btnClearAll2ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable2MouseClicked
    {//GEN-HEADEREND:event_jTable2MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();

        textAreaID2.setText(model.getValueAt(i, 0).toString());
        textCity.setText(model.getValueAt(i, 1).toString());
        textDistrict.setText(model.getValueAt(i, 2).toString());
        textBarangay.setText(model.getValueAt(i, 3).toString());
        textComments.setText(model.getValueAt(i, 4).toString());

    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyPressed
    {//GEN-HEADEREND:event_jTable2KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textAreaID2.setText(model.getValueAt(i, 0).toString());
            textCity.setText(model.getValueAt(i, 1).toString());
            textDistrict.setText(model.getValueAt(i, 2).toString());
            textBarangay.setText(model.getValueAt(i, 3).toString());
            textComments.setText(model.getValueAt(i, 4).toString());

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyTyped
    {//GEN-HEADEREND:event_jTable2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable2KeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnClearAll11;
    private javax.swing.JButton btnClearAll2;
    private javax.swing.JButton btnClearAll5;
    private javax.swing.JButton btnClearAllCustomerInquiry3;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnFirst11;
    private javax.swing.JButton btnFirst2;
    private javax.swing.JButton btnFirst3;
    private javax.swing.JButton btnFirst5;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLast11;
    private javax.swing.JButton btnLast2;
    private javax.swing.JButton btnLast3;
    private javax.swing.JButton btnLast5;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnNext11;
    private javax.swing.JButton btnNext2;
    private javax.swing.JButton btnNext3;
    private javax.swing.JButton btnNext5;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnPrevious11;
    private javax.swing.JButton btnPrevious2;
    private javax.swing.JButton btnPrevious3;
    private javax.swing.JButton btnPrevious5;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByAreaID;
    private javax.swing.JButton btnSearchByBarangay;
    private javax.swing.JButton btnSearchByCity;
    private javax.swing.JButton btnSearchByCity1;
    private javax.swing.JButton btnSearchByComments;
    private javax.swing.JButton btnSearchByComments1;
    private javax.swing.JButton btnSearchByCustomerID;
    private javax.swing.JButton btnSearchByDistrict;
    private javax.swing.JButton btnSearchByFirstName;
    private javax.swing.JButton btnSearchByFirstName2;
    private javax.swing.JButton btnSearchByFirstNameTechnicianInquiry5;
    private javax.swing.JButton btnSearchByInvoiceID;
    private javax.swing.JButton btnSearchByLastName;
    private javax.swing.JButton btnSearchByLastName2;
    private javax.swing.JButton btnSearchByLastNameTechnicianInquiry5;
    private javax.swing.JButton btnSearchByLeadTechnician;
    private javax.swing.JButton btnSearchByMiddleName;
    private javax.swing.JButton btnSearchByMiddleName2;
    private javax.swing.JButton btnSearchByMiddleName3;
    private javax.swing.JButton btnSearchByMiddleNameTechnicianInquiry5;
    private javax.swing.JButton btnSearchByRole3;
    private javax.swing.JButton btnSearchByRole5;
    private javax.swing.JButton btnSearchBySecondaryTechnicians;
    private javax.swing.JButton btnSearchBySpecificCity;
    private javax.swing.JButton btnSearchBySpecificCity1;
    private javax.swing.JButton btnSearchBySubscriptionID;
    private javax.swing.JButton btnSearchBySuffix2;
    private javax.swing.JButton btnSearchBySuffixTechnicianInquiry5;
    private javax.swing.JButton btnSearchByTechnicianIDInquiry5;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JButton btnViewAll11;
    private javax.swing.JButton btnViewAll2;
    private javax.swing.JButton btnViewAll5;
    private javax.swing.JButton btnViewAllCustomerInquiry3;
    private javax.swing.JCheckBox jCheckBoxExactSearch;
    private javax.swing.JCheckBox jCheckBoxExactSearch11;
    private javax.swing.JCheckBox jCheckBoxExactSearch3;
    private javax.swing.JCheckBox jCheckBoxExactSearch5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelAreaInquiry;
    private javax.swing.JPanel jPanelCustomerInquiry;
    private javax.swing.JPanel jPanelSubscriptionInquiry;
    private javax.swing.JPanel jPanelTechnicianInquiry;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPaneInvoiceMaintenanceInquiry;
    private javax.swing.JTabbedPane jTabbedPaneInvoiceMaintenanceInquiry1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable5;
    private javax.swing.JTextField textAreaID;
    private javax.swing.JTextField textAreaID2;
    private javax.swing.JTextField textBarangay;
    private javax.swing.JTextField textCity;
    private javax.swing.JTextArea textComments;
    private javax.swing.JTextArea textComments1;
    private javax.swing.JTextField textCustomerFirstNameInquiry;
    private javax.swing.JTextField textCustomerID;
    private javax.swing.JTextField textCustomerIDInquiry;
    private javax.swing.JTextField textCustomerLastNameInquiry;
    private javax.swing.JTextField textCustomerMiddleNameInquiry;
    private javax.swing.JTextArea textCustomerRoleInquiry;
    private javax.swing.JTextField textCustomerSuffixInquiry;
    private javax.swing.JTextField textDistrict;
    private javax.swing.JTextField textFirstNameTechnicianInquiry5;
    private javax.swing.JTextField textInvoiceID;
    private javax.swing.JTextField textLastNameTechnicianInquiry5;
    private javax.swing.JTextField textLeadTechnicianID;
    private javax.swing.JTextField textMiddleNameTechnicianInquiry5;
    private javax.swing.JTextField textMonthlyPayable;
    private javax.swing.JTextArea textRoleTechnicianInquiry5;
    private javax.swing.JTextArea textSecondaryTechnicians;
    private javax.swing.JTextField textSubscribedPlan;
    private javax.swing.JTextField textSubscriptionID;
    private javax.swing.JTextField textSubscriptionID1;
    private javax.swing.JTextField textSuffixTechnicianInquiry5;
    private javax.swing.JTextField textTechnicianIDInquiry5;
    // End of variables declaration//GEN-END:variables
}
