/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemSalesTable {

    /**
     * @param args the command line arguments
     */
      
    int bookid;
    String booktitle;
    String description;
    String authors;
    int totalquantitygood;
    int totalquantitylost;
    int totalquantitydamaged;
    
       
    
    public CableSalesInformationSystemSalesTable
    (            
        int bookid,
        String booktitle,
        String description,
        String authors,
        int totalquantitygood,
        int totalquantitylost,
        int totalquantitydamaged
        
    )
            
    {
        this.bookid=bookid;        
        this.booktitle=booktitle;
        this.description=description;
        this.authors=authors;
        this.totalquantitygood=totalquantitygood;        
        this.totalquantitylost=totalquantitylost;
        this.totalquantitydamaged=totalquantitydamaged;
               
    }
    
    public int getBookID()
    {
        return bookid;
    }
    
    public String getBookTitle()
    {
        return booktitle;
    }
    
    public String getDescription()
    {
        return description;
    }
    public String getAuthors()
    {
        return authors;
    }
    public int getTotalQuantityGood()
    {
        return totalquantitygood;
    }    
    public int getTotalQuantityLost()
    {
        return totalquantitylost;
    }
    public int getTotalQuantityDamaged()
    {
        return totalquantitydamaged;
    }
      
}
