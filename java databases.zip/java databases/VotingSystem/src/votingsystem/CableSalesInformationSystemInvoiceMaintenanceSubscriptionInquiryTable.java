/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package votingsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemInvoiceMaintenanceSubscriptionInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int subscriptionid;
    String subscribedplan;
    double monthlypayable;
    String comments;
    
    
    public CableSalesInformationSystemInvoiceMaintenanceSubscriptionInquiryTable
    (            
        int subscriptionid,
        String subscribedplan,
        double monthlypayable,
        String comments
        
    )
            
    {
        this.subscriptionid=subscriptionid;   
        this.subscribedplan=subscribedplan;
        this.monthlypayable=monthlypayable;
        this.comments=comments;        
             
              
    }
    
    public int getSubscriptonID()
    {
        return subscriptionid;
    }
    
    public String getSubscribedPlan()
    {
        return subscribedplan;
    }
    public double getMonthlyPayable()
    {
        return monthlypayable;
    }
    public String getComments()
    {
        return comments;
    }
    
    
}
