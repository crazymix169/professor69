/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LegalMonitoringSystemCaseProceedingsTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    /*
    query="SELECT tbl_caseproceedings.caseproceedingsid,tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, "
                    + "tbl_caseproceedings.payment FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid";
    */
    
    int caseproceedingsid;
    int caseid;
    int courtid;
    String casetitle;
    String courtname;
    String description;
    String currentcasestatus;
    String date;
    double payment;
    
       
    
    public LegalMonitoringSystemCaseProceedingsTable
    (            
        int caseproceedingsid,
        int caseid,
        int courtid,
        String casetitle,
        String courtname,
        String description,
        String currentcasestatus,
        String date,
        double payment
    )
            
    {
                
        this.caseproceedingsid=caseproceedingsid;
        this.caseid=caseid;
        this.courtid=courtid;
        this.casetitle=casetitle;
        this.courtname=courtname;
        this.description=description;
        this.currentcasestatus=currentcasestatus;
        this.date=date;
        this.payment=payment;
               
        
    }
    
    public int getCaseProceedingsID()
    {
        return caseproceedingsid;
    }
    
    public int getCaseID()
    {
        return caseid;
    }
    public int getCourtID()
    {
        return courtid;
    }
    public String getCaseTitle()
    {
        return casetitle;
    }
    public String getCourtName()
    {
        return courtname;
    }
    public String getDescription()
    {
        return description;
    }
    public String getCurrentCaseStatus()
    {
        return currentcasestatus;
    }
    public String getDate()
    {
        return date;
    }
    public double getPayment()
    {
        return payment;
    }
    
}
