/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LegalMonitoringSystemCasePersonLegalPersonInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int legalpersonid;
    String legalpersontype;    
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    String role;
    
       
    
    public LegalMonitoringSystemCasePersonLegalPersonInquiryTable
    (            
        int legalpersonid,
        String legalpersontype,       
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String role
        
    )
            
    {
        this.legalpersonid=legalpersonid;        
        this.legalpersontype=legalpersontype;         
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.suffix=suffix;
        this.role=role;
          
    }
    
    public int getLegalPersonID()
    {
        return legalpersonid;
    }
    
    public String getLegalPersonType()
    {
        return legalpersontype;
    }        
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }
    
}
