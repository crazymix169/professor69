/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

/**
 *
 * @author crazymix69
 */

public class LegalMonitoringSystemCourtTable
{
 
    int courtid;
    String courtname;
    String courtaddress;
    String courtdescription;
    
    
    public LegalMonitoringSystemCourtTable(int courtid, String courtname,String courtaddress, String courtdescription)
    {
        this.courtid=courtid;
        this.courtname=courtname;
        this.courtaddress=courtaddress;
        this.courtdescription=courtdescription;         
    }
    
    public int getCourtID()
    {
        return courtid;
    }
    
    public String getCourtName()
    {
        return courtname;
    }
    
    public String getCourtAddress()
    {
        return courtaddress;
    }
    
    public String getCourtDescription()
    {
        return courtdescription;
    }    
}
