/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

/**
 *
 * @author crazymix69
 */
public class LegalMonitoringSystemCaseProceedingsCaseInquiryTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int caseid;
    String casetitle;
    
    
    
    
    
    
    
    public LegalMonitoringSystemCaseProceedingsCaseInquiryTable
    (            
        int caseid,
        String casetitle
        
    )
            
    {       
        this.caseid=caseid;        
        this.casetitle=casetitle;                    
        
    }
    
    public int getCaseID()
    {
        return caseid;
    }
    
    public String getCaseTitle()
    {
        return casetitle;
    }
    
    
    
    
}
