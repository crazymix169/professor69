/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class LegalMonitoringSystemCaseProceedingsMaintenance extends javax.swing.JInternalFrame {

    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0, viewall3=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String caseid;
    

    /**
     * Creates new form CasePersonMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
        
    
    
    public LegalMonitoringSystemCaseProceedingsMaintenance() {
        super("Case Summary Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_CaseProceedings_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                int caseid = rs.getInt("tbl_case.caseid");
                int courtid = rs.getInt("tbl_court.courtid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String courtname=rs.getString("tbl_court.courtname");
                String description=rs.getString("tbl_caseproceedings.description");
                String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                String date=rs.getString("tbl_caseproceedings.date");
                double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
                textCaseID.setText(Integer.toString(caseid));
                textCourtID.setText(Integer.toString(courtid));           
                textCaseTitle.setText(casetitle);
                textCourtName.setText(courtname);
                textDescription.setText(description);               
                textCurrentCaseStatus.setText(currentcasestatus);
                textDate.setText(date);
                textPayment.setText(Double.toString(payment));
                                       
                              
            
            }           
            
            viewall=0;           
            Show_CaseProceedings_In_JTable(); 
            viewall2=0;     
            Show_CaseProceedingsCaseInquiry_In_JTable();
            viewall3=0;     
            Show_CaseProceedingsCourtInquiry_In_JTable();
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCaseProceedingsTable> getCaseProceedingsList()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsTable> caseproceedingsidList= new ArrayList<LegalMonitoringSystemCaseProceedingsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid";
                
            }            
            else if(viewall==3) 
            {               
                               
                
                String caseproceedingsid=textCaseProceedingsID.getText().trim();
                int caseproceedingsid1=Integer.parseInt(caseproceedingsid);              
                                
                query="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid and "
                    + "tbl_caseproceedings.caseproceedingsid="+caseproceedingsid1+"";
            }
            else if(viewall==2) 
            {                
                
                String caseid=textCaseID.getText();    
                String courtid=textCourtID.getText().trim();
                int caseid1=Integer.parseInt(caseid);
                int courtid1=Integer.parseInt(courtid);              
                                
                query="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid and "
                    + "(tbl_caseproceedings.caseid= "+caseid1+" or tbl_caseproceedings.courtid= "+courtid1+")";
            }
            else if(viewall==1)
            {
                String courtname=textCourtName.getText().trim();
                String casetitle=textCaseTitle.getText().trim();
                //tbl_legalperson.role like '%"+role+"%'
                query="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid and "
                    + "(tbl_court.courtname like '%"+courtname+"%' or "
                    + "tbl_case.casetitle like '%"+casetitle+"%')";          
                
            
            }    
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCaseProceedingsTable caseproceedingsid1;
            
            while(rs.next())
            {
                /*
                query="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid
                */
               
                caseproceedingsid1 = new  LegalMonitoringSystemCaseProceedingsTable(
                        rs.getInt("tbl_caseproceedings.caseproceedingsid"),rs.getInt("tbl_case.caseid"),
                        rs.getInt("tbl_court.courtid"),
                        rs.getString("tbl_case.casetitle"),
                        rs.getString("tbl_court.courtname"),
                        rs.getString("tbl_caseproceedings.description"),rs.getString("tbl_caseproceedings.currentcasestatus"),
                        rs.getString("tbl_caseproceedings.date"),rs.getDouble("tbl_caseproceedings.payment"));
                caseproceedingsidList.add(caseproceedingsid1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+e.getMessage());
        }
        
        return caseproceedingsidList;
     
    }
    
    public void Show_CaseProceedings_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsTable> list = getCaseProceedingsList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[9];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
             /*
                query="SELECT tbl_caseproceedings.caseproceedingsid,tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, "
                    + "tbl_caseproceedings.payment FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid";
                */
            //model.removeRow(i);
            row[0]=list.get(i).getCaseProceedingsID();
            row[1]=list.get(i).getCaseID();
            row[2]=list.get(i).getCourtID();
            row[3]=list.get(i).getCaseTitle();
            row[4]=list.get(i).getCourtName();            
            row[5]=list.get(i).getDescription(); 
            row[6]=list.get(i).getCurrentCaseStatus();
            row[7]=list.get(i).getDate();
            row[8]=list.get(i).getPayment();            
                                                
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCaseProceedingsCaseInquiryTable> getCaseProceedingsCaseInquiryList()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsCaseInquiryTable> caseproceedingscaseinquiryList= new ArrayList<LegalMonitoringSystemCaseProceedingsCaseInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` WHERE 1";
            }            
            else if(viewall2==3) 
            {               
                               
                
                String caseid=textCaseID1.getText().trim();
                int caseid1=Integer.parseInt(caseid);
                
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` WHERE caseid= "+caseid1+"";
            }
            else if(viewall2==1) 
            {
                
                
                String casetitle=textCaseTitle1.getText();
                
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` "
                        + "WHERE casetitle like '%"+casetitle+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCaseProceedingsCaseInquiryTable caseproceedingscase1;
            
            while(rs.next())
            {
                caseproceedingscase1 = new  LegalMonitoringSystemCaseProceedingsCaseInquiryTable(
                        rs.getInt("caseid"),rs.getString("casetitle")
                        );
                caseproceedingscaseinquiryList.add(caseproceedingscase1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+e.getMessage());
        }
        
        return caseproceedingscaseinquiryList;
     
    }
    
    public void Show_CaseProceedingsCaseInquiry_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsCaseInquiryTable> list = getCaseProceedingsCaseInquiryList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[2];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCaseID();
            row[1]=list.get(i).getCaseTitle();                           
                                                
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCaseProceedingsCourtInquiryTable> getCaseProceedingsInquiryList()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsCourtInquiryTable> caseproceedingsinquiryList= new ArrayList<LegalMonitoringSystemCaseProceedingsCourtInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall3==0)
            {
                query ="SELECT `courtid`, `courtname` "
                        + "FROM `tbl_court` WHERE 1";
            }            
            else if(viewall3==3) 
            {               
                               
                
                String courtid=textCourtID1.getText().trim();
                int courtid1=Integer.parseInt(courtid);                
                
                query ="SELECT `courtid`, `courtname` "
                        + "FROM `tbl_court` WHERE `courtid`="+courtid1+"";
            }
            else if(viewall3==1) 
            {
                
                String courtname=textCourtName1.getText();
                
                
                query ="SELECT `courtid`, `courtname` "
                        + "FROM `tbl_court` WHERE `courtname` like '%"+courtname+"%'";
                        
               
                
                
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCaseProceedingsCourtInquiryTable caseproceedingscourtinquiry1;
            
            while(rs.next())
            {
                
                caseproceedingscourtinquiry1 = new  LegalMonitoringSystemCaseProceedingsCourtInquiryTable(
                        rs.getInt("courtid"),rs.getString("courtname"));
                caseproceedingsinquiryList.add(caseproceedingscourtinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+e.getMessage());
        }
        
        return caseproceedingsinquiryList;
     
    }
    
    public void Show_CaseProceedingsCourtInquiry_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCaseProceedingsCourtInquiryTable> list = getCaseProceedingsInquiryList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[2];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            /*
            int courtid,
        String payment,       
        String courtname,
        String currentcasestatus,
        String date,
        String suffix,
        String role
            */
            //model.removeRow(i);
            row[0]=list.get(i).getCourtID();
            row[1]=list.get(i).getCourtName();
           
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        textCaseTitle = new javax.swing.JTextField();
        textCourtID = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textCaseProceedingsID = new javax.swing.JTextField();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByRoleOrLegalPersonType = new javax.swing.JButton();
        btnSearchByLegalPersonID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textCaseID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        textPayment = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        textCourtName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textCurrentCaseStatus = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textDate = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        textCaseID1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        textCaseTitle1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        textCourtName1 = new javax.swing.JTextField();
        textCourtID1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnCaseIDInq = new javax.swing.JButton();
        btnCaseTitleInq = new javax.swing.JButton();
        btnCourtIDInq = new javax.swing.JButton();
        btnLegalPersonSearch = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        textDescription = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        btnCourtNameSearchInq = new javax.swing.JButton();

        setBackground(new java.awt.Color(51, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Case Person ID", "Case ID", "Legal Person ID", "Case Title", "Remarks", "First Name", "Middle Name", "Last Name", "Legal Person Type", "Suffix", "Role"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textCourtID.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Case Title");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Court ID");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Case ID");

        textCaseProceedingsID.setBackground(new java.awt.Color(0, 255, 255));

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByRoleOrLegalPersonType.setText("Search by Case ID or Court ID");
        btnSearchByRoleOrLegalPersonType.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRoleOrLegalPersonTypeActionPerformed(evt);
            }
        });

        btnSearchByLegalPersonID.setText("Search by Legal Person ID ");
        btnSearchByLegalPersonID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLegalPersonIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Case Proceedings ID");

        textCaseID.setBackground(new java.awt.Color(0, 255, 255));

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Payment");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Court Name");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Current Case Status");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Date");

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Case ID");

        textCaseID1.setBackground(new java.awt.Color(0, 255, 255));

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Case Title");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String []
            {
                "Case ID", "Case Title"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable2);

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Court Name");

        textCourtID1.setBackground(new java.awt.Color(51, 255, 255));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Court ID");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String []
            {
                "Court ID", "Court Name"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(jTable3);

        btnCaseIDInq.setText("search by caseid");
        btnCaseIDInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCaseIDInqActionPerformed(evt);
            }
        });

        btnCaseTitleInq.setText("search by Case Title");
        btnCaseTitleInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCaseTitleInqActionPerformed(evt);
            }
        });

        btnCourtIDInq.setText("Search by court ID by Inquiry");
        btnCourtIDInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCourtIDInqActionPerformed(evt);
            }
        });

        btnLegalPersonSearch.setText("Search by Court Name");
        btnLegalPersonSearch.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLegalPersonSearchActionPerformed(evt);
            }
        });

        textDescription.setBackground(new java.awt.Color(51, 255, 255));
        textDescription.setColumns(20);
        textDescription.setRows(5);
        jScrollPane3.setViewportView(textDescription);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Description");

        btnCourtNameSearchInq.setText("search by court name");
        btnCourtNameSearchInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCourtNameSearchInqActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(textPayment, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(btnFirst)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnPrevious)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(435, 435, 435)
                                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(368, 1197, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)
                                .addComponent(btnSearchByLegalPersonID)
                                .addGap(148, 148, 148)
                                .addComponent(btnCaseIDInq)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCaseTitleInq, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDelete)))
                        .addGap(0, 1040, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textCaseID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textCaseProceedingsID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(2, 2, 2)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textCourtID, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(btnSearchByRoleOrLegalPersonType)
                                                .addComponent(textCaseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addGap(29, 29, 29)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(btnLegalPersonSearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jLabel9)
                                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(textCurrentCaseStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCourtName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCourtID1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCourtName1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textCaseID1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textCaseTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(42, 42, 42)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(btnCourtIDInq)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(btnCourtNameSearchInq, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 833, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByLegalPersonID))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addComponent(textCaseProceedingsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(textCaseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCourtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCaseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchByRoleOrLegalPersonType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCaseIDInq)
                            .addComponent(btnCaseTitleInq))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(textCaseID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textCaseTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCourtIDInq)
                            .addComponent(btnCourtNameSearchInq))
                        .addGap(17, 17, 17)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(textCourtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textCourtID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel20)
                    .addComponent(textCourtName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLegalPersonSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textCurrentCaseStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(textPayment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewAll))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();        
        
        textCaseProceedingsID.setText(model.getValueAt(i, 0).toString());
        textCaseID.setText(model.getValueAt(i, 1).toString());
        textCourtID.setText(model.getValueAt(i, 2).toString());           
        textCaseTitle.setText(model.getValueAt(i, 3).toString());
        textDescription.setText(model.getValueAt(i, 4).toString());  
        textCourtName.setText(model.getValueAt(i, 5).toString());
        textCurrentCaseStatus.setText(model.getValueAt(i, 6).toString());
        textDate.setText(model.getValueAt(i, 7).toString());
        textPayment.setText(model.getValueAt(i, 8).toString());
        //.setText(model.getValueAt(i, 9).toString());
        //.setText(model.getValueAt(i, 10).toString());
            
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textCaseProceedingsID.setText(model.getValueAt(i, 0).toString());
            textCaseID.setText(model.getValueAt(i, 1).toString());
            textCourtID.setText(model.getValueAt(i, 2).toString());           
            textCaseTitle.setText(model.getValueAt(i, 3).toString());
            textDescription.setText(model.getValueAt(i, 4).toString());  
            textCourtName.setText(model.getValueAt(i, 5).toString());
            textCurrentCaseStatus.setText(model.getValueAt(i, 6).toString());
            textDate.setText(model.getValueAt(i, 7).toString());
            textPayment.setText(model.getValueAt(i, 8).toString());
            //.setText(model.getValueAt(i, 9).toString());
            //.setText(model.getValueAt(i, 10).toString());
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String caseproceedingsid=textCaseID.getText().trim();
                int caseproceedingsid2=Integer.parseInt(caseproceedingsid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_caseproceedings` WHERE caseproceedingsid="+caseproceedingsid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  `tbl_caseproceedings` "
                    + " where caseproceedingsid="+caseproceedingsid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_CaseProceedings_In_JTable();
        viewall=0;           
        Show_CaseProceedings_In_JTable(); 
        viewall2=0;     
        Show_CaseProceedingsCaseInquiry_In_JTable();
        viewall3=0;     
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String caseproceedingsid=textCaseProceedingsID.getText().trim();
                int caseproceedingsid2 = Integer.parseInt(caseproceedingsid);
                String caseid=textCaseID.getText().trim();
                int caseid2 = Integer.parseInt(caseid);
                String courtid = textCourtID.getText().trim(); 
                int courtid2=Integer.parseInt(courtid);
                String casetitle=textCaseTitle.getText().trim();           
                String description=textDescription.getText().trim();
                String courtname=textCourtName.getText().trim();
                String currentcasestatus=textCurrentCaseStatus.getText().trim();
                String date=textDate.getText().trim();
                String payment=textPayment.getText().trim();                
                double payment2=Double.parseDouble(payment);  
                
                
                
                
                                               

                if(caseproceedingsid.equals("")||caseid.equals("")|| courtid.equals("")|| description.equals("")||
                  currentcasestatus.equals("")|| date.equals("")||payment.equals("")                   
                   )
                {
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "";
                   
                   
                    sql="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                    + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                    + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                    + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                    + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                    + "tbl_court.courtid=tbl_caseproceedings.courtid "
                    + " and tbl_caseproceedings.caseproceedingsid="+caseproceedingsid2+" and (tbl_case.caseid="+caseid2+" or tbl_court.courtid="+courtid2+")";
                    rs = stmt.executeQuery(sql);


                    int rowCount=0;

                    while ( rs.next( ) )
                    {

                        rowCount++;
                    }

                    
                    
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " rowcount: " +Double.toString(rowCount) );

                    if(rowCount==0)
                    {
                        JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " Sorry, No Record Found!");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                           
                        
                        
                        
                        sql="UPDATE `tbl_caseproceedings` SET `caseid`="+caseid2+" ,`courtid`="+courtid2+","
                                + "`description`='"+description+"',`currentcasestatus`='"+currentcasestatus+"',"
                                + "`date`='"+date+"',`payment`="+payment2+" "
                                + "WHERE `caseproceedingsid`="+caseproceedingsid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_case` where "
                            + "caseid="+caseid2+"";
                        sql="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                        + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                        + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                        + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                        + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                        + "tbl_court.courtid=tbl_caseproceedings.courtid";
                        
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {                        
                            
                            caseproceedingsid2 = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                            caseid2 = rs.getInt("tbl_case.caseid");
                            courtid2 = rs.getInt("tbl_court.courtid");                
                            casetitle=rs.getString("tbl_case.casetitle");
                            courtname=rs.getString("tbl_court.courtname");
                            description=rs.getString("tbl_caseproceedings.description");
                            currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                            date=rs.getString("tbl_caseproceedings.date");
                            payment2=rs.getDouble("tbl_caseproceedings.payment");                                            

                            textCaseProceedingsID.setText(Integer.toString(caseproceedingsid2));
                            textCaseID.setText(Integer.toString(caseid2));
                            textCourtID.setText(Integer.toString(courtid2));           
                            textCaseTitle.setText(casetitle);
                            textCourtName.setText(courtname);
                            textDescription.setText(description);               
                            textCurrentCaseStatus.setText(currentcasestatus);
                            textDate.setText(date);
                            textPayment.setText(Double.toString(payment2));
                            
                            
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid2));
                                textCaseID.setText(Integer.toString(caseid2));
                                textCourtID.setText(Integer.toString(courtid2));           
                                textCaseTitle.setText(casetitle);
                                textCourtName.setText(courtname);
                                textDescription.setText(description);               
                                textCurrentCaseStatus.setText(currentcasestatus);
                                textDate.setText(date);
                                textPayment.setText(Double.toString(payment2));
                                
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_CaseProceedings_In_JTable();
        viewall=0;           
        Show_CaseProceedings_In_JTable(); 
        viewall2=0;     
        Show_CaseProceedingsCaseInquiry_In_JTable();
        viewall3=0;     
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
                       

            //String caseproceedingsid=textCasePersonID.getText().trim();
            //int caseproceedingsid2 = Integer.parseInt(caseproceedingsid);
            String caseid=textCaseID.getText().trim();
            int caseid2 = Integer.parseInt(caseid);
            String courtid = textCourtID.getText().trim(); 
            int courtid2=Integer.parseInt(courtid);
            String casetitle=textCaseTitle.getText().trim();           
            String description=textDescription.getText().trim();
            String courtname=textCourtName.getText().trim();
            String currentcasestatus=textCurrentCaseStatus.getText().trim();
            String date=textDate.getText().trim();
            String payment=textPayment.getText().trim();
            double payment2=Double.parseDouble(payment);
            
            
                   
            

           if(caseid.equals("")|| courtid.equals("")|| description.equals("")||
                  currentcasestatus.equals("")|| date.equals("")||payment.equals(""))
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                String sql="";      
                stmt = con.createStatement( );

                sql ="";
                sql="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                + "tbl_court.courtid=tbl_caseproceedings.courtid "
                + " or (tbl_case.caseid="+caseid2+" and tbl_court.courtid="+courtid2+")";
                rs = stmt.executeQuery(sql);


                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                if(rowCount==0)
                {
                    viewall=0;        
                    Show_CaseProceedings_In_JTable();
                    Show_CaseProceedings_In_JTable();
                    viewall=0;           
                    Show_CaseProceedings_In_JTable(); 
                    viewall2=0;     
                    Show_CaseProceedingsCaseInquiry_In_JTable();
                    viewall3=0;     
                    Show_CaseProceedingsCourtInquiry_In_JTable();
                    
                    return;
                
                }    
                
                
                
                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );




                sql="INSERT INTO `tbl_caseproceedings`(`caseproceedingsid`, `caseid`, `courtid`, `description`, "
                        + "`currentcasestatus`, `date`, `payment`) "
                        + "VALUES (NULL,"+caseid2+", "
                        + " "+courtid2+", '"+description+"', '"+currentcasestatus+"', "
                        + " '"+date+"' ,"+payment+")";

                stmt.executeUpdate(sql);

                stmt = con.createStatement( );

                sql ="";
                sql="SELECT tbl_caseproceedings.caseproceedingsid, tbl_case.caseid, tbl_court.courtid, "
                + "tbl_case.casetitle, tbl_court.courtname, tbl_caseproceedings.description, "
                + "tbl_caseproceedings.currentcasestatus, tbl_caseproceedings.date, tbl_caseproceedings.payment "
                + "FROM `tbl_caseproceedings`,`tbl_case`,`tbl_court` "
                + "WHERE tbl_case.caseid=tbl_caseproceedings.caseid and "
                + "tbl_court.courtid=tbl_caseproceedings.courtid";
                rs = stmt.executeQuery(sql);

                //rowCount=0;

                rs.last();

                int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                caseid2 = rs.getInt("tbl_case.caseid");
                courtid2 = rs.getInt("tbl_court.courtid");                
                casetitle=rs.getString("tbl_case.casetitle");
                courtname=rs.getString("tbl_court.courtname");
                description=rs.getString("tbl_caseproceedings.description");
                currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                date=rs.getString("tbl_caseproceedings.date");
                payment2=rs.getDouble("tbl_caseproceedings.payment");                                            

                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
                textCaseID.setText(Integer.toString(caseid2));
                textCourtID.setText(Integer.toString(courtid2));           
                textCaseTitle.setText(casetitle);
                textCourtName.setText(courtname);
                textDescription.setText(description);               
                textCurrentCaseStatus.setText(currentcasestatus);
                textDate.setText(date);
                textPayment.setText(Double.toString(payment2));      

                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " new inserted record item: "+Double.toString(caseproceedingsid));


                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );


                Show_CaseProceedings_In_JTable();

                

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_CaseProceedings_In_JTable();
        Show_CaseProceedings_In_JTable();
        viewall=0;           
        Show_CaseProceedings_In_JTable(); 
        viewall2=0;     
        Show_CaseProceedingsCaseInquiry_In_JTable();
        viewall3=0;     
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textCaseProceedingsID.setText("");
            textCaseID.setText("");
            textCourtID.setText("");           
            textCaseTitle.setText("");
            textDescription.setText("");  
            textCourtName.setText("");
            textCurrentCaseStatus.setText("");
            textDate.setText("");
            textPayment.setText("");
            

            textCaseID1.setText("");        
            textCaseTitle1.setText("");

            textCourtID1.setText("");           
            textCourtName1.setText("");         
              

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
            int caseid = rs.getInt("tbl_case.caseid");
            int courtid = rs.getInt("tbl_court.courtid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String courtname=rs.getString("tbl_court.courtname");
            String description=rs.getString("tbl_caseproceedings.description");
            String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
            String date=rs.getString("tbl_caseproceedings.date");
            double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

            textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
            textCaseID.setText(Integer.toString(caseid));
            textCourtID.setText(Integer.toString(courtid));           
            textCaseTitle.setText(casetitle);
            textCourtName.setText(courtname);
            textDescription.setText(description);               
            textCurrentCaseStatus.setText(currentcasestatus);
            textDate.setText(date);
            textPayment.setText(Double.toString(payment));         

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                int caseid = rs.getInt("tbl_case.caseid");
                int courtid = rs.getInt("tbl_court.courtid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String courtname=rs.getString("tbl_court.courtname");
                String description=rs.getString("tbl_caseproceedings.description");
                String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                String date=rs.getString("tbl_caseproceedings.date");
                double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
                textCaseID.setText(Integer.toString(caseid));
                textCourtID.setText(Integer.toString(courtid));           
                textCaseTitle.setText(casetitle);
                textCourtName.setText(courtname);
                textDescription.setText(description);               
                textCurrentCaseStatus.setText(currentcasestatus);
                textDate.setText(date);
                textPayment.setText(Double.toString(payment));         

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {  

                textCaseProceedingsID.setText("");
                textCaseID.setText("");
                textCourtID.setText("");           
                textCaseTitle.setText("");
                textDescription.setText("");  
                textCourtName.setText("");
                textCurrentCaseStatus.setText("");
                textDate.setText("");
                textPayment.setText("");
               

                textCaseID1.setText("");        
                textCaseTitle1.setText("");

                textCourtID1.setText("");               
                textCourtName1.setText("");
                
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textCaseProceedingsID.setText("");
        textCaseID.setText("");
        textCourtID.setText("");           
        textCaseTitle.setText("");
        textDescription.setText("");  
        textCourtName.setText("");
        textCurrentCaseStatus.setText("");
        textDate.setText("");
        textPayment.setText("");        
        
        textCaseID1.setText("");        
        textCaseTitle1.setText("");
        
        textCourtID1.setText("");     
        textCourtName1.setText("");
        

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                int caseid = rs.getInt("tbl_case.caseid");
                int courtid = rs.getInt("tbl_court.courtid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String courtname=rs.getString("tbl_court.courtname");
                String description=rs.getString("tbl_caseproceedings.description");
                String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                String date=rs.getString("tbl_caseproceedings.date");
                double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
                textCaseID.setText(Integer.toString(caseid));
                textCourtID.setText(Integer.toString(courtid));           
                textCaseTitle.setText(casetitle);
                textCourtName.setText(courtname);
                textDescription.setText(description);               
                textCurrentCaseStatus.setText(currentcasestatus);
                textDate.setText(date);
                textPayment.setText(Double.toString(payment));         

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_CaseProceedings_In_JTable();
        viewall=0;           
        Show_CaseProceedings_In_JTable(); 
        viewall2=0;     
        Show_CaseProceedingsCaseInquiry_In_JTable();
        viewall3=0;     
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
            int caseid = rs.getInt("tbl_case.caseid");
            int courtid = rs.getInt("tbl_court.courtid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String courtname=rs.getString("tbl_court.courtname");
            String description=rs.getString("tbl_caseproceedings.description");
            String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
            String date=rs.getString("tbl_caseproceedings.date");
            double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

            textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
            textCaseID.setText(Integer.toString(caseid));
            textCourtID.setText(Integer.toString(courtid));           
            textCaseTitle.setText(casetitle);
            textCourtName.setText(courtname);
            textDescription.setText(description);               
            textCurrentCaseStatus.setText(currentcasestatus);
            textDate.setText(date);
            textPayment.setText(Double.toString(payment));           

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
                int caseid = rs.getInt("tbl_case.caseid");
                int courtid = rs.getInt("tbl_court.courtid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String courtname=rs.getString("tbl_court.courtname");
                String description=rs.getString("tbl_caseproceedings.description");
                String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
                String date=rs.getString("tbl_caseproceedings.date");
                double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

                textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
                textCaseID.setText(Integer.toString(caseid));
                textCourtID.setText(Integer.toString(courtid));           
                textCaseTitle.setText(casetitle);
                textCourtName.setText(courtname);
                textDescription.setText(description);               
                textCurrentCaseStatus.setText(currentcasestatus);
                textDate.setText(date);
                textPayment.setText(Double.toString(payment));          

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int caseproceedingsid = rs.getInt("tbl_caseproceedings.caseproceedingsid");
            int caseid = rs.getInt("tbl_case.caseid");
            int courtid = rs.getInt("tbl_court.courtid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String courtname=rs.getString("tbl_court.courtname");
            String description=rs.getString("tbl_caseproceedings.description");
            String currentcasestatus=rs.getString("tbl_caseproceedings.currentcasestatus");
            String date=rs.getString("tbl_caseproceedings.date");
            double payment=rs.getDouble("tbl_caseproceedings.payment");                                            

            textCaseProceedingsID.setText(Integer.toString(caseproceedingsid));
            textCaseID.setText(Integer.toString(caseid));
            textCourtID.setText(Integer.toString(courtid));           
            textCaseTitle.setText(casetitle);
            textCourtName.setText(courtname);
            textDescription.setText(description);               
            textCurrentCaseStatus.setText(currentcasestatus);
            textDate.setText(date);
            textPayment.setText(Double.toString(payment));         

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCaseProceedingsMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search enddate or legal person type
    private void btnSearchByRoleOrLegalPersonTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_CaseProceedings_In_JTable();
        
    }//GEN-LAST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed

    //search Legal Person ID
    private void btnSearchByLegalPersonIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLegalPersonIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLegalPersonIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_CaseProceedings_In_JTable();
    }//GEN-LAST:event_btnSearchByLegalPersonIDActionPerformed

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyPressed
    {//GEN-HEADEREND:event_jTable2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            
            textCaseID1.setText(model.getValueAt(i, 0).toString());                       
            textCaseTitle1.setText(model.getValueAt(i, 1).toString());
            
            

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable2MouseClicked
    {//GEN-HEADEREND:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();
        
        textCaseID1.setText(model.getValueAt(i, 0).toString());                       
        textCaseTitle1.setText(model.getValueAt(i, 1).toString());
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            textCourtID1.setText(model.getValueAt(i, 0).toString());           
            textCourtName1.setText(model.getValueAt(i, 1).toString());        
           
            

        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        int i=jTable3.getSelectedRow();
        TableModel model=jTable3.getModel();

        textCourtID1.setText(model.getValueAt(i, 0).toString());           
        textCourtName1.setText(model.getValueAt(i, 1).toString());        
            
        
        
    }//GEN-LAST:event_jTable3MouseClicked

    private void btnLegalPersonSearchActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLegalPersonSearchActionPerformed
    {//GEN-HEADEREND:event_btnLegalPersonSearchActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_CaseProceedings_In_JTable();
    }//GEN-LAST:event_btnLegalPersonSearchActionPerformed

    private void btnCaseIDInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCaseIDInqActionPerformed
    {//GEN-HEADEREND:event_btnCaseIDInqActionPerformed
        // TODO add your handling code here:
        viewall2=3;
        Show_CaseProceedingsCaseInquiry_In_JTable();
    }//GEN-LAST:event_btnCaseIDInqActionPerformed

    private void btnCourtNameSearchInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCourtNameSearchInqActionPerformed
    {//GEN-HEADEREND:event_btnCourtNameSearchInqActionPerformed
        // TODO add your handling code here:
        viewall3=1;
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnCourtNameSearchInqActionPerformed

    private void btnCourtIDInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCourtIDInqActionPerformed
    {//GEN-HEADEREND:event_btnCourtIDInqActionPerformed
        // TODO add your handling code here:
        viewall3=3;
        Show_CaseProceedingsCourtInquiry_In_JTable();
    }//GEN-LAST:event_btnCourtIDInqActionPerformed

    private void btnCaseTitleInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCaseTitleInqActionPerformed
    {//GEN-HEADEREND:event_btnCaseTitleInqActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_CaseProceedingsCaseInquiry_In_JTable();
    }//GEN-LAST:event_btnCaseTitleInqActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnCaseIDInq;
    private javax.swing.JButton btnCaseTitleInq;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnCourtIDInq;
    private javax.swing.JButton btnCourtNameSearchInq;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLegalPersonSearch;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByLegalPersonID;
    private javax.swing.JButton btnSearchByRoleOrLegalPersonType;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField textCaseID;
    private javax.swing.JTextField textCaseID1;
    private javax.swing.JTextField textCaseProceedingsID;
    private javax.swing.JTextField textCaseTitle;
    private javax.swing.JTextField textCaseTitle1;
    private javax.swing.JTextField textCourtID;
    private javax.swing.JTextField textCourtID1;
    private javax.swing.JTextField textCourtName;
    private javax.swing.JTextField textCourtName1;
    private javax.swing.JTextField textCurrentCaseStatus;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextArea textDescription;
    private javax.swing.JTextField textPayment;
    // End of variables declaration//GEN-END:variables
}
