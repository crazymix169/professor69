/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class LegalMonitoringSystemCasePersonTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    /*
    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
        + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
        + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
        + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
        + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
        + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid";
    */
    
    int casepersonid;
    int caseid;
    int legalpersonid;
    String casetitle;
    String remarks;
    String firstname;
    String middlename;
    String lastname;
    String legalpersontype;
    String suffix;
    String role;
    
    
       
    
    
    public LegalMonitoringSystemCasePersonTable
    (            
        int casepersonid,
        int caseid,
        int legalpersonid,
        String casetitle,
        String remarks,
        String firstname,
        String middlename,
        String lastname,
        String legalpersontype,
        String suffix,
        String role
    
    )
            
    {
        
       
        
        this.casepersonid=casepersonid;
        this.caseid=caseid;
        this.legalpersonid=legalpersonid;
        this.casetitle=casetitle;
        this.remarks=remarks;
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.legalpersontype=legalpersontype;
        this.suffix=suffix;
        this.role=role;
       
               
        
    }
    
    public int getCasePersonID()
    {
        return casepersonid;
    }
    
    public int getCaseID()
    {
        return caseid;
    }
    public int getLegalPersonID()
    {
        return legalpersonid;
    }
    public String getCaseTitle()
    {
        return casetitle;
    }
    public String getRemarks()
    {
        return remarks;
    }
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getLegalPersonType()
    {
        return legalpersontype;
    }
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }
    
}
