/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

/**
 *
 * @author crazymix69
 */
public class LegalMonitoringSystemUserTable
{
 
    int userid;
    String username;
    String userpassword;
    
    
    public LegalMonitoringSystemUserTable(int userid, String username, String userpassword)
    {
        
        this.userid=userid;
        this.username=username;
        this.userpassword=userpassword;
               
        
    }
    
    public int getUserID()
    {
        return userid;
    }
    
    public String getUserName()
    {
        return username;
    }
    
    public String getUserPassword()
    {
        return userpassword;
    }
    
    
    
    
}



