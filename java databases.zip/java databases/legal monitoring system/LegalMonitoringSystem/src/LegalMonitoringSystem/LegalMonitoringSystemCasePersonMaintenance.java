/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LegalMonitoringSystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class LegalMonitoringSystemCasePersonMaintenance extends javax.swing.JInternalFrame {

    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0, viewall3=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String caseid;
    

    /**
     * Creates new form CasePersonMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
        
    
    
    public LegalMonitoringSystemCasePersonMaintenance() {
        super("Case Summary Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_CasePerson_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
                int caseid = rs.getInt("tbl_case.caseid");
                int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String remarks=rs.getString("tbl_caseperson.remarks");
                String firstname=rs.getString("tbl_legalperson.firstname");
                String middlename=rs.getString("tbl_legalperson.middlename");
                String lastname=rs.getString("tbl_legalperson.lastname");
                String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                String suffix=rs.getString("tbl_legalperson.suffix");
                String role=rs.getString("tbl_legalperson.role");                            

                textCasePersonID.setText(Integer.toString(casepersonid));
                textCaseID.setText(Integer.toString(caseid));
                textLegalPersonID.setText(Integer.toString(legalpersonid));           
                textCaseTitle.setText(casetitle);
                textRemarks.setText(remarks);  
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textLegalPersonType.setText(legalpersontype);
                textSuffix.setText(suffix);
                textRole.setText(role);                       
                              
            
            }           
            
            viewall=0;           
            Show_CasePerson_In_JTable();   
            viewall2=0;
            Show_CasePersonCaseInquiry_In_JTable();
            viewall3=0;
            Show_CasePersonLegalPersonInquiry_In_JTable();
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCasePersonTable> getCasePersonList()
    {
        ArrayList<LegalMonitoringSystemCasePersonTable> casepersonList= new ArrayList<LegalMonitoringSystemCasePersonTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid";
                
            }            
            else if(viewall==3) 
            {               
                               
                
                String casepersonid=textCasePersonID.getText().trim();
                int casepersonid1=Integer.parseInt(casepersonid);                
                
                query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + "tbl_caseperson.casepersonid= "+casepersonid1+"";
            }
            else if(viewall==2) 
            {                
                
                String casetitle=textCaseTitle.getText();    
                String caseid=textCasePersonID.getText().trim();
                int caseid1=Integer.parseInt(caseid);
                
                query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " (tbl_case.casetitle like '%"+casetitle+"%' or tbl_case.caseid= "+caseid1+")";
            }
            else if(viewall==1)
            {
                
                
                
                
                
                    
                
                if(jRadioButtonLastName.isSelected())
                {
                    String suffix=textSuffix.getText().trim();
                    String lastname=textLastName.getText().trim();
                    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " tbl_legalperson.lastname like '%"+lastname+"%' or tbl_legalperson.suffix like '%"+suffix+"%'";
                    
                }
                else if(jRadioButtonMiddleName.isSelected())
                {
                    String middlename=textMiddleName.getText().trim();
                    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " tbl_legalperson.middlename like '%"+middlename+"%'";
                }
                else if(jRadioButtonFirstName.isSelected())
                {
                    String firstname=textFirstName.getText().trim();
                    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " tbl_legalperson.firstname like '%"+firstname+"%'";
                }
                else if(jRadioButtonLegalPersonType.isSelected())
                {
                    String legalpersontype=textLegalPersonType.getText().trim();
                    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " tbl_legalperson.legalpersontype like '%"+legalpersontype+"%'";
                }
                else if(jRadioButtonRole.isSelected())
                {
                    String role=textRole.getText().trim();  
                    query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + " tbl_legalperson.role like '%"+role+"%'";
                }
            
            }    
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCasePersonTable caseperson1;
            
            while(rs.next())
            {
               
                caseperson1 = new  LegalMonitoringSystemCasePersonTable(
                        rs.getInt("tbl_caseperson.casepersonid"),rs.getInt("tbl_case.caseid"),
                        rs.getInt("tbl_legalperson.legalpersonid"),
                        rs.getString("tbl_case.casetitle"),
                        rs.getString("tbl_caseperson.remarks"),
                        rs.getString("tbl_legalperson.firstname"),rs.getString("tbl_legalperson.middlename"),
                        rs.getString("tbl_legalperson.lastname"),rs.getString("tbl_legalperson.legalpersontype"),
                        rs.getString("tbl_legalperson.suffix"),
                        rs.getString("tbl_legalperson.role"));
                casepersonList.add(caseperson1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+e.getMessage());
        }
        
        return casepersonList;
     
    }
    
    public void Show_CasePerson_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCasePersonTable> list = getCasePersonList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[11];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
             /*
                query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid";
                */
            //model.removeRow(i);
            row[0]=list.get(i).getCasePersonID();
            row[1]=list.get(i).getCaseID();
            row[2]=list.get(i).getLegalPersonID();
            row[3]=list.get(i).getCaseTitle();
            row[4]=list.get(i).getRemarks();            
            row[5]=list.get(i).getFirstName(); 
            row[6]=list.get(i).getMiddleName();
            row[7]=list.get(i).getLastName();
            row[8]=list.get(i).getLegalPersonType();
            row[9]=list.get(i).getSuffix();            
            row[10]=list.get(i).getRole();  
                                                
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCasePersonCaseInquiryTable> getCasePersonCaseInquiryList()
    {
        ArrayList<LegalMonitoringSystemCasePersonCaseInquiryTable> casepersoncaseinquiryList= new ArrayList<LegalMonitoringSystemCasePersonCaseInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` WHERE 1";
            }            
            else if(viewall2==3) 
            {               
                               
                
                String caseid=textCaseID1.getText().trim();
                int caseid1=Integer.parseInt(caseid);
                
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` WHERE caseid= "+caseid1+"";
            }
            else if(viewall2==2) 
            {
                
                
                String casetitle=textCaseTitle1.getText();
                
                
                query="SELECT `caseid`, `casetitle` FROM `tbl_case` "
                        + "WHERE casetitle like '%"+casetitle+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCasePersonCaseInquiryTable casepersoncase1;
            
            while(rs.next())
            {
                casepersoncase1 = new  LegalMonitoringSystemCasePersonCaseInquiryTable(
                        rs.getInt("caseid"),rs.getString("casetitle")
                        );
                casepersoncaseinquiryList.add(casepersoncase1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+e.getMessage());
        }
        
        return casepersoncaseinquiryList;
     
    }
    
    public void Show_CasePersonCaseInquiry_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCasePersonCaseInquiryTable> list = getCasePersonCaseInquiryList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[2];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCaseID();
            row[1]=list.get(i).getCaseTitle();                           
                                                
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<LegalMonitoringSystemCasePersonLegalPersonInquiryTable> getCasePersonLegalPersonInquiryList()
    {
        ArrayList<LegalMonitoringSystemCasePersonLegalPersonInquiryTable> casepersonlegalpersoninquiryList= new ArrayList<LegalMonitoringSystemCasePersonLegalPersonInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall3==0)
            {
                query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE 1";
            }            
            else if(viewall3==3) 
            {               
                               
                
                String legalpersonid=textLegalPersonID1.getText().trim();
                int legalpersonid1=Integer.parseInt(legalpersonid);                
                
                query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE `legalpersonid`="+legalpersonid1+"";
            }
            else if(viewall3==1) 
            {                
                
                
                
                
                
                
                
                
                if(jRadioButtonLastName.isSelected())
                {
                    String lastname=textLastName.getText().trim();
                    String suffix=textSuffix.getText().trim();
                    query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE tbl_legalperson.lastname like '%"+lastname+"%' or "
                            + "tbl_legalperson.suffix like '%"+suffix+"%'";
                    
                }
                else if(jRadioButtonMiddleName.isSelected())
                {
                    String middlename=textMiddleName.getText().trim();
                    query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE tbl_legalperson.middlename like '%"+middlename+"%'";
                }
                else if(jRadioButtonFirstName.isSelected())
                {
                    String firstname=textFirstName.getText().trim();
                    query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE tbl_legalperson.firstname like '%"+firstname+"%'";
                }
                else if(jRadioButtonLegalPersonType.isSelected())
                {
                    String legalpersontype=textLegalPersonType.getText().trim();
                    query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE tbl_legalperson.legalpersontype like '%"+legalpersontype+"%'";
                }
                else if(jRadioButtonRole.isSelected())
                {
                    String role=textRole.getText().trim();      
                    query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE tbl_legalperson.role like '%"+role+"%'";
                }
                
                
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            LegalMonitoringSystemCasePersonLegalPersonInquiryTable casepersonlegalpersoninquiry1;
            
            while(rs.next())
            {
                /*query ="SELECT `legalpersonid`, `legalpersontype`,  "
                        + "`firstname`, `middlename`, `lastname`,`suffix`, `role`"
                        + "  FROM `tbl_legalperson` WHERE 1";*/
                casepersonlegalpersoninquiry1 = new  LegalMonitoringSystemCasePersonLegalPersonInquiryTable(
                        rs.getInt("legalpersonid"),rs.getString("legalpersontype"),
                        rs.getString("firstname"),
                        rs.getString("middlename"),rs.getString("lastname"),
                        rs.getString("suffix"),rs.getString("role"));
                casepersonlegalpersoninquiryList.add(casepersonlegalpersoninquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+e.getMessage());
        }
        
        return casepersonlegalpersoninquiryList;
     
    }
    
    public void Show_CasePersonLegalPersonInquiry_In_JTable()
    {
        ArrayList<LegalMonitoringSystemCasePersonLegalPersonInquiryTable> list = getCasePersonLegalPersonInquiryList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[7];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            /*
            int legalpersonid,
        String legalpersontype,       
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String role
            */
            //model.removeRow(i);
            row[0]=list.get(i).getLegalPersonID();
            row[1]=list.get(i).getLegalPersonType();
            row[2]=list.get(i).getFirstName();
            row[3]=list.get(i).getMiddleName();
            row[4]=list.get(i).getLastName();            
            row[5]=list.get(i).getSuffix();          
            row[6]=list.get(i).getRole();
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        textCaseTitle = new javax.swing.JTextField();
        textLegalPersonID = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textCasePersonID = new javax.swing.JTextField();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByRoleOrLegalPersonType = new javax.swing.JButton();
        btnSearchByLegalPersonID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textCaseID = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        textLegalPersonType = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        textSuffix = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        textRole = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        textFirstName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textMiddleName = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textLastName = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        textCaseID1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        textCaseTitle1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        textLegalPersonType1 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        textSuffix1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textRole1 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        textFirstName1 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textMiddleName1 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        textLastName1 = new javax.swing.JTextField();
        textLegalPersonID1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnCaseIDInq = new javax.swing.JButton();
        btnCaseTitleInq = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jRadioButtonFirstName = new javax.swing.JRadioButton();
        jRadioButtonLastName = new javax.swing.JRadioButton();
        jRadioButtonMiddleName = new javax.swing.JRadioButton();
        jRadioButtonLegalPersonType = new javax.swing.JRadioButton();
        jRadioButtonRole = new javax.swing.JRadioButton();
        btnLegalPersonIDInq = new javax.swing.JButton();
        btnLegalPersonSearch = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        textRemarks = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        btnLegalPersonSearchInq = new javax.swing.JButton();

        setBackground(new java.awt.Color(51, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Case Person ID", "Case ID", "Legal Person ID", "Case Title", "Remarks", "First Name", "Middle Name", "Last Name", "Legal Person Type", "Suffix", "Role"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textLegalPersonID.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Case Title");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Legal Person ID");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Case ID");

        textCasePersonID.setBackground(new java.awt.Color(0, 255, 255));

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByRoleOrLegalPersonType.setText("Search by Case Title or Case ID");
        btnSearchByRoleOrLegalPersonType.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRoleOrLegalPersonTypeActionPerformed(evt);
            }
        });

        btnSearchByLegalPersonID.setText("Search by Case Person ID ");
        btnSearchByLegalPersonID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByLegalPersonIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Case Person ID");

        textCaseID.setBackground(new java.awt.Color(0, 255, 255));

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Legal Person Type");

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Suffix");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Role");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("First Name");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Middle Name");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText(" Last Name");

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Case ID");

        textCaseID1.setBackground(new java.awt.Color(0, 255, 255));

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Case Title");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String []
            {
                "Case ID", "Case Title"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable2);

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Legal Person Type");

        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel22.setText("Suffix");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Role");

        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("First Name");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Middle Name");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText(" Last Name");

        textLegalPersonID1.setBackground(new java.awt.Color(51, 255, 255));

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Legal Person ID");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String []
            {
                "Legal Person ID", "Legal Person Type", "First Name", "Middle Name", "Last Name", "Suffix", "Role"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(jTable3);

        btnCaseIDInq.setText("search by caseid");
        btnCaseIDInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCaseIDInqActionPerformed(evt);
            }
        });

        btnCaseTitleInq.setText("search by Case Title");
        btnCaseTitleInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCaseTitleInqActionPerformed(evt);
            }
        });

        jRadioButtonFirstName.setText("First Name");
        jRadioButtonFirstName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonFirstNameActionPerformed(evt);
            }
        });

        jRadioButtonLastName.setSelected(true);
        jRadioButtonLastName.setText("Last Name");
        jRadioButtonLastName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonLastNameActionPerformed(evt);
            }
        });

        jRadioButtonMiddleName.setText("Middle Name");
        jRadioButtonMiddleName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonMiddleNameActionPerformed(evt);
            }
        });

        jRadioButtonLegalPersonType.setText("Legal Person Type");
        jRadioButtonLegalPersonType.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonLegalPersonTypeActionPerformed(evt);
            }
        });

        jRadioButtonRole.setText("Role");
        jRadioButtonRole.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonRoleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButtonFirstName)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButtonLastName)
                            .addComponent(jRadioButtonMiddleName))
                        .addGap(48, 48, 48)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButtonRole)
                            .addComponent(jRadioButtonLegalPersonType, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(406, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonLastName)
                    .addComponent(jRadioButtonLegalPersonType))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonMiddleName)
                    .addComponent(jRadioButtonRole))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jRadioButtonFirstName)
                .addContainerGap())
        );

        btnLegalPersonIDInq.setText("Search by legal person ID by Inquiry");
        btnLegalPersonIDInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLegalPersonIDInqActionPerformed(evt);
            }
        });

        btnLegalPersonSearch.setText("seach among the legal person options");
        btnLegalPersonSearch.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLegalPersonSearchActionPerformed(evt);
            }
        });

        textRemarks.setBackground(new java.awt.Color(51, 255, 255));
        textRemarks.setColumns(20);
        textRemarks.setRows(5);
        jScrollPane3.setViewportView(textRemarks);

        jLabel1.setText("Remarks");

        btnLegalPersonSearchInq.setText("seach among the legal person options");
        btnLegalPersonSearchInq.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLegalPersonSearchInqActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(textRole, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(textLegalPersonType, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(28, 28, 28)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(10, 10, 10)
                                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textSuffix, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(textLastName1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textMiddleName1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textFirstName1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(textSuffix1, javax.swing.GroupLayout.DEFAULT_SIZE, 304, Short.MAX_VALUE)
                                            .addComponent(textRole1))
                                        .addGap(144, 144, 144))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane2))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textLegalPersonID1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textLegalPersonType1)
                                .addGap(144, 144, 144))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(435, 435, 435)
                                .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(374, 374, 374))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchByLegalPersonID)
                        .addGap(148, 148, 148)
                        .addComponent(btnCaseIDInq)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCaseTitleInq, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textCaseID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCasePersonID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textLegalPersonID, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btnSearchByRoleOrLegalPersonType)
                                            .addComponent(textCaseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(65, 65, 65)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(btnLegalPersonSearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(btnLegalPersonIDInq)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLegalPersonSearchInq, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(42, 42, 42)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 833, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCaseID1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textCaseTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 1531, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(282, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByLegalPersonID))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addComponent(textCasePersonID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(textCaseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textLegalPersonID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textCaseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCaseIDInq)
                            .addComponent(btnCaseTitleInq))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(textCaseID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textCaseTitle1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchByRoleOrLegalPersonType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLegalPersonSearch)
                        .addGap(11, 11, 11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnLegalPersonIDInq)
                            .addComponent(btnLegalPersonSearchInq))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21)
                            .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel10))
                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(textLegalPersonType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textSuffix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(52, 52, 52))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textLegalPersonID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel20)
                            .addComponent(textLegalPersonType1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel23)
                                    .addComponent(textFirstName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel11))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(textMiddleName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel7)
                                        .addComponent(textRole1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textSuffix1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel22)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel12))
                            .addComponent(textLastName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();        
        
        textCasePersonID.setText(model.getValueAt(i, 0).toString());
        textCaseID.setText(model.getValueAt(i, 1).toString());
        textLegalPersonID.setText(model.getValueAt(i, 2).toString());           
        textCaseTitle.setText(model.getValueAt(i, 3).toString());
        textRemarks.setText(model.getValueAt(i, 4).toString());  
        textFirstName.setText(model.getValueAt(i, 5).toString());
        textMiddleName.setText(model.getValueAt(i, 6).toString());
        textLastName.setText(model.getValueAt(i, 7).toString());
        textLegalPersonType.setText(model.getValueAt(i, 8).toString());
        textSuffix.setText(model.getValueAt(i, 9).toString());
        textRole.setText(model.getValueAt(i, 10).toString());
            
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textCasePersonID.setText(model.getValueAt(i, 0).toString());
            textCaseID.setText(model.getValueAt(i, 1).toString());
            textLegalPersonID.setText(model.getValueAt(i, 2).toString());           
            textCaseTitle.setText(model.getValueAt(i, 3).toString());
            textRemarks.setText(model.getValueAt(i, 4).toString());  
            textFirstName.setText(model.getValueAt(i, 5).toString());
            textMiddleName.setText(model.getValueAt(i, 6).toString());
            textLastName.setText(model.getValueAt(i, 7).toString());
            textLegalPersonType.setText(model.getValueAt(i, 8).toString());
            textSuffix.setText(model.getValueAt(i, 9).toString());
            textRole.setText(model.getValueAt(i, 10).toString());
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String caseid=textCaseID.getText().trim();
                int caseid2=Integer.parseInt(caseid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_case` where caseid"+caseid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  `tbl_case`"
                    + " where caseid="+caseid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_CasePerson_In_JTable();
        viewall=0;       
        Show_CasePerson_In_JTable();
        viewall2=0;
        Show_CasePersonCaseInquiry_In_JTable();
        viewall3=0;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String casepersonid=textCasePersonID.getText().trim();
                int casepersonid2 = Integer.parseInt(casepersonid);
                String caseid=textCaseID.getText().trim();
                int caseid2 = Integer.parseInt(caseid);
                String legalpersonid = textLegalPersonID.getText().trim(); 
                int legalpersonid2=Integer.parseInt(legalpersonid);
                String casetitle=textCaseTitle.getText().trim();           
                String remarks=textRemarks.getText().trim();
                String firstname=textFirstName.getText().trim();
                String middlename=textMiddleName.getText().trim();
                String lastname=textLastName.getText().trim();
                String legalpersontype=textLegalPersonType.getText().trim();
                String suffix=textSuffix.getText().trim();
                String role=textRole.getText().trim();      
                
                
                
                
                                               

                if(casepersonid.equals("")||caseid.equals("")||legalpersonid.equals("")||remarks.equals("")                   
                   )
                {
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_case` where "
                            + "caseid="+caseid+" or (casetitle='"+casetitle+"')";
                    sql="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and ( "
                        + " tbl_caseperson.casepersonid="+casepersonid2+" or (tbl_case.caseid="+caseid2+" and tbl_legalperson.legalpersonid="+legalpersonid2+"))";
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                           
                        
                        
                        sql="UPDATE `tbl_caseperson` SET `caseid`="+caseid+","
                                + "`legalpersonid`="+legalpersonid+",`remarks`='"+remarks+"' "
                                + "WHERE `casepersonid`="+casepersonid+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_case` where "
                            + "caseid="+caseid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {                        
                            
                            casepersonid2 = rs.getInt("tbl_caseperson.casepersonid");
                            caseid2 = rs.getInt("tbl_case.caseid");
                            legalpersonid2 = rs.getInt("tbl_legalperson.legalpersonid");                
                            casetitle=rs.getString("tbl_case.casetitle");
                            remarks=rs.getString("tbl_caseperson.remarks");
                            firstname=rs.getString("tbl_legalperson.firstname");
                            middlename=rs.getString("tbl_legalperson.middlename");
                            lastname=rs.getString("tbl_legalperson.lastname");
                            legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                            suffix=rs.getString("tbl_legalperson.suffix");
                            role=rs.getString("tbl_legalperson.role");                            

                            textCasePersonID.setText(Integer.toString(casepersonid2));
                            textCaseID.setText(Integer.toString(caseid2));
                            textLegalPersonID.setText(Integer.toString(legalpersonid2));           
                            textCaseTitle.setText(casetitle);
                            textRemarks.setText(remarks);  
                            textFirstName.setText(firstname);
                            textMiddleName.setText(middlename);
                            textLastName.setText(lastname);
                            textLegalPersonType.setText(legalpersontype);
                            textSuffix.setText(suffix);
                            textRole.setText(role);  
                            
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textCasePersonID.setText(Integer.toString(casepersonid2));
                                textCaseID.setText(Integer.toString(caseid2));
                                textLegalPersonID.setText(Integer.toString(legalpersonid2));           
                                textCaseTitle.setText(casetitle);
                                textRemarks.setText(remarks);  
                                textFirstName.setText(firstname);
                                textMiddleName.setText(middlename);
                                textLastName.setText(lastname);
                                textLegalPersonType.setText(legalpersontype);
                                textSuffix.setText(suffix);
                                textRole.setText(role);
                                
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_CasePerson_In_JTable();
        viewall=0;       
        Show_CasePerson_In_JTable();
        viewall2=0;
        Show_CasePersonCaseInquiry_In_JTable();
        viewall3=0;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/legalmonitoringsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
                       

            //String casepersonid=textCasePersonID.getText().trim();
            //int casepersonid2 = Integer.parseInt(casepersonid);
            String caseid=textCaseID.getText().trim();
            int caseid2 = Integer.parseInt(caseid);
            String legalpersonid = textLegalPersonID.getText().trim(); 
            int legalpersonid2=Integer.parseInt(legalpersonid);
            String casetitle=textCaseTitle.getText().trim();           
            String remarks=textRemarks.getText().trim();
            String firstname=textFirstName.getText().trim();
            String middlename=textMiddleName.getText().trim();
            String lastname=textLastName.getText().trim();
            String legalpersontype=textLegalPersonType.getText().trim();
            String suffix=textSuffix.getText().trim();
            String role=textRole.getText().trim();      
            
                   
            

           if(caseid.equals("")|| legalpersonid.equals("")|| remarks.equals(""))
            {
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_case` where casetitle='"+casetitle+"'";
                query="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid and "
                        + "tbl_case.caseid="+caseid2+" and tbl_legalperson.legalpersonid="+legalpersonid2+"";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="";
                    
                    sql="INSERT INTO `tbl_caseperson`(`casepersonid`, `caseid`, `legalpersonid`, `remarks`) "
                            + "VALUES (NULL,"+caseid2+","+legalpersonid2+",'"+remarks+"')";
                    sql="INSERT INTO `tbl_caseperson`(`casepersonid`, `caseid`, `legalpersonid`, `remarks`) "
                            + "VALUES (NULL,"+caseid2+","+legalpersonid2+" ,'"+remarks+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_case`";
                    sql="SELECT tbl_caseperson.casepersonid, tbl_case.caseid, tbl_legalperson.legalpersonid, "
                    + "tbl_case.casetitle,tbl_caseperson.remarks, tbl_legalperson.firstname, tbl_legalperson.middlename, "
                    + "tbl_legalperson.lastname, tbl_legalperson.legalpersontype, tbl_legalperson.suffix, "
                    + "tbl_legalperson.role FROM `tbl_caseperson`,`tbl_legalperson`,`tbl_case` "
                    + "WHERE tbl_case.caseid=tbl_caseperson.caseid and "
                    + "tbl_legalperson.legalpersonid=tbl_caseperson.legalpersonid ";
              
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
                    caseid2 = rs.getInt("tbl_case.caseid");
                    legalpersonid2 = rs.getInt("tbl_legalperson.legalpersonid");                
                    casetitle=rs.getString("tbl_case.casetitle");
                    remarks=rs.getString("tbl_caseperson.remarks");
                    firstname=rs.getString("tbl_legalperson.firstname");
                    middlename=rs.getString("tbl_legalperson.middlename");
                    lastname=rs.getString("tbl_legalperson.lastname");
                    legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                    suffix=rs.getString("tbl_legalperson.suffix");
                    role=rs.getString("tbl_legalperson.role");                            

                    textCasePersonID.setText(Integer.toString(casepersonid));
                    textCaseID.setText(Integer.toString(caseid2));
                    textLegalPersonID.setText(Integer.toString(legalpersonid2));           
                    textCaseTitle.setText(casetitle);
                    textRemarks.setText(remarks);  
                    textFirstName.setText(firstname);
                    textMiddleName.setText(middlename);
                    textLastName.setText(lastname);
                    textLegalPersonType.setText(legalpersontype);
                    textSuffix.setText(suffix);
                    textRole.setText(role);         

                    JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " new inserted record item: "+Double.toString(caseid2));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_CasePerson_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_CasePerson_In_JTable();
        viewall=0;       
        Show_CasePerson_In_JTable();
        viewall2=0;
        Show_CasePersonCaseInquiry_In_JTable();
        viewall3=0;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textCasePersonID.setText("");
            textCaseID.setText("");
            textLegalPersonID.setText("");           
            textCaseTitle.setText("");
            textRemarks.setText("");  
            textFirstName.setText("");
            textMiddleName.setText("");
            textLastName.setText("");
            textLegalPersonType.setText("");
            textSuffix.setText("");
            textRole.setText("");

            textCaseID1.setText("");        
            textCaseTitle1.setText("");

            textLegalPersonID1.setText("");       
            textFirstName1.setText("");
            textMiddleName1.setText("");
            textLastName1.setText("");
            textLegalPersonType1.setText("");
            textSuffix1.setText("");
            textRole1.setText("");  
              

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
            int caseid = rs.getInt("tbl_case.caseid");
            int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String remarks=rs.getString("tbl_caseperson.remarks");
            String firstname=rs.getString("tbl_legalperson.firstname");
            String middlename=rs.getString("tbl_legalperson.middlename");
            String lastname=rs.getString("tbl_legalperson.lastname");
            String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
            String suffix=rs.getString("tbl_legalperson.suffix");
            String role=rs.getString("tbl_legalperson.role");                            

            textCasePersonID.setText(Integer.toString(casepersonid));
            textCaseID.setText(Integer.toString(caseid));
            textLegalPersonID.setText(Integer.toString(legalpersonid));           
            textCaseTitle.setText(casetitle);
            textRemarks.setText(remarks);  
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textLegalPersonType.setText(legalpersontype);
            textSuffix.setText(suffix);
            textRole.setText(role);         

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
                int caseid = rs.getInt("tbl_case.caseid");
                int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String remarks=rs.getString("tbl_caseperson.remarks");
                String firstname=rs.getString("tbl_legalperson.firstname");
                String middlename=rs.getString("tbl_legalperson.middlename");
                String lastname=rs.getString("tbl_legalperson.lastname");
                String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                String suffix=rs.getString("tbl_legalperson.suffix");
                String role=rs.getString("tbl_legalperson.role");                            

                textCasePersonID.setText(Integer.toString(casepersonid));
                textCaseID.setText(Integer.toString(caseid));
                textLegalPersonID.setText(Integer.toString(legalpersonid));           
                textCaseTitle.setText(casetitle);
                textRemarks.setText(remarks);  
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textLegalPersonType.setText(legalpersontype);
                textSuffix.setText(suffix);
                textRole.setText(role);         

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {  

                textCasePersonID.setText("");
                textCaseID.setText("");
                textLegalPersonID.setText("");           
                textCaseTitle.setText("");
                textRemarks.setText("");  
                textFirstName.setText("");
                textMiddleName.setText("");
                textLastName.setText("");
                textLegalPersonType.setText("");
                textSuffix.setText("");
                textRole.setText("");

                textCaseID1.setText("");        
                textCaseTitle1.setText("");

                textLegalPersonID1.setText("");       
                textFirstName1.setText("");
                textMiddleName1.setText("");
                textLastName1.setText("");
                textLegalPersonType1.setText("");
                textSuffix1.setText("");
                textRole1.setText("");  
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textCasePersonID.setText("");
        textCaseID.setText("");
        textLegalPersonID.setText("");           
        textCaseTitle.setText("");
        textRemarks.setText("");  
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textLegalPersonType.setText("");
        textSuffix.setText("");
        textRole.setText("");
        
        textCaseID1.setText("");        
        textCaseTitle1.setText("");
        
        textLegalPersonID1.setText("");       
        textFirstName1.setText("");
        textMiddleName1.setText("");
        textLastName1.setText("");
        textLegalPersonType1.setText("");
        textSuffix1.setText("");
        textRole1.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
                int caseid = rs.getInt("tbl_case.caseid");
                int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String remarks=rs.getString("tbl_caseperson.remarks");
                String firstname=rs.getString("tbl_legalperson.firstname");
                String middlename=rs.getString("tbl_legalperson.middlename");
                String lastname=rs.getString("tbl_legalperson.lastname");
                String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                String suffix=rs.getString("tbl_legalperson.suffix");
                String role=rs.getString("tbl_legalperson.role");                            

                textCasePersonID.setText(Integer.toString(casepersonid));
                textCaseID.setText(Integer.toString(caseid));
                textLegalPersonID.setText(Integer.toString(legalpersonid));           
                textCaseTitle.setText(casetitle);
                textRemarks.setText(remarks);  
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textLegalPersonType.setText(legalpersontype);
                textSuffix.setText(suffix);
                textRole.setText(role);           

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;       
        Show_CasePerson_In_JTable();
        viewall2=0;
        Show_CasePersonCaseInquiry_In_JTable();
        viewall3=0;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
        
        
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
            int caseid = rs.getInt("tbl_case.caseid");
            int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String remarks=rs.getString("tbl_caseperson.remarks");
            String firstname=rs.getString("tbl_legalperson.firstname");
            String middlename=rs.getString("tbl_legalperson.middlename");
            String lastname=rs.getString("tbl_legalperson.lastname");
            String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
            String suffix=rs.getString("tbl_legalperson.suffix");
            String role=rs.getString("tbl_legalperson.role");                            

            textCasePersonID.setText(Integer.toString(casepersonid));
            textCaseID.setText(Integer.toString(caseid));
            textLegalPersonID.setText(Integer.toString(legalpersonid));           
            textCaseTitle.setText(casetitle);
            textRemarks.setText(remarks);  
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textLegalPersonType.setText(legalpersontype);
            textSuffix.setText(suffix);
            textRole.setText(role);            

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
                int caseid = rs.getInt("tbl_case.caseid");
                int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
                String casetitle=rs.getString("tbl_case.casetitle");
                String remarks=rs.getString("tbl_caseperson.remarks");
                String firstname=rs.getString("tbl_legalperson.firstname");
                String middlename=rs.getString("tbl_legalperson.middlename");
                String lastname=rs.getString("tbl_legalperson.lastname");
                String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
                String suffix=rs.getString("tbl_legalperson.suffix");
                String role=rs.getString("tbl_legalperson.role");                            

                textCasePersonID.setText(Integer.toString(casepersonid));
                textCaseID.setText(Integer.toString(caseid));
                textLegalPersonID.setText(Integer.toString(legalpersonid));           
                textCaseTitle.setText(casetitle);
                textRemarks.setText(remarks);  
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textLegalPersonType.setText(legalpersontype);
                textSuffix.setText(suffix);
                textRole.setText(role);           

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int casepersonid = rs.getInt("tbl_caseperson.casepersonid");
            int caseid = rs.getInt("tbl_case.caseid");
            int legalpersonid = rs.getInt("tbl_legalperson.legalpersonid");                
            String casetitle=rs.getString("tbl_case.casetitle");
            String remarks=rs.getString("tbl_caseperson.remarks");
            String firstname=rs.getString("tbl_legalperson.firstname");
            String middlename=rs.getString("tbl_legalperson.middlename");
            String lastname=rs.getString("tbl_legalperson.lastname");
            String legalpersontype=rs.getString("tbl_legalperson.legalpersontype");
            String suffix=rs.getString("tbl_legalperson.suffix");
            String role=rs.getString("tbl_legalperson.role");                            

            textCasePersonID.setText(Integer.toString(casepersonid));
            textCaseID.setText(Integer.toString(caseid));
            textLegalPersonID.setText(Integer.toString(legalpersonid));           
            textCaseTitle.setText(casetitle);
            textRemarks.setText(remarks);  
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textLegalPersonType.setText(legalpersontype);
            textSuffix.setText(suffix);
            textRole.setText(role);          

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(LegalMonitoringSystemCasePersonMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search enddate or legal person type
    private void btnSearchByRoleOrLegalPersonTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_CasePerson_In_JTable();
        
    }//GEN-LAST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed

    //search Legal Person ID
    private void btnSearchByLegalPersonIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLegalPersonIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLegalPersonIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_CasePerson_In_JTable();
    }//GEN-LAST:event_btnSearchByLegalPersonIDActionPerformed

    private void jRadioButtonLastNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonLastNameActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonLastNameActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonLastName.isSelected())
        {
            //jRadioButtonLastName.setSelected(false);
            jRadioButtonFirstName.setSelected(false);
            jRadioButtonMiddleName.setSelected(false);
            jRadioButtonLegalPersonType.setSelected(false);
            jRadioButtonRole.setSelected(false);
        }    
    }//GEN-LAST:event_jRadioButtonLastNameActionPerformed

    private void jRadioButtonMiddleNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonMiddleNameActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonMiddleNameActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonMiddleName.isSelected())
        {
            
            jRadioButtonLastName.setSelected(false);
            jRadioButtonFirstName.setSelected(false);
            //jRadioButtonMiddleName.setSelected(false);
            jRadioButtonLegalPersonType.setSelected(false);
            jRadioButtonRole.setSelected(false);
        }
    }//GEN-LAST:event_jRadioButtonMiddleNameActionPerformed

    private void jRadioButtonFirstNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonFirstNameActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonFirstNameActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonFirstName.isSelected())
        {
            
            jRadioButtonLastName.setSelected(false);
            //jRadioButtonFirstName.setSelected(false);
            jRadioButtonMiddleName.setSelected(false);
            jRadioButtonLegalPersonType.setSelected(false);
            jRadioButtonRole.setSelected(false);
        }
    }//GEN-LAST:event_jRadioButtonFirstNameActionPerformed

    private void jRadioButtonLegalPersonTypeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonLegalPersonTypeActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonLegalPersonTypeActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonLegalPersonType.isSelected())
        {
            
            jRadioButtonLastName.setSelected(false);
            jRadioButtonFirstName.setSelected(false);
            jRadioButtonMiddleName.setSelected(false);
            //jRadioButtonLegalPersonType.setSelected(false);
            jRadioButtonRole.setSelected(false);
        }
    }//GEN-LAST:event_jRadioButtonLegalPersonTypeActionPerformed

    private void jRadioButtonRoleActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonRoleActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonRoleActionPerformed
        // TODO add your handling code here:
        if(jRadioButtonRole.isSelected())
        {
            
            jRadioButtonLastName.setSelected(false);
            jRadioButtonFirstName.setSelected(false);
            jRadioButtonMiddleName.setSelected(false);
            jRadioButtonLegalPersonType.setSelected(false);
            //jRadioButtonRole.setSelected(false);
        }
        
    }//GEN-LAST:event_jRadioButtonRoleActionPerformed

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyPressed
    {//GEN-HEADEREND:event_jTable2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            
            textCaseID1.setText(model.getValueAt(i, 0).toString());                       
            textCaseTitle1.setText(model.getValueAt(i, 1).toString());
            
            

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable2MouseClicked
    {//GEN-HEADEREND:event_jTable2MouseClicked
        // TODO add your handling code here:
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();
        
        textCaseID1.setText(model.getValueAt(i, 0).toString());                       
        textCaseTitle1.setText(model.getValueAt(i, 1).toString());
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            textLegalPersonID1.setText(model.getValueAt(i, 0).toString());           
            textLegalPersonType1.setText(model.getValueAt(i, 1).toString());        
            textFirstName1.setText(model.getValueAt(i, 2).toString());
            textMiddleName1.setText(model.getValueAt(i,3).toString());
            textLastName1.setText(model.getValueAt(i, 4).toString());        
            textSuffix1.setText(model.getValueAt(i, 5).toString());
            textRole1.setText(model.getValueAt(i, 6).toString());
            

        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        int i=jTable3.getSelectedRow();
        TableModel model=jTable3.getModel();

        textLegalPersonID1.setText(model.getValueAt(i, 0).toString());           
        textLegalPersonType1.setText(model.getValueAt(i, 1).toString());        
        textFirstName1.setText(model.getValueAt(i, 2).toString());
        textMiddleName1.setText(model.getValueAt(i,3).toString());
        textLastName1.setText(model.getValueAt(i, 4).toString());        
        textSuffix1.setText(model.getValueAt(i, 5).toString());
        textRole1.setText(model.getValueAt(i, 6).toString());
        
    }//GEN-LAST:event_jTable3MouseClicked

    private void btnLegalPersonSearchActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLegalPersonSearchActionPerformed
    {//GEN-HEADEREND:event_btnLegalPersonSearchActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_CasePerson_In_JTable();
    }//GEN-LAST:event_btnLegalPersonSearchActionPerformed

    private void btnCaseIDInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCaseIDInqActionPerformed
    {//GEN-HEADEREND:event_btnCaseIDInqActionPerformed
        // TODO add your handling code here:
        viewall2=3;
        Show_CasePersonCaseInquiry_In_JTable();
    }//GEN-LAST:event_btnCaseIDInqActionPerformed

    private void btnLegalPersonSearchInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLegalPersonSearchInqActionPerformed
    {//GEN-HEADEREND:event_btnLegalPersonSearchInqActionPerformed
        // TODO add your handling code here:
        viewall3=1;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
    }//GEN-LAST:event_btnLegalPersonSearchInqActionPerformed

    private void btnCaseTitleInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCaseTitleInqActionPerformed
    {//GEN-HEADEREND:event_btnCaseTitleInqActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_CasePersonCaseInquiry_In_JTable();
    }//GEN-LAST:event_btnCaseTitleInqActionPerformed

    private void btnLegalPersonIDInqActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnLegalPersonIDInqActionPerformed
    {//GEN-HEADEREND:event_btnLegalPersonIDInqActionPerformed
        // TODO add your handling code here:
        viewall3=3;        
        Show_CasePersonLegalPersonInquiry_In_JTable();
    }//GEN-LAST:event_btnLegalPersonIDInqActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnCaseIDInq;
    private javax.swing.JButton btnCaseTitleInq;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLegalPersonIDInq;
    private javax.swing.JButton btnLegalPersonSearch;
    private javax.swing.JButton btnLegalPersonSearchInq;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByLegalPersonID;
    private javax.swing.JButton btnSearchByRoleOrLegalPersonType;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButtonFirstName;
    private javax.swing.JRadioButton jRadioButtonLastName;
    private javax.swing.JRadioButton jRadioButtonLegalPersonType;
    private javax.swing.JRadioButton jRadioButtonMiddleName;
    private javax.swing.JRadioButton jRadioButtonRole;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField textCaseID;
    private javax.swing.JTextField textCaseID1;
    private javax.swing.JTextField textCasePersonID;
    private javax.swing.JTextField textCaseTitle;
    private javax.swing.JTextField textCaseTitle1;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textFirstName1;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textLastName1;
    private javax.swing.JTextField textLegalPersonID;
    private javax.swing.JTextField textLegalPersonID1;
    private javax.swing.JTextField textLegalPersonType;
    private javax.swing.JTextField textLegalPersonType1;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextField textMiddleName1;
    private javax.swing.JTextArea textRemarks;
    private javax.swing.JTextField textRole;
    private javax.swing.JTextField textRole1;
    private javax.swing.JTextField textSuffix;
    private javax.swing.JTextField textSuffix1;
    // End of variables declaration//GEN-END:variables
}
