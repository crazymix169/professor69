/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustBadSaleslMaintenance extends javax.swing.JFrame {
    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0,viewall3=0;
    String query;
    
    String username;
    String userid;
    String goodsname;
    String goodsid;

    /**
     * Creates new form SalesAndInventoryCristalStocktrailMaintenance
     */
    
    
    public SalesAndInventoryAugustBadSaleslMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        
        Show_BadSales_In_JTable();
    }
    
    public SalesAndInventoryAugustBadSaleslMaintenance() {
        initComponents();
        
        DoConnect();
        
        Show_BadSales_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_badsales";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); 
            
            int badsalesid = rs.getInt("badsalesid");
            int stocksid = rs.getInt("stocksid");
            int quantity=rs.getInt("quantity");
            Date date=rs.getDate("date");
            Date time = rs.getTime("time");
            
            Date now = new Date();
            System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
            //SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
            System.out.println("Format 2:   " + dateFormatter.format(now));
            
            textStocktrailID.setText(Integer.toString(badsalesid));
            textStocksID.setText(Integer.toString(stocksid));
            
            textStockType.setText(Integer.toString(quantity));
            textDate.setText(dateFormatter.format(date));
            textTime.setText(dateFormatter2.format(time));
            
            
            
            
                 
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
             Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    
    
    
    
    
    
    
    
    public ArrayList<SalesAndInventoryAugustBadSalesTable> getSalestrailList()
    {
        ArrayList<SalesAndInventoryAugustBadSalesTable> badsalesList= new ArrayList<SalesAndInventoryAugustBadSalesTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "Select * from tbl_badsales";
            }
            else
            {
                goodsid=textStocktrailID.getText();
                int stocksid1=Integer.parseInt(goodsid);
                query = "Select * from tbl_badsales where badsalesid = "+goodsid+"";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustBadSalesTable badsales;
            
            while(rs.next())
            {
                badsales = new  SalesAndInventoryAugustBadSalesTable(rs.getInt("badsalesid"),rs.getInt("stocksid"),
                        rs.getInt("quantity"),rs.getDate("date")
                        , rs.getDate("time"));
                badsalesList.add(badsales);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return badsalesList;
     
    }
    
    public void Show_BadSales_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustBadSalesTable> list = getSalestrailList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[5];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getBadSalesID();
            row[1]=list.get(i).getSalesID();
            
            row[2]=list.get(i).getQuantity();
            row[3]=list.get(i).getDateofStocks();
            row[4]=list.get(i).getTimeofStocks();
            
            
                        
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNext = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        btnViewAll = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        textDate = new javax.swing.JTextField();
        btnFirst = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textStocktrailID = new javax.swing.JTextField();
        btnClearAll = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        textStocksID = new javax.swing.JTextField();
        textTime = new javax.swing.JTextField();
        textStockType = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Bad Sales ID", "Sales ID", "Quantity", "Date", "Time"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane8.setViewportView(jTable2);

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete this User");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Stocks ID");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText(" Date");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Stocktrail ID");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Stock Type");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnPrevious)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 1078, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textStocktrailID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(1, 1, 1))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(27, 27, 27)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textStockType, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAll, javax.swing.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
                            .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
                            .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAll, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnFanAdminWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(363, 363, 363)))
                .addContainerGap(563, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textStocktrailID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(btnFanAdminWelcome))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textStockType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(btnEdit))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClearAll))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLast, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(251, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                /*
                stmt = con.createStatement( );
                String sql="Select * from tbl_sales";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                rs.next( ); */

                int salesid = rs.getInt("stocktrailid");
                int stocksid = rs.getInt("stocksid");
                String stocktype=rs.getString("stocktype");
                String date=rs.getString("date");
                String time = rs.getString("time");

                textStocksID.setText(Integer.toString(stocksid));
                textStocktrailID.setText(Integer.toString(salesid));
                textStockType.setText(stocktype);
                textDate.setText(date);
                textTime.setText(time);

                //stmt.close();
                //con.close();

                

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();

        textStocktrailID.setText(model.getValueAt(i, 0).toString());
        textStocksID.setText(model.getValueAt(i, 1).toString());
        textStockType.setText(model.getValueAt(i, 2).toString());
        textDate.setText(model.getValueAt(i, 3).toString());
        textTime.setText(model.getValueAt(i, 4).toString());
        
        

    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

             textStocktrailID.setText(model.getValueAt(i, 0).toString());
             textStocksID.setText(model.getValueAt(i, 1).toString());
             textStockType.setText(model.getValueAt(i, 2).toString());
             textDate.setText(model.getValueAt(i, 3).toString());
             textTime.setText(model.getValueAt(i, 4).toString());

        }

    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

             textStocktrailID.setText(model.getValueAt(i, 0).toString());
             textStocksID.setText(model.getValueAt(i, 1).toString());
             textStockType.setText(model.getValueAt(i, 2).toString());
             textDate.setText(model.getValueAt(i, 3).toString());
             textTime.setText(model.getValueAt(i, 4).toString());

        }
    }//GEN-LAST:event_jTable2KeyTyped

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_BadSales_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                /*
                stmt = con.createStatement( );
                String sql="Select * from tbl_sales";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                rs.next( ); */

                int salesid = rs.getInt("stocktrailid");
                int stocksid = rs.getInt("stocksid");
                String stocktype=rs.getString("stocktype");
                String date=rs.getString("date");
                String time = rs.getString("time");

                textStocksID.setText(Integer.toString(stocksid));
                textStocktrailID.setText(Integer.toString(salesid));
                textStockType.setText(stocktype);
                textDate.setText(date);
                textTime.setText(time);

                //stmt.close();
                //con.close();

                

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            /*
            stmt = con.createStatement( );
            String sql="Select * from tbl_sales";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); */

            int salesid = rs.getInt("stocktrailid");
            int stocksid = rs.getInt("stocksid");
            String stocktype=rs.getString("stocktype");
            String date=rs.getString("date");
            String time = rs.getString("time");

            textStocksID.setText(Integer.toString(stocksid));
            textStocktrailID.setText(Integer.toString(salesid));
            textStockType.setText(stocktype);
            textDate.setText(date);
            textTime.setText(time);

            //stmt.close();
            //con.close();

            

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            /*
            stmt = con.createStatement( );
            String sql="Select * from tbl_sales";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            rs.next( ); */

            int salesid = rs.getInt("stocktrailid");
            int stocksid = rs.getInt("stocksid");
            String stocktype=rs.getString("stocktype");
            String date=rs.getString("date");
            String time = rs.getString("time");

            textStocksID.setText(Integer.toString(stocksid));
            textStocktrailID.setText(Integer.toString(salesid));
            textStockType.setText(stocktype);
            textDate.setText(date);
            textTime.setText(time);

            //stmt.close();
            //con.close();

            

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        
        textStocksID.setText("");
        textStocktrailID.setText("");
        textStockType.setText("");
        textDate.setText("");
        textTime.setText("");

        
        

    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String stocktrailid3=textStocktrailID.getText().trim();
                int stocktrailid2=Integer.parseInt(stocktrailid3);

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String stocktype=textStockType.getText().trim();
                String date2=textDate.getText().trim();
                String time2=textTime.getText().trim();

                if(stocktrailid3.equals("")|| stocksid.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_stocktrail where stocktraild="+stocktrailid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        /*int id_col2 = rs.getInt("goodsid");
                        String goodsname2 = rs.getString("goodsname");
                        String goodsdescription2 = rs.getString("goodsdescription");
                        String userlevel2 = rs.getString("userlevel");

                        String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                        System.out.println( p );*/

                        rowCount++;
                    }

                    if(rowCount==1)
                    {

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        sql="Update tbl_stocktrail"
                        + " SET  date='"+date2+"',time='"+time2+"'"
                        + " where stocktrailid="+stocktrailid2+"";

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Admin User Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        Show_BadSales_In_JTable();
                    }
                    else
                    {

                        /*
                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());
                        */

                        /*
                        sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                        + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                        String fname=trim(textFirstName.getText());
                        String mname=trim(textMiddleName.getText());
                        String lname=trim(textLastName.getText());
                        String address=trim(textAddress.getText());
                        String sex=trim(comboSex.getSelectedItem());
                        String jobtitle=trim(textJobTitle.getText());
                        String email=trim(textEmail.getText());
                        String dateofbirth=trim(textDateOfBirth.getText());
                        String hobby=trim(textHobby.getText());

                        */
                        JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " Sorry, No Record UPDATED! ");

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_BadSales_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String stocktrailid3=textStocktrailID.getText().trim();
                int stocktrailid2=Integer.parseInt(stocktrailid3);

                stmt = con.createStatement( );
                String sql="Select * from tbl_stocktrail where stocktraild="+stocktrailid2+" ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    /*int id_col2 = rs.getInt("goodsid");
                    String goodsname2 = rs.getString("goodsname");
                    String goodsdescription2 = rs.getString("goodsdescription");
                    String userlevel2 = rs.getString("userlevel");

                    String p = id_col2 + "          " + goodsname2 + "      " + goodsdescription2+ "      " + userlevel2;
                    System.out.println( p );*/

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {

                    /*
                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());
                    */

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    /*
                    sql ="INSERT INTO table_idolinformation " + "VALUES (NULL, '"+goodsname+"', '"+userpass+"', '"+fname+"', '"+mname+"',"
                    + " '"+lname+"', '"+address+"', '"+sex+"', '"+jobtitle+"', '"+email+"', '"+dateofbirth+"', '"+hobby+"')";

                    String fname=trim(textFirstName.getText());
                    String mname=trim(textMiddleName.getText());
                    String lname=trim(textLastName.getText());
                    String address=trim(textAddress.getText());
                    String sex=trim(comboSex.getSelectedItem());
                    String jobtitle=trim(textJobTitle.getText());
                    String email=trim(textEmail.getText());
                    String dateofbirth=trim(textDateOfBirth.getText());
                    String hobby=trim(textHobby.getText());

                    */
                    /*
                    sql="Update table_idolinformation"
                    + " SET  fangoodsname='"+goodsname+",FNAME='"+fname+"',MNAME='"+mname+"', LNAME='"+lname+"', "
                    + "address='"+address+"', sex='"+sex+"',job_title='"+jobtitle+"',email='"+email+"',"
                    + "dob='"+dateofbirth+"', hobby='"+hobby+"'"
                    + " where idolinformationid="+goodsid2+"";*/

                    sql="DELETE FROM  tbl_stocktrail"
                    + " where stocktrailid="+stocktrailid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustBadSaleslMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_BadSales_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustBadSaleslMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustBadSaleslMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustBadSaleslMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustBadSaleslMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalesAndInventoryAugustBadSaleslMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextField textStockType;
    private javax.swing.JTextField textStocksID;
    private javax.swing.JTextField textStocktrailID;
    private javax.swing.JTextField textTime;
    // End of variables declaration//GEN-END:variables
}
