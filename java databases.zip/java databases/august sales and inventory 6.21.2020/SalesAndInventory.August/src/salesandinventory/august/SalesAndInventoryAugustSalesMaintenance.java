/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustSalesMaintenance extends javax.swing.JFrame {
    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0,viewall3=0;
    String query;
    
    String username;
    String userid;
    String goodsname;
    String goodsid;

    /**
     * Creates new form SalesAndInventoryCristalSalesMaintenance
     */
    
    
    public SalesAndInventoryAugustSalesMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_GoodsAvailableFromStocks_In_JTable();
       
        Show_Sales_In_JTable();
    }
    
    public SalesAndInventoryAugustSalesMaintenance() {
        initComponents();
        
        DoConnect();
        Show_GoodsAvailableFromStocks_In_JTable();
        
        Show_Sales_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            /*
            String sql="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods";
            rs = stmt.executeQuery(sql);*/
            /*
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%t%'
            
            int salesid;
            int stocksid;
            int goodsid;
            String goodsname;
            String goodsdescription;
            int quantityordered;
            double totalpayable;
            double totalpayment;
            double totalchange;
            String salesstatus;
            Date dateofsales;
            Date timeofsales;
            
            */
            String sql="Select tbl_sales.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_sales.quantityordered,"
                    +"tbl_sales.totalpayable, tbl_sales.totalpayment, tbl_sales.totalchange"
                    +", tbl_sales.salessatus,tbl_sales.date, tbl_sales.time from tbl_stocks,tbl_goods,tbl_sales"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                    +"";
            rs = stmt.executeQuery(sql);
            
            

            int rowCount=0;

            rs.next( ); 
            
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textQuantityOrdered.setText(Double.toString(quantityordered));
            textTotalPayable.setText(Double.toString(totalpayable));
            textTotalAmountPaid.setText(Double.toString(totalpayment));
            textTotalChange.setText(Double.toString(totalchange));
            
            textDate.setText(date);
            textTime.setText(time);
            
            /*
            //stmt.close();
            //con.close();
            
            stmt2 = con.createStatement( );
            sql="Select * from tbl_stocks";
            rs2 = stmt2.executeQuery(sql);

            rowCount=0;
            
            int stocksid2=0;
            int goodsid2=0;

            double totalcost2;
            double totalamountpaid2;
            double remainingamount2;

            String salesstatus2;

            //rs2.next( );
            while(rs2.next())
            {
                if(stocksid==rs2.getInt("stocksid"))
                {
                    stocksid2 = rs2.getInt("stocksid");
                    goodsid2 = rs2.getInt("goodsid");

                    totalcost2 = rs2.getDouble("totalcost");
                    totalamountpaid2 = rs2.getDouble("totalamountpaid");
                    remainingamount2 = rs2.getDouble("remainingamount");
                    
                    salesstatus2=rs2.getString("salesstatus");
                    
                    textStocksID.setText(Integer.toString(stocksid2));
                    textGoodsID.setText(Integer.toString(goodsid2));

                    textTotalChange.setText(Double.toString(totalcost2));
                    textTotalAmountPaid.setText(Double.toString(totalamountpaid2));
                    textRemainingAmount.setText(Double.toString(remainingamount2));
                    textSalesStatus.setText(salesstatus2);
                    
                    break;
                    
                }
            }        
            
            stmt3 = con.createStatement( );
            sql="Select * from tbl_goods where goodsid="+goodsid2+"";
            rs3 = stmt3.executeQuery(sql);

            rowCount=0;
            
            int goodsid3;
            
            String goodsname3;
            String goodsdescription3;

            //rs3.next( );
            while(rs3.next())
            {
                if(goodsid2==rs3.getInt("goodsid"))
                {
                    goodsid3=rs3.getInt("goodsid");
            
                    goodsname3=rs3.getString("goodsname");
                    goodsdescription3=rs3.getString("goodsdescription")    ;
                    
                    textGoodsID.setText(Integer.toString(goodsid3));
           
                    textGoodsName.setText(goodsname3);
                    textGoodsDescription.setText(goodsdescription3);
                    
                    break;
                  
                }
            }*/
                 
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    
    
    
    
    public ArrayList<SalesAndInventoryAugustSalesInquiryTable> getGoodsList()
    {
        ArrayList<SalesAndInventoryAugustSalesInquiryTable> goodsList= new ArrayList<SalesAndInventoryAugustSalesInquiryTable>();
        Connection connection = getConnection();
        
        /*
            String sql="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods";
            rs = stmt.executeQuery(sql);*/
            /*
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%t%'
            
            int salesid;
            int stocksid;
            int goodsid;
            String goodsname;
            String goodsdescription;
            int quantityordered;
            double totalpayable;
            double totalpayment;
            double totalchange;
            String salesstatus;
            Date dateofsales;
            Date timeofsales;
            
            */
       
        
        try
        {
            if(viewall3==0)
            {
                //query = "Select * from tbl_goods";
                query="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods"
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0";
            }
            else
            {
                goodsname=textGoodsName.getText();
                //query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
                query="SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,tbl_stocks.price,"
                        +"tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` "
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%"+goodsname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs3=st.executeQuery(query);
            
           
            
            SalesAndInventoryAugustSalesInquiryTable goods1;
            
            while(rs3.next())
            {
                goods1 = new  SalesAndInventoryAugustSalesInquiryTable(rs3.getString("goodsname"),rs3.getString("goodsdescription"),rs3.getInt("stocksid"), 
                             rs.getDouble("price"),rs.getInt("quantity"), rs.getDouble("totalpayable") );
                goodsList.add(goods1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return goodsList;
     
    }
    
    public void Show_GoodsAvailableFromStocks_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustSalesInquiryTable> list = getGoodsList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
        /*
            query="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods"
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0";
            */
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getGoodsName();
            row[1]=list.get(i).getGoodsDescription();
            row[2]=list.get(i).getStocksID();
            row[3]=list.get(i).getPrice();
            row[4]=list.get(i).getQuantity();
            row[5]=list.get(i).getTotalAmountPayable();
            
            
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustSalesTable> getSalesList()
    {
        ArrayList<SalesAndInventoryAugustSalesTable> salesList= new ArrayList<SalesAndInventoryAugustSalesTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                //query = "Select * from tbl_sales";
                query="Select tbl_sales.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_sales.quantityordered,"
                    +"tbl_sales.totalpayable, tbl_sales.totalpayment, tbl_sales.totalchange"
                    +", tbl_sales.salessatus,tbl_sales.date, tbl_sales.time from tbl_stocks,tbl_goods,tbl_sales"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid";
            }
            else
            {
                goodsname=textGoodsName.getText();
                //int stocksid1=Integer.parseInt(goodsid);
                //query = "Select * from tbl_sales where stocksid = "+goodsid+"";
                query="Select tbl_sales.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_sales.quantityordered,"
                    +"tbl_sales.totalpayable, tbl_sales.totalpayment, tbl_sales.totalchange"
                    +", tbl_sales.salessatus,tbl_sales.date, tbl_sales.time from tbl_stocks,tbl_goods,tbl_sales"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                        + "and and tbl_goods.goodsname LIKE '%"+goodsname+"%' ";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           /*
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            */
            
            SalesAndInventoryAugustSalesTable sales1;
            
            while(rs.next())
            {
                sales1 = new  SalesAndInventoryAugustSalesTable(rs.getInt("salesid"),rs.getInt("stocksid"),
                        rs.getInt("goodsid"),rs.getString("goodsname"),rs.getString("goodsdescription"),
                        rs.getInt("quantityordered"),rs.getDouble("totalpayable"),
                        rs.getDouble("totalchange"),rs.getDouble("totalpayment"),rs.getString("salesstatus"),rs.getDate("date")
                        , rs.getTime("time"));
                salesList.add(sales1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return salesList;
     
    }
    
    public void Show_Sales_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustSalesTable> list = getSalesList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
        
        /*
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            */
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSalesID();
            row[1]=list.get(i).getStocksID();
            row[2]=list.get(i).getGoodsID();
            row[3]=list.get(i).getGoodsName();
            row[4]=list.get(i).getGoodsDescription();
            row[5]=list.get(i).getQuantityOrdered();
            row[6]=list.get(i).getTotalPayable();
            row[7]=list.get(i).getTotalPayment();
            row[8]=list.get(i).getTotalChange();
            row[9]=list.get(i).getSalesStatus();
            row[10]=list.get(i).getDateofSales();
            row[11]=list.get(i).getTimeofSales();
            
            
                        
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textStocksID = new javax.swing.JTextField();
        textTime = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textGoodsDescription = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        textTotalChange = new javax.swing.JTextField();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        textSalesStatus = new javax.swing.JTextField();
        btnClearAll = new javax.swing.JButton();
        textGoodsName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByGoodsname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        textDate = new javax.swing.JTextField();
        btnFirst = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textSalesID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textQuantityOrdered = new javax.swing.JTextField();
        textGoodsID = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        textTotalAmountPaid = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        textTotalPayable = new javax.swing.JTextField();
        textSearchGoodsFromStocks = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        textGoodsDescription.setBackground(new java.awt.Color(51, 255, 255));
        textGoodsDescription.setColumns(20);
        textGoodsDescription.setRows(5);
        jScrollPane1.setViewportView(textGoodsDescription);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Total Change");

        textTotalChange.setBackground(new java.awt.Color(102, 255, 0));

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Sales Status");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Goods Description");

        textSalesStatus.setBackground(new java.awt.Color(255, 102, 0));

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        textGoodsName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Goods ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Goods Name");

        btnSearchByGoodsname.setText("Search by Goods Name");
        btnSearchByGoodsname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Stocks ID");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText(" Date");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Sales ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Quantity Ordered");

        textGoodsID.setBackground(new java.awt.Color(51, 255, 255));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Goods Name", "Goods Description", "Stocks ID", "Sales ID", "Quantity from Stocks", "Price", "Total Amount Payable"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable3KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable3KeyTyped(evt);
            }
        });
        jScrollPane7.setViewportView(jTable3);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sales ID", "Stocks ID", "Goods ID", "Goods Name", "Goods Description", "Quantity Ordered", "Total Payable", "Total Payment", "Total Change", "Date", "Time"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane8.setViewportView(jTable2);

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Total Amount Paid");

        textTotalAmountPaid.setBackground(new java.awt.Color(51, 255, 51));

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Total Payable");

        textTotalPayable.setBackground(new java.awt.Color(51, 255, 51));

        textSearchGoodsFromStocks.setText("Search Goods from Stocks");
        textSearchGoodsFromStocks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textSearchGoodsFromStocksActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textGoodsName)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textGoodsID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(btnSearchByGoodsname)
                                                .addGap(98, 98, 98)))))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(1, 1, 1))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(27, 27, 27)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textQuantityOrdered, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(30, 30, 30)
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textSalesID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(textTotalPayable, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(textTotalAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(2, 2, 2)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(textSalesStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(textTotalChange, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE))))))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnPrevious)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnFanAdminWelcome))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(textSearchGoodsFromStocks)))
                        .addGap(0, 553, Short.MAX_VALUE))
                    .addComponent(jScrollPane8))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(jLabel5))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textGoodsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textGoodsName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearchByGoodsname)
                        .addGap(21, 21, 21)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textSalesID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textQuantityOrdered, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textTotalPayable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(textTotalAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(textTotalChange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textSalesStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textSearchGoodsFromStocks)
                        .addGap(104, 104, 104)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEdit)
                            .addComponent(btnDelete)
                            .addComponent(btnNewRecord))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSaveRecord)
                            .addComponent(btnCancelNewRecord)
                            .addComponent(btnClearAll)
                            .addComponent(btnFanAdminWelcome))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(177, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textGoodsID.setText("");
        textGoodsName.setText("");
        textGoodsDescription.setText("");
        textStocksID.setText("");
        textSalesID.setText("");
        textQuantityOrdered.setText("");
        textDate.setText("");
        textTime.setText("");
                     
        textStocksID.setText("");
        textGoodsID.setText("");

        textTotalChange.setText("");
        textTotalAmountPaid.setText("");
        textTotalPayable.setText("");
        textSalesStatus.setText("");
                    
                    
            
                    
    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnSearchByGoodsnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsnameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_GoodsAvailableFromStocks_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsnameActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {
                
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textQuantityOrdered.setText(Double.toString(quantityordered));
            textTotalPayable.setText(Double.toString(totalpayable));
            textTotalAmountPaid.setText(Double.toString(totalpayment));
            textTotalChange.setText(Double.toString(totalchange));
            
            textDate.setText(date);
            textTime.setText(time);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Sales_In_JTable();
        viewall3=0;
        Show_GoodsAvailableFromStocks_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {
                
                int salesid = rs.getInt("salesid");
                int stocksid = rs.getInt("stocksid");
                int goodsid=rs.getInt("goodsid");
                String goodsname=rs.getString("goodsname");
                String goodsdescription=rs.getString("goodsdescription");
                int quantityordered=rs.getInt("quantityordered");
                double totalpayable=rs.getDouble("totalpayable");
                double totalpayment=rs.getDouble("totalpayment");
                double totalchange=rs.getDouble("totalchange");
                String salesstatus=rs.getString("salesstatus");


                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft = 
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 = 
                new SimpleDateFormat (" hh:mm:ss ");

                String date=ft.format(rs.getDate("date"));
                String time = ft.format(rs.getTime("time"));

                textStocksID.setText(Integer.toString(stocksid));
                textSalesID.setText(Integer.toString(salesid));
                textGoodsID.setText(Integer.toString(goodsid));
                textGoodsName.setText(goodsname);
                textGoodsDescription.setText(goodsdescription);
                textQuantityOrdered.setText(Double.toString(quantityordered));
                textTotalPayable.setText(Double.toString(totalpayable));
                textTotalAmountPaid.setText(Double.toString(totalpayment));
                textTotalChange.setText(Double.toString(totalchange));

                textDate.setText(date);
                textTime.setText(time);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();
            
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textQuantityOrdered.setText(Double.toString(quantityordered));
            textTotalPayable.setText(Double.toString(totalpayable));
            textTotalAmountPaid.setText(Double.toString(totalpayment));
            textTotalChange.setText(Double.toString(totalchange));
            
            textDate.setText(date);
            textTime.setText(time);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();
              
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textQuantityOrdered.setText(Double.toString(quantityordered));
            textTotalPayable.setText(Double.toString(totalpayable));
            textTotalAmountPaid.setText(Double.toString(totalpayment));
            textTotalChange.setText(Double.toString(totalchange));
            
            textDate.setText(date);
            textTime.setText(time);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        int i=jTable3.getSelectedRow();
        TableModel model=jTable3.getModel();
        /*
        
        */
        /*
        textGoodsID.setText(model.getValueAt(i, 0).toString());
        textGoodsName.setText(model.getValueAt(i, 1).toString());
        textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/
                
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();
/*
            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/

        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();
/*
            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/

        }
    }//GEN-LAST:event_jTable3KeyTyped

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();
               
        textStocksID.setText(model.getValueAt(i, 0).toString());
        textSalesID.setText(model.getValueAt(i, 1).toString());
        textGoodsID.setText(model.getValueAt(i, 2).toString());
        textGoodsName.setText(model.getValueAt(i, 3).toString());
        textGoodsDescription.setText(model.getValueAt(i, 4).toString());
        textQuantityOrdered.setText(model.getValueAt(i, 5).toString());
        textTotalPayable.setText(model.getValueAt(i, 6).toString());
        textTotalAmountPaid.setText(model.getValueAt(i, 7).toString());
        textTotalChange.setText(model.getValueAt(i, 8).toString());
        textDate.setText(model.getValueAt(i, 9).toString());
        textTime.setText(model.getValueAt(i, 10).toString());
        

        
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();
       
            
            textStocksID.setText(model.getValueAt(i, 0).toString());
            textSalesID.setText(model.getValueAt(i, 1).toString());
            textGoodsID.setText(model.getValueAt(i, 2).toString());
            textGoodsName.setText(model.getValueAt(i, 3).toString());
            textGoodsDescription.setText(model.getValueAt(i, 4).toString());
            textQuantityOrdered.setText(model.getValueAt(i, 5).toString());
            textTotalPayable.setText(model.getValueAt(i, 6).toString());
            textTotalAmountPaid.setText(model.getValueAt(i, 7).toString());
            textTotalChange.setText(model.getValueAt(i, 8).toString());
            textDate.setText(model.getValueAt(i, 9).toString());
            textTime.setText(model.getValueAt(i, 10).toString());

        }

        
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textStocksID.setText(model.getValueAt(i, 0).toString());
            textSalesID.setText(model.getValueAt(i, 1).toString());
            textGoodsID.setText(model.getValueAt(i, 2).toString());
            textGoodsName.setText(model.getValueAt(i, 3).toString());
            textGoodsDescription.setText(model.getValueAt(i, 4).toString());
            textQuantityOrdered.setText(model.getValueAt(i, 5).toString());
            textTotalPayable.setText(model.getValueAt(i, 6).toString());
            textTotalAmountPaid.setText(model.getValueAt(i, 7).toString());
            textTotalChange.setText(model.getValueAt(i, 8).toString());
            textDate.setText(model.getValueAt(i, 9).toString());
            textTime.setText(model.getValueAt(i, 10).toString());

        }
    }//GEN-LAST:event_jTable2KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Record?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String salesid=textSalesID.getText().trim();
                int salesid2=Integer.parseInt(salesid);

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String amountpaid=textQuantityOrdered.getText().trim();
                double amountpaid2=Double.parseDouble(amountpaid);

                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String salesstatus="unsold";//textSalesStatus.getText().trim();

                String date=ft.format(dNow);//textDate.getText().trim();
                String time = ft2.format(dNow2);//textTime.getText().trim();

                if(salesid.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " Sorry, there is/are empty textboxes! ");
                }
               

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    
                    String sql="DELETE FROM  tbl_sales"
                    + " where salesid="+salesid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"A Record Has been Modified!");

                    Show_Sales_In_JTable();

                

            } catch (ClassNotFoundException | SQLException | NullPointerException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
            viewall=0;
            Show_Sales_In_JTable();
            viewall3=0;
            Show_GoodsAvailableFromStocks_In_JTable();
            
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Sales_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            textGoodsID.setText("");
            textGoodsName.setText("");
            textGoodsDescription.setText("");
            textSalesID.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");

            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));

            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");

                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String stocksid=textStocksID.getText().trim();
            int stocksid2=Integer.parseInt(stocksid);

            String quantityordered=textQuantityOrdered.getText().trim();
            int quantityordered2=Integer.parseInt(quantityordered);
            
            double totalpayable=0,totalpayment=0,change=0;
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft =
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 =
            new SimpleDateFormat (" hh:mm:ss ");

            String salesstatus="unsold";//textSalesStatus.getText().trim();

            String date=ft.format(dNow);//textDate.getText().trim();
            String time = ft2.format(dNow2);//textTime.getText().trim();

            if(stocksid.equals("")|| quantityordered.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " Sorry, there is/are empty textboxes! ");
            }
            else
            {
                stmt = con.createStatement( );
                String sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                rs = stmt.executeQuery(sql);

                int v=0;
                while(rs.next())
                {
                    if(stocksid2==rs.getInt("stocksid"))
                    {

                        v++;
                        break;
                    }
                }

                if(v!=1)
                {
                    viewall=0;
                    Show_Sales_In_JTable();
                    viewall3=0;
                    Show_GoodsAvailableFromStocks_In_JTable();
                    
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " Product does not exist! ");
                    return;
                }

                

                stmt = con.createStatement( );
                sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                rs = stmt.executeQuery(sql);

                v=0;
                int qty=0;
                double totalsales=0,due=0;
                while(rs.next())
                {
                    if(stocksid2==rs.getInt("stocksid"))
                    {

                        //totalsales=totalsales+rs.getDouble("totalamountpaid")+amountpaid2;
                        due=rs.getDouble("price");
                        qty=rs.getInt("quantity");
                        v++;
                        break;
                    }
                }
                
                if(quantityordered2>qty)
                {
                    quantityordered2=qty;
                }
                
                int stocksqty=qty-quantityordered2;

                

                int vv=0;
                totalpayable=due*quantityordered2;
                due=0;
                
                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_sales " + "VALUES (NULL,"+stocksid2+", "+quantityordered2+","
                        + ""+totalpayable+","+totalpayment+","+change+""
                        + "'"+salesstatus+"', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);
                
                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql="Update tbl_stocks"
                    + " SET quantity="+stocksqty+",date=CURDATE(),time=CURTIME()"
                    + " where stocksid="+stocksid2+"";

                stmt.executeUpdate(sql);

                

                

                

                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"A New Sales Item is Added!");
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

                Show_Sales_In_JTable();

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Sales_In_JTable();
        viewall3=0;
        Show_GoodsAvailableFromStocks_In_JTable();
        
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );
                
                String salesid=textSalesID.getText().trim();
                int salesid2=Integer.parseInt(salesid);
                
                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String quantityordered=textQuantityOrdered.getText().trim();
                int quantityordered2=Integer.parseInt(quantityordered);

                double totalpayable=0,totalpayment=0,change=0;


                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String salesstatus="unsold";//textSalesStatus.getText().trim();

                String date=ft.format(dNow);//textDate.getText().trim();
                String time = ft2.format(dNow2);//textTime.getText().trim();

                if(salesid.equals("")||stocksid.equals("")|| quantityordered.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " Sorry, there is/are empty textboxes! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_sales where stocksid="+salesid2+"";
                    rs = stmt.executeQuery(sql);
                    
                    int v1=0,cqty=0;
                    
                    while(rs.next())
                    {
                        if(salesid2==rs.getInt("salesid"))
                        {
                            cqty=rs.getInt("quantityordered");
                            v1++;
                            break;
                        }
                    }
                    
                    stmt = con.createStatement( );
                    sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                    rs = stmt.executeQuery(sql);

                    int v=0;
                    while(rs.next())
                    {
                        if(stocksid2==rs.getInt("stocksid"))
                        {

                            v++;
                            break;
                        }
                    }

                    if(v!=1||v1!=1)
                    {
                        viewall=0;
                        Show_Sales_In_JTable();
                        viewall3=0;
                        Show_GoodsAvailableFromStocks_In_JTable();

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " Product does not exist! ");
                        return;
                    }

                    

                    stmt = con.createStatement( );
                    sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                    rs = stmt.executeQuery(sql);

                    v=0;
                    int qty=0;
                    double totalsales=0,due=0;
                    while(rs.next())
                    {
                        if(stocksid2==rs.getInt("stocksid"))
                        {

                            //totalsales=totalsales+rs.getDouble("totalamountpaid")+amountpaid2;
                            due=rs.getDouble("price");
                            qty=rs.getInt("quantity");
                            v++;
                            break;
                        }
                    }
                    int stocksqty=0;
                    
                    int remqty=0;
                    
                    if(cqty<quantityordered2)
                    {
                        quantityordered2=cqty;
                    }
                    else
                    {
                        stocksqty=cqty-quantityordered2+qty;
                        
                    }

                    int vv=0;
                    totalpayable=due*quantityordered2;
                    due=0;

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql="Update tbl_sales"
                        + " SET quantityordered="+quantityordered2+""
                            + "totalpayable="+totalpayable+",date=CURDATE(),time=CURTIME()"
                        + " where salesid="+salesid2+"";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql="Update tbl_stocks"
                        + " SET quantity="+stocksqty+",date=CURDATE(),time=CURTIME()"
                        + " where stocksid="+stocksid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this,"A Record Has been Modified!");

                    Show_Sales_In_JTable();

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustSalesMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
            viewall=0;
            Show_Sales_In_JTable();
            viewall3=0;
            Show_GoodsAvailableFromStocks_In_JTable();
            

        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void textSearchGoodsFromStocksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textSearchGoodsFromStocksActionPerformed
        // TODO add your handling code here:
        viewall3=1;
        Show_GoodsAvailableFromStocks_In_JTable();
        
    }//GEN-LAST:event_textSearchGoodsFromStocksActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustSalesMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustSalesMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustSalesMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustSalesMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalesAndInventoryAugustSalesMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByGoodsname;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextArea textGoodsDescription;
    private javax.swing.JTextField textGoodsID;
    private javax.swing.JTextField textGoodsName;
    private javax.swing.JTextField textQuantityOrdered;
    private javax.swing.JTextField textSalesID;
    private javax.swing.JTextField textSalesStatus;
    private javax.swing.JButton textSearchGoodsFromStocks;
    private javax.swing.JTextField textStocksID;
    private javax.swing.JTextField textTime;
    private javax.swing.JTextField textTotalAmountPaid;
    private javax.swing.JTextField textTotalChange;
    private javax.swing.JTextField textTotalPayable;
    // End of variables declaration//GEN-END:variables
}
