/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustUserTable
{
 
    int userid;
    String username;
    String userpassword;
    
    
    public SalesAndInventoryAugustUserTable(int userid, String username, String userpassword)
    {
        
        this.userid=userid;
        this.username=username;
        this.userpassword=userpassword;
               
        
    }
    
    public int getUserID()
    {
        return userid;
    }
    
    public String getUserName()
    {
        return username;
    }
    
    public String getUserPassword()
    {
        return userpassword;
    }
    
    
    
    
}



