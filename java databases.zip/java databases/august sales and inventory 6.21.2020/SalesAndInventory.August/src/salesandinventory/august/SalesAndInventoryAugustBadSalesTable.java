/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;
import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustBadSalesTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int badsalesid;
    int salesid;
    
    int quantity;
   
    Date salesandinventorydate;
    Date salesandinventorytime;
    
    
    public SalesAndInventoryAugustBadSalesTable
    (    
    int badsalesid,
    int salesid, 
    int quantity,
   
    Date salesandinventorydate,
    Date salesandinventorytime 
    )
            
    {
        
       
        
        this.badsalesid=badsalesid;
        this.salesid=salesid; 
        this.quantity=quantity;
       
        this.salesandinventorydate=salesandinventorydate;
        this.salesandinventorytime=salesandinventorytime; 
               
        
    }
    
    public int getBadSalesID()
    {
        return badsalesid;
    }
    
    public int getSalesID()
    {
        return salesid;
    }
    public int getQuantity()
    {
        return quantity;
    }
        
    public Date getDateofStocks()
    {
        return salesandinventorydate;
    }
    
    public Date getTimeofStocks()
    {
        return salesandinventorytime;
    }
    
}
