/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustPaymentMaintenance extends javax.swing.JFrame {
    
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0,viewall3=0;
    String query;
    
    String username;
    String userid;
    String goodsname;
    String goodsid;

    /**
     * Creates new form SalesAndInventoryCristalSalesMaintenance
     */
    
    
    public SalesAndInventoryAugustPaymentMaintenance(String Userid, String Username) {
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_GoodsAvailableFromStocks_In_JTable();
       
        Show_Sales_In_JTable();
    }
    
    public SalesAndInventoryAugustPaymentMaintenance() {
        initComponents();
        
        DoConnect();
        Show_GoodsAvailableFromStocks_In_JTable();
        
        Show_Sales_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            /*
            String sql="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods";
            rs = stmt.executeQuery(sql);*/
            /*
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%t%'
            
            int salesid;
            int stocksid;
            int goodsid;
            String goodsname;
            String goodsdescription;
            int quantityordered;
            double totalpayable;
            double totalpayment;
            double totalchange;
            String salesstatus;
            Date dateofsales;
            Date timeofsales;
            
            */
            String sql="Select tbl_payment.paymentid,tbl_payment.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,"
                    + "tbl_payment.amountpaid,  "
                    + "tbl_payment.remarks,tbl_payment.date, tbl_payment.time from tbl_stocks,tbl_goods,tbl_sales,tbl_payment"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                    + "and tbl_payment.salesid=tbl_sales.salesid";
            rs = stmt.executeQuery(sql);
            
            /*
            int paymentid;
            int salesid;
            int stocksid;
            int goodsid;
            String goodsname;
            String goodsdescription;
            double amountpaid;
            double change;
            String remarks;
            Date dateofpayment;
            Date timeofpayment;
            */
            

            int rowCount=0;

            rs.next( ); 
            
            int paymentid = rs.getInt("paymentid");
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double amountpaid=rs.getDouble("amountpaid");
            
            String remarks=rs.getString("remarks");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);
            
            
                 
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    
    
    
    
    public ArrayList<SalesAndInventoryAugustPaymentInquiryTable> getGoodsList()
    {
        ArrayList<SalesAndInventoryAugustPaymentInquiryTable> goodsList= new ArrayList<SalesAndInventoryAugustPaymentInquiryTable>();
        Connection connection = getConnection();
        
        /*
            String sql="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods";
            rs = stmt.executeQuery(sql);*/
            /*
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0
            SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%t%'
            
            int salesid;
            int stocksid;
            int goodsid;
            String goodsname;
            String goodsdescription;
            int quantityordered;
            double totalpayable;
            double totalpayment;
            double totalchange;
            String salesstatus;
            Date dateofsales;
            Date timeofsales;
            
            */
       
        
        try
        {
            if(viewall3==0)
            {
                //query = "Select * from tbl_goods";
                query="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,tbl_sales.salesID"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods,tbl_sales"
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0";
            }
            else
            {
                goodsname=textGoodsName.getText();
                //query = "Select * from tbl_goods where goodsname like '%"+goodsname+"%'";
                query="SELECT tbl_goods.goodsname, tbl_goods.goodsdescription, tbl_stocks.stocksID,"
                        + ",tbl_sales.salesID,tbl_stocks.price,"
                        +"tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable FROM `tbl_stocks`, `tbl_goods` "
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0 and tbl_goods.goodsname LIKE '%"+goodsname+"%'";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs3=st.executeQuery(query);
            
            /*
            String goodsname;
            String goodsdescription;
            int stocksid;
            int salesid;
            double price;
            int quantity;
            double totalamountpayable;
            */
            
            SalesAndInventoryAugustPaymentInquiryTable goods1;
            
            while(rs3.next())
            {
                goods1 = new  SalesAndInventoryAugustPaymentInquiryTable(rs3.getString("goodsname"),
                             rs3.getString("goodsdescription"),rs3.getInt("stocksid"),rs3.getInt("salesid"), 
                             rs.getDouble("price"),rs.getInt("quantity"), rs.getDouble("totalpayable") );
                goodsList.add(goods1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return goodsList;
     
    }
    
    public void Show_GoodsAvailableFromStocks_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustPaymentInquiryTable> list = getGoodsList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[7];
        
       
            model.setRowCount(0);
        /*
            query="Select tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_stocks.stocksID,"
                    +"tbl_stocks.price,tbl_stocks.quantity, tbl_stocks.price*tbl_stocks.quantity AS TotalPayable from tbl_stocks,tbl_goods"
                        +"WHERE tbl_stocks.goodsid=tbl_goods.goodsid and tbl_stocks.quantity>0";
            */
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getGoodsName();
            row[1]=list.get(i).getGoodsDescription();
            row[2]=list.get(i).getStocksID();
            row[2]=list.get(i).getSalesID();
            row[3]=list.get(i).getPrice();
            row[4]=list.get(i).getQuantity();
            row[5]=list.get(i).getTotalAmountPayable();
            
            
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<SalesAndInventoryAugustPaymentTable> getPaymentList()
    {
        ArrayList<SalesAndInventoryAugustPaymentTable> paymentList= new ArrayList<SalesAndInventoryAugustPaymentTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                //query = "Select * from tbl_sales";
                query="Select tbl_payment.paymentid,tbl_payment.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,"
                    + "tbl_payment.amountpaid,  "
                    + "tbl_payment.remarks,tbl_payment.date, tbl_payment.time from tbl_stocks,tbl_goods,tbl_sales,tbl_payment"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                    + "and tbl_payment.salesid=tbl_sales.salesid";
                /*
                query="Select tbl_sales.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_sales.quantityordered,"
                    +"tbl_sales.totalpayable, tbl_sales.totalpayment, tbl_sales.totalchange"
                    +", tbl_sales.salessatus,tbl_sales.date, tbl_sales.time from tbl_stocks,tbl_goods,tbl_sales"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid";*/
            }
            else
            {
                goodsname=textGoodsName.getText();
                //int stocksid1=Integer.parseInt(goodsid);
                //query = "Select * from tbl_sales where stocksid = "+goodsid+"";
                /*
                int paymentid;
                int salesid;
                int stocksid;
                int goodsid;
                String goodsname;
                String goodsdescription;
                double amountpaid;

                String remarks;
                Date dateofpayment;
                Date timeofpayment;
                */
                query="Select tbl_payment.paymentid,tbl_payment.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,"
                    + "tbl_payment.amountpaid,  "
                    + "tbl_payment.remarks,tbl_payment.date, tbl_payment.time from tbl_stocks,tbl_goods,tbl_sales,tbl_payment"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                        + ""
                    + "and tbl_payment.salesid=tbl_sales.salesid"
                        + "and and tbl_goods.goodsname LIKE '%"+goodsname+"%'";
                /*
                query="Select tbl_sales.salesid, tbl_sales.stocksid, tbl_goods.goodsid, "
                    +"tbl_goods.goodsname, tbl_goods.goodsdescription,tbl_sales.quantityordered,"
                    +"tbl_sales.totalpayable, tbl_sales.totalpayment, tbl_sales.totalchange"
                    +", tbl_sales.salessatus,tbl_sales.date, tbl_sales.time from tbl_stocks,tbl_goods,tbl_sales"
                    +" where tbl_goods.goodsid=tbl_stocks.goodsid and tbl_stocks.stocksid=tbl_sales.stocksid"
                        + "and tbl_payment.salesid=tbl_sales.salesid"
                        + "and and tbl_goods.goodsname LIKE '%"+goodsname+"%'"
                        + "and and tbl_goods.goodsname LIKE '%"+goodsname+"%' ";*/
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           /*
                int paymentid;
                int salesid;
                int stocksid;
                int goodsid;
                String goodsname;
                String goodsdescription;
                double amountpaid;

                String remarks;
                Date dateofpayment;
                Date timeofpayment;
                */
            
            SalesAndInventoryAugustPaymentTable sales1;
            
            while(rs.next())
            {
                sales1 = new  SalesAndInventoryAugustPaymentTable(rs.getInt("paymentid"),rs.getInt("salesid"),rs.getInt("stocksid"),
                        rs.getInt("goodsid"),rs.getString("goodsname"),rs.getString("goodsdescription"),
                        rs.getDouble("amountpaid"),rs.getString("remarks"), rs.getDate("date"), rs.getTime("time"));
                paymentList.add(sales1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            
        }
        
        return paymentList;
     
    }
    
    public void Show_Sales_In_JTable()
    {
        ArrayList<SalesAndInventoryAugustPaymentTable> list = getPaymentList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[9];
        
       
            model.setRowCount(0);
        
        /*
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            int quantityordered=rs.getInt("quantityordered");
            double totalpayable=rs.getDouble("totalpayable");
            double totalpayment=rs.getDouble("totalpayment");
            double totalchange=rs.getDouble("totalchange");
            String salesstatus=rs.getString("salesstatus");
            */
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSalesID();
            row[1]=list.get(i).getStocksID();
            row[2]=list.get(i).getGoodsID();
            row[3]=list.get(i).getGoodsName();
            row[4]=list.get(i).getGoodsDescription();
            row[5]=list.get(i).getAmountPaid();
            row[6]=list.get(i).getRemarks();
            row[7]=list.get(i).getDateofPayment();
            row[8]=list.get(i).getTimeofPayment();
            
            
                        
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textStocksID = new javax.swing.JTextField();
        textTime = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textGoodsDescription = new javax.swing.JTextArea();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textGoodsName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByGoodsname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFanAdminWelcome = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        textDate = new javax.swing.JTextField();
        btnFirst = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        textSalesID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textAmountPaid = new javax.swing.JTextField();
        textGoodsID = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        textSearchGoodsFromStocks = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        textPaymentID = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        textRemarks = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        textGoodsDescription.setBackground(new java.awt.Color(51, 255, 255));
        textGoodsDescription.setColumns(20);
        textGoodsDescription.setRows(5);
        jScrollPane1.setViewportView(textGoodsDescription);

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Goods Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        textGoodsName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Goods ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Goods Name");

        btnSearchByGoodsname.setText("Search by Goods Name");
        btnSearchByGoodsname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByGoodsnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFanAdminWelcome.setText("Back to Fan Admin Welcome Form");
        btnFanAdminWelcome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFanAdminWelcomeActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Stocks ID");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText(" Date");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Sales ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Amount Paid");

        textGoodsID.setBackground(new java.awt.Color(51, 255, 255));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Goods Name", "Goods Description", "Stocks ID", "Sales ID", "Price", "Quantity from Sales", "Total Amount Payable"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable3KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable3KeyTyped(evt);
            }
        });
        jScrollPane7.setViewportView(jTable3);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Payment ID", "Sales ID", "Stocks ID", "Goods ID", "Goods Name", "Goods Description", "Amount Paid", "Change", "Remarks", "Date", "Time"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane8.setViewportView(jTable2);

        textSearchGoodsFromStocks.setText("Search Goods from Stocks");
        textSearchGoodsFromStocks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textSearchGoodsFromStocksActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Payment ID");

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Remarks");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textGoodsName)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textGoodsID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(btnSearchByGoodsname)
                                                .addGap(98, 98, 98)))))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(30, 30, 30)
                                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(textSalesID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(textRemarks, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                        .addComponent(textAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(3, 3, 3))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnPrevious)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnFanAdminWelcome))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textPaymentID, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(textSearchGoodsFromStocks)))
                        .addGap(0, 553, Short.MAX_VALUE))
                    .addComponent(jScrollPane8))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textGoodsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textGoodsName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSearchByGoodsname)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(15, 15, 15)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textSearchGoodsFromStocks)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textPaymentID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textSalesID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textStocksID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textAmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEdit)
                            .addComponent(btnDelete)
                            .addComponent(btnNewRecord))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSaveRecord)
                            .addComponent(btnCancelNewRecord)
                            .addComponent(btnClearAll)
                            .addComponent(btnFanAdminWelcome))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textRemarks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(15, 15, 15)))
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(208, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textGoodsID.setText("");
        textGoodsName.setText("");
        textGoodsDescription.setText("");
        textStocksID.setText("");
        textSalesID.setText("");
        textPaymentID.setText("");
        textAmountPaid.setText("");
        textDate.setText("");
        textTime.setText("");
                     
        
        textRemarks.setText("");
  
            
                    
    }//GEN-LAST:event_btnClearAllActionPerformed

    private void btnSearchByGoodsnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByGoodsnameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_GoodsAvailableFromStocks_In_JTable();
    }//GEN-LAST:event_btnSearchByGoodsnameActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {
                
            int paymentid = rs.getInt("paymentid");
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double amountpaid=rs.getDouble("amountpaid");
            
            String remarks=rs.getString("remarks");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_Sales_In_JTable();
        viewall3=0;
        Show_GoodsAvailableFromStocks_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    private void btnFanAdminWelcomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFanAdminWelcomeActionPerformed
        // TODO add your handling code here:

        new SalesAndInventoryAugustAdminWelcome(userid,username).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnFanAdminWelcomeActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {
                
                int paymentid = rs.getInt("paymentid");
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double amountpaid=rs.getDouble("amountpaid");
            
            String remarks=rs.getString("remarks");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();
            
            int paymentid = rs.getInt("paymentid");
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double amountpaid=rs.getDouble("amountpaid");
            
            String remarks=rs.getString("remarks");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();
              
            int paymentid = rs.getInt("paymentid");
            int salesid = rs.getInt("salesid");
            int stocksid = rs.getInt("stocksid");
            int goodsid=rs.getInt("goodsid");
            String goodsname=rs.getString("goodsname");
            String goodsdescription=rs.getString("goodsdescription");
            double amountpaid=rs.getDouble("amountpaid");
            
            String remarks=rs.getString("remarks");
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft = 
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 = 
            new SimpleDateFormat (" hh:mm:ss ");
            
            String date=ft.format(rs.getDate("date"));
            String time = ft.format(rs.getTime("time"));
            
            textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        int i=jTable3.getSelectedRow();
        TableModel model=jTable3.getModel();
/*
        textGoodsID.setText(model.getValueAt(i, 0).toString());
        textGoodsName.setText(model.getValueAt(i, 1).toString());
        textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/
                
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();
/*
            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/

        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable3KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();
/*
            textGoodsID.setText(model.getValueAt(i, 0).toString());
            textGoodsName.setText(model.getValueAt(i, 1).toString());
            textGoodsDescription.setText(model.getValueAt(i, 2).toString());*/

        }
    }//GEN-LAST:event_jTable3KeyTyped

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields
        int i=jTable2.getSelectedRow();
        TableModel model=jTable2.getModel();
               /*
        textStocksID.setText(Integer.toString(stocksid));
            textSalesID.setText(Integer.toString(salesid));
            textPaymentID.setText(Integer.toString(paymentid));
            textGoodsID.setText(Integer.toString(goodsid));
            textGoodsName.setText(goodsname);
            textGoodsDescription.setText(goodsdescription);
            textAmountPaid.setText(Double.toString(amountpaid));
            textChange.setText(Double.toString(change));
            textRemarks.setText(remarks);
           
            
            textDate.setText(date);
            textTime.setText(time);
        
        int paymentid;
    int salesid;
    int stocksid;
    int goodsid;
    String goodsname;
    String goodsdescription;
    double amountpaid;
    double change;
    String remarks;
    Date dateofpayment;
    Date timeofpayment;
        */
        textPaymentID.setText(model.getValueAt(i, 0).toString());
        textSalesID.setText(model.getValueAt(i, 1).toString());
        textStocksID.setText(model.getValueAt(i, 2).toString());
        textGoodsID.setText(model.getValueAt(i, 3).toString());
        textGoodsName.setText(model.getValueAt(i, 4).toString());
        textGoodsDescription.setText(model.getValueAt(i, 5).toString());
        textAmountPaid.setText(model.getValueAt(i, 6).toString());
        
        textRemarks.setText(model.getValueAt(i, 7).toString());
        textDate.setText(model.getValueAt(i, 8).toString());
        textTime.setText(model.getValueAt(i, 9).toString());
        

        
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();
       
            
            textPaymentID.setText(model.getValueAt(i, 0).toString());
            textSalesID.setText(model.getValueAt(i, 1).toString());
            textStocksID.setText(model.getValueAt(i, 2).toString());
            textGoodsID.setText(model.getValueAt(i, 3).toString());
            textGoodsName.setText(model.getValueAt(i, 4).toString());
            textGoodsDescription.setText(model.getValueAt(i, 5).toString());
            textAmountPaid.setText(model.getValueAt(i, 6).toString());

            textRemarks.setText(model.getValueAt(i, 7).toString());
            textDate.setText(model.getValueAt(i, 8).toString());
            textTime.setText(model.getValueAt(i, 9).toString());

        }

        
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textPaymentID.setText(model.getValueAt(i, 0).toString());
            textSalesID.setText(model.getValueAt(i, 1).toString());
            textStocksID.setText(model.getValueAt(i, 2).toString());
            textGoodsID.setText(model.getValueAt(i, 3).toString());
            textGoodsName.setText(model.getValueAt(i, 4).toString());
            textGoodsDescription.setText(model.getValueAt(i, 5).toString());
            textAmountPaid.setText(model.getValueAt(i, 6).toString());

            textRemarks.setText(model.getValueAt(i, 7).toString());
            textDate.setText(model.getValueAt(i, 8).toString());
            textTime.setText(model.getValueAt(i, 9).toString());

        }
    }//GEN-LAST:event_jTable2KeyTyped

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Record?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );
                
                String paymentid=textPaymentID.getText().trim();
                int paymentid2=Integer.parseInt(paymentid);
                
                String salesid=textSalesID.getText().trim();
                int salesid2=Integer.parseInt(salesid);

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String amountpaid=textAmountPaid.getText().trim();
                double amountpaid2=Integer.parseInt(amountpaid);

                double totalpayable=0,totalpayment=0,change=0;


                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String remarks="";//textSalesStatus.getText().trim();

                String date=ft.format(dNow);//textDate.getText().trim();
                String time = ft2.format(dNow2);//textTime.getText().trim();

                if(paymentid.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Sorry, there is/are empty textboxes! ");
                }
                else
                {
                    int v=0,v1=0;
                    
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_payment where paymentid="+paymentid2+"";
                    rs = stmt.executeQuery(sql);
                    
                    
                    
                    stmt = con.createStatement( );
                    sql="Select * from tbl_sales where salessid="+salesid2+"";
                    rs = stmt.executeQuery(sql);

                    
                    int qty=0;
                    while(rs.next())
                    {
                        if(salesid2==rs.getInt("salesid"))
                        {
                            stocksid2=rs.getInt("stocksid");
                            qty=rs.getInt("quantityordered");
                            v++;
                            break;
                        }
                    }

                    if(v!=1||v1!=1)
                    {
                        viewall=0;
                        Show_Sales_In_JTable();
                        viewall3=0;
                        Show_GoodsAvailableFromStocks_In_JTable();

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product does not exist! ");
                        return;
                    }



                    stmt = con.createStatement( );
                    sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                    rs = stmt.executeQuery(sql);

                    v=0;

                    double totalsales=0,due=0;
                    while(rs.next())
                    {
                        if(stocksid2==rs.getInt("stocksid"))
                        {

                            //totalsales=totalsales+rs.getDouble("totalamountpaid")+amountpaid2;
                            due=rs.getDouble("price");
                            //qty=rs.getInt("quantity");
                            v++;
                            break;
                        }
                    }

                    double totalpayable1=due*qty;
                    double amountalreadypaid=0;
                    stmt = con.createStatement( );
                    sql="Select * from tbl_payment where salessid="+salesid2+"";
                    rs = stmt.executeQuery(sql);
                    while(rs.next())
                    {
                        amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                    }

                    if(amountalreadypaid>=totalpayable1)
                    {
                        viewall=0;
                        Show_Sales_In_JTable();
                        viewall3=0;
                        Show_GoodsAvailableFromStocks_In_JTable();

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product already sold! ");
                        return;

                    }
                    else
                    {
                        

                        
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        //String salesstatus="sold";
                        sql="Delete from tbl_payment"
                           + " where paymentid="+paymentid2+"";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( );
                        sql="Select * from tbl_payment where salessid="+salesid2+"";
                        rs = stmt.executeQuery(sql);
                        amountalreadypaid=0;
                        
                        while(rs.next())
                        {
                            amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                        }

                        if(amountalreadypaid>=totalpayable1 && amountalreadypaid>0)
                        {


                            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                            String salesstatus="sold";
                            sql="Update tbl_sales"
                                + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                                + " where salesid="+salesid2+"";

                            stmt.executeUpdate(sql);
                        }
                        else
                        {

                            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                            String salesstatus="partially sold";
                            sql="Update tbl_sales"
                                + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                                + " where salesid="+salesid2+"";

                            stmt.executeUpdate(sql);

                        }

                    }

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"A Payment is Modified!");
                    
                    Show_Sales_In_JTable();

                }

                

            } catch (ClassNotFoundException | SQLException | NullPointerException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
            viewall=0;
            Show_Sales_In_JTable();
            viewall3=0;
            Show_GoodsAvailableFromStocks_In_JTable();
            
        }
        else
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_Sales_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            textGoodsID.setText("");
            textGoodsName.setText("");
            textGoodsDescription.setText("");
            textPaymentID.setText("");

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        /*
        textUsername.setText("");
        textpassPassword.setText("");
        textpassVerifyPassword.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textAddress.setText("");
        textJobTitle.setText("");
        textEmail.setText("");
        textDateOfBirth.setText("");
        textHobby.setText("");*/

        try {
            rs.absolute( curRow );

            int id_col2 = rs.getInt("goodsid");

            String goodsname2 = rs.getString("goodsname");

            String goodsdescription2 = rs.getString("goodsdescription");

            textGoodsID.setText(Integer.toString(id_col2));

            textGoodsName.setText(goodsname2);
            textGoodsDescription.setText(goodsdescription2);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int id_col2 = rs.getInt("goodsid");

                String goodsname2 = rs.getString("goodsname");

                String goodsdescription2 = rs.getString("goodsdescription");

                textGoodsID.setText(Integer.toString(id_col2));
                textGoodsName.setText(goodsname2);
                textGoodsDescription.setText(goodsname2);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            String salesid=textSalesID.getText().trim();
            int salesid2=Integer.parseInt(salesid);

            String stocksid=textStocksID.getText().trim();
            int stocksid2=Integer.parseInt(stocksid);

            String amountpaid=textAmountPaid.getText().trim();
            double amountpaid2=Integer.parseInt(amountpaid);
            
            double totalpayable=0,totalpayment=0,change=0;
            
            
            //current date
            Date dNow = new Date( );
            SimpleDateFormat ft =
            new SimpleDateFormat (" yyyy.MM.dd " ) ;

            //current time
            Date dNow2 = new Date( );
            SimpleDateFormat ft2 =
            new SimpleDateFormat (" hh:mm:ss ");

            String remarks="";//textSalesStatus.getText().trim();

            String date=ft.format(dNow);//textDate.getText().trim();
            String time = ft2.format(dNow2);//textTime.getText().trim();

            if(salesid.equals("")|| amountpaid.equals(""))
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Sorry, there is/are empty textboxes! ");
            }
            else
            {
                stmt = con.createStatement( );
                String sql="Select * from tbl_sales where salessid="+salesid2+"";
                rs = stmt.executeQuery(sql);

                int v=0;
                int qty=0;
                while(rs.next())
                {
                    if(salesid2==rs.getInt("salesid"))
                    {
                        stocksid2=rs.getInt("stocksid");
                        qty=rs.getInt("quantityordered");
                        v++;
                        break;
                    }
                }

                if(v!=1)
                {
                    viewall=0;
                    Show_Sales_In_JTable();
                    viewall3=0;
                    Show_GoodsAvailableFromStocks_In_JTable();
                    
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product does not exist! ");
                    return;
                }

                

                stmt = con.createStatement( );
                sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                rs = stmt.executeQuery(sql);

                v=0;
                
                double totalsales=0,due=0;
                while(rs.next())
                {
                    if(stocksid2==rs.getInt("stocksid"))
                    {

                        //totalsales=totalsales+rs.getDouble("totalamountpaid")+amountpaid2;
                        due=rs.getDouble("price");
                        //qty=rs.getInt("quantity");
                        v++;
                        break;
                    }
                }
                
                double totalpayable1=due*qty;
                double amountalreadypaid=0;
                stmt = con.createStatement( );
                sql="Select * from tbl_payment where salessid="+salesid2+"";
                rs = stmt.executeQuery(sql);
                while(rs.next())
                {
                    amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                }
                
                if(amountalreadypaid>=totalpayable1)
                {
                    viewall=0;
                    Show_Sales_In_JTable();
                    viewall3=0;
                    Show_GoodsAvailableFromStocks_In_JTable();
                    
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product already sold! ");
                    return;
                
                }
                else
                {
                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_payment " + "VALUES (NULL,"+salesid2+", "+amountpaid2+","
                            + "'"+remarks+"', CURDATE(), CURTIME())";

                    stmt.executeUpdate(sql);
                    
                    stmt = con.createStatement( );
                    sql="Select * from tbl_payment where salessid="+salesid2+"";
                    rs = stmt.executeQuery(sql);
                    amountalreadypaid=0;
                    while(rs.next())
                    {
                        amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                    }
                    
                    if(amountalreadypaid>=totalpayable1 && amountalreadypaid>0)
                    {
                    
                    
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        String salesstatus="sold";
                        sql="Update tbl_sales"
                            + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                            + " where salesid="+salesid2+"";

                        stmt.executeUpdate(sql);
                    }
                    else
                    {
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        String salesstatus="partially sold";
                        sql="Update tbl_sales"
                            + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                            + " where salesid="+salesid2+"";

                        stmt.executeUpdate(sql);
                    
                    }
                
                }

                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"A New Payment is Added!");
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

                Show_Sales_In_JTable();

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        Show_Sales_In_JTable();
        viewall3=0;
        Show_GoodsAvailableFromStocks_In_JTable();
        
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/augustsalesandinventory";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );
                
                String paymentid=textPaymentID.getText().trim();
                int paymentid2=Integer.parseInt(paymentid);
                
                String salesid=textSalesID.getText().trim();
                int salesid2=Integer.parseInt(salesid);

                String stocksid=textStocksID.getText().trim();
                int stocksid2=Integer.parseInt(stocksid);

                String amountpaid=textAmountPaid.getText().trim();
                double amountpaid2=Integer.parseInt(amountpaid);

                double totalpayable=0,totalpayment=0,change=0;


                //current date
                Date dNow = new Date( );
                SimpleDateFormat ft =
                new SimpleDateFormat (" yyyy.MM.dd " ) ;

                //current time
                Date dNow2 = new Date( );
                SimpleDateFormat ft2 =
                new SimpleDateFormat (" hh:mm:ss ");

                String remarks="";//textSalesStatus.getText().trim();

                String date=ft.format(dNow);//textDate.getText().trim();
                String time = ft2.format(dNow2);//textTime.getText().trim();

                if(salesid.equals("")|| amountpaid.equals("")||paymentid.equals(""))
                {
                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Sorry, there is/are empty textboxes! ");
                }
                else
                {
                    int v=0,v1=0;
                    
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_payment where paymentid="+paymentid2+"";
                    rs = stmt.executeQuery(sql);
                    
                    
                    
                    stmt = con.createStatement( );
                    sql="Select * from tbl_sales where salessid="+salesid2+"";
                    rs = stmt.executeQuery(sql);

                    
                    int qty=0;
                    while(rs.next())
                    {
                        if(salesid2==rs.getInt("salesid"))
                        {
                            stocksid2=rs.getInt("stocksid");
                            qty=rs.getInt("quantityordered");
                            v++;
                            break;
                        }
                    }

                    if(v!=1||v1!=1)
                    {
                        viewall=0;
                        Show_Sales_In_JTable();
                        viewall3=0;
                        Show_GoodsAvailableFromStocks_In_JTable();

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product does not exist! ");
                        return;
                    }



                    stmt = con.createStatement( );
                    sql="Select * from tbl_stocks where stocksid="+stocksid2+"";
                    rs = stmt.executeQuery(sql);

                    v=0;

                    double totalsales=0,due=0;
                    while(rs.next())
                    {
                        if(stocksid2==rs.getInt("stocksid"))
                        {

                            //totalsales=totalsales+rs.getDouble("totalamountpaid")+amountpaid2;
                            due=rs.getDouble("price");
                            //qty=rs.getInt("quantity");
                            v++;
                            break;
                        }
                    }

                    double totalpayable1=due*qty;
                    double amountalreadypaid=0;
                    stmt = con.createStatement( );
                    sql="Select * from tbl_payment where salessid="+salesid2+"";
                    rs = stmt.executeQuery(sql);
                    while(rs.next())
                    {
                        amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                    }

                    if(amountalreadypaid>=totalpayable1)
                    {
                        viewall=0;
                        Show_Sales_In_JTable();
                        viewall3=0;
                        Show_GoodsAvailableFromStocks_In_JTable();

                        JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " Product already sold! ");
                        return;

                    }
                    else
                    {
                        

                        
                        
                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        //String salesstatus="sold";
                        sql="Update tbl_payment"
                            + " SET  salesid="+salesid2+",amountpaid="+amountpaid2+",date=CURDATE(),time=CURTIME()"
                            + " where paymentid="+paymentid2+"";

                        stmt.executeUpdate(sql);
                        
                        stmt = con.createStatement( );
                        sql="Select * from tbl_payment where salessid="+salesid2+"";
                        rs = stmt.executeQuery(sql);
                        amountalreadypaid=0;
                        
                        while(rs.next())
                        {
                            amountalreadypaid=amountalreadypaid+rs.getDouble("amountpaid");
                        }

                        if(amountalreadypaid>=totalpayable1 && amountalreadypaid>0)
                        {


                            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                            String salesstatus="sold";
                            sql="Update tbl_sales"
                                + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                                + " where salesid="+salesid2+"";

                            stmt.executeUpdate(sql);
                        }
                        else
                        {

                            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                            String salesstatus="partially sold";
                            sql="Update tbl_sales"
                                + " SET salesstatus='"+salesstatus+"',date=CURDATE(),time=CURTIME()"
                                + " where salesid="+salesid2+"";

                            stmt.executeUpdate(sql);

                        }

                    }

                    JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this,"A Payment is Modified!");
                    
                    Show_Sales_In_JTable();

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException ex)
            {
                JOptionPane.showMessageDialog(SalesAndInventoryAugustPaymentMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
            viewall=0;
            Show_Sales_In_JTable();
            viewall3=0;
            Show_GoodsAvailableFromStocks_In_JTable();
            

        }
    }//GEN-LAST:event_btnEditActionPerformed

    private void textSearchGoodsFromStocksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textSearchGoodsFromStocksActionPerformed
        // TODO add your handling code here:
        viewall3=1;
        Show_GoodsAvailableFromStocks_In_JTable();
        
    }//GEN-LAST:event_textSearchGoodsFromStocksActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustPaymentMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustPaymentMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustPaymentMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalesAndInventoryAugustPaymentMaintenance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalesAndInventoryAugustPaymentMaintenance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFanAdminWelcome;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByGoodsname;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField textAmountPaid;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextArea textGoodsDescription;
    private javax.swing.JTextField textGoodsID;
    private javax.swing.JTextField textGoodsName;
    private javax.swing.JTextField textPaymentID;
    private javax.swing.JTextField textRemarks;
    private javax.swing.JTextField textSalesID;
    private javax.swing.JButton textSearchGoodsFromStocks;
    private javax.swing.JTextField textStocksID;
    private javax.swing.JTextField textTime;
    // End of variables declaration//GEN-END:variables
}
