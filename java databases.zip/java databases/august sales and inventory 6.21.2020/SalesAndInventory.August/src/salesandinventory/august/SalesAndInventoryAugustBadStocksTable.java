/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory.august;

/**
 *
 * @author crazymix69
 */
public class SalesAndInventoryAugustBadStocksTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int badstocksid;
    int stocksid;
    int quantity;
   
    String salesandinventorydate;
    String salesandinventorytime;
    
    
    public SalesAndInventoryAugustBadStocksTable
    (    
    int stocktrailid,
    int stocksid, 
    int quantity,
   
    String salesandinventorydate,
    String salesandinventorytime 
    )
            
    {
        
       
        
        this.badstocksid=badstocksid;
        this.stocksid=stocksid; 
        this.quantity=quantity;
       
        this.salesandinventorydate=salesandinventorydate;
        this.salesandinventorytime=salesandinventorytime; 
               
        
    }
    
    public int getBadStocksID()
    {
        return badstocksid;
    }
    
    public int getStocksID()
    {
        return stocksid;
    }
    public int getQuantity()
    {
        return quantity;
    }
        
    public String getDateofStocks()
    {
        return salesandinventorydate;
    }
    
    public String getTimeofStocks()
    {
        return salesandinventorytime;
    }
    
}
