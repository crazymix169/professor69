/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class CableSalesInformationSystemAreaMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
  
    
    
    
    // tbl_area fieldvarialbes
    private static final String TBL_AREA_AREAID = "areaid";  // Compliant
    private static final String TBL_AREA_CITY = "city";  // Compliant
    private static final String TBL_AREA_DISTRICT = "district";  // Compliant
    private static final String TBL_AREA_BARANGAY = "barangay";  // Compliant
    private static final String TBL_AREA_COMMENTS = "comments";  // Compliant
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public CableSalesInformationSystemAreaMaintenance() {
        super("Area Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Area_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            jCheckBoxExactSearch.setSelected(true);
            // TODO add your handling code here:

            String xx="org.gjt.mm.mysql.Driver";
            Class.forName(xx);
            String host;            
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="SELECT * FROM `tbl_area`";
                        
            //sql="SELECT * FROM `tbl_area`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();                         
               
                textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs.getString(TBL_AREA_CITY));
                textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs.getString(TBL_AREA_COMMENTS));
         
            }           
            
            viewall=0;           
            
            Show_Area_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
        
        
        
    }
    
    public ArrayList<CableSalesInformationSystemAreaTable> getAreaList()
    {
        ArrayList<CableSalesInformationSystemAreaTable> areaList= new ArrayList<CableSalesInformationSystemAreaTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_area`";
            }
            else if(viewall==1)
            {
                
                
                String city=textCity.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city like '%"+city+"%' ";
                 
                 if(jCheckBoxExactSearch.isSelected())
                 {
                     query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city = '"+city+"' ";
                 
                 }
            
                
            }
            else if(viewall==4)
            {
                
                
                String district=textDistrict.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" district like '%"+district+"%' ";
                 
                 if(jCheckBoxExactSearch.isSelected())
                 {
                     query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city = '"+district+"' ";
                 
                 }
            
                
            }
            else if(viewall==5)
            {
                
                String barangay=textBarangay.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" barangay like '%"+barangay+"%' ";
                 
                if(jCheckBoxExactSearch.isSelected())
                 {
                     query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city = '"+barangay+"' ";
                 
                 }
                
            
                
            }
            else if(viewall==6)
            {
                
                String comments=textComments.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" comments like '%"+comments+"%' ";
                 
                 if(jCheckBoxExactSearch.isSelected())
                 {
                     query ="SELECT * FROM `tbl_area` WHERE "                       
                        +" city = '"+comments+"' ";
                 
                 }
                
                
            
                
            }
            
            else if(viewall==3) 
            {
                
                               
                
                String areaid=textAreaID.getText().trim();
                int areaid1=Integer.parseInt(areaid);
                
                query ="SELECT * FROM `tbl_area` WHERE areaid = "+areaid1+"";
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemAreaTable area;
           
            while(rs.next())
            {
                area = new  CableSalesInformationSystemAreaTable(
                        rs.getInt(TBL_AREA_AREAID),
                        rs.getString(TBL_AREA_CITY),rs.getString(TBL_AREA_DISTRICT),
                        rs.getString(TBL_AREA_BARANGAY),
                        rs.getString(TBL_AREA_COMMENTS)
                       
                );
                areaList.add(area);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " error269: "+e.getMessage());
        }
        
        return areaList;
     
    }
    
    public void Show_Area_In_JTable()
    {
        ArrayList<CableSalesInformationSystemAreaTable> list = getAreaList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[5];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getAreaID();
            row[1]=list.get(i).getCity();
            row[2]=list.get(i).getDistrict();
            row[3]=list.get(i).getBarangay();
            row[4]=list.get(i).getComments();
            
                       
            
            
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btnSearchByCity = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        textComments = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByComments = new javax.swing.JButton();
        btnSearchByAreaID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textAreaID = new javax.swing.JTextField();
        textCity = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textDistrict = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textBarangay = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        btnSearchByDistrict = new javax.swing.JButton();
        btnSearchByBarangay = new javax.swing.JButton();
        btnSearchBySpecificCity = new javax.swing.JButton();
        jCheckBoxExactSearch = new javax.swing.JCheckBox();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Area ID", "City", "District", "Barangay", "Comments"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Comments");

        btnSearchByCity.setText("Search by City");
        btnSearchByCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByCityActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        textComments.setBackground(new java.awt.Color(51, 255, 255));
        textComments.setColumns(20);
        textComments.setRows(5);
        jScrollPane1.setViewportView(textComments);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByComments.setText("Search by Comments");
        btnSearchByComments.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByCommentsActionPerformed(evt);
            }
        });

        btnSearchByAreaID.setText("Search by Area ID ");
        btnSearchByAreaID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByAreaIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Area ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("District");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Barangay");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("City");

        btnSearchByDistrict.setText("Search by District");
        btnSearchByDistrict.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByDistrictActionPerformed(evt);
            }
        });

        btnSearchByBarangay.setText("Search by Barangay");
        btnSearchByBarangay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByBarangayActionPerformed(evt);
            }
        });

        btnSearchBySpecificCity.setText("Search by Specific City");
        btnSearchBySpecificCity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchBySpecificCityActionPerformed(evt);
            }
        });

        jCheckBoxExactSearch.setText("Exact Search");
        jCheckBoxExactSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxExactSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(435, 435, 435)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnPrevious)
                                        .addGap(25, 25, 25)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnDelete)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchByAreaID))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textDistrict, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(textBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(4, 4, 4))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(6, 6, 6)
                                    .addComponent(textCity, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(106, 106, 106)
                                    .addComponent(btnSearchByComments)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnSearchByCity)
                                    .addComponent(btnSearchByBarangay, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByDistrict))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnSearchBySpecificCity, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(93, 93, 93)
                                .addComponent(jCheckBoxExactSearch)))))
                .addContainerGap(350, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByAreaID))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(textAreaID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByCity)
                    .addComponent(btnSearchByDistrict)
                    .addComponent(jCheckBoxExactSearch))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByBarangay)
                    .addComponent(btnSearchBySpecificCity))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(btnSearchByComments))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel21)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textDistrict, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(textBarangay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textAreaID.setText(model.getValueAt(i, 0).toString());
        textCity.setText(model.getValueAt(i, 1).toString());
        textDistrict.setText(model.getValueAt(i, 2).toString());
        textBarangay.setText(model.getValueAt(i, 3).toString());
        textComments.setText(model.getValueAt(i, 4).toString());
        
               
        
               
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textAreaID.setText(model.getValueAt(i, 0).toString());
            textCity.setText(model.getValueAt(i, 1).toString());
            textDistrict.setText(model.getValueAt(i, 2).toString());
            textBarangay.setText(model.getValueAt(i, 3).toString());
            textComments.setText(model.getValueAt(i, 4).toString());
            
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String areaid=textAreaID.getText().trim();
                int areaid2=Integer.parseInt(areaid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_area` where areaid="+areaid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_area"
                    + " where areaid="+areaid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String areaid = textAreaID.getText().trim();
                int areaid2=Integer.parseInt(areaid);
                String city=textCity.getText().trim();
                String district=textDistrict.getText().trim();
                String barangay=textBarangay.getText().trim();
                String comments=textComments.getText().trim();
              
                if(areaid.equals("")||city.equals("")
                   || district.equals("")|| barangay.equals("")|| comments.equals(""))
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_area` where "
                            + "areaid="+areaid+"  "
                        + "and comments='"+comments+"' and city='"+city+"' "
                        + "and district='"+district+"' and barangay='"+barangay+"')";
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        sql="UPDATE `tbl_area` "
                                + "SET "
                                + "`comments`='"+comments+"',"
                                + "`city`='"+city+"',"
                                + "`district`='"+district+"',`barangay`='"+barangay+"'"
                                + ""
                                + ""
                                + " WHERE `areaid`="+areaid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_area` where "
                            + "areaid="+areaid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            
                            rowCount++;
                            if(rowCount==1)
                            {
                                textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                                textCity.setText(rs.getString(TBL_AREA_CITY));
                                textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                                textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                                textComments.setText(rs.getString(TBL_AREA_COMMENTS));                                                          
                                
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            
            String city=textCity.getText().trim();
            String district=textDistrict.getText().trim();
            String barangay=textBarangay.getText().trim();
            String comments=textComments.getText().trim();
           
            
            
            
                   
            

           if(city.equals("")|| comments.equals("")
                  
                   || district.equals("")|| barangay.equals(""))
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_area` where  "
                        + " comments='"+comments+"' and city='"+city+"' "
                        + "and district='"+district+"' and barangay='"+barangay+"'";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="INSERT INTO `tbl_area`(`areaid`,`city`, `district`, `barangay`,"
                            + " `comments`"
                            + ") "
                            + "VALUES (NULL,'"+city+"','"+district+"','"+barangay+"','"+comments+"'"
                            + ")";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_area`";
                    rs = stmt.executeQuery(sql);

                    

                    rs.last();

                    textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                    textCity.setText(rs.getString(TBL_AREA_CITY));
                    textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                    textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                    textComments.setText(rs.getString(TBL_AREA_COMMENTS));
                                
                    
                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " new inserted record item: "+textAreaID.getText());

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_Area_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textAreaID.setText("");
            textCity.setText("");
            textDistrict.setText("");
            textBarangay.setText("");
            textComments.setText("");
            textComments.setText("");
                      
          
            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,err.getMessage());
            
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
            textCity.setText(rs.getString(TBL_AREA_CITY));
            textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
            textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
            textComments.setText(rs.getString(TBL_AREA_COMMENTS));
           
            
             
            
            
              
            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,err.getMessage());
            

            try
            {
                rs.first();

                textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs.getString(TBL_AREA_CITY));
                textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs.getString(TBL_AREA_COMMENTS));
                  

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textAreaID.setText("");
                textCity.setText("");
                textDistrict.setText("");
                textBarangay.setText("");
                textComments.setText("");
                   
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handlitextPositionhere:
        textAreaID.setText("");
        textCity.setText("");
        textDistrict.setText("");
        textBarangay.setText("");
        textComments.setText("");
              

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search area city
    private void btnSearchByCityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByCityActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Area_In_JTable();
        jCheckBoxExactSearch.setSelected(!true);
    }//GEN-LAST:event_btnSearchByCityActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs.getString(TBL_AREA_CITY));
                textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs.getString(TBL_AREA_COMMENTS));
           

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
            textCity.setText(rs.getString(TBL_AREA_CITY));
            textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
            textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
            textComments.setText(rs.getString(TBL_AREA_COMMENTS));
       
          

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
                textCity.setText(rs.getString(TBL_AREA_CITY));
                textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
                textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
                textComments.setText(rs.getString(TBL_AREA_COMMENTS));
           

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            textAreaID.setText(Integer.toString(rs.getInt(TBL_AREA_AREAID)));
            textCity.setText(rs.getString(TBL_AREA_CITY));
            textDistrict.setText(rs.getString(TBL_AREA_DISTRICT));
            textBarangay.setText(rs.getString(TBL_AREA_BARANGAY));
            textComments.setText(rs.getString(TBL_AREA_COMMENTS));
           

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemAreaMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search role or legal person type
    private void btnSearchByCommentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByCommentsActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Area_In_JTable();
        
    }//GEN-LAST:event_btnSearchByCommentsActionPerformed

    //search Legal Person ID
    private void btnSearchByAreaIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByAreaIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByAreaIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Area_In_JTable();
    }//GEN-LAST:event_btnSearchByAreaIDActionPerformed

    private void btnSearchByDistrictActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByDistrictActionPerformed
    {//GEN-HEADEREND:event_btnSearchByDistrictActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchByDistrictActionPerformed

    private void btnSearchByBarangayActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByBarangayActionPerformed
    {//GEN-HEADEREND:event_btnSearchByBarangayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchByBarangayActionPerformed

    private void btnSearchBySpecificCityActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySpecificCityActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySpecificCityActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_Area_In_JTable();
        jCheckBoxExactSearch.setSelected(true);
    }//GEN-LAST:event_btnSearchBySpecificCityActionPerformed

    private void jCheckBoxExactSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxExactSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxExactSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByAreaID;
    private javax.swing.JButton btnSearchByBarangay;
    private javax.swing.JButton btnSearchByCity;
    private javax.swing.JButton btnSearchByComments;
    private javax.swing.JButton btnSearchByDistrict;
    private javax.swing.JButton btnSearchBySpecificCity;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JCheckBox jCheckBoxExactSearch;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textAreaID;
    private javax.swing.JTextField textBarangay;
    private javax.swing.JTextField textCity;
    private javax.swing.JTextArea textComments;
    private javax.swing.JTextField textDistrict;
    // End of variables declaration//GEN-END:variables
}
