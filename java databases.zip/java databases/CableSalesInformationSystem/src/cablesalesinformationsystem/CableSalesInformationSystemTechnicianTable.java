/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemTechnicianTable {

    /**
     * @param args the command line arguments
     */
      
    /**
     * @param args the command line arguments
     */
      
    int technicianid;
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    String role;        
    String sex;
    String birthdate;               
    String address;
    String hobby;       
    String skills;
    String educationalattainment;
    
    public CableSalesInformationSystemTechnicianTable
    (            
        int technicianid,
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String role,        
        String sex,
        String birthdate,               
        String address,
        String hobby,
        String skills,
        String educationalattainment
    )
            
    {
        this.technicianid=technicianid;   
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;        
        this.suffix=suffix;
        this.role=role;
        this.sex=sex;
        this.birthdate=birthdate;     
        this.address=address;
        this.hobby=hobby; 
        this.skills=skills;      
        this.educationalattainment=educationalattainment;      
              
    }
    
    public int getTechnicianID()
    {
        return technicianid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }     
    
    public String getSex()
    {
        return sex;
    }
    public String getBirthDate()
    {
        return birthdate;
    }    
    
    public String getAddress()
    {
        return address;
    }
    public String getHobby()
    {
        return hobby;
    }   
    public String getSkills()
    {
        return skills;
    }
    public String getEducationalAttainment()
    {
        return educationalattainment;
    }
}
