/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int salesid;
    int cashierid;
    int customerid;
    double totalamountpayable;
    double totalamountpaid;
    double totalchange;
   
    
       
    
    public CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable
    (            
        int salesid,
        int cashierid,
        int customerid,
        double totalamountpayable,
        double totalamountpaid,
        double totalchange
        
        
    )
            
    {
        this.salesid=salesid;        
        this.cashierid=cashierid;
        this.customerid=customerid;
        this.totalamountpayable=totalamountpayable;
        this.totalamountpaid=totalamountpaid;        
        this.totalchange=totalchange;
        
               
    }
    
    public int getSalesID()
    {
        return salesid;
    }
    
    public int getCashierID()
    {
        return cashierid;
    }
    
    public int getCustomerID()
    {
        return customerid;
    }
    public double getTotalAmountPayable()
    {
        return totalamountpayable;
    }
    public double getTotalAmountPaid()
    {
        return totalamountpaid;
    }    
    public double getTotalChange()
    {
        return totalchange;
    }
  
      
}
