/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int customerid;
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    String role;        
    
    
    
    public CableSalesInformationSystemInvoiceMaintenanceCustomerInquiryTable
    (            
        int customerid,
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String role        
        
    )
            
    {
        this.customerid=customerid;   
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;        
        this.suffix=suffix;
        this.role=role;
        
              
    }
    
    public int getCustomerID()
    {
        return customerid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }     
    
    
}
