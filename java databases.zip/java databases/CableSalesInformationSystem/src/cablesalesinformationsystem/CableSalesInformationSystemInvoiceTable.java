/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemInvoiceTable {

    /**
     * @param args the command line arguments
     */
      
    int invoiceid;
    int customerid;
    int subscriptionid;
    int areaid;
    int leadtechnicianid;
    String secondarytechnicians;        
    
    
    public CableSalesInformationSystemInvoiceTable
    (            
        int invoiceid,
        int customerid,
        int subscriptionid,
        int areaid,
        int leadtechnicianid,
        String secondarytechnicians       
       
    )
            
    {
        this.invoiceid=invoiceid;   
        this.customerid=customerid;
        this.subscriptionid=subscriptionid;
        this.areaid=areaid;        
        this.leadtechnicianid=leadtechnicianid;
        this.secondarytechnicians=secondarytechnicians;
             
              
    }
    
    public int getInvoiceID()
    {
        return invoiceid;
    }
    
    public int getCustomerID()
    {
        return customerid;
    }
    public int getSubscriptionID()
    {
        return subscriptionid;
    }
    public int getAreaID()
    {
        return areaid;
    }
    
    public int getLeadTechnicianID()
    {
        return leadtechnicianid;
    }
    public String getSecondaryTechnicians()
    {
        return secondarytechnicians;
    }     
    
    
}
