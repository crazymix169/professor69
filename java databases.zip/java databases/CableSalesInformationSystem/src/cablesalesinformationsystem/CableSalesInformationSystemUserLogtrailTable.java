/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;





/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemUserLogtrailTable
{
 
    int logtrailid;
    int userid;
    String username;
    String logtype;
    Date date;
    Date time;
    
    
    public CableSalesInformationSystemUserLogtrailTable(int logtrailid,int userid, String username, String logtype, Date date, Date time)
    {
        
        this.logtrailid=logtrailid;
        this.userid=userid;
        this.username=username;        
        this.logtype=logtype;
        this.date=date;
        this.time=time;
               
        
    }
    
    public int getLogtrailID()
    {
        return logtrailid;
    }
    
    public int getUserID()
    {
        return userid;
    }
     public String getUserName()
    {
        return username;
    }
    public String getLogtype()
    {
        return logtype;
    }
    
    public Date getDate()
    {
        return date;
    }
    
    public Date getTime()
    {
        return time;
    }
    
    
    
    
}

