/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class CableSalesInformationSystemPaymentMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String bookid;
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public CableSalesInformationSystemPaymentMaintenance() {
        super("Legal Person Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Book_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_book`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int bookid = rs.getInt("bookid");
                String booktitle=rs.getString("booktitle");
                String description=rs.getString("description");
                String authors=rs.getString("authors");
                int totalgoodquantity=rs.getInt("totalgoodquantity");
                int totallostquantity=rs.getInt("totallostquantity");
                int totaldamagedquantity=rs.getInt("totaldamagedquantity");
                

                textBookID.setText(Integer.toString(bookid));
                textBookTitle.setText(booktitle);
                textDescription.setText(description);
                textAuthors.setText(Integer.toString(totalgoodquantity));   
                textTotalGoodQuantity.setText(authors);
                textTotalLostQuantity.setText(Integer.toString(totalgoodquantity));
                textTotalDamagedQuantity.setText(Integer.toString(totalgoodquantity));
                
            
            }           
            
            viewall=0;           
            
            Show_Book_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<CableSalesInformationSystemPaymentTable> getBookList()
    {
        ArrayList<CableSalesInformationSystemPaymentTable> bookList= new ArrayList<CableSalesInformationSystemPaymentTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_book`";;
            }
            else if(viewall==1)
            {
                
                
                String totallostquantity=textTotalLostQuantity.getText().trim();
                String totaldamagedquantity=textTotalDamagedQuantity.getText().trim();
                
                                
                 query ="SELECT * FROM `tbl_book` WHERE "                       
                        +" totallostquantity like '%"+totallostquantity+"%' or totaldamagedquantity like '%"+totaldamagedquantity+"%' ";
                        
            
                
            }
            else if(viewall==3) 
            {
                
                               
                
                String bookid=textBookID.getText().trim();
                int bookid1=Integer.parseInt(bookid);
                
                query ="SELECT * FROM `tbl_book` WHERE bookid = "+bookid1+"";
            }
            else if(viewall==2) 
            {
                
                String authors=textTotalGoodQuantity.getText();
                String booktitle=textBookTitle.getText();
                
                query ="SELECT * FROM `tbl_book` WHERE authors like '%"+authors+"%' or "
                        + "booktitle like '%"+booktitle+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemPaymentTable book1;
            
            while(rs.next())
            {
                book1 = new  CableSalesInformationSystemPaymentTable(
                        rs.getInt("bookid"),rs.getString("booktitle"),
                        rs.getString("description"),
                        rs.getString("authors"),rs.getInt("totalquantitygood"),
                        rs.getInt("totalquantitylost"),rs.getInt("totalquantitydamaged"));
                bookList.add(book1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+e.getMessage());
        }
        
        return bookList;
     
    }
    
    public void Show_Book_In_JTable()
    {
        ArrayList<CableSalesInformationSystemPaymentTable> list = getBookList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[7];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getBookID();
            row[1]=list.get(i).getBookTitle();
            row[2]=list.get(i).getDescription();
            row[3]=list.get(i).getAuthors();
            row[4]=list.get(i).getTotalQuantityGood();            
            row[5]=list.get(i).getTotalQuantityLost();
            row[6]=list.get(i).getTotalQuantityDamaged();                    
                                                
            model.addRow(row);
            
        }
        
    }
    
    /*
    School Inquiry
    */
    public ArrayList<CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable> getAuthorList()
    {
        ArrayList<CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable> authorList= new ArrayList<CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author`";
            }            
            else if(viewall2==3) 
            {               
                               
                
                String authorid=textAuthorIDInquiry.getText().trim();
                int authorid1=Integer.parseInt(authorid);
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE authorid= "+authorid1+"";
            }
            else if(viewall2==2) 
            {
                
                
                String firstname=textAuthorFirstNameInquiry.getText();
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE "
                        + "firstname like '%"+firstname+"%'";
            }
            else if(viewall2==4) 
            {
                
                
                String middlename=textAuthorMiddleNameInquiry.getText();
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE "
                        + "firstname like '%"+middlename+"%'";
            }
            else if(viewall2==5) 
            {
                
                
                String lastname=textAuthorLastNameInquiry.getText();
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE "
                        + "lastname like '%"+lastname+"%'";
            }
            else if(viewall2==6) 
            {
                
                
                String suffix=textAuthorSuffixInquiry.getText();
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE "
                        + "firstname like '%"+suffix+"%'";
            }
            else if(viewall2==7) 
            {
                
                
                String role=textAuthorRoleInquiry.getText();
                
                query ="SELECT `authorid`, `firstname`, `middlename`, `lastname`, `suffix`, `role` FROM `tbl_author` WHERE "
                        + "firstname like '%"+role+"%' ";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable salesinquiry1;
            
            while(rs2.next())
            {
                salesinquiry1 = new  CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable(
                        rs2.getInt("salesid"),rs2.getInt("cashierid"),rs2.getInt("customerid"),
                        rs2.getDouble("totalamountpayable"),rs2.getDouble("totalamountpaid"),rs2.getDouble("totalchange")
                        );
                authorList.add(salesinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+e.getMessage());
        }
        
        return authorList;
     
    }
    
    public void Show_AuthorInquiry_In_JTable()
    {
        ArrayList<CableSalesInformationSystemPaymentMaitenanceSalesInquiryTable> list = getAuthorList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[6];
        
        //model.addColumn("blade");
        
        model.setRowCount(0);
        
            
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSalesID();
            row[1]=list.get(i).getCashierID();
            row[2]=list.get(i).getCustomerID();
            row[3]=list.get(i).getTotalAmountPayable();
            row[4]=list.get(i).getTotalAmountPaid();
            row[5]=list.get(i).getTotalChange();
                              
                                                
            model.addRow(row);
            
        }
        
    } 
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textTotalGoodQuantity = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textBookTitle = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textAuthors = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByRoleOrLegalPersonType = new javax.swing.JButton();
        btnSearchByLegalPersonID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textBookID = new javax.swing.JTextField();
        textTotalLostQuantity = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textTotalDamagedQuantity = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textDescription = new javax.swing.JTextArea();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        textAuthorIDInquiry = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        textAuthorFirstNameInquiry = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnAuthorIDInquiry = new javax.swing.JButton();
        btnAuthorFirstNameInquiry = new javax.swing.JButton();
        btnViewAllSchools = new javax.swing.JButton();
        btnClearAllSchools = new javax.swing.JButton();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        textAuthorInquiryPut = new javax.swing.JTextArea();
        btnAuthorInquiryAdd = new javax.swing.JButton();
        textAuthorMiddleNameInquiry = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        textAuthorLastNameInquiry = new javax.swing.JTextField();
        textAuthorSuffixInquiry = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        btnAuthorMiddleNameInquiry = new javax.swing.JButton();
        btnAuthorLastNameInquiry = new javax.swing.JButton();
        textAuthorRoleInquiry = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        btnAuthorSuffixInquiry = new javax.swing.JButton();
        btnAuthorRoleInquiry = new javax.swing.JButton();
        btnSearchByAuthorFirstNameInquiry = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Legal Person ID", "Legal Person Type", "Suffix", "Role", "Comment", "First Name", "Middle Name", "Last Name", "Sex", "Birthdate", "Address", "Hobby"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(6).setHeaderValue("Middle Name");
            jTable1.getColumnModel().getColumn(7).setHeaderValue("Last Name");
            jTable1.getColumnModel().getColumn(8).setHeaderValue("Sex");
            jTable1.getColumnModel().getColumn(9).setHeaderValue("Birthdate");
            jTable1.getColumnModel().getColumn(10).setHeaderValue("Address");
            jTable1.getColumnModel().getColumn(11).setHeaderValue("Hobby");
        }

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Authors");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Description");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Total Good Quantity");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Booktitle");

        textAuthors.setBackground(new java.awt.Color(51, 255, 255));
        textAuthors.setColumns(20);
        textAuthors.setRows(5);
        jScrollPane1.setViewportView(textAuthors);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByRoleOrLegalPersonType.setText("Search by Authors");
        btnSearchByRoleOrLegalPersonType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByRoleOrLegalPersonTypeActionPerformed(evt);
            }
        });

        btnSearchByLegalPersonID.setText("Search by Book ID ");
        btnSearchByLegalPersonID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByLegalPersonIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Payment ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Total Damaged Quantity");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("Total Lost Quantity");

        textDescription.setBackground(new java.awt.Color(51, 255, 255));
        textDescription.setColumns(20);
        textDescription.setRows(5);
        jScrollPane2.setViewportView(textDescription);

        jLabel22.setText("Author ID");

        jLabel23.setText("Author First Name ");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Author ID", "FirstName", "MiddleName", "LastName", "Suffix"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(jTable3);

        btnAuthorIDInquiry.setText("Search by Author ID ");
        btnAuthorIDInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorIDInquiryActionPerformed(evt);
            }
        });

        btnAuthorFirstNameInquiry.setText("Search by Author First Name");
        btnAuthorFirstNameInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorFirstNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllSchools.setText("View All Authors");
        btnViewAllSchools.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewAllSchoolsActionPerformed(evt);
            }
        });

        btnClearAllSchools.setText("Clear All Authors");
        btnClearAllSchools.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllSchoolsActionPerformed(evt);
            }
        });

        jLabel24.setText("Clicked Author Name");

        textAuthorInquiryPut.setColumns(20);
        textAuthorInquiryPut.setRows(5);
        jScrollPane6.setViewportView(textAuthorInquiryPut);

        btnAuthorInquiryAdd.setText("Add to List of Authors");
        btnAuthorInquiryAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorInquiryAddActionPerformed(evt);
            }
        });

        jLabel25.setText("Author Role");

        jLabel26.setText("Author First Name ");

        jLabel27.setText("Author First Name ");

        btnAuthorMiddleNameInquiry.setText("Search by Author Middle Name");
        btnAuthorMiddleNameInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorMiddleNameInquiryActionPerformed(evt);
            }
        });

        btnAuthorLastNameInquiry.setText("Search by Author Last Name");
        btnAuthorLastNameInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorLastNameInquiryActionPerformed(evt);
            }
        });

        jLabel28.setText("Author Role");

        btnAuthorSuffixInquiry.setText("Search by Author Suffix");
        btnAuthorSuffixInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorSuffixInquiryActionPerformed(evt);
            }
        });

        btnAuthorRoleInquiry.setText("Search by Author Role");
        btnAuthorRoleInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAuthorRoleInquiryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(jLabel24))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel22)
                                    .addComponent(jLabel25)
                                    .addComponent(jLabel26)
                                    .addComponent(jLabel27)
                                    .addComponent(jLabel28))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(textAuthorFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textAuthorIDInquiry)
                                    .addComponent(textAuthorMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textAuthorLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textAuthorSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .addComponent(textAuthorRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnAuthorFirstNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAuthorIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAuthorMiddleNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAuthorLastNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAuthorSuffixInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnAuthorRoleInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAllSchools, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAllSchools, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAuthorInquiryAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(textAuthorIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAuthorIDInquiry)
                    .addComponent(btnViewAllSchools))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textAuthorFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAuthorFirstNameInquiry)
                            .addComponent(btnClearAllSchools))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnAuthorMiddleNameInquiry)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnAuthorLastNameInquiry)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnAuthorSuffixInquiry)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnAuthorRoleInquiry))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textAuthorMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel26))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textAuthorLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textAuthorSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel28)
                                    .addComponent(textAuthorRoleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLabel23))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAuthorInquiryAdd))
                .addGap(23, 23, 23)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane5.addTab("Author Inquiry Panel", jPanel2);

        jTabbedPane1.addTab("Book Inquiry", jTabbedPane5);

        btnSearchByAuthorFirstNameInquiry.setText("Search by Author Inquiry");
        btnSearchByAuthorFirstNameInquiry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchByAuthorFirstNameInquiryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(435, 435, 435)
                                .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnBackToMDIForm)
                                        .addGap(30, 30, 30)
                                        .addComponent(btnSearchByLegalPersonID)
                                        .addGap(72, 72, 72)
                                        .addComponent(btnSearchByAuthorFirstNameInquiry))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(12, 12, 12)
                                                    .addComponent(textBookID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(btnSearchByRoleOrLegalPersonType)
                                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(textTotalGoodQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel9)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textTotalDamagedQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textTotalLostQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnDelete))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 760, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 289, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByLegalPersonID)
                            .addComponent(btnSearchByAuthorFirstNameInquiry))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(17, 17, 17)
                                .addComponent(jLabel14))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textBookID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textBookTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addGap(18, 18, 18)
                        .addComponent(btnSearchByRoleOrLegalPersonType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(textTotalGoodQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textTotalLostQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel21)))
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textTotalDamagedQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEdit)
                                .addComponent(btnNewRecord)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnCancelNewRecord)
                                .addComponent(btnClearAll))
                            .addComponent(btnSaveRecord)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        
        textBookID.setText(model.getValueAt(i, 0).toString());
        textBookTitle.setText(model.getValueAt(i, 1).toString());
        textDescription.setText(model.getValueAt(i, 2).toString());
        textTotalGoodQuantity.setText(model.getValueAt(i, 3).toString());
        textAuthors.setText(model.getValueAt(i, 4).toString());        
        textTotalLostQuantity.setText(model.getValueAt(i, 5).toString());
        textTotalDamagedQuantity.setText(model.getValueAt(i, 6).toString());
               
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textBookID.setText(model.getValueAt(i, 0).toString());
            textBookTitle.setText(model.getValueAt(i, 1).toString());
            textDescription.setText(model.getValueAt(i, 2).toString());
            textTotalGoodQuantity.setText(model.getValueAt(i, 3).toString());
            textAuthors.setText(model.getValueAt(i, 4).toString());        
            textTotalLostQuantity.setText(model.getValueAt(i, 5).toString());
            textTotalDamagedQuantity.setText(model.getValueAt(i, 6).toString());
            
            

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String bookid=textBookID.getText().trim();
                int bookid2=Integer.parseInt(bookid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_book` where bookid="+bookid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_book"
                    + " where bookid="+bookid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String bookid = textBookID.getText().trim();
                int bookid2=Integer.parseInt(bookid);
                String booktitle=textBookTitle.getText().trim();
                String description=textDescription.getText().trim();
                String authors=textTotalGoodQuantity.getText().trim();
                String totalgoodquantity=textAuthors.getText().trim();
                int totalgoodquantity2=Integer.parseInt(totalgoodquantity);
                String totallostquantity=textTotalLostQuantity.getText().trim();
                int totallostquantity2=Integer.parseInt(totallostquantity);
                String totaldamagedquantity=textTotalDamagedQuantity.getText().trim();
                int totaldamagedquantity2=Integer.parseInt(totaldamagedquantity);
                
              
                
                
                
                
                                               

                if(bookid.equals("")||booktitle.equals("")||totallostquantity.equals("")
                   || totaldamagedquantity.equals("")|| description.equals("")|| authors.equals("")|| totalgoodquantity.equals("")
                   )
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_book` where "
                            + "bookid="+bookid+" or (booktitle='"+booktitle+"' ";
                       
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        sql="UPDATE `tbl_book` "
                                + "SET `booktitle`='"+booktitle+"',"
                                + "`description`='"+description+"',`authors`='"+authors+"',"
                                + "`totalgoodquantity`="+totalgoodquantity2+",`totallostquantity`="+totallostquantity2+","
                                + "`totaldamagedquantity`="+totaldamagedquantity2+""
                                + " WHERE `bookid`="+bookid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_book` where "
                            + "bookid="+bookid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            bookid2 = rs.getInt("bookid");
                            booktitle=rs.getString("booktitle");
                            description=rs.getString("description");
                            authors=rs.getString("authors");
                            totalgoodquantity2=rs.getInt("totalgoodquantity");
                            totallostquantity2=rs.getInt("totallostquantity");
                            totaldamagedquantity2=rs.getInt("totaldamagedquantity");
                            

                            
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textBookID.setText(Integer.toString(bookid2));
                                textBookTitle.setText(booktitle);
                                textDescription.setText(description);                                  
                                textAuthors.setText(authors); 
                                textTotalGoodQuantity.setText(totalgoodquantity);
                                textTotalLostQuantity.setText(totallostquantity);
                                textTotalDamagedQuantity.setText(totaldamagedquantity);
                                
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            //String bookid = textLegalPersonID.getText().trim();
            //int bookid2=Integer.parseInt(bookid);
            String booktitle=textBookTitle.getText().trim();
            String description=textDescription.getText().trim();
            String authors=textTotalGoodQuantity.getText().trim();
            String totalgoodquantity=textAuthors.getText().trim();
            int totalgoodquantity2=Integer.parseInt(totalgoodquantity);
            String totallostquantity=textTotalLostQuantity.getText().trim();
            int totallostquantity2=Integer.parseInt(totallostquantity);
            String totaldamagedquantity=textTotalDamagedQuantity.getText().trim();
            int totaldamagedquantity2=Integer.parseInt(totaldamagedquantity);
            
                   
            

           if(booktitle.equals("")|| totallostquantity.equals("")|| description.equals("")|| 
                   authors.equals("")|| totalgoodquantity.equals("")
                   || totaldamagedquantity.equals(""))
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_book` where booktitle='"+booktitle+"' ";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="INSERT INTO `tbl_book`(`bookid`, `booktitle`, `description`, `authors`, `totalgoodquantity`, "
                            + "`totallostquantity`, `totaldamagedquantity`) "
                            + "VALUES (NULL,'"+booktitle+"','"+description+"','"+authors+"','"+totalgoodquantity+"',"
                            + "'"+totallostquantity+"','"+totaldamagedquantity+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_book`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int bookid = rs.getInt("bookid");
                    booktitle=rs.getString("booktitle");
                    description=rs.getString("description");
                    authors=rs.getString("authors");
                    totalgoodquantity=rs.getString("totalgoodquantity");
                    totallostquantity=rs.getString("totallostquantity");
                    totaldamagedquantity=rs.getString("totaldamagedquantity");
                    

                    textBookID.setText(Integer.toString(bookid));
                    textBookTitle.setText(booktitle);
                    textDescription.setText(description);
                    textTotalGoodQuantity.setText(authors);
                    textAuthors.setText(totalgoodquantity);                
                    textTotalLostQuantity.setText(totallostquantity);
                    textTotalDamagedQuantity.setText(totaldamagedquantity);
                    

                    JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " new inserted record item: "+Double.toString(bookid));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_Book_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textBookID.setText("");
            textBookTitle.setText("");
            textDescription.setText("");
            textTotalGoodQuantity.setText("");
            textAuthors.setText("");                
            textTotalLostQuantity.setText("");
            textTotalDamagedQuantity.setText("");
           

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int bookid = rs.getInt("bookid");
            String booktitle=rs.getString("booktitle");
            String description=rs.getString("description");
            String authors=rs.getString("authors");
            String totalgoodquantity=rs.getString("totalgoodquantity");
            String totallostquantity=rs.getString("totallostquantity");
            String totaldamagedquantity=rs.getString("totaldamagedquantity");
            

            textBookID.setText(Integer.toString(bookid));
            textBookTitle.setText(booktitle);
            textDescription.setText(description);
            textTotalGoodQuantity.setText(authors);
            textAuthors.setText(totalgoodquantity);                
            textTotalLostQuantity.setText(totallostquantity);
            textTotalDamagedQuantity.setText(totaldamagedquantity);
            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int bookid = rs.getInt("bookid");
                String booktitle=rs.getString("booktitle");
                String description=rs.getString("description");
                String authors=rs.getString("authors");
                String totalgoodquantity=rs.getString("totalgoodquantity");
                String totallostquantity=rs.getString("totallostquantity");
                String totaldamagedquantity=rs.getString("totaldamagedquantity");
                

                textBookID.setText(Integer.toString(bookid));
                textBookTitle.setText(booktitle);
                textDescription.setText(description);
                textTotalGoodQuantity.setText(authors);
                textAuthors.setText(totalgoodquantity);                
                textTotalLostQuantity.setText(totallostquantity);
                textTotalDamagedQuantity.setText(totaldamagedquantity);
                

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textBookID.setText("");
                textBookTitle.setText("");
                textDescription.setText("");
                textTotalGoodQuantity.setText("");
                textAuthors.setText("");                
                textTotalLostQuantity.setText("");
                textTotalDamagedQuantity.setText("");
                
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textBookID.setText("");
        textBookTitle.setText("");
        textDescription.setText("");
        textTotalGoodQuantity.setText("");
        textAuthors.setText("");                
        textTotalLostQuantity.setText("");
        textTotalDamagedQuantity.setText("");
        

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {
                
                

                int bookid = rs.getInt("bookid");
                String booktitle=rs.getString("booktitle");
                String description=rs.getString("description");
                String authors=rs.getString("authors");
                String totalgoodquantity=Integer.toString(rs.getInt("totalgoodquantity"));                
                String totallostquantity=Integer.toString(rs.getInt("totallostquantity"));                
                String totaldamagedquantity=Integer.toString(rs.getInt("totaldamagedquantity"));                           
                

                textBookID.setText(Integer.toString(bookid));
                textBookTitle.setText(booktitle);
                textDescription.setText(description);
                textTotalGoodQuantity.setText(authors);
                textAuthors.setText(totalgoodquantity);                
                textTotalLostQuantity.setText(totallostquantity);
                textTotalDamagedQuantity.setText(totaldamagedquantity);
                

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int bookid = rs.getInt("bookid");
            String booktitle=rs.getString("booktitle");
            String description=rs.getString("description");
            String authors=rs.getString("authors");
            String totalgoodquantity=Integer.toString(rs.getInt("totalgoodquantity"));            
            String totallostquantity=Integer.toString(rs.getInt("totallostquantity"));            
            String totaldamagedquantity=Integer.toString(rs.getInt("totaldamagedquantity"));       


            textBookID.setText(Integer.toString(bookid));
            textBookTitle.setText(booktitle);
            textDescription.setText(description);
            textTotalGoodQuantity.setText(authors);
            textAuthors.setText(totalgoodquantity);                
            textTotalLostQuantity.setText(totallostquantity);
            textTotalDamagedQuantity.setText(totaldamagedquantity);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int bookid = rs.getInt("bookid");
                String booktitle=rs.getString("booktitle");
                String description=rs.getString("description");
                String authors=rs.getString("authors");
                String totalgoodquantity=Integer.toString(rs.getInt("totalgoodquantity"));                
                String totallostquantity=Integer.toString(rs.getInt("totallostquantity"));                
                String totaldamagedquantity=Integer.toString(rs.getInt("totaldamagedquantity"));                           
                

                textBookID.setText(Integer.toString(bookid));
                textBookTitle.setText(booktitle);
                textDescription.setText(description);
                textTotalGoodQuantity.setText(authors);
                textAuthors.setText(totalgoodquantity);                
                textTotalLostQuantity.setText(totallostquantity);
                textTotalDamagedQuantity.setText(totaldamagedquantity);

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int bookid = rs.getInt("bookid");
                String booktitle=rs.getString("booktitle");
                String description=rs.getString("description");
                String authors=rs.getString("authors");
                String totalgoodquantity=Integer.toString(rs.getInt("totalgoodquantity"));                
                String totallostquantity=Integer.toString(rs.getInt("totallostquantity"));                
                String totaldamagedquantity=Integer.toString(rs.getInt("totaldamagedquantity"));                           
                

                textBookID.setText(Integer.toString(bookid));
                textBookTitle.setText(booktitle);
                textDescription.setText(description);
                textTotalGoodQuantity.setText(authors);
                textAuthors.setText(totalgoodquantity);                
                textTotalLostQuantity.setText(totallostquantity);
                textTotalDamagedQuantity.setText(totaldamagedquantity);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemPaymentMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search authors or legal person type
    private void btnSearchByRoleOrLegalPersonTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Book_In_JTable();
        
    }//GEN-LAST:event_btnSearchByRoleOrLegalPersonTypeActionPerformed

    //search Legal Person ID
    private void btnSearchByLegalPersonIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByLegalPersonIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByLegalPersonIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnSearchByLegalPersonIDActionPerformed

    private void btnClearAllSchoolsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllSchoolsActionPerformed
    {//GEN-HEADEREND:event_btnClearAllSchoolsActionPerformed
        // TODO add your handling code here:
        textAuthorIDInquiry.setText("");
        textAuthorFirstNameInquiry.setText("");
    }//GEN-LAST:event_btnClearAllSchoolsActionPerformed

    private void btnViewAllSchoolsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllSchoolsActionPerformed
    {//GEN-HEADEREND:event_btnViewAllSchoolsActionPerformed
        // TODO add your handling code here:
        viewall2=0;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnViewAllSchoolsActionPerformed

    //Author First Name Inquiry
    private void btnAuthorFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorFirstNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorFirstNameInquiryActionPerformed

    private void btnAuthorIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=3;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorIDInquiryActionPerformed

    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:
        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable3.getSelectedRow();
                TableModel model=jTable3.getModel();

                //textAuthorIDInquiry.setText(model.getValueAt(i, 0).toString());
                //textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
                String author="";
                author+=model.getValueAt(i, 1).toString()+" ";
                author+=model.getValueAt(i, 2).toString()+" ";
                author+=model.getValueAt(i, 3).toString()+" ";
                author+=model.getValueAt(i, 4).toString()+"";
                textAuthorInquiryPut.setText(author);
                

            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            //textAuthorIDInquiry.setText(model.getValueAt(i, 0).toString());
            //textAuthorNameInquiry.setText(model.getValueAt(i, 1).toString());
            String author="";
                author+="";
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable3MouseClicked

    //search legal person Name
    private void btnSearchByAuthorFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByAuthorFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnSearchByAuthorFirstNameInquiryActionPerformed
        // TODO add your handling code here:

        viewall=1;
        Show_Book_In_JTable();
    }//GEN-LAST:event_btnSearchByAuthorFirstNameInquiryActionPerformed

    private void btnAuthorInquiryAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorInquiryAddActionPerformed
    {//GEN-HEADEREND:event_btnAuthorInquiryAddActionPerformed
        // TODO add your handling code here:
        textAuthors.setText("\n"+textAuthorInquiryPut.getText());
        
        
    }//GEN-LAST:event_btnAuthorInquiryAddActionPerformed

    //Author Middle Name inquiry
    private void btnAuthorMiddleNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorMiddleNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorMiddleNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=4;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorMiddleNameInquiryActionPerformed

    //Author Last name inquiry
    private void btnAuthorLastNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorLastNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorLastNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=5;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorLastNameInquiryActionPerformed

    //Author Suffix Inquiry
    private void btnAuthorSuffixInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorSuffixInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorSuffixInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=6;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorSuffixInquiryActionPerformed

    //Author Role Inquiry
    private void btnAuthorRoleInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnAuthorRoleInquiryActionPerformed
    {//GEN-HEADEREND:event_btnAuthorRoleInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=7;
        Show_AuthorInquiry_In_JTable();
    }//GEN-LAST:event_btnAuthorRoleInquiryActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAuthorFirstNameInquiry;
    private javax.swing.JButton btnAuthorIDInquiry;
    private javax.swing.JButton btnAuthorInquiryAdd;
    private javax.swing.JButton btnAuthorLastNameInquiry;
    private javax.swing.JButton btnAuthorMiddleNameInquiry;
    private javax.swing.JButton btnAuthorRoleInquiry;
    private javax.swing.JButton btnAuthorSuffixInquiry;
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnClearAllSchools;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByAuthorFirstNameInquiry;
    private javax.swing.JButton btnSearchByLegalPersonID;
    private javax.swing.JButton btnSearchByRoleOrLegalPersonType;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JButton btnViewAllSchools;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField textAuthorFirstNameInquiry;
    private javax.swing.JTextField textAuthorIDInquiry;
    private javax.swing.JTextArea textAuthorInquiryPut;
    private javax.swing.JTextField textAuthorLastNameInquiry;
    private javax.swing.JTextField textAuthorMiddleNameInquiry;
    private javax.swing.JTextField textAuthorRoleInquiry;
    private javax.swing.JTextField textAuthorSuffixInquiry;
    private javax.swing.JTextArea textAuthors;
    private javax.swing.JTextField textBookID;
    private javax.swing.JTextField textBookTitle;
    private javax.swing.JTextArea textDescription;
    private javax.swing.JTextField textTotalDamagedQuantity;
    private javax.swing.JTextField textTotalGoodQuantity;
    private javax.swing.JTextField textTotalLostQuantity;
    // End of variables declaration//GEN-END:variables
}
