/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    /**
     * @param args the command line arguments
     */
      
    int technicianid;
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    String role;        
    
    
    public CableSalesInformationSystemInvoiceMaintenanceTechnicianInquiryTable
    (            
        int technicianid,
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String role       
        
    )
            
    {
        this.technicianid=technicianid;   
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;        
        this.suffix=suffix;
        this.role=role;
             
              
    }
    
    public int getTechnicianID()
    {
        return technicianid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    
    public String getSuffix()
    {
        return suffix;
    }
    public String getRole()
    {
        return role;
    }     
    
    
}
