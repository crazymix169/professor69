/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import java.time.LocalDateTime; // Import the LocalDateTime class
import java.time.format.DateTimeFormatter; // Import the DateTimeFormatter class
import java.time.LocalDate;
import java.sql.PreparedStatement;

import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 *
 * @author owner
 */
public class CableSalesInformationSystemUserLogtrailMaintenance extends javax.swing.JInternalFrame {
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    
    PreparedStatement stmt2;
    
    int curRow = 0,viewall=0;
    String query;
    
    String logtrailid;
    String userid;
    String username;
    
    // tbl_userslogtrail fieldvarialbes
    private static final String TBL_USERSLOGTRAIL_LOGTRAILID = "tbl_userslogtrail.userslogtrailid";  // Compliant
    private static final String TBL_USERS_USERID = "tbl_users.userid";  // Compliant
    private static final String TBL_USERS_USERNAME = "tbl_users.username";  // Compliant
    private static final String TBL_USERSLOGTRAIL_LOGTYPE = "tbl_userslogtrail.logtype";  // Compliant
    private static final String TBL_USERSLOGTRAIL_DATE = "tbl_userslogtrail.date";  // Compliant
    private static final String TBL_USERSLOGTRAIL_TIME = "tbl_userslogtrail.time";  // Compliant

    /**
     * Creates new form SalesAndInventoryCristalUserLogtrailMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    
    
    public CableSalesInformationSystemUserLogtrailMaintenance() {
        super("User Log Trail Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        initComponents();
        
        DoConnect();
        viewall=0;
        Show_UsersLogtrail_In_JTable();
        jRadioButtonManualDate.setSelected(false);
        jRadioButtonAutoDate.setSelected(true);
        
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="SELECT tbl_userslogtrail.userslogtrailid, tbl_users.userid, tbl_users.username,"
                    + " tbl_userslogtrail.logtype, tbl_userslogtrail.date, "
                    + "tbl_userslogtrail.time FROM `tbl_userslogtrail`,`tbl_users` "
                    + "WHERE tbl_users.userid=tbl_userslogtrail.userid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();                

                textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
                textUserName.setText(rs.getString(TBL_USERS_USERNAME));
                textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
                textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
                textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
                SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
                textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));
                
            }

            
            
            comboLogtype.removeAllItems();
            comboLogtype.addItem("Login");
            comboLogtype.addItem("Logout");
            
            
        
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
                        
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<CableSalesInformationSystemUserLogtrailTable> getUsersLogtrailList()
    {
        
            
        ArrayList<CableSalesInformationSystemUserLogtrailTable> UserLogtrailList= new ArrayList<CableSalesInformationSystemUserLogtrailTable>();
        Connection connection = getConnection();
            
            
        try
        {        
            if(viewall==0)
            {
                query="SELECT tbl_userslogtrail.userslogtrailid, tbl_users.userid, tbl_users.username,"
                    + " tbl_userslogtrail.logtype, tbl_userslogtrail.date, "
                    + "tbl_userslogtrail.time FROM `tbl_userslogtrail`,`tbl_users` "
                    + "WHERE tbl_users.userid=tbl_userslogtrail.userid";
            }
            else if(viewall==2)
            {
                userid=textUserID.getText();
                int userid2=Integer.parseInt(userid);
                logtrailid=textLogtrailID.getText();
                query="SELECT tbl_userslogtrail.userslogtrailid, tbl_users.userid, tbl_users.username,"
                    + " tbl_userslogtrail.logtype, tbl_userslogtrail.date, "
                    + "tbl_userslogtrail.time FROM `tbl_userslogtrail`,`tbl_users` "
                    + "WHERE tbl_users.userid=tbl_userslogtrail.userid and (tbl_userslogtrail.logtype like '%"+comboLogtype.toString()+"%'"
                + " or tbl_userslogtrail.userid="+userid2+")";

            }
            else if(viewall==1)
            {
                username=textUserName.getText();

                query="SELECT tbl_userslogtrail.userslogtrailid, tbl_users.userid, tbl_users.username,"
                    + " tbl_userslogtrail.logtype, tbl_userslogtrail.date, "
                    + "tbl_userslogtrail.time FROM `tbl_userslogtrail`,`tbl_users` "
                    + "WHERE tbl_users.userid=tbl_userslogtrail.userid and (tbl_userslogtrail.logtype like '%"+comboLogtype.toString()+"%'"
                + " and tbl_users.username like '%"+username+"%' )";

            }

            int i=1;

            Statement st;

            String frmDate1=textDate.getText();
            String toDate1=textTime.getText();
            frmDate1="2020-05-28";
            toDate1="2020-05-30";
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date from = sdf.parse(frmDate1);
            java.util.Date to = sdf.parse(toDate1);

            java.sql.Date from1 = new java.sql.Date(from.getTime());
            java.sql.Date to1 = new java.sql.Date(to.getTime());

            
            stmt = connection.createStatement();
            

            rs = stmt.executeQuery(query);
            CableSalesInformationSystemUserLogtrailTable logtrail1;

            while(rs.next())
            {
                /*
                query="SELECT tbl_userslogtrail.userslogtrailid, tbl_users.userid, tbl_users.username,"
                    + " tbl_userslogtrail.logtype, tbl_userslogtrail.date, "
                    + "tbl_userslogtrail.time FROM `tbl_userslogtrail`,`tbl_users` "
                    + "WHERE tbl_users.userid=tbl_userslogtrail.userid";
                */
                logtrail1 = new  CableSalesInformationSystemUserLogtrailTable(rs.getInt("tbl_userslogtrail.userslogtrailid"),
                        rs.getInt("tbl_users.userid"),rs.getString("tbl_users.username"),
                        rs.getString("tbl_userslogtrail.logtype"), rs.getDate("tbl_userslogtrail.date"), 
                        rs.getTime("tbl_userslogtrail.time"));
                UserLogtrailList.add(logtrail1);
            }           

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }                        
        return UserLogtrailList;    
    }
    
    public void Show_UsersLogtrail_In_JTable()
    {
        ArrayList<CableSalesInformationSystemUserLogtrailTable> list = getUsersLogtrailList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
           
            row[0]=list.get(i).getLogtrailID();
            row[1]=list.get(i).getUserID();
            row[2]=list.get(i).getUserName();
            row[3]=list.get(i).getLogtype();
            row[4]=list.get(i).getDate();
            row[5]=list.get(i).getTime();           
            
            model.addRow(row);
            
        }
        
    }
        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        btnNewRecord = new javax.swing.JButton();
        btnBackToMDIForm = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        comboLogtype = new javax.swing.JComboBox<>();
        textCurDateTime = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnLast = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textDate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        textUserID = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        btnSearchByUserID = new javax.swing.JButton();
        textLogtrailID = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        textLogtype = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textTime = new javax.swing.JTextField();
        btnDisplayCurentDateTime = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        textUserName = new javax.swing.JTextField();
        btnSearchByUserName = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jRadioButtonManualDate = new javax.swing.JRadioButton();
        jRadioButtonAutoDate = new javax.swing.JRadioButton();

        setTitle("User Logtrail Manitenance");

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText(" Date");

        comboLogtype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboLogtype.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                comboLogtypeMouseClicked(evt);
            }
        });
        comboLogtype.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                comboLogtypeActionPerformed(evt);
            }
        });

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Display Current Date and Time");

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("User ID");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Logtrail ID", "User ID", "User Name", "Logtype", "Date", "Time"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Logtrail ID");

        btnDelete.setText("Delete this User");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSearchByUserID.setText("Search by User ID");
        btnSearchByUserID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByUserIDActionPerformed(evt);
            }
        });

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Logtype");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Time");

        btnDisplayCurentDateTime.setText("Display Current Date and Time");
        btnDisplayCurentDateTime.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDisplayCurentDateTimeActionPerformed(evt);
            }
        });

        btnClear.setText("Clear Textboxes");
        btnClear.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("User Name");

        btnSearchByUserName.setText("Search by User Name");
        btnSearchByUserName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByUserNameActionPerformed(evt);
            }
        });

        jRadioButtonManualDate.setText("Manual Date");
        jRadioButtonManualDate.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonManualDateActionPerformed(evt);
            }
        });

        jRadioButtonAutoDate.setText("Computer Date");
        jRadioButtonAutoDate.setName(""); // NOI18N
        jRadioButtonAutoDate.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jRadioButtonAutoDateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButtonManualDate)
                    .addComponent(jRadioButtonAutoDate))
                .addContainerGap(228, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jRadioButtonManualDate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRadioButtonAutoDate)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                        .addGap(311, 311, 311))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBackToMDIForm)
                        .addGap(252, 252, 252))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(btnSaveRecord)
                        .addGap(36, 36, 36)
                        .addComponent(btnCancelNewRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textLogtrailID))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(textUserName)
                                        .addGap(4, 4, 4))
                                    .addComponent(textUserID))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnSearchByUserID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnSearchByUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textTime))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textDate))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(comboLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(textLogtype))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(textCurDateTime)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnDisplayCurentDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(51, 51, 51))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textLogtrailID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(textUserID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSearchByUserID)
                                .addGap(1, 1, 1)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textUserName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)))
                    .addComponent(btnSearchByUserName, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(textLogtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(textDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(textTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textCurDateTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(btnDisplayCurentDateTime))
                .addGap(79, 79, 79)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnBackToMDIForm)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete)
                        .addComponent(btnNewRecord))
                    .addComponent(btnEdit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSaveRecord)
                    .addComponent(btnCancelNewRecord)
                    .addComponent(btnClear))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //create new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling code here:

        try
        {

            curRow = rs.getRow( ); 
            
            textUserID.setText("");
            textUserName.setText("");
            textLogtrailID.setText("");
            textLogtype.setText("");            
            textDate.setText("");            
            textTime.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,err.getMessage());
            
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //back to MDI form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:       
        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
       
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
            textUserName.setText(rs.getString(TBL_USERS_USERNAME));
            textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
            textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
            textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
            textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            textUserID.setText("");
            textLogtrailID.setText("");
            textUserName.setText("");
            textLogtype.setText("");
            textDate.setText("");
            textTime.setText("");
            textCurDateTime.setText("");
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,err.getMessage());
           

            try
            {
                rs.first();

                textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
                textUserName.setText(rs.getString(TBL_USERS_USERNAME));
                textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
                textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
                textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
                SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
                textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                textUserID.setText("");
                textLogtrailID.setText("");
                textUserName.setText("");
                textLogtype.setText("");
                textDate.setText("");
                textTime.setText("");
                textCurDateTime.setText("");
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
                textUserName.setText(rs.getString(TBL_USERS_USERNAME));
                textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
                textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
                textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
                SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
                textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //move first
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();
            
            textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
            textUserName.setText(rs.getString(TBL_USERS_USERNAME));
            textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
            textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
            textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
            textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
                textUserName.setText(rs.getString(TBL_USERS_USERNAME));
                textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
                textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
                textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
                SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
                textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void comboLogtypeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboLogtypeMouseClicked
        // TODO add your handling code here:
        textLogtype.setText(comboLogtype.getItemAt(comboLogtype.getSelectedIndex()).trim());
    }//GEN-LAST:event_comboLogtypeMouseClicked

    private void comboLogtypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboLogtypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboLogtypeActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            textUserID.setText(Integer.toString(rs.getInt(TBL_USERS_USERID)));
            textUserName.setText(rs.getString(TBL_USERS_USERNAME));
            textLogtrailID.setText(Integer.toString(rs.getInt(TBL_USERSLOGTRAIL_LOGTRAILID)));
            textLogtype.setText(rs.getString(TBL_USERSLOGTRAIL_LOGTYPE));
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd");
            textDate.setText(dateFormatter.format(dateFormatter.format(rs.getDate(TBL_USERSLOGTRAIL_DATE))));
            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("hh:mm:ss");
            textTime.setText(dateFormatter2.format(rs.getTime(TBL_USERSLOGTRAIL_TIME)));

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();

        textUserID.setText(model.getValueAt(i, 0).toString());
        textLogtrailID.setText(model.getValueAt(i, 1).toString());
        textLogtype.setText(model.getValueAt(i, 2).toString());
        textDate.setText(model.getValueAt(i, 3).toString());
        textTime.setText(model.getValueAt(i, 4).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textUserID.setText(model.getValueAt(i, 0).toString());
            textLogtrailID.setText(model.getValueAt(i, 1).toString());
            textLogtype.setText(model.getValueAt(i, 2).toString());
            textDate.setText(model.getValueAt(i, 3).toString());
            textTime.setText(model.getValueAt(i, 4).toString());

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    // delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid=textUserID.getText().trim();
                int userid2=Integer.parseInt(userid);

                String logtrailid=textLogtrailID.getText().trim();
                int logtrailid2= Integer.parseInt(logtrailid);

                String date=textDate.getText().trim();

                stmt = con.createStatement( );
                String sql="Select * from tbl_userslogtrail where logtrailid="+logtrailid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );

                    sql="DELETE FROM  tbl_userslogtrail"
                    + " where logtrailid="+logtrailid2+"";

                    stmt.executeUpdate(sql);

                    JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Fan Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("com.mysql.jdbc.Driver");

                String host;
                host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String userid3=textUserID.getText().trim();
                int userid2=Integer.parseInt(userid3);

                String logtrailid=textLogtrailID.getText().trim();
                int logtrailid2=Integer.parseInt(logtrailid);
                Date date2= new Date();
                Date date3= new Date();
                
                SimpleDateFormat ft =  new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss");
                SimpleDateFormat ft2 =  new SimpleDateFormat ("yyyy.MM.dd");
                SimpleDateFormat ft3 =  new SimpleDateFormat ("hh:mm:ss");
                String date=ft2.format(date2).toString().trim();
                String datex=ft3.format(date3).toString().trim();
                try
                {
                    date2=ft2.parse(textDate.getText());
                    
                }
                catch(Exception e)
                {
                    try
                    {    
                        date2=ft2.parse(date);
                    }
                    catch(Exception ex)
                    {
                    
                    }    
                } 
                
                try
                {
                    date3=ft3.parse(textTime.getText());
                    
                }
                catch(Exception e)
                {
                   try
                    {    
                        date2=ft3.parse(datex);
                    }
                    catch(Exception ex)
                    {
                    
                    }
                }  
                
                
                
                
                //String date=textDate.getText().trim();

                if(logtrailid.equals("")|| date.equals("")||userid3.equals(""))
                {
                    JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_userslogtrail where userid="+userid2+" or logtrailid='"+logtrailid+"' ";
                    String sql="Select * from tbl_userslogtrail where logtrailid='"+logtrailid+"' ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        rowCount++;
                    }

                    if(rowCount==0)
                    {
                        JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " Sorry, No such Record! ");
                    }
                    else
                    {

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        //String sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+UserID+",'"+logtype+"', CURDATE(),CURTIME())";
                        if(jRadioButtonAutoDate.isSelected()==true)
                        {    
                            sql="Update tbl_userslogtrail"
                            + " SET  logtype='"+comboLogtype.getItemAt(comboLogtype.getSelectedIndex()).trim()+"',date=CURDATE(), time=CURTIME()"
                            + " where logtrailid="+logtrailid2+"";
                        }
                        else if(jRadioButtonManualDate.isSelected()==true)
                        {
                            sql="Update tbl_userslogtrail"
                            + " SET  logtype='"+comboLogtype.getItemAt(comboLogtype.getSelectedIndex()).trim()+"',date=date2, time=date3"
                            + " where logtrailid="+logtrailid2+"";
                        }    

                        stmt.executeUpdate(sql);

                        JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Admin User Successfully Modified!");

                        Show_UsersLogtrail_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    // search by user ID
    private void btnSearchByUserIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByUserIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnSearchByUserIDActionPerformed

    //display current date and time
    private void btnDisplayCurentDateTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayCurentDateTimeActionPerformed
        // TODO add your handling code here:

        Date dNow = new Date( );
        SimpleDateFormat ft =
        new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss");

        //System.out.println("Current Date: " + ft.format(dNow));
        textCurDateTime.setText(ft.format(dNow));
    }//GEN-LAST:event_btnDisplayCurentDateTimeActionPerformed

    //clear all textboxes
    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        textUserID.setText("");
        textLogtrailID.setText("");
        textUserName.setText("");
        textLogtype.setText("");
        textDate.setText("");
        textTime.setText("");
        textCurDateTime.setText("");
    }//GEN-LAST:event_btnClearActionPerformed

    //save new record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("com.mysql.jdbc.Driver");

            String host;
            host="jdbc:mysql://localhost:3306/cablesalesinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            String logtrailID=textLogtrailID.getText().trim();
            int LogtrailID=Integer.parseInt(logtrailID);
            String userID=textUserID.getText().trim();
            int UserID=Integer.parseInt(userID);
            String logtype=comboLogtype.getItemAt(comboLogtype.getSelectedIndex());
            String date=textDate.getText().trim();
            String time=textTime.getText().trim();

            if(logtrailID.equals("")|| date.equals("")||userID.equals(""))
            {
                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " Sorry, Either the logtrailid or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
               
                Date date2= new Date();
                Date date3= new Date();
                
                SimpleDateFormat ft =  new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss");
                SimpleDateFormat ft2 =  new SimpleDateFormat ("yyyy.MM.dd");
                SimpleDateFormat ft3 =  new SimpleDateFormat ("hh:mm:ss");
                date=ft2.format(date2).toString().trim();
                String datex=ft3.format(date3).toString().trim();
                String sql="";
                try
                {
                    date2=ft2.parse(textDate.getText());
                    
                }
                catch(Exception e)
                {
                    try
                    {    
                        date2=ft2.parse(date);
                    }
                    catch(Exception ex)
                    {
                    
                    }    
                } 
                
                try
                {
                    date3=ft3.parse(textTime.getText());
                    
                }
                catch(Exception e)
                {
                   try
                    {    
                        date3=ft3.parse(datex);
                    }
                    catch(Exception ex)
                    {
                    
                    }
                }  
                 if(jRadioButtonAutoDate.isSelected()==true)
                        {    
                            sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+UserID+",'"+logtype+"', CURDATE(),CURTIME())";
                        }
                        else if(jRadioButtonManualDate.isSelected()==true)
                        {
                             sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+UserID+",'"+logtype+"', date2,date3)";
                        }    
                
                stmt.executeUpdate(sql);

                JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this,"A New User Logtrail is Added!");
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

                Show_UsersLogtrail_In_JTable();

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException ex)
        {
            JOptionPane.showMessageDialog(CableSalesInformationSystemUserLogtrailMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    // view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //search by username
    private void btnSearchByUserNameActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByUserNameActionPerformed
    {//GEN-HEADEREND:event_btnSearchByUserNameActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_UsersLogtrail_In_JTable();
    }//GEN-LAST:event_btnSearchByUserNameActionPerformed

    //manual date
    private void jRadioButtonManualDateActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonManualDateActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonManualDateActionPerformed
        // TODO add your handling code here:
        //jRadioButtonManualDate.setSelected(false);
        if(jRadioButtonManualDate.isSelected())
            jRadioButtonAutoDate.setSelected(!true);
        
    }//GEN-LAST:event_jRadioButtonManualDateActionPerformed

    //computerized date
    private void jRadioButtonAutoDateActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jRadioButtonAutoDateActionPerformed
    {//GEN-HEADEREND:event_jRadioButtonAutoDateActionPerformed
        // TODO add your handling code here:
        //jRadioButtonManualDate.setSelected(false);
        if(jRadioButtonAutoDate.isSelected())
            jRadioButtonManualDate.setSelected(!true);
    }//GEN-LAST:event_jRadioButtonAutoDateActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDisplayCurentDateTime;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByUserID;
    private javax.swing.JButton btnSearchByUserName;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JComboBox<String> comboLogtype;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButtonAutoDate;
    private javax.swing.JRadioButton jRadioButtonManualDate;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textCurDateTime;
    private javax.swing.JTextField textDate;
    private javax.swing.JTextField textLogtrailID;
    private javax.swing.JTextField textLogtype;
    private javax.swing.JTextField textTime;
    private javax.swing.JTextField textUserID;
    private javax.swing.JTextField textUserName;
    // End of variables declaration//GEN-END:variables
}
