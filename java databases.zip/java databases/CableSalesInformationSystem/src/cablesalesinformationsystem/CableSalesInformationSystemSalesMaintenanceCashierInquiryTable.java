/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cablesalesinformationsystem;

/**
 *
 * @author crazymix69
 */
public class CableSalesInformationSystemSalesMaintenanceCashierInquiryTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int authorid;
    String firstname; 
    String middlename; 
    String lastname; 
    String suffix; 
    String role; 
   
    public CableSalesInformationSystemSalesMaintenanceCashierInquiryTable
    (            
        int authorid,
        String firstname,
        String middlename, 
        String lastname, 
        String suffix, 
        String role 
        
    )
            
    {            
        this.authorid=authorid;        
        this.firstname=firstname;     
        this.middlename=middlename;
        this.lastname=lastname;
        this.suffix=suffix;
        this.role=role;

        
    }
    
    public int getAuthorID()
    {
        return authorid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    
    public String getMiddleName()
    {
        return middlename;
    }
    
    public String getLastName()
    {
        return lastname;
    }
    
    public String getSuffix()
    {
        return suffix;
    }
    
    public String getRole()
    {
        return role;
    }
    
    
    
}
