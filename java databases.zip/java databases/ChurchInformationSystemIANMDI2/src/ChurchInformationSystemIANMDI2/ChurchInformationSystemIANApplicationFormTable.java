/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANApplicationFormTable {

    /**
     * @param args the command line arguments
     */
      
    int applicationformid;
    int serviceid;
    int churchid;
    String churchname;
    String churchdescription;
    String servicetype;
    String servicedescription;
    String firstname;
    String middlename;
    String lastname;
    String birthdate;
    String sex;
    String birthplace;
    String citizenship;
    String address;
    String hobby;
       
    
    public ChurchInformationSystemIANApplicationFormTable
    (            
        int applicationformid,
        int serviceid,
        int churchid,
        String churchname,
        String churchdescription,
        String servicetype,
        String servicedescription,
        String firstname,
        String middlename,
        String lastname,
        String birthdate,
        String sex,
        String birthplace,
        String citizenship,
        String address,
        String hobby
    )
            
    {
        this.applicationformid=applicationformid;        
        this.serviceid=serviceid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.servicetype=servicetype;
        this.servicedescription=servicedescription;
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.birthdate=birthdate;
        this.sex=sex;
        this.birthplace=birthplace;
        this.citizenship=citizenship;
        this.address=address;
        this.hobby=hobby;       
    }
    
    public int getApplicationFormID()
    {
        return applicationformid;
    }
    
    public int getServiceID()
    {
        return serviceid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchsname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getServicetype()
    {
        return servicetype;
    }
    public String getServiceDescription()
    {
        return servicedescription;
    }
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getBirthDate()
    {
        return birthdate;
    }
    public String getSex()
    {
        return sex;
    }
    public String getBirthPlace()
    {
        return birthplace;
    }
    public String getCitizenship()
    {
        return citizenship;
    }
    public String getAddress()
    {
        return address;
    }
    public String getHobby()
    {
        return hobby;
    }   
}
