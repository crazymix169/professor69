/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class ChurchInformationSystemIANApplicationFormMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String churchid;
    String servicetype;
    String serviceid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public ChurchInformationSystemIANApplicationFormMaintenance(String Userid, String Username) {
        
        super("Application Form Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }
    
    public ChurchInformationSystemIANApplicationFormMaintenance() {
        super("Application Form Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid ";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description");
                String firstname=rs.getString("tbl_applicationform.firstname");
                String middlename=rs.getString("tbl_applicationform.middlename");
                String lastname=rs.getString("tbl_applicationform.lastname");
                String birthdate=rs.getString("tbl_applicationform.birthdate");
                String sex=rs.getString("tbl_applicationform.sex");
                String birthplace=rs.getString("tbl_applicationform.birthplace");
                String citizenship=rs.getString("tbl_applicationform.citizenship");
                String address=rs.getString("tbl_applicationform.address");
                String hobby=rs.getString("tbl_applicationform.hobby");

                textApplicationFormID.setText(Integer.toString(applicationformid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textBirthdate.setText(birthdate);
                textSex.setText(sex);
                textBirthplace.setText(birthplace);
                textCitizenship.setText(citizenship);
                textAddress.setText(address);
                textHobby.setText(hobby);
            
            }
            
            
            
            viewall=0;
            viewall2=0;
            Show_Services_In_JTable();
            Show_ApplicationForm_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANApplicationFormTable> getApplicationFormList()
    {
        ArrayList<ChurchInformationSystemIANApplicationFormTable> applicationformList= new ArrayList<ChurchInformationSystemIANApplicationFormTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid ";
            }
            else if(viewall==1)
            {
                
                churchname=textChurchName.getText().trim();
                servicetype=textServiceType.getText().trim();
                String firstname=textFirstName.getText().trim();
                String middlename=textMiddleName.getText().trim();
                String lastname=textLastName.getText().trim();
                
                
                 query ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid  and "
                        +"(tbl_church.churchname like '%"+churchname+"%' "
                        +"or tbl_applicationform.firstname like '%"+firstname+"%'or tbl_applicationform.middlename like '%"+middlename+"%'"
                        + "or tbl_applicationform.lastname like '%"+lastname+"%' or tbl_services.servicetype like '%"+servicetype+"%')";
            
                
            }
            else if(viewall==3) 
            {
                
                               
                serviceid=textServiceID.getText();
                int serviceid1=Integer.parseInt(serviceid);
                String firstnameid=textApplicationFormID.getText().trim();
                int firstnameid1=Integer.parseInt(firstnameid);
                
                 query ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid "
                        + "and (tbl_services.churchid= "+serviceid1+" or tbl_applicationform.applicationformid= "+firstnameid1+")";
            }
            else if(viewall==2) 
            {
                
                churchid=textChurchID.getText();
                int churchid1=Integer.parseInt(churchid);
                
                query ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid "
                        + " and tbl_services.churchid= "+churchid1+"";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            query ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                    + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                    + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                    + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                    + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                    + "and tbl_services.serviceid=tbl_applicationform.serviceid ";
            ChurchInformationSystemIANApplicationFormTable applicationform1;
            
            while(rs.next())
            {
                applicationform1 = new  ChurchInformationSystemIANApplicationFormTable(
                        rs.getInt("tbl_applicationform.applicationformid"),rs.getInt("tbl_services.serviceid"),
                        rs.getInt("tbl_church.churchid"),
                        rs.getString("tbl_church.churchname"),rs.getString("tbl_church.description")
                ,rs.getString("tbl_services.servicetype"),rs.getString("tbl_services.description"),
                        rs.getString("tbl_applicationform.firstname"),rs.getString("tbl_applicationform.middlename"),
                        rs.getString("tbl_applicationform.lastname"),rs.getString("tbl_applicationform.birthdate"),
                        rs.getString("tbl_applicationform.sex"), rs.getString("tbl_applicationform.birthplace"),
                        rs.getString("tbl_applicationform.citizenship")
                        ,rs.getString("tbl_applicationform.address"),rs.getString("tbl_applicationform.hobby"));
                applicationformList.add(applicationform1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+e.getMessage());
        }
        
        return applicationformList;
     
    }
    
    public void Show_ApplicationForm_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANApplicationFormTable> list = getApplicationFormList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[16];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getApplicationFormID();
            row[1]=list.get(i).getServiceID();
            row[2]=list.get(i).getChurchID();
            row[3]=list.get(i).getChurchsname();
            row[4]=list.get(i).getChurchDescription();
            row[5]=list.get(i).getServicetype();
            row[6]=list.get(i).getServiceDescription();
            row[7]=list.get(i).getFirstName();
            row[8]=list.get(i).getMiddleName();
            row[9]=list.get(i).getLastName();
            row[10]=list.get(i).getBirthDate();
            row[11]=list.get(i).getSex();
            row[12]=list.get(i).getBirthPlace();
            row[13]=list.get(i).getCitizenship();
            row[14]=list.get(i).getAddress();
            row[15]=list.get(i).getHobby();
                                                
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANServicesTable> getServicesList()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> servicesList= new ArrayList<ChurchInformationSystemIANServicesTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid ";
            }
            else if(viewall2==1)
            {
                churchname=textChurchName1.getText();
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and "
                        +"tbl_church.churchname like '%"+churchname+"%'";
                
            
            }
            else if(viewall2==2)
            {
                int gg;
                try
                {    
                    churchid=textChurchID1.getText();
                    gg=Integer.parseInt(churchid);
                }
                catch (Exception e)
                {
                    gg=0;
                }    
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and tbl_services.churchid= "+gg+"";
                
            }
            
               

            int i=1;
            
            Statement st;
          
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANServicesTable services1;
            
            while(rs2.next())
            {
                
                services1 = new  ChurchInformationSystemIANServicesTable(rs2.getInt("tbl_services.serviceid"),
                        rs2.getInt("tbl_church.churchid"), rs2.getString("tbl_church.churchname"),
                        rs2.getString("tbl_church.description"),rs2.getString("tbl_services.servicetype"),
                        rs2.getString("tbl_services.description"));
                servicesList.add(services1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+e.getMessage());
        }
        
        return servicesList;
     
    }
    
    public void Show_Services_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> list = getServicesList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getServiceID();
            row[1]=list.get(i).getChurchID();
            row[2]=list.get(i).getChurchsname();
            row[3]=list.get(i).getChurchDescription();
            row[4]=list.get(i).getServicetype();
            row[5]=list.get(i).getServiceDescription();
                                    
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textServiceType = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textChurchID = new javax.swing.JTextField();
        textChurchName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByChurchname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textServiceID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textChurchDescription = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textChurchID1 = new javax.swing.JTextField();
        textChurchName1 = new javax.swing.JTextField();
        btnSearchByChurchname1 = new javax.swing.JButton();
        btnSearchByChurchID = new javax.swing.JButton();
        btnSearchByChurchID1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textServiceDescription = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnSearchByApplicationFormID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textApplicationFormID = new javax.swing.JTextField();
        textFirstName = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textMiddleName = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textLastName = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textBirthdate = new javax.swing.JTextField();
        textSex = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        textBirthplace = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        textCitizenship = new javax.swing.JTextField();
        textAddress = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        textHobby = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Application Form ID", "Service ID", "Church ID", "Church Name", "Church Description", "Service Type", "Service Description", "First Name", "Middle Name", "Last Name", "Birthdate", "Sex", "Birth Place", "Citizenship", "Address", "Hobby"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Service type");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Service ID", "Church ID", "Church Name", "Church Description", "Service Type", "Service Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Church Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textChurchName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Church ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Church Name");

        btnSearchByChurchname.setText("Search by Church Name or Person  in Available Churches");
        btnSearchByChurchname.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Service ID");

        textChurchDescription.setBackground(new java.awt.Color(51, 255, 255));
        textChurchDescription.setColumns(20);
        textChurchDescription.setRows(5);
        jScrollPane1.setViewportView(textChurchDescription);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Churich ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Church Name");

        textChurchName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByChurchname1.setText("Search by Church Name");
        btnSearchByChurchname1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchname1ActionPerformed(evt);
            }
        });

        btnSearchByChurchID.setText("Search by Church ID in Available Churches");
        btnSearchByChurchID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchIDActionPerformed(evt);
            }
        });

        btnSearchByChurchID1.setText("Search by Church ID");
        btnSearchByChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchID1ActionPerformed(evt);
            }
        });

        textServiceDescription.setBackground(new java.awt.Color(51, 255, 255));
        textServiceDescription.setColumns(20);
        textServiceDescription.setRows(5);
        jScrollPane2.setViewportView(textServiceDescription);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Service Description");

        btnSearchByApplicationFormID.setText("Search by Application Form ID in Available Churches");
        btnSearchByApplicationFormID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByApplicationFormIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("ApplicationForm ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Middle Name");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText(" Last Name");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Birthdate");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Sex");

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Birthplace");

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Citizenship");

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Address");

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Hobby");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("First Name");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchByApplicationFormID))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(textChurchID))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(textApplicationFormID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textServiceID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnSearchByChurchname)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(16, 16, 16)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnSearchByChurchID)
                                        .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(10, 10, 10)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(47, 47, 47)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSearchByChurchID1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByChurchname1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(textChurchID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textChurchName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(textServiceType, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnPrevious)
                                        .addGap(25, 25, 25)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane5))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(435, 435, 435)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textBirthdate, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textSex, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textCitizenship, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textHobby, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textBirthplace, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByChurchname1)
                    .addComponent(btnSearchByChurchID1)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByApplicationFormID))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(textApplicationFormID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(textServiceID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textChurchID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchByChurchID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchByChurchname)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textServiceType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textBirthplace, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jLabel17))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9))
                            .addComponent(textMiddleName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel10))
                            .addComponent(textLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel11))
                            .addComponent(textBirthdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel12))
                            .addComponent(textSex, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel18))
                            .addComponent(textCitizenship, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel19))
                            .addComponent(textAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel20))
                            .addComponent(textHobby, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textApplicationFormID.setText(model.getValueAt(i, 0).toString());
            textServiceID.setText(model.getValueAt(i, 1).toString());
            textChurchID.setText(model.getValueAt(i, 2).toString());
            textChurchName.setText(model.getValueAt(i, 3).toString());
            textChurchDescription.setText(model.getValueAt(i, 4).toString());
            textServiceType.setText(model.getValueAt(i, 5).toString());
            textServiceDescription.setText(model.getValueAt(i, 6).toString());
            textFirstName.setText(model.getValueAt(i, 7).toString());
            textMiddleName.setText(model.getValueAt(i, 8).toString());
            textLastName.setText(model.getValueAt(i, 9).toString());
            textBirthdate.setText(model.getValueAt(i, 10).toString());
            textSex.setText(model.getValueAt(i, 11).toString());
            textBirthplace.setText(model.getValueAt(i, 12).toString());
            textCitizenship.setText(model.getValueAt(i, 13).toString());
            textAddress.setText(model.getValueAt(i, 14).toString());
            textHobby.setText(model.getValueAt(i, 15).toString());   
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textApplicationFormID.setText(model.getValueAt(i, 0).toString());
                textServiceID.setText(model.getValueAt(i, 1).toString());
                textChurchID.setText(model.getValueAt(i, 2).toString());
                textChurchName.setText(model.getValueAt(i, 3).toString());
                textChurchDescription.setText(model.getValueAt(i, 4).toString());
                textServiceType.setText(model.getValueAt(i, 5).toString());
                textServiceDescription.setText(model.getValueAt(i, 6).toString());
                textFirstName.setText(model.getValueAt(i, 7).toString());
                textMiddleName.setText(model.getValueAt(i, 8).toString());
                textLastName.setText(model.getValueAt(i, 9).toString());
                textBirthdate.setText(model.getValueAt(i, 10).toString());
                textSex.setText(model.getValueAt(i, 11).toString());
                textBirthplace.setText(model.getValueAt(i, 12).toString());
                textCitizenship.setText(model.getValueAt(i, 13).toString());
                textAddress.setText(model.getValueAt(i, 14).toString());
                textHobby.setText(model.getValueAt(i, 15).toString());


            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String applicationformid=textApplicationFormID.getText().trim();
                int applicationformid2=Integer.parseInt(applicationformid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_applicationform where applicationformid="+applicationformid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_applicationform"
                    + " where serviceid="+applicationformid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                
                
                String serviceid=textServiceID.getText().trim();
                int serviceid2=Integer.parseInt(serviceid);



                String firstname=textFirstName.getText().trim();
                String middlename=textMiddleName.getText().trim();
                String lastname=textLastName.getText().trim();
                String birthdate=textBirthdate.getText().trim();
                String sex=textSex.getText().trim();
                String birthplace=textBirthplace.getText().trim();
                String citizenship=textCitizenship.getText().trim();
                String address=textAddress.getText().trim();
                String hobby=textHobby.getText().trim();
                
                
                
                String applicationformid=textApplicationFormID.getText().trim();
                int applicationformid2 = Integer.parseInt(applicationformid);
                                               

                if(applicationformid.equals("")||serviceid.equals("")||firstname.equals("")
                   || middlename.equals("")|| lastname.equals("")|| birthdate.equals("")
                   || sex.equals("")|| birthplace.equals("")|| citizenship.equals("")
                   || address.equals("")|| hobby.equals(""))
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="";
                    sql ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                        + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                        + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                        + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                        + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                        + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                        + "and tbl_services.serviceid=tbl_applicationform.serviceid "
                        + "and ( tbl_applicationform.applicationformid="+applicationformid2+" or (tbl_services.serviceid="+serviceid2+" and tbl_applicationform.firstname='"+firstname+"' and "
                        + "tbl_applicationform.middlename='"+middlename+"' and tbl_applicationform.lastname='"+lastname+"'))";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " Sorry, No Record Found! ");
                    }
                    else if(rowCount==1)
                    {

                       

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                        
                        
                        sql="UPDATE `tbl_applicationform` SET `serviceid`="+serviceid2+",`firstname`='"+firstname+"',"
                                + "`middlename`='"+middlename+"',`lastname`='"+lastname+"',`birthdate`='"+birthdate+"',"
                                + "`sex`='"+sex+"',`birthplace`='"+birthplace+"',`citizenship`='"+citizenship+"',"
                                + "`address`='"+address+"',`hobby`='"+hobby+"' WHERE `applicationformid`="+applicationformid2+"";

                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                        + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                        + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                        + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                        + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                        + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                        + "and tbl_services.serviceid=tbl_applicationform.serviceid and tbl_applicationform.applicationformid="+applicationformid2+" ";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;
               

                        
                        

                        while ( rs.next( ) )
                        {
                            applicationformid2 = rs.getInt("tbl_applicationform.applicationformid");
                            serviceid2 = rs.getInt("tbl_services.serviceid");
                            int churchid2 = rs.getInt("tbl_church.churchid");
                            String churchname=rs.getString("tbl_church.churchname");
                            String churchdescription=rs.getString("tbl_church.description");
                            String servicetype=rs.getString("tbl_services.servicetype");
                            String servicedescription=rs.getString("tbl_services.description");
                            firstname=rs.getString("tbl_applicationform.firstname");
                            middlename=rs.getString("tbl_applicationform.middlename");
                            lastname=rs.getString("tbl_applicationform.lastname");
                            birthdate=rs.getString("tbl_applicationform.birthdate");
                            sex=rs.getString("tbl_applicationform.sex");
                            birthplace=rs.getString("tbl_applicationform.birthplace");
                            citizenship=rs.getString("tbl_applicationform.citizenship");
                            address=rs.getString("tbl_applicationform.address");
                            hobby=rs.getString("tbl_applicationform.hobby");
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textApplicationFormID.setText(Integer.toString(applicationformid2));
                                textServiceID.setText(Integer.toString(serviceid2));
                                textChurchID.setText(Integer.toString(churchid2));
                                textChurchName.setText(churchname);
                                textChurchDescription.setText(churchdescription);
                                textServiceType.setText(servicetype);
                                textServiceDescription.setText(servicedescription); 
                                textFirstName.setText(firstname);
                                textMiddleName.setText(middlename);
                                textLastName.setText(lastname);
                                textBirthdate.setText(birthdate);
                                textSex.setText(sex);
                                textBirthplace.setText(birthplace);
                                textCitizenship.setText(citizenship);
                                textAddress.setText(address);
                                textHobby.setText(hobby);
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
           

            
            
            String serviceid=textServiceID.getText().trim();
            int serviceid2=Integer.parseInt(serviceid);
                       

            
            String firstname=textFirstName.getText().trim();
            String middlename=textMiddleName.getText().trim();
            String lastname=textLastName.getText().trim();
            String birthdate=textBirthdate.getText().trim();
            String sex=textSex.getText().trim();
            String birthplace=textBirthplace.getText().trim();
            String citizenship=textCitizenship.getText().trim();
            String address=textAddress.getText().trim();
            String hobby=textHobby.getText().trim();
            
            
            

           if(serviceid.equals("")|| firstname.equals("")
                   || middlename.equals("")|| lastname.equals("")|| birthdate.equals("")
                   || sex.equals("")|| birthplace.equals("")|| citizenship.equals("")
                   || address.equals("")|| hobby.equals(""))
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and tbl_services.serviceid= "+serviceid2+"";
                rs = stmt.executeQuery(query);
                int rowCount2=0;

                while ( rs.next( ) )
                {
                    
                    rowCount2++;
                }
                
                stmt = con.createStatement( );
               
                String sql="";
                
                sql ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                        + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                        + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                        + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                        + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                        + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                        + "and tbl_services.serviceid=tbl_applicationform.serviceid "
                        + "and (tbl_services.serviceid="+serviceid2+" and tbl_applicationform.firstname='"+firstname+"' and "
                        + "tbl_applicationform.middlename='"+middlename+"' and tbl_applicationform.lastname='"+lastname+"')";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }

                if(rowCount==1||rowCount2==0)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    
                    
                    sql="INSERT INTO `tbl_applicationform`(`applicationformid`, `serviceid`, `firstname`, `middlename`, `lastname`, "
                            + "`birthdate`, `sex`, `birthplace`, `citizenship`, `address`, `hobby`) "
                            + "VALUES (NULL,"+serviceid2+",'"+firstname+"',"
                            + "'"+middlename+"','"+lastname+"','"+birthdate+"',"
                            + "'"+sex+"','"+birthplace+"','"+citizenship+"',"
                            + "'"+address+"','"+hobby+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_services where churchid="+churchid2+" ";
                    //sql="Select * from tbl_services ";
                    sql ="SELECT tbl_applicationform.applicationformid, tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname,"
                        + " tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                        + "tbl_applicationform.firstname, tbl_applicationform.middlename, tbl_applicationform.lastname, "
                        + "tbl_applicationform.birthdate, tbl_applicationform.sex, tbl_applicationform.birthplace, "
                        + "tbl_applicationform.citizenship, tbl_applicationform.address, tbl_applicationform.hobby "
                        + "FROM `tbl_applicationform`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid "
                        + "and tbl_services.serviceid=tbl_applicationform.serviceid ";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
                    serviceid2 = rs.getInt("tbl_services.serviceid");
                    int churchid2 = rs.getInt("tbl_church.churchid");
                    churchname=rs.getString("tbl_church.churchname");
                    String churchdescription=rs.getString("tbl_church.description");
                    servicetype=rs.getString("tbl_services.servicetype");
                    String servicedescription=rs.getString("tbl_services.description");
                    firstname=rs.getString("tbl_applicationform.firstname");
                    middlename=rs.getString("tbl_applicationform.middlename");
                    lastname=rs.getString("tbl_applicationform.lastname");
                    birthdate=rs.getString("tbl_applicationform.birthdate");
                    sex=rs.getString("tbl_applicationform.sex");
                    birthplace=rs.getString("tbl_applicationform.birthplace");
                    citizenship=rs.getString("tbl_applicationform.citizenship");
                    address=rs.getString("tbl_applicationform.address");
                    hobby=rs.getString("tbl_applicationform.hobby");

                    textApplicationFormID.setText(Integer.toString(applicationformid));
                    textServiceID.setText(Integer.toString(serviceid2));
                    textChurchID.setText(Integer.toString(churchid2));
                    textChurchName.setText(churchname);
                    textChurchDescription.setText(churchdescription);
                    textServiceType.setText(servicetype);
                    textServiceDescription.setText(servicedescription); 
                    textFirstName.setText(firstname);
                    textMiddleName.setText(middlename);
                    textLastName.setText(lastname);
                    textBirthdate.setText(birthdate);
                    textSex.setText(sex);
                    textBirthplace.setText(birthplace);
                    textCitizenship.setText(citizenship);
                    textAddress.setText(address);
                    textHobby.setText(hobby);

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " new inserted record item: "+Double.toString(serviceid2));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Services_In_JTable();
                    Show_ApplicationForm_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textApplicationFormID.setText("");
            textServiceID.setText("");
            textChurchID.setText("");
            textChurchName.setText("");
            textChurchDescription.setText("");
            textServiceType.setText("");
            textServiceDescription.setText("");
            textFirstName.setText("");
            textMiddleName.setText("");
            textLastName.setText("");
            textBirthdate.setText("");
            textSex.setText("");
            textBirthplace.setText("");
            textCitizenship.setText("");
            textAddress.setText("");
            textHobby.setText("");           

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description");
            String firstname=rs.getString("tbl_applicationform.firstname");
            String middlename=rs.getString("tbl_applicationform.middlename");
            String lastname=rs.getString("tbl_applicationform.lastname");
            String birthdate=rs.getString("tbl_applicationform.birthdate");
            String sex=rs.getString("tbl_applicationform.sex");
            String birthplace=rs.getString("tbl_applicationform.birthplace");
            String citizenship=rs.getString("tbl_applicationform.citizenship");
            String address=rs.getString("tbl_applicationform.address");
            String hobby=rs.getString("tbl_applicationform.hobby");

            textApplicationFormID.setText(Integer.toString(applicationformid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textBirthdate.setText(birthdate);
            textSex.setText(sex);
            textBirthplace.setText(birthplace);
            textCitizenship.setText(citizenship);
            textAddress.setText(address);
            textHobby.setText(hobby);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description");
                String firstname=rs.getString("tbl_applicationform.firstname");
                String middlename=rs.getString("tbl_applicationform.middlename");
                String lastname=rs.getString("tbl_applicationform.lastname");
                String birthdate=rs.getString("tbl_applicationform.birthdate");
                String sex=rs.getString("tbl_applicationform.sex");
                String birthplace=rs.getString("tbl_applicationform.birthplace");
                String citizenship=rs.getString("tbl_applicationform.citizenship");
                String address=rs.getString("tbl_applicationform.address");
                String hobby=rs.getString("tbl_applicationform.hobby");

                textApplicationFormID.setText(Integer.toString(applicationformid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textBirthdate.setText(birthdate);
                textSex.setText(sex);
                textBirthplace.setText(birthplace);
                textCitizenship.setText(citizenship);
                textAddress.setText(address);
                textHobby.setText(hobby);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                
                textApplicationFormID.setText("");
                textServiceID.setText("");
                textChurchID.setText("");
                textChurchName.setText("");
                textChurchDescription.setText("");
                textServiceType.setText("");
                textServiceDescription.setText("");
                textFirstName.setText("");
                textMiddleName.setText("");
                textLastName.setText("");
                textBirthdate.setText("");
                textSex.setText("");
                textBirthplace.setText("");
                textCitizenship.setText("");
                textAddress.setText("");
                textHobby.setText("");   

                textChurchID1.setText("");
                textChurchName1.setText("");
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textApplicationFormID.setText("");
        textServiceID.setText("");
        textChurchID.setText("");
        textChurchName.setText("");
        textChurchDescription.setText("");
        textServiceType.setText("");
        textServiceDescription.setText("");
        textFirstName.setText("");
        textMiddleName.setText("");
        textLastName.setText("");
        textBirthdate.setText("");
        textSex.setText("");
        textBirthplace.setText("");
        textCitizenship.setText("");
        textAddress.setText("");
        textHobby.setText("");   
        
        textChurchID1.setText("");
        textChurchName1.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search church Name
    private void btnSearchByChurchnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchnameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchnameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description");
                String firstname=rs.getString("tbl_applicationform.firstname");
                String middlename=rs.getString("tbl_applicationform.middlename");
                String lastname=rs.getString("tbl_applicationform.lastname");
                String birthdate=rs.getString("tbl_applicationform.birthdate");
                String sex=rs.getString("tbl_applicationform.sex");
                String birthplace=rs.getString("tbl_applicationform.birthplace");
                String citizenship=rs.getString("tbl_applicationform.citizenship");
                String address=rs.getString("tbl_applicationform.address");
                String hobby=rs.getString("tbl_applicationform.hobby");

                textApplicationFormID.setText(Integer.toString(applicationformid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textBirthdate.setText(birthdate);
                textSex.setText(sex);
                textBirthplace.setText(birthplace);
                textCitizenship.setText(citizenship);
                textAddress.setText(address);
                textHobby.setText(hobby);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description");
            String firstname=rs.getString("tbl_applicationform.firstname");
            String middlename=rs.getString("tbl_applicationform.middlename");
            String lastname=rs.getString("tbl_applicationform.lastname");
            String birthdate=rs.getString("tbl_applicationform.birthdate");
            String sex=rs.getString("tbl_applicationform.sex");
            String birthplace=rs.getString("tbl_applicationform.birthplace");
            String citizenship=rs.getString("tbl_applicationform.citizenship");
            String address=rs.getString("tbl_applicationform.address");
            String hobby=rs.getString("tbl_applicationform.hobby");

            textApplicationFormID.setText(Integer.toString(applicationformid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textBirthdate.setText(birthdate);
            textSex.setText(sex);
            textBirthplace.setText(birthplace);
            textCitizenship.setText(citizenship);
            textAddress.setText(address);
            textHobby.setText(hobby);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description");
                String firstname=rs.getString("tbl_applicationform.firstname");
                String middlename=rs.getString("tbl_applicationform.middlename");
                String lastname=rs.getString("tbl_applicationform.lastname");
                String birthdate=rs.getString("tbl_applicationform.birthdate");
                String sex=rs.getString("tbl_applicationform.sex");
                String birthplace=rs.getString("tbl_applicationform.birthplace");
                String citizenship=rs.getString("tbl_applicationform.citizenship");
                String address=rs.getString("tbl_applicationform.address");
                String hobby=rs.getString("tbl_applicationform.hobby");

                textApplicationFormID.setText(Integer.toString(applicationformid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textFirstName.setText(firstname);
                textMiddleName.setText(middlename);
                textLastName.setText(lastname);
                textBirthdate.setText(birthdate);
                textSex.setText(sex);
                textBirthplace.setText(birthplace);
                textCitizenship.setText(citizenship);
                textAddress.setText(address);
                textHobby.setText(hobby);

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int applicationformid = rs.getInt("tbl_applicationform.applicationformid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description");
            String firstname=rs.getString("tbl_applicationform.firstname");
            String middlename=rs.getString("tbl_applicationform.middlename");
            String lastname=rs.getString("tbl_applicationform.lastname");
            String birthdate=rs.getString("tbl_applicationform.birthdate");
            String sex=rs.getString("tbl_applicationform.sex");
            String birthplace=rs.getString("tbl_applicationform.birthplace");
            String citizenship=rs.getString("tbl_applicationform.citizenship");
            String address=rs.getString("tbl_applicationform.address");
            String hobby=rs.getString("tbl_applicationform.hobby");

            textApplicationFormID.setText(Integer.toString(applicationformid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textFirstName.setText(firstname);
            textMiddleName.setText(middlename);
            textLastName.setText(lastname);
            textBirthdate.setText(birthdate);
            textSex.setText(sex);
            textBirthplace.setText(birthplace);
            textCitizenship.setText(citizenship);
            textAddress.setText(address);
            textHobby.setText(hobby);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANApplicationFormMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search by church Name
    private void btnSearchByChurchname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchname1ActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchname1ActionPerformed

    //search church ID
    private void btnSearchByChurchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_ApplicationForm_In_JTable();
        
    }//GEN-LAST:event_btnSearchByChurchIDActionPerformed

    //search by church ID
    private void btnSearchByChurchID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchID1ActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchID1ActionPerformed

    //search Application Form ID
    private void btnSearchByApplicationFormIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByApplicationFormIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByApplicationFormIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_ApplicationForm_In_JTable();
    }//GEN-LAST:event_btnSearchByApplicationFormIDActionPerformed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyTyped
    {//GEN-HEADEREND:event_jTable2KeyTyped
        // TODO add your handling code here:
        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textServiceID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textServiceType.setText(model.getValueAt(i, 4).toString());
                textServiceDescription.setText(model.getValueAt(i, 5).toString());

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2KeyTyped

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyPressed
    {//GEN-HEADEREND:event_jTable2KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textServiceID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textServiceType.setText(model.getValueAt(i, 4).toString());
                textServiceDescription.setText(model.getValueAt(i, 5).toString());

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable2MouseClicked
    {//GEN-HEADEREND:event_jTable2MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textServiceID.setText(model.getValueAt(i, 0).toString());
            textChurchID.setText(model.getValueAt(i, 1).toString());
            textChurchName.setText(model.getValueAt(i, 2).toString());
            textChurchDescription.setText(model.getValueAt(i, 3).toString());
            textServiceType.setText(model.getValueAt(i, 4).toString());
            textServiceDescription.setText(model.getValueAt(i, 5).toString());
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByApplicationFormID;
    private javax.swing.JButton btnSearchByChurchID;
    private javax.swing.JButton btnSearchByChurchID1;
    private javax.swing.JButton btnSearchByChurchname;
    private javax.swing.JButton btnSearchByChurchname1;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField textAddress;
    private javax.swing.JTextField textApplicationFormID;
    private javax.swing.JTextField textBirthdate;
    private javax.swing.JTextField textBirthplace;
    private javax.swing.JTextArea textChurchDescription;
    private javax.swing.JTextField textChurchID;
    private javax.swing.JTextField textChurchID1;
    private javax.swing.JTextField textChurchName;
    private javax.swing.JTextField textChurchName1;
    private javax.swing.JTextField textCitizenship;
    private javax.swing.JTextField textFirstName;
    private javax.swing.JTextField textHobby;
    private javax.swing.JTextField textLastName;
    private javax.swing.JTextField textMiddleName;
    private javax.swing.JTextArea textServiceDescription;
    private javax.swing.JTextField textServiceID;
    private javax.swing.JTextField textServiceType;
    private javax.swing.JTextField textSex;
    // End of variables declaration//GEN-END:variables
}
