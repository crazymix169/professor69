/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANPriestTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int priestid;
    int churchid;
    String churchname;
    String churchdescription;
    String priestfirstname;
    String priestmiddlename;
    String priestlastname;
    
    
    
    
    public ChurchInformationSystemIANPriestTable
    (            
    int priestid,
    int churchid,
    String churchname,
    String churchdescription,
    String priestfirstname,
    String priestmiddlename,
    String priestlastname
    )
            
    {       
        this.priestid=priestid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.priestfirstname=priestfirstname;
        this.priestmiddlename=priestmiddlename;
        this.priestlastname=priestlastname;     
        
    }
    
    public int getPriestID()
    {
        return priestid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchName()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getPriestFirstName()
    {
        return priestfirstname;
    }
    public String getPriestMiddleName()
    {
        return priestmiddlename;
    }
    public String getPriestLastName()
    {
        return priestlastname;
    }
    
}
