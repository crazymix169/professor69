/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class ChurchInformationSystemIANRecordsMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String churchid;
    String recordstitle;
    String recordsid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public ChurchInformationSystemIANRecordsMaintenance(String Userid, String Username) {
        
        super("Records Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }
    
    public ChurchInformationSystemIANRecordsMaintenance() {
        super("Records Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        initComponents();
        
        DoConnect();
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_records";
            sql="";
            sql = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;
            
            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                int recordsid = rs.getInt("recordsid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String recordstitle=rs.getString("recordstitle");
                String recordsdescription=rs.getString("tbl_records.description");         

                textRecordsID.setText(Integer.toString(recordsid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textRecordsTitle.setText(recordstitle);
                textRecordsDescription.setText(recordsdescription);   
            
            }
               
            
            viewall=0;
            viewall2=0;
            Show_Church_In_JTable();
            Show_Records_In_JTable();
            
            //stmt.close();
            //con.close();
            /*
            stmt2 = con.createStatement( );
            sql="Select * from tbl_church where churchid="+churchid+"";
            rs2 = stmt2.executeQuery(sql);

            rowCount=0;

            rs2.next( ); 
            
            int id_col2 = rs2.getInt("churchid");
            
            String churchname2 = rs2.getString("churchname");
            String churchdescription2 = rs2.getString("churchdescription");
            

            //textGoodsID.setText(Integer.toString(id_col2));
           
            textGoodsName.setText(churchname2);
            textGoodsDescription.setText(churchdescription2);*/
            
            //stmt.close();
            //con.close();
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANRecordsTable> getRecords()
    {
        ArrayList<ChurchInformationSystemIANRecordsTable> recordsList= new ArrayList<ChurchInformationSystemIANRecordsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid";
            }
            else if(viewall==1)
            {
                
                churchname=textChurchName.getText().trim();
                recordstitle=textRecordsTitle.getText().trim();
                
                query = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid and"
                        +"(tbl_church.churchname like '%"+churchname+"%' or tbl_records.recordstitle like '%"+recordstitle+"%')";
            
            }
            else if(viewall==3) 
            {
                
                
                recordsid=textRecordsID.getText();
                int recordsid1=Integer.parseInt(recordsid);
                query = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid and tbl_records.recordsid= "+recordsid1+" ";
            }
            else if(viewall==2)
            {
                
                
                
                churchid=textChurchID.getText();
                int churchid1=Integer.parseInt(churchid);
                query = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid and tbl_records.churchid= "+churchid1+" ";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANRecordsTable records1;
            
            while(rs.next())
            {
                records1 = new  ChurchInformationSystemIANRecordsTable(rs.getInt("recordsid"),rs.getInt("churchid"),
                        rs.getString("churchname"),rs.getString("tbl_church.description"),rs.getString("recordstitle"),
                        rs.getString("tbl_records.description"));
                recordsList.add(records1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+e.getMessage());
            
        }
        
        return recordsList;
     
    }
    
    public void Show_Records_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANRecordsTable> list = getRecords();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getRecordsID();
            row[1]=list.get(i).getChurchID();
            row[2]=list.get(i).getChurchsname();
            row[3]=list.get(i).getChurchDescription();
            row[4]=list.get(i).getRecordsTitle();
            row[5]=list.get(i).getRecordsDescription();
            
            
                        
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANChurchTable> getChurchList()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> churchList= new ArrayList<ChurchInformationSystemIANChurchTable>();
        Connection connection = getConnection();
          
        try
        {
            
            if(viewall2==0)
            {
                query = "Select * from tbl_church";
            }
            else if(viewall2==1)
            {
                churchname=textChurchName1.getText();
                query = "Select * from tbl_church where churchname like '%"+churchname+"%'";

            }
            else  if(viewall2==2)
            {
                churchid=textChurchID1.getText();
                int gg=Integer.parseInt(churchid);
                query="Select * from tbl_church where churchid= "+gg+"";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANChurchTable church1;
            
            while(rs2.next())
            {
                church1 = new  ChurchInformationSystemIANChurchTable(rs2.getInt("churchid"), rs2.getString("churchname"), 
                              rs2.getString("description"));
                churchList.add(church1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " church search "+e.getMessage());
        }
        
        return churchList;
     
    }
    
    public void Show_Church_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> list = getChurchList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getChurchID();
            row[1]=list.get(i).getChurchName();
            row[2]=list.get(i).getChurchDescription();
                        
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textRecordsTitle = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textChurchID = new javax.swing.JTextField();
        textChurchName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByChurchname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textRecordsID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textChurchDescription = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textChurchID1 = new javax.swing.JTextField();
        textChurchName1 = new javax.swing.JTextField();
        btnSearchByChurchname1 = new javax.swing.JButton();
        btnSearchByChurchID = new javax.swing.JButton();
        btnSearchByChurchID1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textRecordsDescription = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnSearchByRecordsID = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Records ID", "Church ID", "Church Name", "Church Description", "Records Title", "Records Description"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Records Title");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Church ID", "Church Name", "Church Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Church Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textChurchName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Church ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Church Name");

        btnSearchByChurchname.setText("Search by Church Name or Records Title  in Available Churches");
        btnSearchByChurchname.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Records ID");

        textChurchDescription.setBackground(new java.awt.Color(51, 255, 255));
        textChurchDescription.setColumns(20);
        textChurchDescription.setRows(5);
        jScrollPane1.setViewportView(textChurchDescription);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Churich ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Church Name");

        textChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                textChurchID1ActionPerformed(evt);
            }
        });

        textChurchName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByChurchname1.setText("Search by Church Name");
        btnSearchByChurchname1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchname1ActionPerformed(evt);
            }
        });

        btnSearchByChurchID.setText("Search by Church ID in Available Churches");
        btnSearchByChurchID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchIDActionPerformed(evt);
            }
        });

        btnSearchByChurchID1.setText("Search by Church ID");
        btnSearchByChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchID1ActionPerformed(evt);
            }
        });

        textRecordsDescription.setBackground(new java.awt.Color(51, 255, 255));
        textRecordsDescription.setColumns(20);
        textRecordsDescription.setRows(5);
        jScrollPane2.setViewportView(textRecordsDescription);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Records Description");

        btnSearchByRecordsID.setText("Search by Records ID in Available Churches");
        btnSearchByRecordsID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRecordsIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(92, 92, 92))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(14, 14, 14)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(16, 16, 16)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(10, 10, 10))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSearchByChurchID)
                            .addComponent(btnSearchByRecordsID)
                            .addComponent(textChurchID, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                            .addComponent(textChurchName)
                            .addComponent(textRecordsID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSearchByChurchID1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByChurchname1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(textChurchID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textChurchName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnSearchByChurchname)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(10, 10, 10))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(textRecordsTitle, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByChurchname1)
                    .addComponent(btnSearchByChurchID1)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByRecordsID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textRecordsID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textChurchID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addGap(136, 136, 136))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                                .addComponent(btnSearchByChurchID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addGap(10, 10, 10)
                                .addComponent(btnSearchByChurchname)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textRecordsTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textRecordsID.setText(model.getValueAt(i, 0).toString());
            textChurchID.setText(model.getValueAt(i, 1).toString());
            textChurchName.setText(model.getValueAt(i, 2).toString());
            textChurchDescription.setText(model.getValueAt(i, 3).toString());  
            textRecordsTitle.setText(model.getValueAt(i, 4).toString());
            textRecordsDescription.setText(model.getValueAt(i, 5).toString());
        }
        catch(Exception e)
        {
            
        }

       
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textRecordsID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textRecordsTitle.setText(model.getValueAt(i, 4).toString());
                textRecordsDescription.setText(model.getValueAt(i, 5).toString());


            }
        
        }
        catch(Exception e)
        {
            
        }
        
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Record?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String recordsid=textRecordsID.getText().trim();
                int recordsid2=Integer.parseInt(recordsid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_records where recordsid="+recordsid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                   

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    

                    sql="DELETE FROM  tbl_records"
                    + " where recordsid="+recordsid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String recordsid=textRecordsID.getText().trim();
                int recordsid2=Integer.parseInt(recordsid);

                String churchid=textChurchID.getText().trim();
                int churchid2=Integer.parseInt(churchid);
                
                String churchname=textChurchName.getText().trim();
                String churchdescription=textChurchDescription.getText().trim();
                String recordstitle=textRecordsTitle.getText().trim();
                String recordsdescription=textRecordsDescription.getText().trim();
                                               

                if(recordsid.equals("")|| churchid.equals("")|| churchname.equals("")|| churchdescription.equals("")||
                        recordstitle.equals("")|| recordsdescription.equals(""))
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql="Select * from tbl_records where recordsid="+recordsid2+" "
                            + "or (churchid="+churchid2+" and ) ";
                    sql="SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                            + "WHERE tbl_records.recordsid="+recordsid2+" or (tbl_church.churchid="+churchid2+" and tbl_records.recordstitle='"+recordstitle+"')";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " Sorry, No Record Found or potential duplicate upon editing! ");
                    }
                    else
                    {                   

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                        

                        sql="Update tbl_records"
                        + " SET  tbl_records.churchid="+churchid2+",tbl_records.recordstitle='"+recordstitle+"',tbl_records.description="+recordsdescription+""
                        + " where tbl_records.recordsid="+recordsid2+"";
                        
                        sql="UPDATE `tbl_records` SET `churchid`="+churchid2+",`recordstitle`='"+recordstitle+"',"
                                + "`description`='"+recordsdescription+"' WHERE `recordsid`="+recordsid2+"";

                        stmt.executeUpdate(sql);

                        

                        stmt = con.createStatement( );
                        sql="Select * from tbl_records where recordsid="+recordsid2+" ";
                        sql="SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                            + "WHERE tbl_records.recordsid="+recordsid2+"";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            recordsid2 = rs.getInt("recordsid");
                            churchid2 = rs.getInt("churchid");
                            churchname=rs.getString("churchname");
                            churchdescription=rs.getString("tbl_church.description");
                            recordstitle=rs.getString("recordstitle");
                            recordsdescription=rs.getString("tbl_records.description");

                            rowCount++;
                            if(rowCount==1)
                            {
                                textRecordsID.setText(Integer.toString(recordsid2));
                                textChurchID.setText(Integer.toString(churchid2));
                                textChurchName.setText(churchname);
                                textChurchDescription.setText(churchdescription);
                                textRecordsTitle.setText(recordstitle);
                                textRecordsDescription.setText(recordsdescription);
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        //Show_Church_In_JTable();
                        //Show_Records_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save new record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
           

            String churchid=textChurchID.getText().trim();
            int churchid2=Integer.parseInt(churchid);

            String churchname=textChurchName.getText().trim();
            String churchdescription=textChurchDescription.getText().trim();
            String recordstitle=textRecordsTitle.getText().trim();
            String recordsdescription=textRecordsDescription.getText().trim();

           if(churchid.equals("")||
                        recordstitle.equals("")|| recordsdescription.equals(""))
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                String sql="Select * from tbl_records ";
                sql = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_records.churchid="+churchid2+" and tbl_records.recordstitle='"+recordstitle+"'";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " Sorry, Record already exists! ");
                }
                else
                {
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_records " + "VALUES (NULL,"+churchid2+", '"+recordstitle+"','"+recordsdescription+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_records where churchid="+churchid2+" ";
                    //sql="Select * from tbl_records ";
                    
                    sql = "SELECT tbl_records.recordsid,tbl_church.churchid,tbl_church.churchname,tbl_church.description, "
                    + "tbl_records.recordstitle, tbl_records.description FROM `tbl_records`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_records.churchid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int recordsid2=rs.getInt("recordsid");

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " new inserted record item: "+Double.toString(recordsid2));

                    /*
                    stmt2 = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_stocktrail " + "VALUES (NULL,"+recordsid2+", 'stockin', '"+date+"', '"+time+"')";

                    stmt2.executeUpdate(sql);*/

                    //JOptionPane.showMessageDialog(ChurchInformationSystemIANActivitiesMaintenance.this,"A New Stock Item is Added!");
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Church_In_JTable();
                    Show_Records_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textRecordsID.setText("");
            textChurchID.setText("");
            textChurchName.setText("");
            textChurchDescription.setText("");
            textRecordsTitle.setText("");
            textRecordsDescription.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try {
            rs.absolute( curRow );

            int recordsid = rs.getInt("recordsid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String recordstitle=rs.getString("recordstitle");
            String recordsdescription=rs.getString("tbl_records.description");         

            textRecordsID.setText(Integer.toString(recordsid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textRecordsTitle.setText(recordstitle);
            textRecordsDescription.setText(recordsdescription);            

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int recordsid = rs.getInt("recordsid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String recordstitle=rs.getString("recordstitle");
                String recordsdescription=rs.getString("tbl_records.description");         

                textRecordsID.setText(Integer.toString(recordsid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textRecordsTitle.setText(recordstitle);
                textRecordsDescription.setText(recordsdescription);           

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {                       

                textChurchID.setText("");
                textChurchName.setText("");
                textChurchDescription.setText("");

                textRecordsID.setText("");
                textRecordsDescription.setText("");
                textRecordsTitle.setText("");

                textChurchID1.setText("");
                textChurchName1.setText(""); 
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        
        try
        {    
            
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textChurchID.setText(model.getValueAt(i, 0).toString());
            textChurchName.setText(model.getValueAt(i, 1).toString());
            textChurchDescription.setText(model.getValueAt(i, 2).toString());

            
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:

        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyTyped

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textChurchID.setText("");
        textChurchName.setText("");
        textChurchDescription.setText("");

        textRecordsID.setText("");
        textRecordsDescription.setText("");
        textRecordsTitle.setText("");
        
        textChurchID1.setText("");
        textChurchName1.setText("");
       

    }//GEN-LAST:event_btnClearAllActionPerformed

    //SEARCH BY church Name or records title
    private void btnSearchByChurchnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchnameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchnameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int recordsid = rs.getInt("recordsid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String recordstitle=rs.getString("recordstitle");
                String recordsdescription=rs.getString("tbl_records.description");         

                textRecordsID.setText(Integer.toString(recordsid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textRecordsTitle.setText(recordstitle);
                textRecordsDescription.setText(recordsdescription);      

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //move first
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int recordsid = rs.getInt("recordsid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String recordstitle=rs.getString("recordstitle");
            String recordsdescription=rs.getString("tbl_records.description");         

            textRecordsID.setText(Integer.toString(recordsid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textRecordsTitle.setText(recordstitle);
            textRecordsDescription.setText(recordsdescription);      

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to MDI Form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int recordsid = rs.getInt("recordsid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String recordstitle=rs.getString("recordstitle");
                String recordsdescription=rs.getString("tbl_records.description");         

                textRecordsID.setText(Integer.toString(recordsid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textRecordsTitle.setText(recordstitle);
                textRecordsDescription.setText(recordsdescription);      

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int recordsid = rs.getInt("recordsid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String recordstitle=rs.getString("recordstitle");
            String recordsdescription=rs.getString("tbl_records.description");         

            textRecordsID.setText(Integer.toString(recordsid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textRecordsTitle.setText(recordstitle);
            textRecordsDescription.setText(recordsdescription);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRecordsMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search by church Name
    private void btnSearchByChurchname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchname1ActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchname1ActionPerformed

    //search by church ID
    private void btnSearchByChurchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Records_In_JTable();
        
    }//GEN-LAST:event_btnSearchByChurchIDActionPerformed

    //search by church ID
    private void btnSearchByChurchID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchID1ActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchID1ActionPerformed

    //search by records ID
    private void btnSearchByRecordsIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByRecordsIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByRecordsIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Records_In_JTable();
    }//GEN-LAST:event_btnSearchByRecordsIDActionPerformed

    private void textChurchID1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_textChurchID1ActionPerformed
    {//GEN-HEADEREND:event_textChurchID1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textChurchID1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByChurchID;
    private javax.swing.JButton btnSearchByChurchID1;
    private javax.swing.JButton btnSearchByChurchname;
    private javax.swing.JButton btnSearchByChurchname1;
    private javax.swing.JButton btnSearchByRecordsID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea textChurchDescription;
    private javax.swing.JTextField textChurchID;
    private javax.swing.JTextField textChurchID1;
    private javax.swing.JTextField textChurchName;
    private javax.swing.JTextField textChurchName1;
    private javax.swing.JTextArea textRecordsDescription;
    private javax.swing.JTextField textRecordsID;
    private javax.swing.JTextField textRecordsTitle;
    // End of variables declaration//GEN-END:variables
}
