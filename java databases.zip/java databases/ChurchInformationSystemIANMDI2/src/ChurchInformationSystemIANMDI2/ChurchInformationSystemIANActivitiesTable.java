/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANActivitiesTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int activitiesid;
    int churchid;
    String churchname;
    String churchdescription;
    String activitytype;
    String activitydescription;
    
    
    
    
    
    public ChurchInformationSystemIANActivitiesTable
    (            
        int activitiesid,
        int churchid,
        String churchname,
        String churchdescription,
        String activitytype,
        String activitydescription    
    )
            
    {
              
        
        this.activitiesid=activitiesid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.activitytype=activitytype;
        this.activitydescription=activitydescription;
                      
        
    }
    
    public int getActivitiesID()
    {
        return activitiesid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getActivitiestype()
    {
        return activitytype;
    }
    public String getActivitiesDescription()
    {
        return activitydescription;
    }
    
}
