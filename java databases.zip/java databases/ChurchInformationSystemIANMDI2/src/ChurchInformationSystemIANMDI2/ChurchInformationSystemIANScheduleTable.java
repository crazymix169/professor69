/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANScheduleTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int scheduleid;
    int priestid;
    int churchid;
    String churchname;
    String churchdescription;
    String priestfirstname;
    String priestmiddlename;
    String priestlastname;
    String starttime;
    String endtime;
    String scheduletype;
    
    
    public ChurchInformationSystemIANScheduleTable
    (
        int scheduleid,
        int priestid,
        int churchid,
        String churchname,
        String churchdescription,
        String priestfirstname,
        String priestmiddlename,
        String priestlastname,
        String starttime,
        String endtime,
        String scheduletype    
    )
    {
        this.scheduleid=scheduleid;
        this.priestid=priestid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.priestfirstname=priestfirstname;
        this.priestmiddlename=priestmiddlename;
        this.priestlastname=priestlastname;  
        this.starttime=starttime;
        this.endtime=endtime;
        this.scheduletype=scheduletype;
    }
    
    public int getScheduleID()
    {
        return scheduleid;
    }
    
    public int getPriestID()
    {
        return priestid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchName()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getPriestFirstName()
    {
        return priestfirstname;
    }
    public String getPriestMiddleName()
    {
        return priestmiddlename;
    }
    public String getPriestLastName()
    {
        return priestlastname;
    }
    public String getStartTime()
    {
        return starttime;
    }
    public String getEndTime()
    {
        return endtime;
    }
    public String getScheduleType()
    {
        return scheduletype;
    }    
}
