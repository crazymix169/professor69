/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class TORSystemInstructorTable {

    /**
     * @param args the command line arguments
     */
      
    int instructorid;
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    String sex;
    String birthdate;               
    String address;
    String hobby;
    String clubs;   
    String comment;
    String status;
    String mastersdegree;
    String doctorate;   
    String seminars;
    String researches;
    
       
    
    public TORSystemInstructorTable
    (            
        int instructorid,        
        String firstname,
        String middlename,
        String lastname,
        String suffix,
        String sex,
        String birthdate,               
        String address,
        String hobby,  
        String clubs,        
        String comment,
        String status,
        String mastersdegree,
        String doctorate,   
        String seminars,
        String researches
        
    )
            
    {
        this.instructorid=instructorid; 
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.suffix=suffix;
        this.sex=sex;
        this.birthdate=birthdate;       
        this.address=address;
        this.hobby=hobby;
        this.clubs=clubs;                
        this.comment=comment;  
        this.status=status; 
        this.mastersdegree=mastersdegree;
        this.doctorate=doctorate;   
        this.seminars=seminars;
        this.researches=researches;
               
    }
    
    public int getInstructorID()
    {
        return instructorid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getSuffix()
    {
        return suffix;
    }
    public String getSex()
    {
        return sex;
    }
    public String getBirthDate()
    {
        return birthdate;
    }    
    
    public String getAddress()
    {
        return address;
    }
    public String getHobby()
    {
        return hobby;
    }  
    
    public String getClubs()
    {
        return clubs;
    }   
    
    public String getComment()
    {
        return comment;
    }   
    public String getStatus()
    {
        return status;
    } 
    
    public String getMastersDegree()
    {
        return mastersdegree;
    } 
    public String getDoctorate()
    {
        return doctorate;
    } 
    public String getSeminars()
    {
        return seminars;
    } 
    public String getResearches()
    {
        return researches;
    } 
     
}
