/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class TORSystemCourseMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String courseid;
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
        
    
    
    public TORSystemCourseMaintenance() {
        super("Course Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Course_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_course`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int courseid = rs.getInt("courseid");
                String coursecode=rs.getString("coursecode");
                String coursetitle=rs.getString("coursetitle");
                String courseobjectives=rs.getString("courseobjectives");
                String coursemission=rs.getString("coursemission");
                String coursevision=rs.getString("coursevision");                
                String coursedescription=rs.getString("coursedescription");                

                textCourseID.setText(Integer.toString(courseid));
                textCourseCode.setText(coursecode);
                textCourseTitle.setText(coursetitle);
                textCourseObjectives.setText(courseobjectives); 
                textCourseMission.setText(coursemission); 
                textCourseVision.setText(coursevision); 
                textCourseDescription.setText(coursedescription);                
            
            }           
            
            viewall=0;           
            Show_Course_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<TORSystemCourseTable> getCourseList()
    {
        ArrayList<TORSystemCourseTable> applicationformList= new ArrayList<TORSystemCourseTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_course`";;
            }            
            else if(viewall==3) 
            {               
                               
                
                String courseid=textCourseID.getText().trim();
                int courseid1=Integer.parseInt(courseid);
                
                query ="SELECT * FROM `tbl_course` WHERE courseid= "+courseid1+"";
            }
            else if(viewall==2) 
            {
                
                
                String coursecode=textCourseCode.getText();
                String coursetitle=textCourseTitle.getText();
                
                query ="SELECT * FROM `tbl_course` WHERE  "
                        + "coursecode like '%"+coursecode+"%' or "
                        + "coursetitle like '%"+coursetitle+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            TORSystemCourseTable course1;
            
            while(rs.next())
            {
                course1 = new  TORSystemCourseTable(
                        rs.getInt("courseid"),rs.getString("coursecode"),rs.getString("coursetitle"),
                        rs.getString("courseobjectives"),rs.getString("coursemission"),rs.getString("coursevision"),                        
                        rs.getString("coursedescription"));
                applicationformList.add(course1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " error269: "+e.getMessage());
        }
        
        return applicationformList;
     
    }
    
    public void Show_Course_In_JTable()
    {
        ArrayList<TORSystemCourseTable> list = getCourseList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[7];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCourseID();
            row[1]=list.get(i).getCourseCode();
            row[2]=list.get(i).getCourseTitle();
            row[3]=list.get(i).getCourseObjectives();
            row[4]=list.get(i).getCourseMission();
            row[5]=list.get(i).getCourseVision();
            row[6]=list.get(i).getCourseDescription();
                          
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textCourseCode = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textCourseObjectives = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByCourseCodeORCourseTitle = new javax.swing.JButton();
        btnSearchByCourseID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textCourseID = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        textCourseDescription = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        textCourseTitle = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        textCourseMission = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        textCourseVision = new javax.swing.JTextField();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Course ID", "Course Code", "Course Title", "Course Ojectives", "Mission", "Vision", "Course Description"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Court Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Course Code");

        textCourseObjectives.setBackground(new java.awt.Color(51, 255, 255));
        textCourseObjectives.setColumns(20);
        textCourseObjectives.setRows(5);
        jScrollPane1.setViewportView(textCourseObjectives);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByCourseCodeORCourseTitle.setText("Search by Coure Code or Course Title");
        btnSearchByCourseCodeORCourseTitle.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCourseCodeORCourseTitleActionPerformed(evt);
            }
        });

        btnSearchByCourseID.setText("Search by Course ID ");
        btnSearchByCourseID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByCourseIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Course ID");

        textCourseDescription.setBackground(new java.awt.Color(51, 255, 255));
        textCourseDescription.setColumns(20);
        textCourseDescription.setRows(5);
        jScrollPane2.setViewportView(textCourseDescription);

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Course Objectives");

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Course Title");

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Course Mission");

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel18.setText("Course Vision");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textCourseCode, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearchByCourseCodeORCourseTitle))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(btnBackToMDIForm)
                .addGap(30, 30, 30)
                .addComponent(btnSearchByCourseID)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textCourseMission, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textCourseVision, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnDelete))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(textCourseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 27, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(435, 435, 435)
                                .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByCourseID))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(textCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(textCourseCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(textCourseMission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(textCourseVision, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(btnSearchByCourseCodeORCourseTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(textCourseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnViewAll)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnEdit)
                                .addComponent(btnNewRecord)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnCancelNewRecord)
                                .addComponent(btnClearAll))
                            .addComponent(btnSaveRecord))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 289, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields
        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textCourseID.setText(model.getValueAt(i, 0).toString());
            textCourseCode.setText(model.getValueAt(i, 1).toString());
            textCourseTitle.setText(model.getValueAt(i, 2).toString()); 
            textCourseObjectives.setText(model.getValueAt(i, 3).toString());  
            textCourseMission.setText(model.getValueAt(i, 4).toString()); 
            textCourseVision.setText(model.getValueAt(i, 5).toString()); 
            textCourseDescription.setText(model.getValueAt(i, 6).toString());
        }
        catch(Exception e)
        {
        }    
            
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textCourseID.setText(model.getValueAt(i, 0).toString());
                textCourseCode.setText(model.getValueAt(i, 1).toString());
                textCourseTitle.setText(model.getValueAt(i, 2).toString()); 
                textCourseObjectives.setText(model.getValueAt(i, 3).toString());  
                textCourseMission.setText(model.getValueAt(i, 4).toString()); 
                textCourseVision.setText(model.getValueAt(i, 5).toString()); 
                textCourseDescription.setText(model.getValueAt(i, 6).toString());


            }
        }
        catch(Exception e)
        {
        }  
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String courseid=textCourseID.getText().trim();
                int courseid2=Integer.parseInt(courseid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_course` where courseid"+courseid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  `tbl_course`"
                    + " where courseid="+courseid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String courseid = textCourseID.getText().trim();
                int courseid2=Integer.parseInt(courseid);
                String coursecode=textCourseCode.getText().trim();
                String coursetitle=textCourseTitle.getText().trim();
                String courseobjectives=textCourseObjectives.getText().trim(); 
                String coursemission=textCourseMission.getText().trim();
                String coursevision=textCourseVision.getText().trim();    
                String coursedescription=textCourseDescription.getText().trim();                               
              
               
                
                
                
                
                 
                
                
                
                                               

                if(courseid.equals("")||coursecode.equals("")|| coursemission.equals("")||
                        coursedescription.equals("")|| courseobjectives.equals("")
                   || coursetitle.equals("")|| coursevision.equals(""))
                {
                    JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_course` where "
                            + "courseid="+courseid+" or (coursecode='"+coursecode+"')";;
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                           
                        
                        sql="";
                        
                        sql="UPDATE `tbl_course` SET `coursecode`='"+coursecode+"',"
                                + "`coursetitle`='"+coursetitle+"',`courseobjectives`='"+courseobjectives+"',"
                                + "`coursemission`='"+coursemission+"',`coursevision`='"+coursevision+"',"
                                + "`coursedescription`='"+coursedescription+"' WHERE `courseid`="+courseid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_course` where "
                            + "courseid="+courseid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            rowCount++;
                            if(rowCount==1)
                            {
                                courseid2 = rs.getInt("courseid");
                                coursecode=rs.getString("coursecode");
                                coursetitle=rs.getString("coursetitle");
                                courseobjectives=rs.getString("courseobjectives");
                                coursemission=rs.getString("coursemission");
                                coursevision=rs.getString("coursevision");                
                                coursedescription=rs.getString("coursedescription");                

                                textCourseID.setText(Integer.toString(courseid2));
                                textCourseCode.setText(coursecode);
                                textCourseTitle.setText(coursetitle);
                                textCourseObjectives.setText(courseobjectives); 
                                textCourseMission.setText(coursemission); 
                                textCourseVision.setText(coursevision); 
                                textCourseDescription.setText(coursedescription);                                
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            //String courseid = textCourseID.getText().trim();
            //int courseid2=Integer.parseInt(courseid);
            String coursecode=textCourseCode.getText().trim();
            String coursetitle=textCourseTitle.getText().trim();
            String courseobjectives=textCourseObjectives.getText().trim();
            String coursemission=textCourseMission.getText().trim();
            String coursevision=textCourseVision.getText().trim();    
            String coursedescription=textCourseDescription.getText().trim();   
            
            
                   
            

           if(coursecode.equals("")|| coursemission.equals("")||coursedescription.equals("")|| courseobjectives.equals("")
                   || coursetitle.equals("")|| coursevision.equals(""))
            {
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_course` where coursecode='"+coursecode+"'";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="";
                    sql="INSERT INTO `tbl_course`(`courseid`, `coursecode`, `coursetitle`, `courseobjectives`, "
                            + "`coursemission`, `coursevision`, `coursedescription`) "
                            + "VALUES (NULL,'"+coursecode+"','"+coursetitle+"','"+courseobjectives+"',"
                            + "'"+coursemission+"','"+coursevision+"','"+coursedescription+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_course`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int courseid = rs.getInt("courseid");
                    coursecode=rs.getString("coursecode");
                    coursetitle=rs.getString("coursetitle");
                    courseobjectives=rs.getString("courseobjectives");
                    coursemission=rs.getString("coursemission");
                    coursevision=rs.getString("coursevision");                
                    coursedescription=rs.getString("coursedescription");                

                    textCourseID.setText(Integer.toString(courseid));
                    textCourseCode.setText(coursecode);
                    textCourseTitle.setText(coursetitle);
                    textCourseObjectives.setText(courseobjectives); 
                    textCourseMission.setText(coursemission); 
                    textCourseVision.setText(coursevision); 
                    textCourseDescription.setText(coursedescription);         

                    JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " new inserted record item: "+Double.toString(courseid));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_Course_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textCourseID.setText("");
            textCourseCode.setText("");
            textCourseTitle.setText("");
            textCourseObjectives.setText("");
            textCourseMission.setText(""); 
            textCourseVision.setText(""); 
            textCourseDescription.setText("");
              

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int courseid = rs.getInt("courseid");
            String coursecode=rs.getString("coursecode");
            String coursetitle=rs.getString("coursetitle");
            String courseobjectives=rs.getString("courseobjectives");
            String coursemission=rs.getString("coursemission");
            String coursevision=rs.getString("coursevision");                
            String coursedescription=rs.getString("coursedescription");                

            textCourseID.setText(Integer.toString(courseid));
            textCourseCode.setText(coursecode);
            textCourseTitle.setText(coursetitle);
            textCourseObjectives.setText(courseobjectives); 
            textCourseMission.setText(coursemission); 
            textCourseVision.setText(coursevision); 
            textCourseDescription.setText(coursedescription);        

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int courseid = rs.getInt("courseid");
                String coursecode=rs.getString("coursecode");
                String coursetitle=rs.getString("coursetitle");
                String courseobjectives=rs.getString("courseobjectives");
                String coursemission=rs.getString("coursemission");
                String coursevision=rs.getString("coursevision");                
                String coursedescription=rs.getString("coursedescription");                

                textCourseID.setText(Integer.toString(courseid));
                textCourseCode.setText(coursecode);
                textCourseTitle.setText(coursetitle);
                textCourseObjectives.setText(courseobjectives); 
                textCourseMission.setText(coursemission); 
                textCourseVision.setText(coursevision); 
                textCourseDescription.setText(coursedescription);        

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {                 

                textCourseID.setText("");
                textCourseCode.setText("");
                textCourseTitle.setText("");
                textCourseObjectives.setText("");
                textCourseMission.setText(""); 
                textCourseVision.setText(""); 
                textCourseDescription.setText("");
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textCourseID.setText("");
        textCourseCode.setText("");
        textCourseTitle.setText("");
        textCourseObjectives.setText("");
        textCourseMission.setText(""); 
        textCourseVision.setText(""); 
        textCourseDescription.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int courseid = rs.getInt("courseid");
                String coursecode=rs.getString("coursecode");
                String coursetitle=rs.getString("coursetitle");
                String courseobjectives=rs.getString("courseobjectives");
                String coursemission=rs.getString("coursemission");
                String coursevision=rs.getString("coursevision");                
                String coursedescription=rs.getString("coursedescription");                

                textCourseID.setText(Integer.toString(courseid));
                textCourseCode.setText(coursecode);
                textCourseTitle.setText(coursetitle);
                textCourseObjectives.setText(courseobjectives); 
                textCourseMission.setText(coursemission); 
                textCourseVision.setText(coursevision); 
                textCourseDescription.setText(coursedescription);        

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;      
        
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int courseid = rs.getInt("courseid");
            String coursecode=rs.getString("coursecode");
            String coursetitle=rs.getString("coursetitle");
            String courseobjectives=rs.getString("courseobjectives");
            String coursemission=rs.getString("coursemission");
            String coursevision=rs.getString("coursevision");                
            String coursedescription=rs.getString("coursedescription");                

            textCourseID.setText(Integer.toString(courseid));
            textCourseCode.setText(coursecode);
            textCourseTitle.setText(coursetitle);
            textCourseObjectives.setText(courseobjectives); 
            textCourseMission.setText(coursemission); 
            textCourseVision.setText(coursevision); 
            textCourseDescription.setText(coursedescription);         

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int courseid = rs.getInt("courseid");
                String coursecode=rs.getString("coursecode");
                String coursetitle=rs.getString("coursetitle");
                String courseobjectives=rs.getString("courseobjectives");
                String coursemission=rs.getString("coursemission");
                String coursevision=rs.getString("coursevision");                
                String coursedescription=rs.getString("coursedescription");                

                textCourseID.setText(Integer.toString(courseid));
                textCourseCode.setText(coursecode);
                textCourseTitle.setText(coursetitle);
                textCourseObjectives.setText(courseobjectives); 
                textCourseMission.setText(coursemission); 
                textCourseVision.setText(coursevision); 
                textCourseDescription.setText(coursedescription);       

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int courseid = rs.getInt("courseid");
            String coursecode=rs.getString("coursecode");
            String coursetitle=rs.getString("coursetitle");
            String courseobjectives=rs.getString("courseobjectives");
            String coursemission=rs.getString("coursemission");
            String coursevision=rs.getString("coursevision");                
            String coursedescription=rs.getString("coursedescription");                

            textCourseID.setText(Integer.toString(courseid));
            textCourseCode.setText(coursecode);
            textCourseTitle.setText(coursetitle);
            textCourseObjectives.setText(courseobjectives); 
            textCourseMission.setText(coursemission); 
            textCourseVision.setText(coursevision); 
            textCourseDescription.setText(coursedescription);        

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemCourseMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search coursecode
    private void btnSearchByCourseCodeORCourseTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByCourseCodeORCourseTitleActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Course_In_JTable();
        
    }//GEN-LAST:event_btnSearchByCourseCodeORCourseTitleActionPerformed

    //search Legal Person ID
    private void btnSearchByCourseIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByCourseIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByCourseIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnSearchByCourseIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByCourseCodeORCourseTitle;
    private javax.swing.JButton btnSearchByCourseID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textCourseCode;
    private javax.swing.JTextArea textCourseDescription;
    private javax.swing.JTextField textCourseID;
    private javax.swing.JTextField textCourseMission;
    private javax.swing.JTextArea textCourseObjectives;
    private javax.swing.JTextField textCourseTitle;
    private javax.swing.JTextField textCourseVision;
    // End of variables declaration//GEN-END:variables
}
