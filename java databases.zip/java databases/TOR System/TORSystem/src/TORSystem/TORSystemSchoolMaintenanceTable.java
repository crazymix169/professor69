/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

/**
 *
 * @author crazymix69
 */
public class TORSystemSchoolMaintenanceTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int schoolid;
    String schoolname;
    String schooldescription;
    String mission;
    String vision;
    String address;
    
    
    
    
    
    
    public TORSystemSchoolMaintenanceTable
    (            
        int schoolid,
        String schoolname,
        String schooldescription,
        String mission,
        String vision,
        String address
    )
            
    {    
        
        this.schoolid=schoolid;        
        this.schoolname=schoolname;
        this.schooldescription=schooldescription;
        this.mission=mission;
        this.vision=vision;        
        this.address=address;                     
        
    }
    
    public int getSchoolID()
    {
        return schoolid;
    }
    
    public String getSchoolName()
    {
        return schoolname;
    }
    
    public String getSchoolDescription()
    {
        return schooldescription;
    }
    public String getSchoolMission()
    {
        return mission;
    }
    public String getSchoolVision()
    {
        return vision;
    }    
    public String getSchoolAddress()
    {
        return address;
    }
    
    
}
