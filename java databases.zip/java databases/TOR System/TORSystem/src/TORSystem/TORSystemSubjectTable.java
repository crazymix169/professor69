/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class TORSystemSubjectTable {

    /**
     * @param args the command line arguments
     */
      
    int subjectid;
    String subjectcode;
    String subjecttitle;
    String subjectdescription;
    String subjectobjectives;
    
       
    
    public TORSystemSubjectTable
    (            
        int subjectid,
        String subjectcode,
        String subjecttitle,
        String subjectdescription,
        String subjectobjectives
        
    )
            
    {
        this.subjectid=subjectid;        
        this.subjectcode=subjectcode;
        this.subjecttitle=subjecttitle;
        this.subjectdescription=subjectdescription;
        this.subjectobjectives=subjectobjectives;        
        
    }
    
    public int getSubjectID()
    {
        return subjectid;
    }
    
    public String getSubjectCode()
    {
        return subjectcode;
    }
    
    public String getSubjectTitle()
    {
        return subjecttitle;
    }
    public String getSubjectDescription()
    {
        return subjectdescription;
    }
    public String getSubjectObjectives()
    {
        return subjectobjectives;
    }    
    
}
