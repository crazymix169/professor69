/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class TORSystemSubjectMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String subjectid;
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public TORSystemSubjectMaintenance() {
        super("Subject Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_Subject_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_subject`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int subjectid = rs.getInt("subjectid");
                String subjectcode=rs.getString("subjectcode");
                String subjecttitle=rs.getString("subjecttitle");
                String subjectdescription=rs.getString("subjectdescription");
                String subjectobjectives=rs.getString("subjectobjectives");                

                textSubjectID.setText(Integer.toString(subjectid));
                textSubjectCode.setText(subjectcode);
                textSubjectTitle.setText(subjecttitle);
                textSubjectDescription.setText(subjectdescription);
                textSubjectObjectives.setText(subjectobjectives);                
                
            
            }           
            
            viewall=0;           
            
            Show_Subject_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<TORSystemSubjectTable> getSubjectList()
    {
        ArrayList<TORSystemSubjectTable> subjectList= new ArrayList<TORSystemSubjectTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_subject`";;
            }
            
            else if(viewall==3) 
            {
                
                               
                
                String subjectid=textSubjectID.getText().trim();
                int subjectid1=Integer.parseInt(subjectid);
                
                query ="SELECT * FROM `tbl_subject` WHERE subjectid = "+subjectid1+"";
            }
            else if(viewall==2) 
            {
                
                String subjecttitle=textSubjectTitle.getText();
                String subjectcode=textSubjectCode.getText();
                
                query ="SELECT * FROM `tbl_subject` WHERE subjectdescription like '%"+subjecttitle+"%' or "
                        + "subjectcode like '%"+subjectcode+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            TORSystemSubjectTable subject1;
            
            while(rs.next())
            {
                subject1 = new  TORSystemSubjectTable(
                        rs.getInt("subjectid"),rs.getString("subjectcode"),
                        rs.getString("subjecttitle"),
                        rs.getString("subjectdescription"),rs.getString("subjectobjectives")
                        );
                subjectList.add(subject1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " error269: "+e.getMessage());
        }
        
        return subjectList;
     
    }
    
    public void Show_Subject_In_JTable()
    {
        ArrayList<TORSystemSubjectTable> list = getSubjectList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSubjectID();
            row[1]=list.get(i).getSubjectCode();
            row[2]=list.get(i).getSubjectTitle();
            row[3]=list.get(i).getSubjectDescription();
            row[4]=list.get(i).getSubjectObjectives();            
                
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textSubjectTitle = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textSubjectCode = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textSubjectObjectives = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchBySubjectCodeOrSubjectTitle = new javax.swing.JButton();
        btnSearchBySubjectID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textSubjectID = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        textSubjectDescription = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Subject ID", "Subject Code", "Subject Title", "Subject Description", "Subject Objectives"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Subject Objectives");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Subject Title");

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Subject Code");

        textSubjectObjectives.setBackground(new java.awt.Color(51, 255, 255));
        textSubjectObjectives.setColumns(20);
        textSubjectObjectives.setRows(5);
        jScrollPane1.setViewportView(textSubjectObjectives);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchBySubjectCodeOrSubjectTitle.setText("Search by Subject Code or Subject Title");
        btnSearchBySubjectCodeOrSubjectTitle.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySubjectCodeOrSubjectTitleActionPerformed(evt);
            }
        });

        btnSearchBySubjectID.setText("Search by Subject ID ");
        btnSearchBySubjectID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchBySubjectIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Subject ID");

        textSubjectDescription.setBackground(new java.awt.Color(51, 255, 255));
        textSubjectDescription.setColumns(20);
        textSubjectDescription.setRows(5);
        jScrollPane2.setViewportView(textSubjectDescription);

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Subject Description");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnPrevious)
                                        .addGap(25, 25, 25)
                                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSaveRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnCancelNewRecord)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane5))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(435, 435, 435)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnBackToMDIForm)
                        .addGap(30, 30, 30)
                        .addComponent(btnSearchBySubjectID))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(textSubjectID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(textSubjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnSearchBySubjectCodeOrSubjectTitle)
                                .addComponent(textSubjectTitle)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchBySubjectID))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(textSubjectID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(textSubjectCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textSubjectTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSearchBySubjectCodeOrSubjectTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textSubjectID.setText(model.getValueAt(i, 0).toString());
            textSubjectCode.setText(model.getValueAt(i, 1).toString());
            textSubjectTitle.setText(model.getValueAt(i, 2).toString());
            textSubjectDescription.setText(model.getValueAt(i, 3).toString());
            textSubjectObjectives.setText(model.getValueAt(i, 4).toString());    
        
        }
        catch(Exception e)
        {
        }
            
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textSubjectID.setText(model.getValueAt(i, 0).toString());
                textSubjectCode.setText(model.getValueAt(i, 1).toString());
                textSubjectTitle.setText(model.getValueAt(i, 2).toString());
                textSubjectDescription.setText(model.getValueAt(i, 3).toString());
                textSubjectObjectives.setText(model.getValueAt(i, 4).toString());   

            }
        
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String subjectid=textSubjectID.getText().trim();
                int subjectid2=Integer.parseInt(subjectid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_subject` where subjectid="+subjectid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  `tbl_subject` "
                    + " where subjectid="+subjectid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String subjectid = textSubjectID.getText().trim();
                int subjectid2=Integer.parseInt(subjectid);
                String subjectcode=textSubjectCode.getText().trim();
                String subjecttitle=textSubjectTitle.getText().trim();
                String subjectdescription=textSubjectDescription.getText().trim();
                String subjectobjectives=textSubjectObjectives.getText().trim(); 
                
                
                
                
                                               

                if(subjectid.equals("")||subjectcode.equals("")||
                    subjecttitle.equals("")|| subjectdescription.equals("")|| subjectobjectives.equals("")
                   )
                {
                    JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
                    String sql= "SELECT * FROM `tbl_subject` where "
                            + "subjectid="+subjectid+" or (subjectcode='"+subjectcode+"' "
                        + "and subjecttitle='"+subjecttitle+"' )";;
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2)
                    {
                        JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing");
                    }
                    else if(rowCount==1)
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        sql="UPDATE `tbl_subject` "
                                + "SET `subjectcode`='"+subjectcode+"',"
                                + "`subjecttitle`='"+subjecttitle+"',`subjectdescription`='"+subjectdescription+"',"
                                + "`subjectobjectives`='"+subjectobjectives+"' "
                                + " WHERE `subjectid`="+subjectid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_subject` where "
                            + "subjectid="+subjectid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            subjectid2 = rs.getInt("subjectid");
                            subjectcode=rs.getString("subjectcode");
                            subjecttitle=rs.getString("subjecttitle");
                            subjectdescription=rs.getString("subjectdescription");
                            subjectobjectives=rs.getString("subjectobjectives");
                            

                            
                            
                            

                            rowCount++;
                            if(rowCount==1)
                            {
                                textSubjectID.setText(Integer.toString(subjectid2));
                                textSubjectCode.setText(subjectcode);
                                textSubjectTitle.setText(subjecttitle);
                                textSubjectDescription.setText(subjectdescription);
                                textSubjectObjectives.setText(subjectobjectives);                
                                
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            //String subjectid = textLegalPersonID.getText().trim();
            //int subjectid2=Integer.parseInt(subjectid);
            String subjectcode=textSubjectCode.getText().trim();
            String subjecttitle=textSubjectTitle.getText().trim();
            String subjectdescription=textSubjectDescription.getText().trim();
            String subjectobjectives=textSubjectObjectives.getText().trim();
            
                   
            

           if(subjectcode.equals("")|| subjecttitle.equals("")|| 
                   subjectdescription.equals("")|| subjectobjectives.equals("")
                   )
            {
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                query = "SELECT * FROM `tbl_subject` where subjectcode='"+subjectcode+"' "
                        + "and subjecttitle='"+subjecttitle+"' ";
                rs = stmt.executeQuery(query);
                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                

                if(rowCount==1)
                {
                    JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " Sorry, Individual already exists! ");
                }
                else
                {            
                    
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="INSERT INTO `tbl_subject`(`subjectid`, `subjectcode`, `subjecttitle`, `subjectdescription`, `subjectobjectives`) "
                            + "VALUES (NULL,'"+subjectcode+"','"+subjecttitle+"','"+subjectdescription+"','"+subjectobjectives+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_subject`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int subjectid = rs.getInt("subjectid");
                    subjectcode=rs.getString("subjectcode");
                    subjecttitle=rs.getString("subjecttitle");
                    subjectdescription=rs.getString("subjectdescription");
                    subjectobjectives=rs.getString("subjectobjectives");                   

                    textSubjectID.setText(Integer.toString(subjectid));
                    textSubjectCode.setText(subjectcode);
                    textSubjectTitle.setText(subjecttitle);
                    textSubjectDescription.setText(subjectdescription);
                    textSubjectObjectives.setText(subjectobjectives);                
                    

                    JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " new inserted record item: "+Double.toString(subjectid));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_Subject_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textSubjectID.setText("");
            textSubjectCode.setText("");
            textSubjectTitle.setText("");
            textSubjectDescription.setText("");
            textSubjectObjectives.setText("");                
              

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int subjectid = rs.getInt("subjectid");
            String subjectcode=rs.getString("subjectcode");
            String subjecttitle=rs.getString("subjecttitle");
            String subjectdescription=rs.getString("subjectdescription");
            String subjectobjectives=rs.getString("subjectobjectives");                

            textSubjectID.setText(Integer.toString(subjectid));
            textSubjectCode.setText(subjectcode);
            textSubjectTitle.setText(subjecttitle);
            textSubjectDescription.setText(subjectdescription);
            textSubjectObjectives.setText(subjectobjectives);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int subjectid = rs.getInt("subjectid");
                String subjectcode=rs.getString("subjectcode");
                String subjecttitle=rs.getString("subjecttitle");
                String subjectdescription=rs.getString("subjectdescription");
                String subjectobjectives=rs.getString("subjectobjectives");                

                textSubjectID.setText(Integer.toString(subjectid));
                textSubjectCode.setText(subjectcode);
                textSubjectTitle.setText(subjecttitle);
                textSubjectDescription.setText(subjectdescription);
                textSubjectObjectives.setText(subjectobjectives);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textSubjectID.setText("");
                textSubjectCode.setText("");
                textSubjectTitle.setText("");
                textSubjectDescription.setText("");
                textSubjectObjectives.setText("");                
                
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textSubjectID.setText("");
        textSubjectCode.setText("");
        textSubjectTitle.setText("");
        textSubjectDescription.setText("");
        textSubjectObjectives.setText("");                
        

    }//GEN-LAST:event_btnClearAllActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int subjectid = rs.getInt("subjectid");
                String subjectcode=rs.getString("subjectcode");
                String subjecttitle=rs.getString("subjecttitle");
                String subjectdescription=rs.getString("subjectdescription");
                String subjectobjectives=rs.getString("subjectobjectives");                

                textSubjectID.setText(Integer.toString(subjectid));
                textSubjectCode.setText(subjectcode);
                textSubjectTitle.setText(subjecttitle);
                textSubjectDescription.setText(subjectdescription);
                textSubjectObjectives.setText(subjectobjectives);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int subjectid = rs.getInt("subjectid");
            String subjectcode=rs.getString("subjectcode");
            String subjecttitle=rs.getString("subjecttitle");
            String subjectdescription=rs.getString("subjectdescription");
            String subjectobjectives=rs.getString("subjectobjectives");                

            textSubjectID.setText(Integer.toString(subjectid));
            textSubjectCode.setText(subjectcode);
            textSubjectTitle.setText(subjecttitle);
            textSubjectDescription.setText(subjectdescription);
            textSubjectObjectives.setText(subjectobjectives);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int subjectid = rs.getInt("subjectid");
                String subjectcode=rs.getString("subjectcode");
                String subjecttitle=rs.getString("subjecttitle");
                String subjectdescription=rs.getString("subjectdescription");
                String subjectobjectives=rs.getString("subjectobjectives");                

                textSubjectID.setText(Integer.toString(subjectid));
                textSubjectCode.setText(subjectcode);
                textSubjectTitle.setText(subjecttitle);
                textSubjectDescription.setText(subjectdescription);
                textSubjectObjectives.setText(subjectobjectives);

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int subjectid = rs.getInt("subjectid");
                String subjectcode=rs.getString("subjectcode");
                String subjecttitle=rs.getString("subjecttitle");
                String subjectdescription=rs.getString("subjectdescription");
                String subjectobjectives=rs.getString("subjectobjectives");                

                textSubjectID.setText(Integer.toString(subjectid));
                textSubjectCode.setText(subjectcode);
                textSubjectTitle.setText(subjecttitle);
                textSubjectDescription.setText(subjectdescription);
                textSubjectObjectives.setText(subjectobjectives);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemSubjectMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search subjectdescription or legal person type
    private void btnSearchBySubjectCodeOrSubjectTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchBySubjectCodeOrSubjectTitleActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Subject_In_JTable();
        
    }//GEN-LAST:event_btnSearchBySubjectCodeOrSubjectTitleActionPerformed

    //search Legal Person ID
    private void btnSearchBySubjectIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchBySubjectIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchBySubjectIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnSearchBySubjectIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchBySubjectCodeOrSubjectTitle;
    private javax.swing.JButton btnSearchBySubjectID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField textSubjectCode;
    private javax.swing.JTextArea textSubjectDescription;
    private javax.swing.JTextField textSubjectID;
    private javax.swing.JTextArea textSubjectObjectives;
    private javax.swing.JTextField textSubjectTitle;
    // End of variables declaration//GEN-END:variables
}
