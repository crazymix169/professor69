/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

/**
 *
 * @author crazymix69
 */

public class TORSystemCourseTable
{
 
    int courseid;
    String coursecode;
    String coursetitle;
    String courseobjectives;
    String coursemission;
    String coursevision;
    String coursedescription;
    
    
    public TORSystemCourseTable(
            int courseid, String coursecode,String coursetitle, String courseobjectives,
            String coursemission,
            String coursevision,
            String coursedescription)
    {
        this.courseid=courseid;
        this.coursecode=coursecode;
        this.coursetitle=coursetitle;
        this.courseobjectives=courseobjectives;  
        this.coursemission=coursemission;
        this.coursevision=coursevision;
        this.courseobjectives=courseobjectives;
        
    }
    
    public int getCourseID()
    {
        return courseid;
    }
    
    public String getCourseCode()
    {
        return coursecode;
    }
    
    public String getCourseTitle()
    {
        return coursetitle;
    }
    
    public String getCourseObjectives()
    {
        return courseobjectives;
    }  
    public String getCourseMission()
    {
        return coursemission;
    }
    public String getCourseVision()
    {
        return coursevision;
    }
    public String getCourseDescription()
    {
        return coursedescription;
    }
    
        
}
