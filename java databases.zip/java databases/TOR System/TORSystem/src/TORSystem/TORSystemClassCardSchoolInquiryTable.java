/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

/**
 *
 * @author crazymix69
 */
public class TORSystemClassCardSchoolInquiryTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int schoolid;
    String schoolname; 
   
    public TORSystemClassCardSchoolInquiryTable
    (            
        int schoolid,
        String schoolname
        
    )
            
    {            
        this.schoolid=schoolid;        
        this.schoolname=schoolname;                  
        
    }
    
    public int getSchoolID()
    {
        return schoolid;
    }
    
    public String getSchoolName()
    {
        return schoolname;
    }       
    
}
