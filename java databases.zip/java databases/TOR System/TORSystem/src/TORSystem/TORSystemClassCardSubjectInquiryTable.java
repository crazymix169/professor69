/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class TORSystemClassCardSubjectInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int subjectid;
    String subjectcode;
    String subjecttitle;   
  
    public TORSystemClassCardSubjectInquiryTable
    (            
        int subjectid,
        String subjectcode,
        String subjecttitle        
        
    )
            
    {
        this.subjectid=subjectid;        
        this.subjectcode=subjectcode;
        this.subjecttitle=subjecttitle;
             
        
    }
    
    public int getSubjectID()
    {
        return subjectid;
    }
    
    public String getSubjectCode()
    {
        return subjectcode;
    }
    
    public String getSubjectTitle()
    {
        return subjecttitle;
    }
    
}
