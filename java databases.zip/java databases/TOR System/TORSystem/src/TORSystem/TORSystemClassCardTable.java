/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class TORSystemClassCardTable {

    /**
     * @param args the command line arguments
     */
      
    int classcardid;
    int schoolid;
    int courseid;
    int subjectid;
    int instructorid;
    int studentid;
    double units;               
    String grade;
    String removalgrade;
    double numericalgrade;   
    String remarks;
    double credits;
    String credittype;
    String semester;   
    String schoolyearstart;
    String schoolyearend;
    
       
    
    public TORSystemClassCardTable
    (            
        int classcardid,
        int schoolid,
        int courseid,
        int subjectid,
        int instructorid,
        int studentid,
        double units,               
        String grade,
        String removalgrade,
        double numericalgrade,   
        String remarks,
        double credits,
        String credittype,
        String semester,   
        String schoolyearstart,
        String schoolyearend
        
    )
            
    {        
        this.classcardid=classcardid; 
        this.schoolid=schoolid;
        this.courseid=courseid;
        this.subjectid=subjectid;
        this.instructorid=instructorid;
        this.studentid=studentid;
        this.units=units;       
        this.grade=grade;
        this.removalgrade=removalgrade;
        this.numericalgrade=numericalgrade;                
        this.remarks=remarks;  
        this.credits=credits; 
        this.credittype=credittype;
        this.semester=semester;   
        this.schoolyearstart=schoolyearstart;
        this.schoolyearend=schoolyearend;               
    }
    
    public int getClassCardID()
    {
        return classcardid;
    }
    
    public int getSchoolId()
    {
        return schoolid;
    }
    public int getCourseID()
    {
        return courseid;
    }
    public int getSubjectID()
    {
        return subjectid;
    }
    public int getInstructorID()
    {
        return instructorid;
    }
    public int getStudentID()
    {
        return studentid;
    }
    public double getUnits()
    {
        return units;
    }    
    
    public String getGrade()
    {
        return grade;
    }
    public String getRemovalGrade()
    {
        return removalgrade;
    }  
    
    public double getNumericalGrade()
    {
        return numericalgrade;
    }   
    
    public String getRemarks()
    {
        return remarks;
    }   
    public double getCredits()
    {
        return credits;
    } 
    
    public String getCreditType()
    {
        return credittype;
    } 
    public String getSemester()
    {
        return semester;
    } 
    public String getSchoolYearStart()
    {
        return schoolyearstart;
    } 
    public String getSchoolYearEnd()
    {
        return schoolyearend;
    } 
     
}
