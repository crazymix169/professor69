/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class TORSystemClassCardStudentInquiryTable {

    /**
     * @param args the command line arguments
     */
      
    int studentid;
    String firstname;
    String middlename;
    String lastname;
    String suffix;
    
    
       
    
    public TORSystemClassCardStudentInquiryTable
    (            
        int studentid,        
        String firstname,
        String middlename,
        String lastname,
        String suffix
        
    )
            
    {
        this.studentid=studentid; 
        this.firstname=firstname;
        this.middlename=middlename;
        this.lastname=lastname;
        this.suffix=suffix;        
               
    }
    
    public int getStudentID()
    {
        return studentid;
    }
    
    public String getFirstName()
    {
        return firstname;
    }
    public String getMiddleName()
    {
        return middlename;
    }
    public String getLastName()
    {
        return lastname;
    }
    public String getSuffix()
    {
        return suffix;
    }
    
}
