/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

/**
 *
 * @author crazymix69
 */

public class TORSystemClassCardCourseInquiryTable
{
 
    int courseid;
    String coursecode;
    String coursetitle;   
        
    public TORSystemClassCardCourseInquiryTable(
            int courseid, String coursecode,String coursetitle)
    {
        this.courseid=courseid;
        this.coursecode=coursecode;
        this.coursetitle=coursetitle;        
        
    }
    
    public int getCourseID()
    {
        return courseid;
    }
    
    public String getCourseCode()
    {
        return coursecode;
    }
    
    public String getCourseTitle()
    {
        return coursetitle;
    }
   
}
