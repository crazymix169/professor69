/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TORSystem;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class TORSystemClassCardMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3,stmt4,stmt5,stmt6;
    ResultSet rs,rs2,rs3,rs4,rs5,rs6,rsaverage;
    
    int curRow = 0,viewall=0;
    int viewall2=0,viewall3=0,viewall4=0,viewall5=0,viewall6=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String instructorid;
    

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
     
    
    
    public TORSystemClassCardMaintenance() {
        super("Class Card Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        initComponents();
        
        DoConnect();
        
        Show_ClassCard_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
                        
            sql="SELECT * FROM `tbl_classcard`";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                
                int classcardid=rs.getInt("classcardid");
                int schoolid=rs.getInt("schoolid");
                int courseid=rs.getInt("courseid");
                int subjectid=rs.getInt("subjectid");
                int instructorid=rs.getInt("instructorid");
                int studentid=rs.getInt("studentid");
                double units=rs.getDouble("units");               
                String grade=rs.getString("grade");
                String removalgrade=rs.getString("removalgrade");
                double numericalgrade=rs.getDouble("numericalgrade");   
                String remarks=rs.getString("remarks");
                double credits=rs.getDouble("credits");
                String credittype=rs.getString("credittype");
                String semester=rs.getString("semester");   
                String schoolyearstart=rs.getString("schoolyearstart");
                String schoolyearend=rs.getString("schoolyearend");               

                textClassCardID.setText(Integer.toString(classcardid));
                textSchoolID.setText(Integer.toString(schoolid));
                textCourseID.setText(Integer.toString(courseid));
                textSubjectID.setText(Integer.toString(subjectid));
                textInstructorID.setText(Integer.toString(instructorid));
                textStudentID.setText(Integer.toString(studentid));               
                textUnits.setText(Double.toString(units));                              
                textGrade.setText(grade);
                textRemovalGrade.setText(removalgrade);
                textNumericalGrade.setText(Double.toString(numericalgrade));
                textRemarks.setText(remarks); 
                textCredits.setText(Double.toString(credits));
                textCreditType.setText(credittype);
                textSemester.setText(semester);   
                textSchoolYearStart.setText(schoolyearstart);
                textSchoolYearEnd.setText(schoolyearend);
                
                
                
            
            }           
            
            viewall=0;             
            Show_ClassCard_In_JTable();  
            viewall2=0;             
            Show_School_In_JTable();  
            viewall3=0;
            Show_Course_In_JTable();
            viewall4=0;
            Show_Subject_In_JTable();
            viewall5=0;
            Show_Instructor_In_JTable();
            viewall6=0;
            Show_Student_In_JTable();
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    /*
    Class Card
    */
    public ArrayList<TORSystemClassCardTable> getClassCardList()
    {
        ArrayList<TORSystemClassCardTable> classcardList= new ArrayList<TORSystemClassCardTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query ="SELECT * FROM `tbl_classcard`";
                
                
            }
            else if(viewall==1)
            {
                
                
                String schoolid=textSchoolID.getText().trim();
                String courseid=textCourseID.getText().trim();
                String subjectid=textSubjectID.getText().trim();
                String instructorid=textInstructorID.getText().trim();
                                
                 query ="SELECT * FROM `tbl_classcard` WHERE "                       
                        +" schoolid like '%"+schoolid+"%' or courseid like '%"+courseid+"%' "
                        + "or subjectid like '%"+subjectid+"%' or instructorid like '%"+instructorid    +"%'";
            
                
            }
            else if(viewall==3) 
            {
                
                               
                
                String classcardid=textClassCardID.getText().trim();
                int classcardidid1=Integer.parseInt(classcardid);
                
                query ="SELECT * FROM `tbl_classcard` WHERE instructorid = "+classcardidid1+"";
            }
            else if(viewall==2) 
            {
                
                String studentid=textStudentID.getText();
                int studentid2=Integer.parseInt(studentid);
                
                
                
                query ="SELECT * FROM `tbl_classcard` WHERE studentid = "+studentid2+" and  "
                        + " credittype = 'credited' and (remarks='passed' or remarks='failed')";
                stmt= connection.createStatement();
                rsaverage=stmt.executeQuery(query);
                double totalunitz=0, numericalgrado=0,earnedunits=0,gradecredit=0;  
                while(rsaverage.next())
                {
                    numericalgrado=rsaverage.getDouble("numericalgrade");

                    String marka=rsaverage.getString("remarks");
                    totalunitz+=rsaverage.getDouble("units");
                    if(marka.equals("passed")&&numericalgrado!=0)
                    {
                        earnedunits+=rsaverage.getDouble("units");
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }  
                    else if(marka.equals("failed")&&numericalgrado!=0)
                    {
                        earnedunits+=0;
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }
                    else if(marka.equals("no grade")&&numericalgrado!=0)
                    {
                        earnedunits+=0;
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }
                }
                String GWA=Double.toString(gradecredit/totalunitz);
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, "The General Average ofL: "+
                    Integer.toString(studentid2)+" is: "+GWA +" with a total earned units of "+Double.toString(earnedunits));
                rsaverage.close();
                
                
            }
            else if(viewall==4) 
            {
                
                String studentid=textStudentID.getText().trim();
                int studentid2=Integer.parseInt(studentid);
                String sem=textSemester.getText().trim();
                String systart=textSchoolYearStart.getText().trim();
                String syend=textSchoolYearEnd.getText().trim();
                
                
                query ="SELECT * FROM `tbl_classcard` WHERE studentid = "+studentid2+" and  "
                        + "semester='"+sem+"' and schoolyearstart='"+systart+"' and "
                        + "schoolyearend='"+syend+"' and "
                        + "credittype = 'credited' and (remarks='passed' or remarks='failed' or remarks='no grade')";
                stmt= connection.createStatement();
                rsaverage=stmt.executeQuery(query);
                double totalunitz=0, numericalgrado=0,earnedunits=0,gradecredit=0;  
                while(rsaverage.next())
                {
                    numericalgrado=rsaverage.getDouble("numericalgrade");

                    String marka=rsaverage.getString("remarks");
                    totalunitz+=rsaverage.getDouble("units");
                    if(marka.equals("passed")&&numericalgrado!=0)
                    {
                        earnedunits+=rsaverage.getDouble("units");
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }  
                    else if(marka.equals("failed")&&numericalgrado!=0)
                    {
                        earnedunits+=0;
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }
                    else if(marka.equals("no grade")&&numericalgrado!=0)
                    {
                        earnedunits+=0;
                        gradecredit+=rsaverage.getDouble("units")*numericalgrado;
                    }
                }
                String GWA=Double.toString(gradecredit/totalunitz);
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, "The General Average ofL: "+
                    Integer.toString(studentid2)+" is: "+GWA +" with a total earned units of "+Double.toString(earnedunits));
                rsaverage.close();
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            TORSystemClassCardTable classcard1;
            
            while(rs.next())
            {
                /*
                int classcardid;
                int schoolid;
                int courseid;
                int subjectid;
                int instructorid;
                int studentid;
                double units;               
                String grade;
                String removalgrade;
                double numericalgrade;   
                String remarks;
                double credits;
                String credittype;
                String semester;   
                String schoolyearstart;
                String schoolyearend;
                */
                classcard1 = new  TORSystemClassCardTable(
                        rs.getInt("classcardid"),rs.getInt("schoolid"),rs.getInt("courseid"),
                        rs.getInt("subjectid"), rs.getInt("instructorid"),rs.getInt("studentid"),
                        rs.getDouble("units"),rs.getString("grade"),rs.getString("removalgrade"),                      
                        rs.getDouble("numericalgrade"),rs.getString("remarks"),
                        rs.getDouble("credits"),rs.getString("credittype"),rs.getString("semester"),
                        rs.getString("schoolyearstart"),rs.getString("schoolyearend")
                        );
                classcardList.add(classcard1);
                
                
                
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return classcardList;
     
    }
    
    public void Show_ClassCard_In_JTable()
    {
        ArrayList<TORSystemClassCardTable> list = getClassCardList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[16];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            /*
                int classcardid;
                int schoolid;
                int courseid;
                int subjectid;
                int instructorid;
                int studentid;
                double units;               
                String grade;
                String removalgrade;
                double numericalgrade;   
                String remarks;
                double credits;
                String credittype;
                String semester;   
                String schoolyearstart;
                String schoolyearend;
                */
            //model.removeRow(i);
            row[0]=list.get(i).getClassCardID();
            row[1]=list.get(i).getSchoolId();
            row[2]=list.get(i).getCourseID();
            row[3]=list.get(i).getSubjectID();            
            row[4]=list.get(i).getInstructorID();
            row[5]=list.get(i).getStudentID();
            row[6]=list.get(i).getUnits();            
            row[7]=list.get(i).getGrade();
            row[8]=list.get(i).getRemovalGrade();       
            row[9]=list.get(i).getNumericalGrade();
            row[10]=list.get(i).getRemarks();            
            row[11]=list.get(i).getCredits();
            row[12]=list.get(i).getCreditType();       
            row[13]=list.get(i).getSemester();
            row[14]=list.get(i).getSchoolYearStart();            
            row[15]=list.get(i).getSchoolYearEnd();
                 
                                                
            model.addRow(row);
            
        }
        
    }
    
    /*
    School Inquiry
    */
    public ArrayList<TORSystemClassCardSchoolInquiryTable> getSchoolList()
    {
        ArrayList<TORSystemClassCardSchoolInquiryTable> schoolList= new ArrayList<TORSystemClassCardSchoolInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query ="SELECT `schoolid`, `schoolname` FROM `tbl_school`";
            }            
            else if(viewall2==3) 
            {               
                               
                
                String schoolid=textSchoolIDInquiry.getText().trim();
                int schoolid1=Integer.parseInt(schoolid);
                
                query ="SELECT `schoolid`, `schoolname` FROM `tbl_school` WHERE schoolid= "+schoolid1+"";
            }
            else if(viewall2==2) 
            {
                
                
                String schoolname=textSchoolNameInquiry.getText();
                
                query ="SELECT `schoolid`, `schoolname` FROM `tbl_school` WHERE "
                        + "schoolname like '%"+schoolname+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            TORSystemClassCardSchoolInquiryTable schoolinquiry1;
            
            while(rs2.next())
            {
                schoolinquiry1 = new  TORSystemClassCardSchoolInquiryTable(
                        rs2.getInt("schoolid"),rs2.getString("schoolname")
                        );
                schoolList.add(schoolinquiry1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return schoolList;
     
    }
    
    public void Show_School_In_JTable()
    {
        ArrayList<TORSystemClassCardSchoolInquiryTable> list = getSchoolList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[6];
        
        //model.addColumn("blade");
        
        model.setRowCount(0);
        
            
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSchoolID();
            row[1]=list.get(i).getSchoolName();
                              
                                                
            model.addRow(row);
            
        }
        
    }  
    
    
    
    
    
    /*
    Course Inquiry
    */
    
    public ArrayList<TORSystemClassCardCourseInquiryTable> getCourseList()
    {
        ArrayList<TORSystemClassCardCourseInquiryTable> courseinquiryList= new ArrayList<TORSystemClassCardCourseInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall3==0)
            {
                query ="SELECT `courseid`, `coursecode`, `coursetitle` FROM `tbl_course`";;
            }            
            else if(viewall3==3) 
            {               
                               
                
                String courseid=textCourseIDInquiry.getText().trim();
                int courseid1=Integer.parseInt(courseid);
                
                query ="SELECT `courseid`, `coursecode`, `coursetitle` FROM `tbl_course` WHERE courseid= "+courseid1+"";
            }
            else if(viewall3==2) 
            {
                
                
                String coursecode=textCourseCodeInquiry.getText();
                String coursetitle=textCourseTitleInquiry.getText();
                
                query ="SELECT `courseid`, `coursecode`, `coursetitle` FROM `tbl_course` WHERE  "
                        + "coursecode like '%"+coursecode+"%' or "
                        + "coursetitle like '%"+coursetitle+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs3=st.executeQuery(query);
            
           
            
            TORSystemClassCardCourseInquiryTable course1;
            
            while(rs3.next())
            {
                course1 = new  TORSystemClassCardCourseInquiryTable(
                        rs3.getInt("courseid"),rs3.getString("coursecode"),rs3.getString("coursetitle"));
                courseinquiryList.add(course1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return courseinquiryList;
     
    }
    
    public void Show_Course_In_JTable()
    {
        ArrayList<TORSystemClassCardCourseInquiryTable> list = getCourseList();
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
               
        Object[] row = new Object[7];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getCourseID();
            row[1]=list.get(i).getCourseCode();
            row[2]=list.get(i).getCourseTitle();
                                      
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    /*
    Subject Inquiry
    */
    
    public ArrayList<TORSystemClassCardSubjectInquiryTable> getSubjectList()
    {
        ArrayList<TORSystemClassCardSubjectInquiryTable> subjectList= new ArrayList<TORSystemClassCardSubjectInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall4==0)
            {
                query ="SELECT `subjectid`, `subjectcode`, `subjecttitle` FROM `tbl_subject`";;
            }
            
            else if(viewall4==3) 
            {
                
                               
                
                String subjectid=textSubjectIDInquiry.getText().trim();
                int subjectid1=Integer.parseInt(subjectid);
                
                query ="SELECT `subjectid`, `subjectcode`, `subjecttitle` FROM `tbl_subject` WHERE subjectid = "+subjectid1+"";
            }
            else if(viewall4==2) 
            {
                
                String subjecttitle=textSubjectTitleInquiry.getText();
                String subjectcode=textSubjectCodeInquiry.getText();
                
                query ="SELECT `subjectid`, `subjectcode`, `subjecttitle` FROM `tbl_subject` WHERE subjectdescription like '%"+subjecttitle+"%' or "
                        + "subjectcode like '%"+subjectcode+"%'";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs4=st.executeQuery(query);
            
           
            
            TORSystemClassCardSubjectInquiryTable subject1;
            
            while(rs4.next())
            {
                subject1 = new  TORSystemClassCardSubjectInquiryTable(
                        rs4.getInt("subjectid"),rs4.getString("subjectcode"),
                        rs4.getString("subjecttitle")
                        
                        );
                subjectList.add(subject1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return subjectList;
     
    }
    
    public void Show_Subject_In_JTable()
    {
        ArrayList<TORSystemClassCardSubjectInquiryTable> list = getSubjectList();
        DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getSubjectID();
            row[1]=list.get(i).getSubjectCode();
            row[2]=list.get(i).getSubjectTitle();                    
                
                                                
            model.addRow(row);
            
        }
        
    }
    
    
    
    
    
    /*
    instructor inquiry
    */
    
    public ArrayList<TORSystemClassCardInstructorInquiryTable> getInstructorList()
    {
        ArrayList<TORSystemClassCardInstructorInquiryTable> instructorList= new ArrayList<TORSystemClassCardInstructorInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall5==0)
            {
                query ="SELECT `instructorid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_instructor`";
            }
            else if(viewall5==1)
            {
                
                
                String firstname=textInstructorFirstNameInquiry.getText().trim();
                String middlename=textInstructorMiddleNameInquiry.getText().trim();
                String lastname=textInstructorLastNameInquiry.getText().trim();
                String suffix=textInstructorSuffixInquiry.getText().trim();
                                
                 query ="SELECT `instructorid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_instructor` WHERE "                       
                        +" firstname like '%"+firstname+"%' or middlename like '%"+middlename+"%' "
                        + "or lastname like '%"+lastname+"%' or suffix like '%"+suffix+"%'";
            
                
            }
            else if(viewall5==3) 
            {
                
                               
                
                String instructorid=textInstructorIDInquiry.getText().trim();
                int instructorid1=Integer.parseInt(instructorid);
                
                query ="SELECT `instructorid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_instructor` WHERE instructorid = "+instructorid1+"";
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs5=st.executeQuery(query);
            
           
            
            TORSystemClassCardInstructorInquiryTable instructor1;
            
            while(rs5.next())
            {
                instructor1 = new  TORSystemClassCardInstructorInquiryTable(
                        rs5.getInt("instructorid"),rs5.getString("firstname"),rs5.getString("middlename"),
                        rs5.getString("lastname"), rs5.getString("suffix")
                        );
                instructorList.add(instructor1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return instructorList;
     
    }
    
    public void Show_Instructor_In_JTable()
    {
        ArrayList<TORSystemClassCardInstructorInquiryTable> list = getInstructorList();
        DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
               
        Object[] row = new Object[16];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getStudentID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();            
            row[4]=list.get(i).getSuffix();            
                 
                                                
            model.addRow(row);
            
        }
        
    }    
    
    
    /*
    student inquiry
    */
    
    public ArrayList<TORSystemClassCardStudentInquiryTable> getStudentList()
    {
        ArrayList<TORSystemClassCardStudentInquiryTable> studentList= new ArrayList<TORSystemClassCardStudentInquiryTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall6==0)
            {
                query ="SELECT `studentid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_student`";;
            }
            else if(viewall6==1)
            {
                
                
                String firstname=textStudentFirstNameInquiry.getText().trim();
                String middlename=textStudentMiddleNameInquiry.getText().trim();
                String lastname=textStudentLastNameInquiry.getText().trim();
                String suffix=textStudentSuffixInquiry.getText().trim();
                                
                 query ="SELECT `studentid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_student` WHERE "                       
                        +" firstname like '%"+firstname+"%' or middlename like '%"+middlename+"%' "
                        + "or lastname like '%"+lastname+"%' or suffix like '%"+suffix+"%'";
            
                
            }
            else if(viewall6==3) 
            {
                
                               
                
                String studentid=textStudentIDInquiry.getText().trim();
                int studentid1=Integer.parseInt(studentid);
                
                query ="SELECT `studentid`, `firstname`, `middlename`, `lastname`, `suffix` FROM `tbl_student` WHERE studentid = "+studentid1+"";
            }
            
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs6=st.executeQuery(query);
            
           
            
            TORSystemClassCardStudentInquiryTable student1;
            
            while(rs6.next())
            {
                student1 = new  TORSystemClassCardStudentInquiryTable(
                        rs6.getInt("studentid"),rs6.getString("firstname"),rs6.getString("middlename"),
                        rs6.getString("lastname"), rs6.getString("suffix")           
                        );
                studentList.add(student1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+e.getMessage());
        }
        
        return studentList;
     
    }
    
    public void Show_Student_In_JTable()
    {
        ArrayList<TORSystemClassCardStudentInquiryTable> list = getStudentList();
        DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
               
        Object[] row = new Object[12];
        
       
            model.setRowCount(0);
                
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getStudentID();
            row[1]=list.get(i).getFirstName();
            row[2]=list.get(i).getMiddleName();
            row[3]=list.get(i).getLastName();            
            row[4]=list.get(i).getSuffix();
                             
                                                
            model.addRow(row);
            
        }
        
    }    
    
    
    /*
    End of Inquiries and Maintenance table
    */
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textInstructorID = new javax.swing.JTextField();
        textNumericalGrade = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByName = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textCredits = new javax.swing.JTextField();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnSearchByClassCardID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textClassCardID = new javax.swing.JTextField();
        textSchoolID = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        textCourseID = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        textSubjectID = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        textUnits = new javax.swing.JTextField();
        textStudentID = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        textGrade = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        textRemovalGrade = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        btnSearchByClubOrStatus = new javax.swing.JButton();
        textCreditType = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        textSemester = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        textRemarks = new javax.swing.JTextField();
        textSchoolYearStart = new javax.swing.JTextField();
        textSchoolYearEnd = new javax.swing.JTextField();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        textSchoolIDInquiry = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        textSchoolNameInquiry = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        btnSchoolIDInquiry = new javax.swing.JButton();
        btnSchoolNameInquiry = new javax.swing.JButton();
        btnViewAllSchools = new javax.swing.JButton();
        btnClearAllSchools = new javax.swing.JButton();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        textCourseIDInquiry = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        textCourseCodeInquiry = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        textCourseTitleInquiry = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnCourseIDInquiry = new javax.swing.JButton();
        btnCourseCodeOrCourseTitleInquiry1 = new javax.swing.JButton();
        btnViewAllSchools1 = new javax.swing.JButton();
        btnClearAllCourses = new javax.swing.JButton();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        textSubjectIDInquiry = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        textSubjectCodeInquiry = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        textSubjectTitleInquiry = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        btnSubjectIDInquiry = new javax.swing.JButton();
        btnSubjectCodeOrSubjectTitleInquiry = new javax.swing.JButton();
        btnClearAllSchools2 = new javax.swing.JButton();
        btnViewAllSchools2 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        textInstructorIDInquiry = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        textInstructorFirstNameInquiry = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        textInstructorLastNameInquiry = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        textInstructorMiddleNameInquiry = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        textInstructorSuffixInquiry = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        btnInstructorIDInquiry = new javax.swing.JButton();
        btnInstructorNameInquiry = new javax.swing.JButton();
        btnClearAllInstructors = new javax.swing.JButton();
        btnViewAllInstructors = new javax.swing.JButton();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jLabel42 = new javax.swing.JLabel();
        textStudentIDInquiry = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        textStudentFirstNameInquiry = new javax.swing.JTextField();
        textStudentMiddleNameInquiry = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        textStudentSuffixInquiry = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        textStudentLastNameInquiry = new javax.swing.JTextField();
        btnClearAllStudents = new javax.swing.JButton();
        btnStudentIDInquiry = new javax.swing.JButton();
        btnStudentNameInquiry = new javax.swing.JButton();
        btnViewAllStudents = new javax.swing.JButton();
        btnclearclasscard = new javax.swing.JButton();
        btnMixedSearch = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Class Card ID", "School ID", "Course ID", "Subject ID", "Instructor ID", "Student ID", "Units", "Grade", "Removal Grade", "Numerical Grade", "Remarks", "Credits", "Credit Type", "Semester", "School Year Start", "School Year End16"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Remarks");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textNumericalGrade.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Instructor ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Numerical Grade");

        btnSearchByName.setText("Search By Student ID with semestral Average");
        btnSearchByName.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByNameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Credits");

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        btnSearchByClassCardID.setText("Search by Class Card ID ");
        btnSearchByClassCardID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByClassCardIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Class Card ID");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Course ID");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Subject ID");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Units");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Student ID");

        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel19.setText("Grade");

        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel20.setText("Removal Grade");

        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21.setText("School ID");

        btnSearchByClubOrStatus.setText("Search By Student ID with General Average");
        btnSearchByClubOrStatus.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByClubOrStatusActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Credit Type");

        textSemester.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                textSemesterActionPerformed(evt);
            }
        });

        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("Semester");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("School Year Start");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("School Year End");

        jLabel22.setText("School ID");

        jLabel23.setText("School Name");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String []
            {
                "School ID", "School Name"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(jTable2);

        btnSchoolIDInquiry.setText("Search by Shool ID ");
        btnSchoolIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSchoolIDInquiryActionPerformed(evt);
            }
        });

        btnSchoolNameInquiry.setText("Search by School Name");
        btnSchoolNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSchoolNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllSchools.setText("View All Schools");
        btnViewAllSchools.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllSchoolsActionPerformed(evt);
            }
        });

        btnClearAllSchools.setText("Clear All Schools");
        btnClearAllSchools.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllSchoolsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23)
                            .addComponent(jLabel22))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textSchoolNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                            .addComponent(textSchoolIDInquiry))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSchoolNameInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSchoolIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAllSchools, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAllSchools, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE))))
                .addContainerGap(76, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(textSchoolIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSchoolIDInquiry)
                    .addComponent(btnViewAllSchools))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(textSchoolNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSchoolNameInquiry)
                        .addComponent(btnClearAllSchools)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(174, Short.MAX_VALUE))
        );

        jTabbedPane5.addTab("School Inquiry Panel", jPanel2);

        jTabbedPane1.addTab("School Inquiry", jTabbedPane5);

        jLabel27.setText("Course ID");

        jLabel28.setText("Course Code");

        jLabel29.setText("Course Title");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String []
            {
                "Course ID", "Course Code", "Course Title"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable3MouseClicked(evt);
            }
        });
        jTable3.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable3KeyPressed(evt);
            }
        });
        jScrollPane6.setViewportView(jTable3);

        btnCourseIDInquiry.setText("Search by Course ID ");
        btnCourseIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCourseIDInquiryActionPerformed(evt);
            }
        });

        btnCourseCodeOrCourseTitleInquiry1.setText("Search by Course Code or Course Title");
        btnCourseCodeOrCourseTitleInquiry1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCourseCodeOrCourseTitleInquiry1ActionPerformed(evt);
            }
        });

        btnViewAllSchools1.setText("View All Courses");
        btnViewAllSchools1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllSchools1ActionPerformed(evt);
            }
        });

        btnClearAllCourses.setText("Clear All Courses");
        btnClearAllCourses.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllCoursesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel27)
                                .addGap(12, 12, 12)
                                .addComponent(textCourseIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jLabel28)
                                .addGap(6, 6, 6)
                                .addComponent(textCourseCodeInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jLabel29)
                                .addGap(6, 6, 6)
                                .addComponent(textCourseTitleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnViewAllSchools1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCourseIDInquiry, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCourseCodeOrCourseTitleInquiry1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnClearAllCourses, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(143, 143, 143))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel27))
                            .addComponent(textCourseIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel28))
                            .addComponent(textCourseCodeInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnCourseIDInquiry)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCourseCodeOrCourseTitleInquiry1)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel29))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(textCourseTitleInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnClearAllCourses)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnViewAllSchools1)
                .addGap(25, 25, 25)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane6.addTab("Course Inquiry Panel", jPanel3);

        jTabbedPane1.addTab("Course Inquiry", jTabbedPane6);

        jPanel4.setLayout(null);

        jLabel32.setText("Subject ID");
        jPanel4.add(jLabel32);
        jLabel32.setBounds(30, 40, 56, 16);
        jPanel4.add(textSubjectIDInquiry);
        textSubjectIDInquiry.setBounds(110, 30, 290, 28);

        jLabel33.setText("Subject Code");
        jPanel4.add(jLabel33);
        jLabel33.setBounds(30, 70, 74, 16);

        textSubjectCodeInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                textSubjectCodeInquiryActionPerformed(evt);
            }
        });
        jPanel4.add(textSubjectCodeInquiry);
        textSubjectCodeInquiry.setBounds(110, 60, 290, 28);

        jLabel34.setText("Subject Title");
        jPanel4.add(jLabel34);
        jLabel34.setBounds(40, 100, 67, 16);
        jPanel4.add(textSubjectTitleInquiry);
        textSubjectTitleInquiry.setBounds(110, 90, 290, 28);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String []
            {
                "Subject ID", "Subject Code", "Subject Title"
            }
        ));
        jTable4.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable4MouseClicked(evt);
            }
        });
        jTable4.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable4KeyPressed(evt);
            }
        });
        jScrollPane7.setViewportView(jTable4);

        jPanel4.add(jScrollPane7);
        jScrollPane7.setBounds(29, 189, 456, 97);

        btnSubjectIDInquiry.setText("Search by Subject ID ");
        btnSubjectIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSubjectIDInquiryActionPerformed(evt);
            }
        });
        jPanel4.add(btnSubjectIDInquiry);
        btnSubjectIDInquiry.setBounds(410, 30, 144, 28);

        btnSubjectCodeOrSubjectTitleInquiry.setText("Search by Subject Code or Subject Title");
        btnSubjectCodeOrSubjectTitleInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSubjectCodeOrSubjectTitleInquiryActionPerformed(evt);
            }
        });
        jPanel4.add(btnSubjectCodeOrSubjectTitleInquiry);
        btnSubjectCodeOrSubjectTitleInquiry.setBounds(410, 60, 243, 28);

        btnClearAllSchools2.setText("Clear All Subjects");
        btnClearAllSchools2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllSchools2ActionPerformed(evt);
            }
        });
        jPanel4.add(btnClearAllSchools2);
        btnClearAllSchools2.setBounds(410, 90, 125, 28);

        btnViewAllSchools2.setText("View All Subjects");
        btnViewAllSchools2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllSchools2ActionPerformed(evt);
            }
        });
        jPanel4.add(btnViewAllSchools2);
        btnViewAllSchools2.setBounds(420, 120, 121, 28);

        jTabbedPane3.addTab("Subject Inquiry Panel", jPanel4);

        jTabbedPane1.addTab("Subject Inquiry", jTabbedPane3);

        jLabel37.setText("Instructor ID");

        jLabel38.setText("First Name");

        textInstructorFirstNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                textInstructorFirstNameInquiryActionPerformed(evt);
            }
        });

        jLabel39.setText("Last Name");

        jLabel40.setText("Midde Name");

        jLabel41.setText("Suffix");

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String []
            {
                "Instructor ID", "First Name", "Middle Name", "Last Name", "Suffix"
            }
        ));
        jTable5.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable5MouseClicked(evt);
            }
        });
        jTable5.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable5KeyPressed(evt);
            }
        });
        jScrollPane8.setViewportView(jTable5);

        btnInstructorIDInquiry.setText("Search by Instructor ID ");
        btnInstructorIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnInstructorIDInquiryActionPerformed(evt);
            }
        });

        btnInstructorNameInquiry.setText("Search by Instructor Name with Suffix");
        btnInstructorNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnInstructorNameInquiryActionPerformed(evt);
            }
        });

        btnClearAllInstructors.setText("Clear All Instructors");
        btnClearAllInstructors.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllInstructorsActionPerformed(evt);
            }
        });

        btnViewAllInstructors.setText("View All Instructors");
        btnViewAllInstructors.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllInstructorsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel38)
                .addGap(80, 80, 80)
                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(textInstructorFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(textInstructorMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(textInstructorLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnClearAllInstructors)
                .addGap(567, 567, 567))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel37)
                        .addGap(6, 6, 6)
                        .addComponent(textInstructorIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jLabel41)
                        .addGap(1, 1, 1)
                        .addComponent(textInstructorSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(btnInstructorIDInquiry)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnViewAllInstructors)
                            .addComponent(btnInstructorNameInquiry)))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClearAllInstructors)
                    .addComponent(btnViewAllInstructors))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInstructorIDInquiry)
                    .addComponent(btnInstructorNameInquiry))
                .addGap(2, 2, 2)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel37))
                    .addComponent(textInstructorIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41)
                    .addComponent(textInstructorSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38)
                    .addComponent(jLabel40)
                    .addComponent(jLabel39))
                .addGap(4, 4, 4)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textInstructorFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textInstructorMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textInstructorLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane2.addTab("Instructor Inquiry Panel", jPanel5);

        jTabbedPane1.addTab("Instructor Inquiry", jTabbedPane2);

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String []
            {
                "Student ID", "First Name", "Middle Name", "Last Name", "Suffix"
            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable6MouseClicked(evt);
            }
        });
        jTable6.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable6KeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(jTable6);

        jLabel42.setText("Student ID");

        jLabel43.setText("First Name");

        textStudentFirstNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                textStudentFirstNameInquiryActionPerformed(evt);
            }
        });

        jLabel44.setText("Midde Name");

        jLabel45.setText("Suffix");

        jLabel46.setText("Last Name");

        btnClearAllStudents.setText("Clear All Students");
        btnClearAllStudents.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllStudentsActionPerformed(evt);
            }
        });

        btnStudentIDInquiry.setText("Search by Student ID ");
        btnStudentIDInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnStudentIDInquiryActionPerformed(evt);
            }
        });

        btnStudentNameInquiry.setText("Search by Student Name with Suffix");
        btnStudentNameInquiry.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnStudentNameInquiryActionPerformed(evt);
            }
        });

        btnViewAllStudents.setText("View All Students");
        btnViewAllStudents.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllStudentsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnStudentIDInquiry)
                            .addComponent(btnClearAllStudents))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnViewAllStudents)
                            .addComponent(btnStudentNameInquiry)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel42)
                        .addGap(4, 4, 4)
                        .addComponent(textStudentIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel45)
                        .addGap(1, 1, 1)
                        .addComponent(textStudentSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel43)
                        .addGap(79, 79, 79)
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(textStudentFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textStudentMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(textStudentLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 618, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClearAllStudents)
                    .addComponent(btnViewAllStudents))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnStudentIDInquiry)
                    .addComponent(btnStudentNameInquiry))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel42)
                    .addComponent(textStudentIDInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45)
                    .addComponent(textStudentSuffixInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel43)
                    .addComponent(jLabel44)
                    .addComponent(jLabel46))
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textStudentFirstNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textStudentMiddleNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textStudentLastNameInquiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane4.addTab("Student Inqury Panel", jPanel1);

        jTabbedPane1.addTab("Student Inquiry", jTabbedPane4);

        btnclearclasscard.setText("Clear Class Card Textboxes");
        btnclearclasscard.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnclearclasscardActionPerformed(evt);
            }
        });

        btnMixedSearch.setText("search for School ID or Course ID or  Subject ID or Instructor ID");
        btnMixedSearch.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnMixedSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnBackToMDIForm)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(50, 50, 50)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(10, 10, 10))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textSchoolID, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textCredits))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textCreditType, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textSubjectID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(textSemester, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textInstructorID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(textSchoolYearStart, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textStudentID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(textSchoolYearEnd, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textUnits, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnSearchByName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textGrade, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnSearchByClubOrStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textRemovalGrade, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textNumericalGrade, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textRemarks, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(btnSearchByClassCardID))
                            .addComponent(textClassCardID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnMixedSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(36, 36, 36)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 1298, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addGap(6, 6, 6)
                                .addComponent(btnCancelNewRecord)))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnclearclasscard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnNewRecord, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBackToMDIForm)
                            .addComponent(btnSearchByClassCardID))
                        .addGap(3, 3, 3)
                        .addComponent(btnMixedSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel21)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel9)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel10)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel13)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel12)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel11)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel19)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel20)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel4)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel5))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(textClassCardID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textSchoolID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14)
                                    .addComponent(textCredits, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textCourseID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textCreditType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel15))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textSubjectID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17)
                                    .addComponent(textSemester, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textInstructorID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(textSchoolYearStart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textStudentID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(textSchoolYearEnd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textUnits, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSearchByName))
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(textGrade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnSearchByClubOrStatus))
                                .addGap(2, 2, 2)
                                .addComponent(textRemovalGrade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(textNumericalGrade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(textRemarks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(btnViewAll)))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEdit)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnNewRecord))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSaveRecord)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnclearclasscard))
                    .addComponent(btnClearAll))
                .addGap(6, 6, 6)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields
        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textClassCardID.setText(model.getValueAt(i, 0).toString());
            textSchoolID.setText(model.getValueAt(i, 1).toString());
            textCourseID.setText(model.getValueAt(i, 2).toString());
            textSubjectID.setText(model.getValueAt(i, 3).toString());        
            textInstructorID.setText(model.getValueAt(i, 4).toString());
            textStudentID.setText(model.getValueAt(i, 5).toString());
            textUnits.setText(model.getValueAt(i, 6).toString());        
            textGrade.setText(model.getValueAt(i, 7).toString());
            textRemovalGrade.setText(model.getValueAt(i, 8).toString()); 
            textNumericalGrade.setText(model.getValueAt(i, 9).toString());
            textRemarks.setText(model.getValueAt(i, 10).toString());        
            textCredits.setText(model.getValueAt(i, 11).toString());
            textCreditType.setText(model.getValueAt(i, 12).toString());
            textSemester.setText(model.getValueAt(i, 13).toString());   
            textSchoolYearStart.setText(model.getValueAt(i, 14).toString());
            textSchoolYearEnd.setText(model.getValueAt(i, 15).toString());
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textClassCardID.setText(model.getValueAt(i, 0).toString());
                textSchoolID.setText(model.getValueAt(i, 1).toString());
                textCourseID.setText(model.getValueAt(i, 2).toString());
                textSubjectID.setText(model.getValueAt(i, 3).toString());        
                textInstructorID.setText(model.getValueAt(i, 4).toString());
                textStudentID.setText(model.getValueAt(i, 5).toString());
                textUnits.setText(model.getValueAt(i, 6).toString());        
                textGrade.setText(model.getValueAt(i, 7).toString());
                textRemovalGrade.setText(model.getValueAt(i, 8).toString()); 
                textNumericalGrade.setText(model.getValueAt(i, 9).toString());
                textRemarks.setText(model.getValueAt(i, 10).toString());        
                textCredits.setText(model.getValueAt(i, 11).toString());
                textCreditType.setText(model.getValueAt(i, 12).toString());
                textSemester.setText(model.getValueAt(i, 13).toString());   
                textSchoolYearStart.setText(model.getValueAt(i, 14).toString());
                textSchoolYearEnd.setText(model.getValueAt(i, 15).toString());            

            }
        
        }
        catch(Exception e)
        {
        }

        
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String classcardid=textClassCardID.getText().trim();
                int classcardid2=Integer.parseInt(classcardid);

                stmt = con.createStatement( );
                String sql="";
                sql="SELECT * FROM `tbl_classcard` where classcardid="+classcardid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                 
                    sql="DELETE FROM  tbl_classcard"
                    + " where classcardid="+classcardid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        //();
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host="jdbc:mysql://localhost:3306/torsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                                
                
                String classcardid = textClassCardID.getText().trim();
                int classcardid2=Integer.parseInt(classcardid);            
                String schoolid=textSchoolID.getText().trim();
                int schoolid2=Integer.parseInt(schoolid);
                String courseid=textCourseID.getText().trim();
                int courseid2=Integer.parseInt(courseid);
                String subjectid=textSubjectID.getText().trim();
                int subjectid2=Integer.parseInt(subjectid);
                String instructorid=textInstructorID.getText().trim();
                int instructorid2=Integer.parseInt(instructorid);
                String studentid=textInstructorID.getText().trim();
                int studentid2=Integer.parseInt(studentid);
                String units=textUnits.getText().trim();    
                double units2=Double.parseDouble(units);
                String grade=textGrade.getText().trim();
                //double grade2=Double.parseDouble(grade);
                String removalgrade=textRemovalGrade.getText().trim();
                String numericalgrade=textNumericalGrade.getText().trim();
                double numericalgrade2=Double.parseDouble(numericalgrade);
                String remarks=textRemarks.getText().trim();
                String credits=textCredits.getText().trim();
                double credits2=Double.parseDouble(credits);
                String credittype=textCreditType.getText().trim();
                String semester=textSemester.getText().trim();   
                String schoolyearstart=textSchoolYearStart.getText().trim();
                String schoolyearend=textSchoolYearEnd.getText().trim();
                              
                
                
                                               

                if(instructorid.equals("")||credits.equals("")||schoolid.equals("")
                   || courseid.equals("")|| subjectid.equals("")|| units.equals("")
                   || studentid.equals("")|| instructorid.equals("")|| numericalgrade.equals("")|| remarks.equals("")
                   || grade.equals("")|| removalgrade.equals("")||credittype.equals("")
                        ||semester.equals("")||schoolyearstart.equals("")||schoolyearend.equals(""))
                {
                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    
                    
                    String sql="";
                    /*
                    stmt = con.createStatement( );
                    
                    sql="SELECT tbl_classcard.classcardid, tbl_school.schoolid, tbl_course.courseid, "
                        + "tbl_subject.subjectid, tbl_instructor.instructorid, tbl_student.studentid, "
                        + "tbl_classcard.units, tbl_classcard.grade, tbl_classcard.removalgrade, "
                        + "tbl_classcard.numericalgrade, tbl_classcard.remarks, "
                        + "tbl_classcard.credits, tbl_classcard.credittype, "
                        + "tbl_classcard.semester, tbl_classcard.schoolyearstart, "
                        + "tbl_classcard.schoolyearend "
                        + "FROM `tbl_school`,`tbl_course`,`tbl_subject`,"
                        + "`tbl_instructor`,`tbl_student`,`tbl_classcard` "
                        + "WHERE tbl_school.schoolid=tbl_classcard.schoolid and "
                        + "tbl_course.courseid=tbl_classcard.courseid and "
                        + "tbl_subject.subjectid=tbl_classcard.subjectid and "
                        + "tbl_instructor.instructorid=tbl_classcard.instructorid "
                        + "and tbl_student.studentid=tbl_classcard.studentid and tbl_classcard.classcardid="+classcardid2+" "
                        + " or (tbl_classcard.schoolid="+schoolid2+" and tbl_classcard.courseid="+courseid2+" "
                        + "and tbl_classcard.subjectid="+subjectid2+" and tbl_classcard.instructorid="+instructorid2+" "
                        + "and tbl_classcard.studentid="+studentid2+" and tbl_classcard.semester='"+semester+"' "
                        + "and tbl_classcard.schoolyearstart='"+schoolyearstart+"' "
                        + "and tbl_classcard.schoolyearend='"+schoolyearend+"')";
                    
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }*/
                    
                    int rowCount=0;
                    
                    stmt = con.createStatement( );
                    query="SELECT * from tbl_school where schoolid="+schoolid2+"";
                    rs = stmt.executeQuery(query);
                    int rowCount2=0;

                    while ( rs.next( ) )
                    {

                        rowCount2++;
                    }

                    stmt = con.createStatement( );
                    query="SELECT * from tbl_course where courseid="+courseid2+"";
                    rs = stmt.executeQuery(query);
                    int rowCount3=0;

                    while ( rs.next( ) )
                    {

                        rowCount3++;
                    }

                    stmt = con.createStatement( );
                    query="SELECT * from tbl_subject where subjectid="+subjectid2+"";
                    rs = stmt.executeQuery(query);
                    int rowCount4=0;

                    while ( rs.next( ) )
                    {

                        rowCount4++;
                    }

                    stmt = con.createStatement( );
                    query="SELECT * from tbl_instructor where instructorid="+instructorid2+"";
                    rs = stmt.executeQuery(query);
                    int rowCount5=0;

                    while ( rs.next( ) )
                    {

                        rowCount5++;
                    }

                    stmt = con.createStatement( );
                    query="SELECT * from tbl_student where studentid="+studentid2+"";
                    rs = stmt.executeQuery(query);
                    int rowCount6=0;

                    while ( rs.next( ) )
                    {

                        rowCount6++;
                    }

                    if(rowCount2==0||rowCount3==0||rowCount4==0||rowCount5==0||rowCount6==0)
                    {
                        JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, No Record Found! or Duplicate upon editing: rowCount: "+Double.toString(rowCount));
                    }
                    else 
                    {                      

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                            
                        
                        sql="UPDATE `tbl_classcard` SET `schoolid`="+schoolid2+",`courseid`="+courseid2+","
                                + "`subjectid`="+subjectid2+",`instructorid`="+instructorid2+","
                                + "`studentid`="+studentid2+",`units`="+units2+","
                                + "`grade`='"+grade+"',`removalgrade`='"+removalgrade+"',"
                                + "`numericalgrade`="+numericalgrade2+",`remarks`='"+remarks+"',"
                                + "`credits`="+credits+",`credittype`='"+credittype+"',"
                                + "`semester`='"+semester+"',`schoolyearstart`='"+schoolyearstart+"',"
                                + "`schoolyearend`='"+schoolyearend+"' WHERE `classcardid`="+classcardid2+"";
                        stmt.executeUpdate(sql);
                      

                        stmt = con.createStatement( );
                        
                        sql ="SELECT * FROM `tbl_classcard` where "
                            + "classcardid="+classcardid2+"";
                        rs = stmt.executeQuery(sql);
                        rowCount=0;                       

                        while ( rs.next( ) )
                        {
                            classcardid2=rs.getInt("classcardid");
                            schoolid2=rs.getInt("schoolid");
                            courseid2=rs.getInt("courseid");
                            subjectid2=rs.getInt("subjectid");
                            instructorid2=rs.getInt("instructorid");
                            studentid2=rs.getInt("studentid");
                            units2=rs.getDouble("units");               
                            grade=rs.getString("grade");
                            removalgrade=rs.getString("removalgrade");
                            numericalgrade2=rs.getDouble("numericalgrade");   
                            remarks=rs.getString("remarks");
                            credits2=rs.getDouble("credits");
                            credittype=rs.getString("credittype");
                            semester=rs.getString("semester");   
                            schoolyearstart=rs.getString("schoolyearstart");
                            schoolyearend=rs.getString("schoolyearend");               

                            textClassCardID.setText(Integer.toString(classcardid2));
                            textSchoolID.setText(Integer.toString(schoolid2));
                            textCourseID.setText(Integer.toString(courseid2));
                            textSubjectID.setText(Integer.toString(subjectid2));
                            textInstructorID.setText(Integer.toString(instructorid2));
                            textStudentID.setText(Integer.toString(studentid2));               
                            textUnits.setText(Double.toString(units2));                              
                            textGrade.setText(grade);
                            textRemovalGrade.setText(removalgrade);
                            textNumericalGrade.setText(Double.toString(numericalgrade2));
                            textRemarks.setText(remarks); 
                            textCredits.setText(Double.toString(credits2));
                            textCreditType.setText(credittype);
                            textSemester.setText(semester);   
                            textSchoolYearStart.setText(schoolyearstart);
                            textSchoolYearEnd.setText(schoolyearend);         
                            
                            rowCount++;
                            if(rowCount==1)
                            {
                                textClassCardID.setText(Integer.toString(classcardid2));
                                textSchoolID.setText(Integer.toString(schoolid2));
                                textCourseID.setText(Integer.toString(courseid2));
                                textSubjectID.setText(Integer.toString(subjectid2));
                                textInstructorID.setText(Integer.toString(instructorid2));
                                textStudentID.setText(Integer.toString(studentid2));               
                                textUnits.setText(Double.toString(units2));                              
                                textGrade.setText(grade);
                                textRemovalGrade.setText(removalgrade);
                                textNumericalGrade.setText(Double.toString(numericalgrade2));
                                textRemarks.setText(remarks); 
                                textCredits.setText(Double.toString(credits2));
                                textCreditType.setText(credittype);
                                textSemester.setText(semester);   
                                textSchoolYearStart.setText(schoolyearstart);
                                textSchoolYearEnd.setText(schoolyearend); 
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Nothing is modified!");
        }
        viewall=0;        
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
           
            host="jdbc:mysql://localhost:3306/torsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
            
            //String classcardid = textClassCardID.getText().trim();
            //int classcardid2=Integer.parseInt(classcardid);            
            
            String schoolid=textSchoolID.getText().trim();
            int schoolid2=Integer.parseInt(schoolid);
            String courseid=textCourseID.getText().trim();
            int courseid2=Integer.parseInt(courseid);
            String subjectid=textSubjectID.getText().trim();
            int subjectid2=Integer.parseInt(subjectid);
            String instructorid=textInstructorID.getText().trim();
            int instructorid2=Integer.parseInt(instructorid);
            String studentid=textInstructorID.getText().trim();
            int studentid2=Integer.parseInt(studentid);
            String units=textUnits.getText().trim();    
            double units2=Double.parseDouble(units);
            String grade=textGrade.getText().trim();
            //double grade2=Double.parseDouble(grade);
            String removalgrade=textRemovalGrade.getText().trim();
            String numericalgrade=textNumericalGrade.getText().trim();
            double numericalgrade2=Double.parseDouble(numericalgrade);
            String remarks=textRemarks.getText().trim();
            String credits=textCredits.getText().trim();
            double credits2=Double.parseDouble(credits);
            String credittype=textCreditType.getText().trim();
            String semester=textSemester.getText().trim();   
            String schoolyearstart=textSchoolYearStart.getText().trim();
            String schoolyearend=textSchoolYearEnd.getText().trim();
                
                        
                   
            

           if(credits.equals("")|| schoolid.equals("")|| instructorid.equals("")|| 
                   numericalgrade.equals("")|| remarks.equals("")
                   || courseid.equals("")|| subjectid.equals("")|| units.equals("")
                   || studentid.equals("")
                   || grade.equals("")|| removalgrade.equals("")
                   ||credittype.equals("")
                        ||semester.equals("")||schoolyearstart.equals("")||schoolyearend.equals(""))
            {
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                /*
                stmt = con.createStatement( );
                
                query="SELECT tbl_classcard.classcardid, tbl_school.schoolid, tbl_course.courseid,"
                        + " tbl_subject.subjectid, tbl_instructor.instructorid, tbl_student.studentid, "
                        + "tbl_classcard.units, tbl_classcard.grade, tbl_classcard.removalgrade, "
                        + "tbl_classcard.numericalgrade, tbl_classcard.remarks, tbl_classcard.credits, "
                        + "tbl_classcard.credittype, tbl_classcard.semester, tbl_classcard.schoolyearstart, "
                        + "tbl_classcard.schoolyearend "
                        + "FROM `tbl_school`,`tbl_course`,`tbl_subject`,`tbl_instructor`,"
                        + "`tbl_student`,`tbl_classcard` "
                        + "WHERE tbl_school.schoolid=tbl_classcard.schoolid and "
                        + "tbl_course.courseid=tbl_classcard.courseid and tbl_subject.subjectid=tbl_classcard.subjectid "
                        + "and tbl_instructor.instructorid=tbl_classcard.instructorid "
                        + "and tbl_student.studentid=tbl_classcard.studentid "
                        + "and tbl_classcard.schoolid="+schoolid2+" and tbl_classcard.courseid="+courseid2+" "
                        + "and tbl_classcard.subjectid="+subjectid2+" and tbl_classcard.instructorid="+instructorid2+" "
                        + "and tbl_classcard.studentid="+studentid2+" and tbl_classcard.semester='"+semester+"' "
                        + "and tbl_classcard.schoolyearstart='"+schoolyearstart+"' "
                        + "and tbl_classcard.schoolyearend='"+schoolyearend+"'";
                
                rs = stmt.executeQuery(query);
                

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }   */
                
                int rowCount=0;
                
                query="SELECT tbl_classcard.classcardid, tbl_school.schoolid, tbl_course.courseid,"
                        + " tbl_subject.subjectid, tbl_instructor.instructorid, tbl_student.studentid, "
                        + "tbl_classcard.units, tbl_classcard.grade, tbl_classcard.removalgrade, "
                        + "tbl_classcard.numericalgrade, tbl_classcard.remarks, tbl_classcard.credits, "
                        + "tbl_classcard.credittype, tbl_classcard.semester, tbl_classcard.schoolyearstart, "
                        + "tbl_classcard.schoolyearend "
                        + " FROM `tbl_school`,`tbl_course`,`tbl_subject`,`tbl_instructor`,"
                        + "`tbl_student`,`tbl_classcard` "
                        + "WHERE "
                        + "tbl_school.schoolid="+schoolid2+" and tbl_course.courseid="+courseid2+" "
                        + "and tbl_subject.subjectid="+subjectid2+" and tbl_instructor.instructorid="+instructorid2+" "
                        + "and tbl_student.studentid="+studentid2+" ";
                
                stmt = con.createStatement( );
                query="SELECT * from tbl_school where schoolid="+schoolid2+"";
                rs = stmt.executeQuery(query);
                int rowCount2=0;

                while ( rs.next( ) )
                {
                    
                    rowCount2++;
                }
                
                stmt = con.createStatement( );
                query="SELECT * from tbl_course where courseid="+courseid2+"";
                rs = stmt.executeQuery(query);
                int rowCount3=0;

                while ( rs.next( ) )
                {
                    
                    rowCount3++;
                }
                
                stmt = con.createStatement( );
                query="SELECT * from tbl_subject where subjectid="+subjectid2+"";
                rs = stmt.executeQuery(query);
                int rowCount4=0;

                while ( rs.next( ) )
                {
                    
                    rowCount4++;
                }
                
                stmt = con.createStatement( );
                query="SELECT * from tbl_instructor where instructorid="+instructorid2+"";
                rs = stmt.executeQuery(query);
                int rowCount5=0;

                while ( rs.next( ) )
                {
                    
                    rowCount5++;
                }
                
                stmt = con.createStatement( );
                query="SELECT * from tbl_student where studentid="+studentid2+"";
                rs = stmt.executeQuery(query);
                int rowCount6=0;

                while ( rs.next( ) )
                {
                    
                    rowCount6++;
                }

                if(rowCount2==0||rowCount3==0||rowCount4==0||rowCount5==0||rowCount6==0)
                {
                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, Record already exists! rowcount: "+Double.toString(rowCount)+ " and rowCount2: "+Double.toString(rowCount2) );
                }
                else
                {            
                    
                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " Sorry, Record already exists! rowcount: "+Double.toString(rowCount)+ " and rowCount2: "+Double.toString(rowCount2) );

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                       
                    
                    String sql="";
                    
                    sql="INSERT INTO `tbl_classcard`(`classcardid`, `schoolid`, `courseid`, "
                            + "`subjectid`, `instructorid`, `studentid`, `units`, `grade`,"
                            + " `removalgrade`, `numericalgrade`, `remarks`, `credits`, "
                            + "`credittype`, `semester`, `schoolyearstart`, `schoolyearend`) "
                            + "VALUES (NULL,'"+schoolid+"','"+courseid+"',"
                            + "'"+subjectid+"','"+instructorid+"','"+studentid+"',"
                            + "'"+units+"','"+grade+"','"+removalgrade+"',"
                            + "'"+numericalgrade+"','"+remarks+"','"+credits+"',"
                            + "'"+credittype+"','"+semester+"','"+schoolyearstart+"',"
                            + "'"+schoolyearend+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql ="SELECT * FROM `tbl_classcard`";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int classcardid=rs.getInt("classcardid");
                    schoolid2=rs.getInt("schoolid");
                    courseid2=rs.getInt("courseid");
                    subjectid2=rs.getInt("subjectid");
                    instructorid2=rs.getInt("instructorid");
                    studentid2=rs.getInt("studentid");
                    units2=rs.getDouble("units");               
                    grade=rs.getString("grade");
                    removalgrade=rs.getString("removalgrade");
                    numericalgrade2=rs.getDouble("numericalgrade");   
                    remarks=rs.getString("remarks");
                    credits2=rs.getDouble("credits");
                    credittype=rs.getString("credittype");
                    semester=rs.getString("semester");   
                    schoolyearstart=rs.getString("schoolyearstart");
                    schoolyearend=rs.getString("schoolyearend");               

                    textClassCardID.setText(Integer.toString(classcardid));
                    textSchoolID.setText(Integer.toString(schoolid2));
                    textCourseID.setText(Integer.toString(courseid2));
                    textSubjectID.setText(Integer.toString(subjectid2));
                    textInstructorID.setText(Integer.toString(instructorid2));
                    textStudentID.setText(Integer.toString(studentid2));               
                    textUnits.setText(Double.toString(units2));                              
                    textGrade.setText(grade);
                    textRemovalGrade.setText(removalgrade);
                    textNumericalGrade.setText(Double.toString(numericalgrade2));
                    textRemarks.setText(remarks); 
                    textCredits.setText(Double.toString(credits2));
                    textCreditType.setText(credittype);
                    textSemester.setText(semester);   
                    textSchoolYearStart.setText(schoolyearstart);
                    textSchoolYearEnd.setText(schoolyearend);

                    JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " new inserted record item: "+Double.toString(classcardid));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    
                    Show_ClassCard_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;        
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textClassCardID.setText("");
            textSchoolID.setText("");
            textCourseID.setText("");
            textSubjectID.setText("");
            textInstructorID.setText("");
            textStudentID.setText("");               
            textUnits.setText("");                              
            textGrade.setText("");
            textRemovalGrade.setText("");
            textCredits.setText("");
            textNumericalGrade.setText("");
            textRemarks.setText("");
            textCredits.setText("");
            textCreditType.setText("");
            textSemester.setText("");   
            textSchoolYearStart.setText("");
            textSchoolYearEnd.setText("");      

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            rs.absolute( curRow );

            int classcardid=rs.getInt("classcardid");
            int schoolid=rs.getInt("schoolid");
            int courseid=rs.getInt("courseid");
            int subjectid=rs.getInt("subjectid");
            int instructorid=rs.getInt("instructorid");
            int studentid=rs.getInt("studentid");
            double units=rs.getDouble("units");               
            String grade=rs.getString("grade");
            String removalgrade=rs.getString("removalgrade");
            double numericalgrade=rs.getDouble("numericalgrade");   
            String remarks=rs.getString("remarks");
            double credits=rs.getDouble("credits");
            String credittype=rs.getString("credittype");
            String semester=rs.getString("semester");   
            String schoolyearstart=rs.getString("schoolyearstart");
            String schoolyearend=rs.getString("schoolyearend");               

            textClassCardID.setText(Integer.toString(classcardid));
            textSchoolID.setText(Integer.toString(schoolid));
            textCourseID.setText(Integer.toString(courseid));
            textSubjectID.setText(Integer.toString(subjectid));
            textInstructorID.setText(Integer.toString(instructorid));
            textStudentID.setText(Integer.toString(studentid));               
            textUnits.setText(Double.toString(units));                              
            textGrade.setText(grade);
            textRemovalGrade.setText(removalgrade);
            textNumericalGrade.setText(Double.toString(numericalgrade));
            textRemarks.setText(remarks); 
            textCredits.setText(Double.toString(credits));
            textCreditType.setText(credittype);
            textSemester.setText(semester);   
            textSchoolYearStart.setText(schoolyearstart);
            textSchoolYearEnd.setText(schoolyearend);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Error: "+ err.getMessage());
            

            try
            {
                rs.first();

                int classcardid=rs.getInt("classcardid");
                int schoolid=rs.getInt("schoolid");
                int courseid=rs.getInt("courseid");
                int subjectid=rs.getInt("subjectid");
                int instructorid=rs.getInt("instructorid");
                int studentid=rs.getInt("studentid");
                double units=rs.getDouble("units");               
                String grade=rs.getString("grade");
                String removalgrade=rs.getString("removalgrade");
                double numericalgrade=rs.getDouble("numericalgrade");   
                String remarks=rs.getString("remarks");
                double credits=rs.getDouble("credits");
                String credittype=rs.getString("credittype");
                String semester=rs.getString("semester");   
                String schoolyearstart=rs.getString("schoolyearstart");
                String schoolyearend=rs.getString("schoolyearend");               

                textClassCardID.setText(Integer.toString(classcardid));
                textSchoolID.setText(Integer.toString(schoolid));
                textCourseID.setText(Integer.toString(courseid));
                textSubjectID.setText(Integer.toString(subjectid));
                textInstructorID.setText(Integer.toString(instructorid));
                textStudentID.setText(Integer.toString(studentid));               
                textUnits.setText(Double.toString(units));                              
                textGrade.setText(grade);
                textRemovalGrade.setText(removalgrade);
                textNumericalGrade.setText(Double.toString(numericalgrade));
                textRemarks.setText(remarks); 
                textCredits.setText(Double.toString(credits));
                textCreditType.setText(credittype);
                textSemester.setText(semester);   
                textSchoolYearStart.setText(schoolyearstart);
                textSchoolYearEnd.setText(schoolyearend);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {               

                textClassCardID.setText("");
                textSchoolID.setText("");
                textCourseID.setText("");
                textSubjectID.setText("");
                textInstructorID.setText("");
                textStudentID.setText("");               
                textUnits.setText("");                              
                textGrade.setText("");
                textRemovalGrade.setText("");
                textCredits.setText("");
                textNumericalGrade.setText("");
                textRemarks.setText("");
                textCredits.setText("");
                textCreditType.setText("");
                textSemester.setText("");   
                textSchoolYearStart.setText("");
                textSchoolYearEnd.setText("");      
                
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textClassCardID.setText("");
        textSchoolID.setText("");
        textCourseID.setText("");
        textSubjectID.setText("");
        textInstructorID.setText("");
        textStudentID.setText("");               
        textUnits.setText("");                              
        textGrade.setText("");
        textRemovalGrade.setText("");
        textCredits.setText("");
        textNumericalGrade.setText("");
        textRemarks.setText("");
        textCredits.setText("");
        textCreditType.setText("");
        textSemester.setText("");   
        textSchoolYearStart.setText("");
        textSchoolYearEnd.setText("");  
        
        textSchoolIDInquiry.setText("");
        textSchoolNameInquiry.setText("");
        
        textCourseIDInquiry.setText("");
        textCourseCodeInquiry.setText("");
        textCourseTitleInquiry.setText("");
        
        textSubjectIDInquiry.setText("");
        textSubjectCodeInquiry.setText("");
        textSubjectTitleInquiry.setText("");
        
        textInstructorIDInquiry.setText("");
        textInstructorFirstNameInquiry.setText("");
        textInstructorFirstNameInquiry.setText("");
        textInstructorMiddleNameInquiry.setText("");
        textInstructorLastNameInquiry.setText("");
        textInstructorSuffixInquiry.setText("");
        
        textStudentIDInquiry.setText("");
        textStudentFirstNameInquiry.setText("");
        textStudentFirstNameInquiry.setText("");
        textStudentMiddleNameInquiry.setText("");
        textStudentLastNameInquiry.setText("");
        textStudentSuffixInquiry.setText("");

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search legal person Name
    private void btnSearchByNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByNameActionPerformed
        // TODO add your handling code here:
        
        viewall=4;
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnSearchByNameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int classcardid=rs.getInt("classcardid");
                int schoolid=rs.getInt("schoolid");
                int courseid=rs.getInt("courseid");
                int subjectid=rs.getInt("subjectid");
                int instructorid=rs.getInt("instructorid");
                int studentid=rs.getInt("studentid");
                double units=rs.getDouble("units");               
                String grade=rs.getString("grade");
                String removalgrade=rs.getString("removalgrade");
                double numericalgrade=rs.getDouble("numericalgrade");   
                String remarks=rs.getString("remarks");
                double credits=rs.getDouble("credits");
                String credittype=rs.getString("credittype");
                String semester=rs.getString("semester");   
                String schoolyearstart=rs.getString("schoolyearstart");
                String schoolyearend=rs.getString("schoolyearend");               

                textClassCardID.setText(Integer.toString(classcardid));
                textSchoolID.setText(Integer.toString(schoolid));
                textCourseID.setText(Integer.toString(courseid));
                textSubjectID.setText(Integer.toString(subjectid));
                textInstructorID.setText(Integer.toString(instructorid));
                textStudentID.setText(Integer.toString(studentid));               
                textUnits.setText(Double.toString(units));                              
                textGrade.setText(grade);
                textRemovalGrade.setText(removalgrade);
                textNumericalGrade.setText(Double.toString(numericalgrade));
                textRemarks.setText(remarks); 
                textCredits.setText(Double.toString(credits));
                textCreditType.setText(credittype);
                textSemester.setText(semester);   
                textSchoolYearStart.setText(schoolyearstart);
                textSchoolYearEnd.setText(schoolyearend);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        
        
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //Move First
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int classcardid=rs.getInt("classcardid");
            int schoolid=rs.getInt("schoolid");
            int courseid=rs.getInt("courseid");
            int subjectid=rs.getInt("subjectid");
            int instructorid=rs.getInt("instructorid");
            int studentid=rs.getInt("studentid");
            double units=rs.getDouble("units");               
            String grade=rs.getString("grade");
            String removalgrade=rs.getString("removalgrade");
            double numericalgrade=rs.getDouble("numericalgrade");   
            String remarks=rs.getString("remarks");
            double credits=rs.getDouble("credits");
            String credittype=rs.getString("credittype");
            String semester=rs.getString("semester");   
            String schoolyearstart=rs.getString("schoolyearstart");
            String schoolyearend=rs.getString("schoolyearend");               

            textClassCardID.setText(Integer.toString(classcardid));
            textSchoolID.setText(Integer.toString(schoolid));
            textCourseID.setText(Integer.toString(courseid));
            textSubjectID.setText(Integer.toString(subjectid));
            textInstructorID.setText(Integer.toString(instructorid));
            textStudentID.setText(Integer.toString(studentid));               
            textUnits.setText(Double.toString(units));                              
            textGrade.setText(grade);
            textRemovalGrade.setText(removalgrade);
            textNumericalGrade.setText(Double.toString(numericalgrade));
            textRemarks.setText(remarks); 
            textCredits.setText(Double.toString(credits));
            textCreditType.setText(credittype);
            textSemester.setText(semester);   
            textSchoolYearStart.setText(schoolyearstart);
            textSchoolYearEnd.setText(schoolyearend);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to mdi form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

       
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try 
        {
            if ( rs.previous() )
            {

                int classcardid=rs.getInt("classcardid");
                int schoolid=rs.getInt("schoolid");
                int courseid=rs.getInt("courseid");
                int subjectid=rs.getInt("subjectid");
                int instructorid=rs.getInt("instructorid");
                int studentid=rs.getInt("studentid");
                double units=rs.getDouble("units");               
                String grade=rs.getString("grade");
                String removalgrade=rs.getString("removalgrade");
                double numericalgrade=rs.getDouble("numericalgrade");   
                String remarks=rs.getString("remarks");
                double credits=rs.getDouble("credits");
                String credittype=rs.getString("credittype");
                String semester=rs.getString("semester");   
                String schoolyearstart=rs.getString("schoolyearstart");
                String schoolyearend=rs.getString("schoolyearend");               

                textClassCardID.setText(Integer.toString(classcardid));
                textSchoolID.setText(Integer.toString(schoolid));
                textCourseID.setText(Integer.toString(courseid));
                textSubjectID.setText(Integer.toString(subjectid));
                textInstructorID.setText(Integer.toString(instructorid));
                textStudentID.setText(Integer.toString(studentid));               
                textUnits.setText(Double.toString(units));                              
                textGrade.setText(grade);
                textRemovalGrade.setText(removalgrade);
                textNumericalGrade.setText(Double.toString(numericalgrade));
                textRemarks.setText(remarks); 
                textCredits.setText(Double.toString(credits));
                textCreditType.setText(credittype);
                textSemester.setText(semester);   
                textSchoolYearStart.setText(schoolyearstart);
                textSchoolYearEnd.setText(schoolyearend);

            }
            else 
            {
                rs.next();
                JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.last();

            int classcardid=rs.getInt("classcardid");
                int schoolid=rs.getInt("schoolid");
                int courseid=rs.getInt("courseid");
                int subjectid=rs.getInt("subjectid");
                int instructorid=rs.getInt("instructorid");
                int studentid=rs.getInt("studentid");
                double units=rs.getDouble("units");               
                String grade=rs.getString("grade");
                String removalgrade=rs.getString("removalgrade");
                double numericalgrade=rs.getDouble("numericalgrade");   
                String remarks=rs.getString("remarks");
                double credits=rs.getDouble("credits");
                String credittype=rs.getString("credittype");
                String semester=rs.getString("semester");   
                String schoolyearstart=rs.getString("schoolyearstart");
                String schoolyearend=rs.getString("schoolyearend");               

                textClassCardID.setText(Integer.toString(classcardid));
                textSchoolID.setText(Integer.toString(schoolid));
                textCourseID.setText(Integer.toString(courseid));
                textSubjectID.setText(Integer.toString(subjectid));
                textInstructorID.setText(Integer.toString(instructorid));
                textStudentID.setText(Integer.toString(studentid));               
                textUnits.setText(Double.toString(units));                              
                textGrade.setText(grade);
                textRemovalGrade.setText(removalgrade);
                textNumericalGrade.setText(Double.toString(numericalgrade));
                textRemarks.setText(remarks); 
                textCredits.setText(Double.toString(credits));
                textCreditType.setText(credittype);
                textSemester.setText(semester);   
                textSchoolYearStart.setText(schoolyearstart);
                textSchoolYearEnd.setText(schoolyearend);

            

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(TORSystemClassCardMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search Legal Person ID
    private void btnSearchByClassCardIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByClassCardIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByClassCardIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnSearchByClassCardIDActionPerformed

    private void btnSearchByClubOrStatusActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByClubOrStatusActionPerformed
    {//GEN-HEADEREND:event_btnSearchByClubOrStatusActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnSearchByClubOrStatusActionPerformed

    private void textSemesterActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_textSemesterActionPerformed
    {//GEN-HEADEREND:event_textSemesterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textSemesterActionPerformed

    private void textSubjectCodeInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_textSubjectCodeInquiryActionPerformed
    {//GEN-HEADEREND:event_textSubjectCodeInquiryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textSubjectCodeInquiryActionPerformed

    private void textInstructorFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_textInstructorFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_textInstructorFirstNameInquiryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textInstructorFirstNameInquiryActionPerformed

    private void textStudentFirstNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_textStudentFirstNameInquiryActionPerformed
    {//GEN-HEADEREND:event_textStudentFirstNameInquiryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textStudentFirstNameInquiryActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable2MouseClicked
    {//GEN-HEADEREND:event_jTable2MouseClicked
        // TODO add your handling code here:
        try
        {    
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textSchoolIDInquiry.setText(model.getValueAt(i, 0).toString());
            textSchoolNameInquiry.setText(model.getValueAt(i, 1).toString());
        }
        catch(Exception e)
        {
        }
            

        
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable2KeyPressed
    {//GEN-HEADEREND:event_jTable2KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textSchoolIDInquiry.setText(model.getValueAt(i, 0).toString());
                textSchoolNameInquiry.setText(model.getValueAt(i, 1).toString());


            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable2KeyPressed

                                       

   
    
    private void jTable3KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable3KeyPressed
    {//GEN-HEADEREND:event_jTable3KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable3.getSelectedRow();
                TableModel model=jTable3.getModel();

                textCourseIDInquiry.setText(model.getValueAt(i, 0).toString());
                textCourseCodeInquiry.setText(model.getValueAt(i, 1).toString());
                textCourseTitleInquiry.setText(model.getValueAt(i, 2).toString()); 


            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable3KeyPressed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable3MouseClicked
    {//GEN-HEADEREND:event_jTable3MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable3.getSelectedRow();
            TableModel model=jTable3.getModel();

            textCourseIDInquiry.setText(model.getValueAt(i, 0).toString());
            textCourseCodeInquiry.setText(model.getValueAt(i, 1).toString());
            textCourseTitleInquiry.setText(model.getValueAt(i, 2).toString());
        }
        catch(Exception e)
        {
        }
        
    }//GEN-LAST:event_jTable3MouseClicked

    
    private void jTable4KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable4KeyPressed
    {//GEN-HEADEREND:event_jTable4KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable4.getSelectedRow();
                TableModel model=jTable4.getModel();            

                textSubjectIDInquiry.setText(model.getValueAt(i, 0).toString());
                textSubjectCodeInquiry.setText(model.getValueAt(i, 3).toString());
                textSubjectTitleInquiry.setText(model.getValueAt(i, 2).toString());      

            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable4KeyPressed

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable4MouseClicked
    {//GEN-HEADEREND:event_jTable4MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable4.getSelectedRow();
            TableModel model=jTable4.getModel();

            textSubjectIDInquiry.setText(model.getValueAt(i, 0).toString());
            textSubjectCodeInquiry.setText(model.getValueAt(i, 3).toString());
            textSubjectTitleInquiry.setText(model.getValueAt(i, 2).toString()); 
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable4MouseClicked

    private void jTable5KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable5KeyPressed
    {//GEN-HEADEREND:event_jTable5KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable5.getSelectedRow();
                TableModel model=jTable5.getModel();

                textInstructorIDInquiry.setText(model.getValueAt(i, 0).toString());
                textInstructorFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
                textInstructorMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
                textInstructorLastNameInquiry.setText(model.getValueAt(i, 3).toString());        
                textInstructorSuffixInquiry.setText(model.getValueAt(i, 4).toString());



            }
        }
        catch(Exception e)
        {
        }
    }//GEN-LAST:event_jTable5KeyPressed

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable5MouseClicked
    {//GEN-HEADEREND:event_jTable5MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable5.getSelectedRow();
            TableModel model=jTable5.getModel();

            textInstructorIDInquiry.setText(model.getValueAt(i, 0).toString());
            textInstructorFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
            textInstructorMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
            textInstructorLastNameInquiry.setText(model.getValueAt(i, 3).toString());        
            textInstructorSuffixInquiry.setText(model.getValueAt(i, 4).toString());
        }
        catch(Exception e)
        {
        }   
            

       
    }//GEN-LAST:event_jTable5MouseClicked

    private void jTable6KeyPressed(java.awt.event.KeyEvent evt)//GEN-FIRST:event_jTable6KeyPressed
    {//GEN-HEADEREND:event_jTable6KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable6.getSelectedRow();
                TableModel model=jTable6.getModel();

                textStudentIDInquiry.setText(model.getValueAt(i, 0).toString());
                textStudentFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
                textStudentMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
                textStudentLastNameInquiry.setText(model.getValueAt(i, 3).toString());        
                textStudentSuffixInquiry.setText(model.getValueAt(i, 4).toString());            


            }
        }
        catch(Exception e)
        {
        }
        
    }//GEN-LAST:event_jTable6KeyPressed

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt)//GEN-FIRST:event_jTable6MouseClicked
    {//GEN-HEADEREND:event_jTable6MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable6.getSelectedRow();
            TableModel model=jTable6.getModel();

            textStudentIDInquiry.setText(model.getValueAt(i, 0).toString());
            textStudentFirstNameInquiry.setText(model.getValueAt(i, 1).toString());
            textStudentMiddleNameInquiry.setText(model.getValueAt(i, 2).toString());
            textStudentLastNameInquiry.setText(model.getValueAt(i, 3).toString());        
            textStudentSuffixInquiry.setText(model.getValueAt(i, 4).toString());            
        }
        catch(Exception e)
        {
        }   

        
    }//GEN-LAST:event_jTable6MouseClicked

    private void btnViewAllSchoolsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllSchoolsActionPerformed
    {//GEN-HEADEREND:event_btnViewAllSchoolsActionPerformed
        // TODO add your handling code here:
        viewall2=0;
        Show_School_In_JTable();
    }//GEN-LAST:event_btnViewAllSchoolsActionPerformed

    private void btnClearAllSchoolsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllSchoolsActionPerformed
    {//GEN-HEADEREND:event_btnClearAllSchoolsActionPerformed
        // TODO add your handling code here:
        textSchoolIDInquiry.setText("");
        textSchoolNameInquiry.setText("");
        
    }//GEN-LAST:event_btnClearAllSchoolsActionPerformed

    private void btnSchoolIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSchoolIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnSchoolIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=3;
        Show_School_In_JTable();
    }//GEN-LAST:event_btnSchoolIDInquiryActionPerformed

    private void btnSchoolNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSchoolNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnSchoolNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_School_In_JTable();
        
    }//GEN-LAST:event_btnSchoolNameInquiryActionPerformed

    private void btnCourseIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCourseIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnCourseIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall3=3;
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnCourseIDInquiryActionPerformed

    private void btnCourseCodeOrCourseTitleInquiry1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnCourseCodeOrCourseTitleInquiry1ActionPerformed
    {//GEN-HEADEREND:event_btnCourseCodeOrCourseTitleInquiry1ActionPerformed
        // TODO add your handling code here:
        viewall3=2;
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnCourseCodeOrCourseTitleInquiry1ActionPerformed

    private void btnViewAllSchools1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllSchools1ActionPerformed
    {//GEN-HEADEREND:event_btnViewAllSchools1ActionPerformed
        // TODO add your handling code here:
        viewall3=0;
        Show_Course_In_JTable();
    }//GEN-LAST:event_btnViewAllSchools1ActionPerformed

    private void btnClearAllCoursesActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllCoursesActionPerformed
    {//GEN-HEADEREND:event_btnClearAllCoursesActionPerformed
        // TODO add your handling code here:
        textCourseIDInquiry.setText("");
        textCourseCodeInquiry.setText("");
        textCourseTitleInquiry.setText("");
    }//GEN-LAST:event_btnClearAllCoursesActionPerformed

    private void btnSubjectIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSubjectIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnSubjectIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall4=3;
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnSubjectIDInquiryActionPerformed

    private void btnSubjectCodeOrSubjectTitleInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSubjectCodeOrSubjectTitleInquiryActionPerformed
    {//GEN-HEADEREND:event_btnSubjectCodeOrSubjectTitleInquiryActionPerformed
        // TODO add your handling code here:
         viewall4=2;
        Show_Subject_In_JTable();
    }//GEN-LAST:event_btnSubjectCodeOrSubjectTitleInquiryActionPerformed

    private void btnClearAllSchools2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllSchools2ActionPerformed
    {//GEN-HEADEREND:event_btnClearAllSchools2ActionPerformed
        // TODO add your handling code here:
        textSubjectIDInquiry.setText("");
        textSubjectCodeInquiry.setText("");
        textSubjectTitleInquiry.setText("");
    }//GEN-LAST:event_btnClearAllSchools2ActionPerformed

    private void btnViewAllSchools2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllSchools2ActionPerformed
    {//GEN-HEADEREND:event_btnViewAllSchools2ActionPerformed
        // TODO add your handling code here: 
        viewall4=0;
        Show_Subject_In_JTable();
        
    }//GEN-LAST:event_btnViewAllSchools2ActionPerformed

    private void btnInstructorIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnInstructorIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnInstructorIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall5=3;
        Show_Instructor_In_JTable();
    }//GEN-LAST:event_btnInstructorIDInquiryActionPerformed

    private void btnInstructorNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnInstructorNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnInstructorNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall5=2;
        Show_Instructor_In_JTable();
    }//GEN-LAST:event_btnInstructorNameInquiryActionPerformed

    private void btnClearAllInstructorsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllInstructorsActionPerformed
    {//GEN-HEADEREND:event_btnClearAllInstructorsActionPerformed
        // TODO add your handling code here:
        textInstructorIDInquiry.setText("");
        textInstructorFirstNameInquiry.setText("");
        textInstructorFirstNameInquiry.setText("");
        textInstructorMiddleNameInquiry.setText("");
        textInstructorLastNameInquiry.setText("");
        textInstructorSuffixInquiry.setText("");
    }//GEN-LAST:event_btnClearAllInstructorsActionPerformed

    private void btnViewAllInstructorsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllInstructorsActionPerformed
    {//GEN-HEADEREND:event_btnViewAllInstructorsActionPerformed
        // TODO add your handling code here:
        viewall5=0;
        Show_Instructor_In_JTable();
    }//GEN-LAST:event_btnViewAllInstructorsActionPerformed

    private void btnClearAllStudentsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnClearAllStudentsActionPerformed
    {//GEN-HEADEREND:event_btnClearAllStudentsActionPerformed
        // TODO add your handling code here:
        textStudentIDInquiry.setText("");
        textStudentFirstNameInquiry.setText("");
        textStudentFirstNameInquiry.setText("");
        textStudentMiddleNameInquiry.setText("");
        textStudentLastNameInquiry.setText("");
        textStudentSuffixInquiry.setText("");
    }//GEN-LAST:event_btnClearAllStudentsActionPerformed

    private void btnStudentIDInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnStudentIDInquiryActionPerformed
    {//GEN-HEADEREND:event_btnStudentIDInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=3;
        Show_Student_In_JTable();
    }//GEN-LAST:event_btnStudentIDInquiryActionPerformed

    private void btnStudentNameInquiryActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnStudentNameInquiryActionPerformed
    {//GEN-HEADEREND:event_btnStudentNameInquiryActionPerformed
        // TODO add your handling code here:
        viewall6=2;
        Show_Student_In_JTable();
    }//GEN-LAST:event_btnStudentNameInquiryActionPerformed

    private void btnViewAllStudentsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnViewAllStudentsActionPerformed
    {//GEN-HEADEREND:event_btnViewAllStudentsActionPerformed
        // TODO add your handling code here:
        viewall6=0;
        Show_Student_In_JTable();
    }//GEN-LAST:event_btnViewAllStudentsActionPerformed

    private void btnclearclasscardActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnclearclasscardActionPerformed
    {//GEN-HEADEREND:event_btnclearclasscardActionPerformed
        // TODO add your handling code here:
        textClassCardID.setText("");
        textSchoolID.setText("");
        textCourseID.setText("");
        textSubjectID.setText("");
        textInstructorID.setText("");
        textStudentID.setText("");               
        textUnits.setText("");                              
        textGrade.setText("");
        textRemovalGrade.setText("");
        textCredits.setText("");
        textNumericalGrade.setText("");
        textRemarks.setText("");
        textCredits.setText("");
        textCreditType.setText("");
        textSemester.setText("");   
        textSchoolYearStart.setText("");
        textSchoolYearEnd.setText("");  
    }//GEN-LAST:event_btnclearclasscardActionPerformed

    private void btnMixedSearchActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnMixedSearchActionPerformed
    {//GEN-HEADEREND:event_btnMixedSearchActionPerformed
        // TODO add your handling code here:
        viewall=1;
        Show_ClassCard_In_JTable();
    }//GEN-LAST:event_btnMixedSearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnClearAllCourses;
    private javax.swing.JButton btnClearAllInstructors;
    private javax.swing.JButton btnClearAllSchools;
    private javax.swing.JButton btnClearAllSchools2;
    private javax.swing.JButton btnClearAllStudents;
    private javax.swing.JButton btnCourseCodeOrCourseTitleInquiry1;
    private javax.swing.JButton btnCourseIDInquiry;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnInstructorIDInquiry;
    private javax.swing.JButton btnInstructorNameInquiry;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnMixedSearch;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSchoolIDInquiry;
    private javax.swing.JButton btnSchoolNameInquiry;
    private javax.swing.JButton btnSearchByClassCardID;
    private javax.swing.JButton btnSearchByClubOrStatus;
    private javax.swing.JButton btnSearchByName;
    private javax.swing.JButton btnStudentIDInquiry;
    private javax.swing.JButton btnStudentNameInquiry;
    private javax.swing.JButton btnSubjectCodeOrSubjectTitleInquiry;
    private javax.swing.JButton btnSubjectIDInquiry;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JButton btnViewAllInstructors;
    private javax.swing.JButton btnViewAllSchools;
    private javax.swing.JButton btnViewAllSchools1;
    private javax.swing.JButton btnViewAllSchools2;
    private javax.swing.JButton btnViewAllStudents;
    private javax.swing.JButton btnclearclasscard;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTextField textClassCardID;
    private javax.swing.JTextField textCourseCodeInquiry;
    private javax.swing.JTextField textCourseID;
    private javax.swing.JTextField textCourseIDInquiry;
    private javax.swing.JTextField textCourseTitleInquiry;
    private javax.swing.JTextField textCreditType;
    private javax.swing.JTextField textCredits;
    private javax.swing.JTextField textGrade;
    private javax.swing.JTextField textInstructorFirstNameInquiry;
    private javax.swing.JTextField textInstructorID;
    private javax.swing.JTextField textInstructorIDInquiry;
    private javax.swing.JTextField textInstructorLastNameInquiry;
    private javax.swing.JTextField textInstructorMiddleNameInquiry;
    private javax.swing.JTextField textInstructorSuffixInquiry;
    private javax.swing.JTextField textNumericalGrade;
    private javax.swing.JTextField textRemarks;
    private javax.swing.JTextField textRemovalGrade;
    private javax.swing.JTextField textSchoolID;
    private javax.swing.JTextField textSchoolIDInquiry;
    private javax.swing.JTextField textSchoolNameInquiry;
    private javax.swing.JTextField textSchoolYearEnd;
    private javax.swing.JTextField textSchoolYearStart;
    private javax.swing.JTextField textSemester;
    private javax.swing.JTextField textStudentFirstNameInquiry;
    private javax.swing.JTextField textStudentID;
    private javax.swing.JTextField textStudentIDInquiry;
    private javax.swing.JTextField textStudentLastNameInquiry;
    private javax.swing.JTextField textStudentMiddleNameInquiry;
    private javax.swing.JTextField textStudentSuffixInquiry;
    private javax.swing.JTextField textSubjectCodeInquiry;
    private javax.swing.JTextField textSubjectID;
    private javax.swing.JTextField textSubjectIDInquiry;
    private javax.swing.JTextField textSubjectTitleInquiry;
    private javax.swing.JTextField textUnits;
    // End of variables declaration//GEN-END:variables
}
