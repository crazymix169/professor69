
import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

public class calc2 extends JFrame
   implements ActionListener
{



   private JTextField outputField,outputField2;
   private JTextField in[]=new JTextField[20];

   private JButton resetButton,clear1Button,clear2Button,clearallButton;
   private JButton save1Button,save2Button,exitButton;
   private JButton sumButton,diffButton,productButton,quotientButton,squareButton,dotButton;

   private JButton zeroButton,oneButton,twoButton,threeButton,fourButton;
   private JButton fiveButton,sixButton,sevenButton,eightButton,nineButton;

   private JLabel v[]=new JLabel[2];


   private double num;
   int yyyy=26;

    DecimalFormat p33 = new DecimalFormat( "0.000" );

	double num1,num2,output1;



   // set up GUI
   public calc2()
   {
      JFrame frame=new JFrame("Expression Calculator");
      //super( "Computing the Final Grade" );
	  frame.setLayout(null);

		frame.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});


		frame.setSize(810,410);

		Font f = new Font("JSL Ancient", Font.ITALIC, 12);
		Font fbi = new Font("JSL Ancient", Font.BOLD | Font.ITALIC,  12);
		Font fp = new Font("JSL Ancient", Font.PLAIN,  12);
  		Font fb = new Font("JSL Ancient", Font.BOLD ,  12);

		//frame.getContentPane();


      // get content pane and set its layout
      //Container container = getContentPane();
      //container.setLayout( null );

      v[0] =  new JLabel( "Input", SwingConstants.CENTER);
	  v[0].setFont(fb);
	  v[0].setForeground(Color.BLACK);
	  v[0].setBounds(1,1,100,20);
	  frame.getContentPane().add( v[0]);



	  outputField = new JTextField();
	  outputField.setBounds(102,1,400,20);
      frame.getContentPane().add( outputField );

      resetButton=new JButton("Clear input and result");
      resetButton.setBackground(Color.YELLOW);
	  resetButton.setBounds(507,1,200,20);
	  frame.getContentPane().add(resetButton);

	  resetButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {

				  output1=0;


					outputField.setText("");

					outputField2.setText("");
			  }
		}
	  );



	  //namer2.addActionListener(this);
	  //namer2.addKeyListener(aug);


	  v[1] =  new JLabel( "Result: ", SwingConstants.CENTER);
	  v[1].setFont(fb);
	  v[1].setForeground(Color.BLACK);
	  v[1].setBounds(1,25,100,20);
	  frame.getContentPane().add( v[1]);



	  outputField2 = new JTextField();
	  outputField2.setBounds(102,25,400,20);
      frame.getContentPane().add( outputField2 );



      save1Button=new JButton("^");
      save1Button.setBackground(Color.YELLOW);
	  save1Button.setBounds(170,60,150,20);
	  frame.getContentPane().add(save1Button);

	  save1Button.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {

				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="^";
				  outputField.setText(namer21);

			  }
		}
	  );

	  clear1Button=new JButton("Get Result!");
	  clear1Button.setBackground(Color.CYAN);
	  clear1Button.setBounds(507,25,200,20);
	  frame.getContentPane().add(clear1Button);

	  clear1Button.addActionListener(

		new ActionListener()
		{
		  public void actionPerformed(ActionEvent event)
		  {
				String expr="";
				Parser p = new Parser();
				expr=outputField.getText();
			  if(expr.equals(""))
			  {
				  expr="empty expression!!";
				  JOptionPane.showMessageDialog(null,"We have an "+expr,";empty expresion",JOptionPane.INFORMATION_MESSAGE);

			  }
			  else
			  {
			  	  try
				  {
					//System.out.println("Result: " + p.evaluate(expr));
					//System.out.println();
					JOptionPane.showMessageDialog(null,"The result is: "+p.evaluate(expr),";expression result",JOptionPane.INFORMATION_MESSAGE);
				  	outputField2.setText(p33.format(p.evaluate(expr)));
				  }
				  catch (ParserException exc)
				  {
					//System.out.println(exc);
					JOptionPane.showMessageDialog(null,"We have: "+exc.toString(),"error",JOptionPane.INFORMATION_MESSAGE);
					expr=exc.toString();
					outputField2.setText(exc.toString());
				  }


			  }
		  }
		}
	  );

      save2Button=new JButton("(");
      save2Button.setBackground(Color.CYAN);
	  save2Button.setBounds(325,60,150,20);
	  frame.getContentPane().add(save2Button);

	  save2Button.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {

				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="(";
				  outputField.setText(namer21);



			  }
		}
	  );

	  clear2Button=new JButton(")");
	  clear2Button.setBackground(Color.YELLOW);
	  clear2Button.setBounds(480,60,150,20);
	  frame.getContentPane().add(clear2Button);

	  clear2Button.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				String namer21="";
			    namer21=outputField.getText();
			    namer21+=")";
				outputField.setText(namer21);

			  }
		}
	  );

	 sumButton=new JButton("+");
	 sumButton.setBackground(Color.YELLOW);
	  sumButton.setBounds(1,85,150,20);
	  frame.getContentPane().add(sumButton);

	  sumButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {

				String namer21="";
				  namer21=outputField.getText();
				  namer21+="+";
				  outputField.setText(namer21);

			  }
		}
	  );

	  diffButton=new JButton("-");
	  diffButton.setBackground(Color.CYAN);
	  diffButton.setBounds(1,110,150,20);
	  frame.getContentPane().add(diffButton);

	  diffButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {

				String namer21="";
				  namer21=outputField.getText();
				  namer21+="-";
			    outputField.setText(namer21);
			  }
		 }
  		);

	 productButton=new JButton("*");
	 productButton.setBackground(Color.YELLOW);
	  productButton.setBounds(1,135,150,20);
	  frame.getContentPane().add(productButton);

	  productButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				String namer21="";
			    namer21=outputField.getText();
			    namer21+="*";
			    outputField.setText(namer21);

			  }
		 }
  		);
  	  quotientButton=new JButton("/");
  	  quotientButton.setBackground(Color.CYAN);
	  	  quotientButton.setBounds(1,160,150,20);
	  	  frame.getContentPane().add(quotientButton);

	  	  quotientButton.addActionListener(

	  		new ActionListener()
	  		{
	  			  public void actionPerformed(ActionEvent event)
	  			  {

					  String namer21="";
					  namer21=outputField.getText();
					  namer21+="/";
				  	  outputField.setText(namer21);

	  			  }
	  		 }
  		);

  		dotButton=new JButton(".");
	    dotButton.setBackground(Color.YELLOW);
		dotButton.setBounds(1,185,150,20);
		  frame.getContentPane().add(dotButton);

		  dotButton.addActionListener(

			new ActionListener()
			{
				  public void actionPerformed(ActionEvent event)
				  {

					  String namer21="";
					  namer21=outputField.getText();
					  namer21+=".";
					  outputField.setText(namer21);

				  }
			 }
  		);

	  sevenButton=new JButton("7");
	  sevenButton.setBackground(Color.CYAN);
	  sevenButton.setBounds(170,85,150,20);
	  frame.getContentPane().add(sevenButton);

	  sevenButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="7";
				  outputField.setText(namer21);

			  }
		}
	  );

	  fourButton=new JButton("4");
	  fourButton.setBackground(Color.YELLOW);
	  fourButton.setBounds(170,110,150,20);
	  frame.getContentPane().add(fourButton);

	  fourButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				 String namer21="";
				  namer21=outputField.getText();
				  namer21+="4";
				  outputField.setText(namer21);

			  }
		 }
  		);

	 oneButton=new JButton("1");
	 oneButton.setBackground(Color.CYAN);
	  oneButton.setBounds(170,135,150,20);
	  frame.getContentPane().add(oneButton);

	  oneButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				 String namer21="";
			   	 namer21=outputField.getText();
			     namer21+="1";
				  outputField.setText(namer21);

			  }
		 }
  		);
  	  zeroButton=new JButton("0");
  	  zeroButton.setBackground(Color.YELLOW);
	  	  zeroButton.setBounds(170,160,150,20);
	  	  frame.getContentPane().add(zeroButton);

	  	  zeroButton.addActionListener(

	  		new ActionListener()
	  		{
	  			  public void actionPerformed(ActionEvent event)
	  			  {
	  				  String namer21="";
					  namer21=outputField.getText();
					  namer21+="0";
				      outputField.setText(namer21);

	  			  }
	  		 }
  		);

	  eightButton=new JButton("8");
	  eightButton.setBackground(Color.YELLOW);
	  eightButton.setBounds(325,85,150,20);
	  frame.getContentPane().add(eightButton);

	  eightButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="8";
				  outputField.setText(namer21);

			  }
		}
	  );

	  fiveButton=new JButton("5");
	  fiveButton.setBackground(Color.CYAN);
	  fiveButton.setBounds(325,110,150,20);
	  frame.getContentPane().add(fiveButton);

	  fiveButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="5";
				  outputField.setText(namer21);

			  }
		 }
  		);

	 twoButton=new JButton("2");
	 twoButton.setBackground(Color.YELLOW);
	  twoButton.setBounds(325,135,150,20);
	  frame.getContentPane().add(twoButton);

	  twoButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="2";
				  outputField.setText(namer21);

			  }
		 }
  		);

  	  clearallButton=new JButton("Clear all");
  	  clearallButton.setBackground(Color.MAGENTA);
	  	  clearallButton.setBounds(325,160,305,20);
	  	  frame.getContentPane().add(clearallButton);

	  	  clearallButton.addActionListener(

	  		new ActionListener()
	  		{
	  			  public void actionPerformed(ActionEvent event)
	  			  {

	  				 output1=0;


	  				 outputField.setText("");
	  				 outputField2.setText("");


	  			  }
	  		 }
  		);

	  nineButton=new JButton("9");
	  nineButton.setBackground(Color.CYAN);
	  nineButton.setBounds(480,85,150,20);
	  frame.getContentPane().add(nineButton);

	  nineButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="9";
				  outputField.setText(namer21);

			  }
		}
	  );

	  sixButton=new JButton("6");
	  sixButton.setBackground(Color.YELLOW);
	  sixButton.setBounds(480,110,150,20);
	  frame.getContentPane().add(sixButton);

	  sixButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				 String namer21="";
				  namer21=outputField.getText();
				  namer21+="6";
				  outputField.setText(namer21);

			  }
		 }
  		);

	  threeButton=new JButton("3");
	  threeButton.setBackground(Color.CYAN);
	  threeButton.setBounds(480,135,150,20);
	  frame.getContentPane().add(threeButton);

	  threeButton.addActionListener(

		new ActionListener()
		{
			  public void actionPerformed(ActionEvent event)
			  {
				  String namer21="";
				  namer21=outputField.getText();
				  namer21+="3";
				  outputField.setText(namer21);

			  }
		 }
  		);

	  exitButton=new JButton("Quit Application");
	  exitButton.setBackground(Color.GREEN);
	  exitButton.setBounds(170,185,460,20);
	  frame.getContentPane().add(exitButton);

	  exitButton.addActionListener(

	  	new ActionListener()
	  	{
	  		  public void actionPerformed(ActionEvent event)
	  		  {
				  System.gc();
				  System.exit(0);
	  		  }
	  	}
	  );


	  squareButton=new JButton("%");
	  squareButton.setBackground(Color.YELLOW);
	  squareButton.setBounds(1,185,150,20);
	  frame.getContentPane().add(squareButton);
	  squareButton.addActionListener(this);

	  //computeButton.addActionListener(this);


	  //firstnum.setEditable(false);
	  //secondnum.setEditable(false);
	  outputField.setEditable(!false);
	  outputField2.setEditable(false);

      //setSize( 900, 750 );
      frame.setVisible( true );
      frame.setResizable(false);
   }


  public void actionPerformed( ActionEvent event )
   {

		String namer21="";
		  namer21=outputField.getText();
		  namer21+="%";
		  outputField.setText(namer21);

   }



   // execute application
   public static void main( String args[] )
   {
      calc2 application = new calc2();

      application.setDefaultCloseOperation(
         JFrame.EXIT_ON_CLOSE );
   }

}