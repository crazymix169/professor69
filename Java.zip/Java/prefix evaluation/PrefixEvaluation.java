import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import java.util.Arrays;

import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

import javax.swing.JOptionPane;

// Java program to evaluate
// a prefix expression.
import java.io.*;
import java.util.*;



public class PrefixEvaluation extends JFrame implements ActionListener {

	private String infixExpression;
	private String postfixExpression;

	private static JTextField textexpression,textanswer=new JTextField();
	private static JLabel labelexpression,labelans= new JLabel();
	private static JButton btnin,btncancel=new JButton();



	public PrefixEvaluation() {

		infixExpression = "";
		postfixExpression = "";

		JFrame frame=new JFrame("Evaluating Prefix Expressions...");
		  //super( "Computing the Final Grade" );
		  frame.setLayout(null);

			frame.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});

		Font fb = new Font("JSL Ancient", Font.BOLD ,  20);

		labelexpression =  new JLabel( "Enter a Prefix Expression(use single space to separate each number or operator):", SwingConstants.CENTER);
		labelexpression.setFont(fb);
		labelexpression.setForeground(Color.BLACK);
		labelexpression.setBounds(50,50,800,40);
		frame.getContentPane().add( labelexpression);
		labelexpression.setVisible(!false);

		labelans =  new JLabel( "The Answer of the Given Prefix Expression is:", SwingConstants.CENTER);
		labelans.setFont(fb);
		labelans.setForeground(Color.BLACK);
		labelans.setBounds(50,150,500,40);
		frame.getContentPane().add( labelans);
		labelans.setVisible(!false);

		textanswer =  new JTextField( "", SwingConstants.CENTER);
		textanswer.setFont(fb);
		textanswer.setForeground(Color.BLACK);
		textanswer.setBackground(Color.CYAN);
		textanswer.setBounds(50,200,500,40);
		frame.getContentPane().add( textanswer);
		textanswer.setVisible(!false);



		textexpression = new JTextField();
		textexpression.setFont(fb);
		textexpression.setBounds(50,100,500,40);
      	frame.getContentPane().add( textexpression );
      	textexpression.setVisible(!false);

		btnin=new JButton("Evaluate Expression!");
		btnin.setBackground(Color.CYAN);
		btnin.setBounds(50,250,250,40);
		frame.getContentPane().add(btnin);
		btnin.setVisible(!false);
		btnin.addActionListener(this);

		btncancel=new JButton("Clear Textboxes!");
		btncancel.setBackground(Color.CYAN);
		btncancel.setBounds(300,250,250,40);
		frame.getContentPane().add(btncancel);
		btncancel.setVisible(!false);
		//btncancel.addActionListener(this);

		btncancel.addActionListener(

			new ActionListener()
			{
				  public void actionPerformed(ActionEvent event)
				  {


						textanswer.setText("");
						textexpression.setText("");

						JOptionPane.showMessageDialog(null, "Textfields Cleared!!!");



				  }
			}
	  	);

		frame.setSize(1010,610);
		frame.setVisible( true );
        frame.setResizable(false);



	}

	//@Override
	public void actionPerformed( ActionEvent event )
	{
		//String command = event.getActionCommand();


		try
		{

			textanswer.setText(Double.toString(evaluatePrefix(textexpression.getText())));



		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, "Input Error: "+e.getMessage());
		}


    }

    static Boolean isOperand(char c)
	{
	    // If the character is a digit
	    // then it must be an operand
	    if(c >= 48 && c <= 57)
	    return true;
	    else
	    return false;
	}

	static double evaluatePrefix(String exprsn)
	{
	    Stack<Double> Stack = new Stack<Double>();

	    for (int j = exprsn.length() - 1; j >= 0; j--) {

	        // Push operand to Stack
	        // To convert exprsn[j] to digit subtract
	        // '0' from exprsn[j].

	        char c = exprsn.charAt(j);

	        if(c == ' ')
	            continue;
	        // If the scanned character is an operand
			// (number here),extract the number
			// Push it to the stack.
			else if(Character.isDigit(c))
			{
				int n = 0;

				//extract the characters and store it in num
				while(Character.isDigit(c))
				{
					n = n*10 + (int)(c-'0');
					j--;
					c = exprsn.charAt(j);
				}
				j++;

				double reverse=0;

				while(n != 0)
				{
					reverse = reverse * 10;
				    reverse = reverse + n%10;
				    n = n/10;
	      		}

				//push the number in stack
				//stack.push(n);
				//Stack.push((double)(exprsn.charAt(j) - 48));
				Stack.push((double)(reverse));
	         }

	        //if (isOperand(exprsn.charAt(j)))


	        else {

	            // Operator encountered
	            // Pop two elements from Stack
	            double o1 = Stack.peek();
	            Stack.pop();
	            double o2 = Stack.peek();
	            Stack.pop();

	            // Use switch case to operate on o1
	            // and o2 and perform o1 O o2.
	            switch (exprsn.charAt(j)) {
	            case '+':
	                Stack.push(o1 + o2);
	                break;
	            case '-':
	                Stack.push(o1 - o2);
	                break;
	            case '*':
	                Stack.push(o1 * o2);
	                break;
	            case '/':
	            	if(o2==0)
	            	{
						textanswer.setText("undefined expression");
					}
	            	else
	            	{   Stack.push(o1 / o2);}
	                break;
	            case '^':
	            	if(o2==0&&o1==0)
					{
						textanswer.setText("undefined expression");
					}
					else
	            	{
					    Stack.push(Math.pow(o1, o2));
					}
	                break;
	            }
	        }
	    }

	    return Stack.peek();
	}







	public static void main(String[] args)
	{

		PrefixEvaluation a=new PrefixEvaluation();
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
		String exprsn = "+ 9 * 2 36";
   		System.out.println("The Expression is: "+exprsn+" the result is: " +evaluatePrefix(exprsn));

	}
}