import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import java.util.Arrays;

import java.awt.*; // specifies how components are arranged
import java.awt.event.*; // provides basic window features
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.*; // displays text and images
import java.text.DecimalFormat;
import javax.swing.SwingConstants;
import java.lang.*;

// Java extension packages
import javax.swing.*;

import javax.swing.JOptionPane;

// Java program to evaluate
// a prefix expression.
import java.io.*;
import java.util.*;




public class PostfixEvaluation extends JFrame implements ActionListener {

	private String infixExpression;
	private String postfixExpression;

	private static JTextField textexpression,textanswer=new JTextField();
	private static JLabel labelexpression,labelans= new JLabel();
	private static JButton btnin,btncancel=new JButton();



	public PostfixEvaluation() {

		infixExpression = "";
		postfixExpression = "";

		JFrame frame=new JFrame("Evaluating Prefix Expressions...");
		  //super( "Computing the Final Grade" );
		  frame.setLayout(null);

			frame.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			});

		Font fb = new Font("JSL Ancient", Font.BOLD ,  20);

		labelexpression =  new JLabel( "Enter a Postfix Expression(use single space to separate each number or operator):", SwingConstants.CENTER);
		labelexpression.setFont(fb);
		labelexpression.setForeground(Color.BLACK);
		labelexpression.setBounds(50,50,800,40);
		frame.getContentPane().add( labelexpression);
		labelexpression.setVisible(!false);

		labelans =  new JLabel( "The Answer of the Given Postfix Expression is:", SwingConstants.CENTER);
		labelans.setFont(fb);
		labelans.setForeground(Color.BLACK);
		labelans.setBounds(50,150,500,40);
		frame.getContentPane().add( labelans);
		labelans.setVisible(!false);

		textanswer =  new JTextField( "", SwingConstants.CENTER);
		textanswer.setFont(fb);
		textanswer.setForeground(Color.BLACK);
		textanswer.setBackground(Color.CYAN);
		textanswer.setBounds(50,200,500,40);
		frame.getContentPane().add( textanswer);
		textanswer.setVisible(!false);



		textexpression = new JTextField();
		textexpression.setFont(fb);
		textexpression.setBounds(50,100,500,40);
      	frame.getContentPane().add( textexpression );
      	textexpression.setVisible(!false);

		btnin=new JButton("Evaluate Expression!");
		btnin.setBackground(Color.CYAN);
		btnin.setBounds(50,250,250,40);
		frame.getContentPane().add(btnin);
		btnin.setVisible(!false);
		btnin.addActionListener(this);

		btncancel=new JButton("Clear Textboxes!");
		btncancel.setBackground(Color.CYAN);
		btncancel.setBounds(300,250,250,40);
		frame.getContentPane().add(btncancel);
		btncancel.setVisible(!false);
		//btncancel.addActionListener(this);

		btncancel.addActionListener(

			new ActionListener()
			{
				  public void actionPerformed(ActionEvent event)
				  {


						textanswer.setText("");
						textexpression.setText("");

						JOptionPane.showMessageDialog(null, "Textfields Cleared!!!");



				  }
			}
	  	);

		frame.setSize(1010,610);
		frame.setVisible( true );
        frame.setResizable(false);



	}

	//@Override
	public void actionPerformed( ActionEvent event )
	{
		//String command = event.getActionCommand();


		try
		{

			textanswer.setText(Double.toString(evaluatePostfix(textexpression.getText())));



		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null, "Input Error: "+e.getMessage());
		}


    }

    // Method to evaluate value of a postfix expression
	static double evaluatePostfix(String exp)
	{
		//create a stack
		Stack<Double> stack = new Stack<>();

		// Scan all characters one by one
		for(int i = 0; i < exp.length(); i++)
		//for(int i = exp.length()-1; i >=0; i--)
		{
			char c = exp.charAt(i);

			if(c == ' ')
			continue;

			// If the scanned character is an operand
			// (number here),extract the number
			// Push it to the stack.
			else if(Character.isDigit(c))
			{
				double n = 0;

				//extract the characters and store it in num
				while(Character.isDigit(c))
				{
					n = n*10 + (int)(c-'0');
					i++;
					c = exp.charAt(i);
				}
				i--;

				//push the number in stack
				stack.push(n);
			}

			// If the scanned character is an operator, pop two
			// elements from stack apply the operator
			else
			{
				double val1 = stack.pop();
				double val2 = stack.pop();

				switch(c)
				{
					case '+':
						stack.push(val2+val1);
					break;

					case '-':
						stack.push(val2- val1);
					break;

					case '*':
						stack.push(val2* val1);
					break;

					case '/':
						if(val1==0)
						{
							textanswer.setText("undefined expression");
						}
						else
						{   stack.push(val2 / val1);}
						break;
					case '^':
						if(val2==0&&val1==0)
						{
							textanswer.setText("undefined expression");
						}
						else
						{
							stack.push(Math.pow(val2, val1));
						}
	                break;
			}
			}
		}
		return stack.pop();
    }







	public static void main(String[] args)
	{

		PostfixEvaluation a=new PostfixEvaluation();
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
		try
		{
			String exprsn = "9 2 36 * +";
   			System.out.println("The Expression is: "+exprsn+" the result is: " +evaluatePostfix(exprsn));
		}
		catch(Exception e){JOptionPane.showMessageDialog(null, "Input Error: "+e.getMessage());}

	}
}