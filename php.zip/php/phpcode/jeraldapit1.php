<!DOCTYPE html>
<html>
<head>
<style>
body {background-color: powderblue;}
h1   {color: blue;}
p    {color: magenta;}
</style>
</head>
<body>

<h1>Jerald Hure Apit</h1>
<br></br>
<p>Birthday: September 15, 2000</p>
<p>Course: BSIT</p>
<p>Year Level: Second Year</p>
<p>Secondary Education: Pinamopoan National High School</p>
<p>Elementary Education: Pinamopoan Elementary School</p>
<p>Hobbies: Reading, Writing, Swimming, Cooking</p>

</body>
</html>