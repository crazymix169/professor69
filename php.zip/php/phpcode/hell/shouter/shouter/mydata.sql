-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: sql207.hostmefree.org
-- Generation Time: Oct 16, 2010 at 10:03 AM
-- Server version: 5.1.49
-- PHP Version: 5.2.6-1+lenny6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hostm_6318188_mydata`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `address`, `gender`, `contactno`, `email`) VALUES
(1, 'nice tits', 'Address', 'Female', 'Contact No', 'Email'),
(2, 'threesome', 'Address 2', 'Male', 'Contact No 2', 'Email 2'),
(36, '54', '63', 'Male', '64', '6'),
(37, 'asshole!!!', '5', 'Male', '6', ''),
(38, 'e5', '5', 'Male', '3', '6');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `ImageID` int(100) NOT NULL AUTO_INCREMENT,
  `Cid` int(100) NOT NULL DEFAULT '0',
  `Sid` int(100) NOT NULL DEFAULT '0',
  `Title` varchar(50) NOT NULL DEFAULT '',
  `Image` varchar(50) NOT NULL DEFAULT '',
  `Viewed` int(15) NOT NULL DEFAULT '0',
  `Published` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `TimeStamp` int(25) NOT NULL DEFAULT '0',
  `userid` int(25) NOT NULL,
  `Username` varchar(150) NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`ImageID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`ImageID`, `Cid`, `Sid`, `Title`, `Image`, `Viewed`, `Published`, `TimeStamp`, `userid`, `Username`) VALUES
(38, 0, 0, 'shai', '1285646240.jpg', 0, 'Yes', 1285646240, 11, 'shaiva nur o mangaccat'),
(37, 0, 0, '432', '1285640806.gif', 0, 'Yes', 1285640806, 2, 'ass'),
(39, 0, 0, 'sa school', '1285848205.jpg', 0, 'Yes', 1285848205, 11, 'shaiva nur o mangaccat'),
(40, 0, 0, 'kuya at ako', '1285848260.jpg', 0, 'Yes', 1285848260, 11, 'shaiva nur o mangaccat');

-- --------------------------------------------------------

--
-- Table structure for table `tblcmt`
--

DROP TABLE IF EXISTS `tblcmt`;
CREATE TABLE IF NOT EXISTS `tblcmt` (
  `msgcmtid` int(20) NOT NULL AUTO_INCREMENT,
  `msgid` int(20) NOT NULL,
  `msguid` int(20) NOT NULL,
  `msgpname` varchar(100) DEFAULT NULL,
  `msgcmtuid` int(20) NOT NULL,
  `msgcmtpname` varchar(100) DEFAULT NULL,
  `cdate2` varchar(100) DEFAULT NULL,
  `ctime2` varchar(100) DEFAULT NULL,
  `cmt` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`msgcmtid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `tblcmt`
--

INSERT INTO `tblcmt` (`msgcmtid`, `msgid`, `msguid`, `msgpname`, `msgcmtuid`, `msgcmtpname`, `cdate2`, `ctime2`, `cmt`) VALUES
(1, 22, 4, 'jasmine', 2, 'ass', '2010.Sep.05', '23.20.41', 'a'),
(2, 17, 2, 'ass', 2, 'ass', '2010.Sep.05', '23.33.56', 'ff'),
(3, 22, 4, 'jasmine', 2, 'ass', '2010.Sep.05', '23.40.36', '35'),
(4, 22, 4, 'jasmine', 2, 'ass', '2010.Sep.05', '23.43.28', 'dd'),
(10, 17, 2, 'ass', 5, 'august', '2010.Sep.06', '08.26.20', 'aa'),
(28, 16, 3, 'aa', 7, 'rehg', '2010.Sep.06', '12.58.16', 'ass'),
(19, 28, 2, 'ass', 2, 'ass', '2010.Sep.06', '11.13.00', '44'),
(20, 22, 4, 'jasmine', 7, 'rehg', '2010.Sep.06', '11.31.58', '454'),
(21, 22, 4, 'jasmine', 7, 'rehg', '2010.Sep.06', '11.32.13', '564'),
(22, 17, 2, 'ass', 7, 'rehg', '2010.Sep.06', '12.03.09', '434'),
(23, 20, 2, 'ass', 7, 'rehg', '2010.Sep.06', '12.18.59', '432'),
(24, 16, 3, 'aa', 7, 'rehg', '2010.Sep.06', '12.50.16', 'sdajlf'),
(25, 26, 2, 'ass', 7, 'rehg', '2010.Sep.06', '12.53.26', '76'),
(26, 16, 3, 'aa', 7, 'rehg', '2010.Sep.06', '12.55.08', '54'),
(27, 26, 2, 'ass', 7, 'rehg', '2010.Sep.06', '12.56.31', 'uhhj'),
(29, 16, 3, 'aa', 2, 'ass', '2010.Sep.06', '12.58.53', '54'),
(30, 32, 7, 'rehg', 4, 'jasmine', '2010.Sep.06', '13.01.00', '52'),
(31, 17, 2, 'ass', 4, 'jasmine', '2010.Sep.06', '13.01.48', '454'),
(32, 17, 2, 'ass', 4, 'jasmine', '2010.Sep.06', '13.02.15', '54'),
(33, 17, 2, 'ass', 7, 'rehg', '2010.Sep.06', '13.02.55', '432'),
(34, 23, 5, 'august', 2, 'ass', '2010.Sep.10', '21.48.31', '4343'),
(35, 31, 7, 'rehg', 2, 'ass', '2010.Sep.10', '21.48.51', '43'),
(36, 45, 2, 'ass', 2, 'ass', '2010.Sep.18', '10.13.04', '33'),
(37, 20, 2, 'ass', 2, 'ass', '2010.Sep.18', '18.35.40', 'f'),
(38, 25, 4, 'jasmine', 2, 'ass', '2010.Sep.18', '18.35.51', 'a'),
(39, 28, 2, 'ass', 2, 'ass', '2010.Sep.18', '18.35.59', 'd'),
(40, 21, 4, 'jasmine', 2, 'ass', '2010.Sep.18', '18.41.04', 'gs'),
(41, 23, 5, 'august', 2, 'ass', '2010.Sep.18', '18.41.18', 'gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggfdgfdgfd'),
(42, 24, 2, 'ass', 2, 'ass', '2010.Sep.18', '18.43.52', 'fgds'),
(43, 14, 2, 'ass', 2, 'ass', '2010.Sep.18', '20.09.28', 'd'),
(44, 61, 2, 'ass', 2, 'ass', '2010.Sep.18', '22.42.03', '4343'),
(45, 40, 2, 'ass', 2, 'ass', '2010.Sep.18', '22.58.43', 'gs'),
(46, 64, 2, 'ass', 2, 'ass', '2010.Sep.18', '22.58.53', '3'),
(47, 25, 4, 'jasmine', 2, 'ass', '2010.Sep.26', '22.03.42', '3'),
(48, 26, 2, 'ass', 2, 'ass', '2010.Sep.27', '01.37.08', '43'),
(49, 26, 2, 'ass', 2, 'ass', '2010.Sep.27', '01.37.20', '5454'),
(50, 66, 2, 'ass', 2, 'ass', '2010.Sep.28', '11.03.18', '43524'),
(51, 23, 5, 'august', 6, 'ax', '2010.Sep.28', '11.08.47', '54234'),
(52, 74, 13, 'mira mae cabcad', 2, 'ass', '2010.Sep.29', '22.16.21', 'I''m great....'),
(53, 75, 14, 'raiza lim', 2, 'ass', '2010.Sep.30', '07.34.57', 'it''s ok!'),
(54, 76, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.30', '20.08.18', 'thank you shai!');

-- --------------------------------------------------------

--
-- Table structure for table `tblimgcmt`
--

DROP TABLE IF EXISTS `tblimgcmt`;
CREATE TABLE IF NOT EXISTS `tblimgcmt` (
  `imgcmtid` int(20) NOT NULL AUTO_INCREMENT,
  `imgid` int(20) NOT NULL,
  `imguid` int(20) NOT NULL,
  `imgpname` varchar(100) DEFAULT NULL,
  `imgcmtuid` int(20) NOT NULL,
  `imgcmtpname` varchar(100) DEFAULT NULL,
  `cdate2` varchar(100) DEFAULT NULL,
  `ctime2` varchar(100) DEFAULT NULL,
  `cmt` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`imgcmtid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `tblimgcmt`
--

INSERT INTO `tblimgcmt` (`imgcmtid`, `imgid`, `imguid`, `imgpname`, `imgcmtuid`, `imgcmtpname`, `cdate2`, `ctime2`, `cmt`) VALUES
(77, 37, 2, 'ass', 9, 'Lyn Mairesse Abenio', '2010.Sep.28', '11.43.29', 'hi'),
(76, 37, 2, 'ass', 2, 'ass', '2010.Sep.28', '10.26.57', '3424'),
(78, 38, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.28', '11.58.32', 'thank you shai!'),
(79, 37, 2, 'ass', 13, 'mira mae cabcad', '2010.Sep.29', '10.19.06', 'hi'),
(80, 38, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.30', '10.24.04', 'white!'),
(81, 38, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.30', '10.26.39', '43'),
(82, 38, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.30', '11.23.06', '32'),
(83, 38, 11, 'shaiva nur o mangaccat', 2, 'ass', '2010.Sep.30', '11.35.02', '32');

-- --------------------------------------------------------

--
-- Table structure for table `tbliskor`
--

DROP TABLE IF EXISTS `tbliskor`;
CREATE TABLE IF NOT EXISTS `tbliskor` (
  `scid` int(20) NOT NULL AUTO_INCREMENT,
  `scitem` varchar(5000) DEFAULT NULL,
  `score` int(20) NOT NULL,
  PRIMARY KEY (`scid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbliskor`
--

INSERT INTO `tbliskor` (`scid`, `scitem`, `score`) VALUES
(1, 'a', 0),
(2, 'b', 1),
(3, 'c', 1),
(4, 'd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmsg`
--

DROP TABLE IF EXISTS `tblmsg`;
CREATE TABLE IF NOT EXISTS `tblmsg` (
  `msgid` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `date2` varchar(100) DEFAULT NULL,
  `time2` varchar(100) DEFAULT NULL,
  `mesg` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`msgid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `tblmsg`
--

INSERT INTO `tblmsg` (`msgid`, `uid`, `pname`, `date2`, `time2`, `mesg`) VALUES
(22, 4, 'jasmine', '2010.Aug.22', '23.06.24', 'halu'),
(21, 4, 'jasmine', '2010.Aug.22', '23.06.15', 'a'),
(31, 7, 'rehg', '2010.Sep.06', '11.19.42', '74'),
(17, 2, 'ass', '2010.Aug.22', '22.36.29', '3'),
(16, 3, 'aa', '2010.Aug.22', '22.36.13', '4'),
(20, 2, 'ass', '2010.Aug.22', '23.04.44', 'a'),
(14, 2, 'ass', '2010.Aug.22', '22.32.45', '3'),
(23, 5, 'august', '2010.Aug.23', '09.30.08', 'aa'),
(24, 2, 'ass', '2010.Aug.23', '09.37.26', 'f'),
(25, 4, 'jasmine', '2010.Aug.23', '09.39.14', 'gn'),
(26, 2, 'ass', '2010.Sep.05', '21.39.50', 'ass'),
(27, 2, 'ass', '2010.Sep.05', '22.01.14', 'ivy thank you'),
(28, 2, 'ass', '2010.Sep.05', '23.40.28', 'f'),
(30, 7, 'rehg', '2010.Sep.06', '11.16.37', '543'),
(32, 7, 'rehg', '2010.Sep.06', '12.35.27', '4'),
(33, 2, 'ass', '2010.Sep.10', '21.38.32', 'dag'),
(34, 2, 'ass', '2010.Sep.16', '07.48.10', '33'),
(35, 2, 'ass', '2010.Sep.16', '07.48.28', '3'),
(36, 2, 'ass', '2010.Sep.16', '07.49.48', '3'),
(37, 2, 'ass', '2010.Sep.16', '07.49.50', '3'),
(38, 2, 'ass', '2010.Sep.16', '07.49.52', '3'),
(39, 2, 'ass', '2010.Sep.16', '07.50.02', '45'),
(40, 2, 'ass', '2010.Sep.16', '07.52.19', '3'),
(41, 2, 'ass', '2010.Sep.16', '07.55.48', 'f'),
(42, 2, 'ass', '2010.Sep.18', '09.51.09', 'fa'),
(43, 2, 'ass', '2010.Sep.18', '09.52.13', '43'),
(44, 2, 'ass', '2010.Sep.18', '09.53.59', 'a'),
(45, 2, 'ass', '2010.Sep.18', '09.56.50', '54'),
(46, 2, 'ass', '2010.Sep.18', '09.57.00', '43'),
(64, 2, 'ass', '2010.Sep.18', '22.22.44', 'fd'),
(63, 3, 'aa', '2010.Sep.18', '20.14.35', 'fa'),
(62, 2, 'ass', '2010.Sep.18', '20.12.47', 'sd'),
(61, 2, 'ass', '2010.Sep.18', '19.30.15', 'fs'),
(60, 2, 'ass', '2010.Sep.18', '18.49.03', '34'),
(59, 2, 'ass', '2010.Sep.18', '18.47.30', '44'),
(58, 2, 'ass', '2010.Sep.18', '18.38.29', 'thes'),
(65, 2, 'ass', '2010.Sep.28', '10.21.52', 'I miss u'),
(66, 2, 'ass', '2010.Sep.28', '11.02.56', 'threesome'),
(67, 6, 'ax', '2010.Sep.28', '11.08.36', '4q324'),
(68, 8, 'august', '2010.Sep.28', '11.16.52', '321'),
(69, 2, 'ass', '2010.Sep.28', '11.46.13', '423'),
(70, 2, 'ass', '2010.Sep.28', '12.02.30', 'hi lyn!'),
(71, 12, 'john boknoy', '2010.Sep.28', '21.12.01', 'mga buang mong tanan......liwat mo ni agusto....'),
(72, 12, 'john boknoy', '2010.Sep.28', '21.12.20', 'mga buang mong tanan......liwat mo ni agusto....'),
(74, 13, 'mira mae cabcad', '2010.Sep.29', '10.23.20', 'musta?'),
(75, 14, 'raiza lim', '2010.Sep.30', '05.56.08', 'haha!... just new here.... ^.^'),
(76, 11, 'shaiva nur o mangaccat', '2010.Sep.30', '20.06.38', 'hello guys'),
(77, 17, 'caroline', '2010.Sep.30', '20.12.45', 'HEY i''M HERE NOY! THANKS! =) =c9>');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `uid` int(20) NOT NULL AUTO_INCREMENT,
  `uname` varchar(50) DEFAULT NULL,
  `pname` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `uepass` varchar(50) DEFAULT NULL,
  `uupass` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`uid`, `uname`, `pname`, `gender`, `uepass`, `uupass`) VALUES
(2, 'aa', 'ass', 'Male', '964d72e72d053d501f2949969849b96c', 'ass'),
(3, 'amor3', 'aa', 'Female', '4124bc0a9335c27f086f24ba207a4912', 'aa'),
(4, 'jas', 'jasmine', 'Female', '0cc175b9c0f1b6a831c399e269772661', 'a'),
(5, 'aug', 'august', 'Male', '0cc175b9c0f1b6a831c399e269772661', 'a'),
(6, 'ass', 'ax', 'Male', '0cc175b9c0f1b6a831c399e269772661', 'a'),
(7, 'amor31', 'rehg', 'Female', '4124bc0a9335c27f086f24ba207a4912', 'aa'),
(8, 'august125', 'august', 'Male', '964d72e72d053d501f2949969849b96c', 'ass'),
(9, 'lynmairesse_abenio@yahoo.com', 'Lyn Mairesse Abenio', 'Female', '7e1bb751b49b4e4f7c8bb849cdd0e677', '03181990'),
(10, 'trisomy2008', 'trisomy', 'Male', '1c8f4d12b3a72c843071d5f574de1b2d', 'trisomy'),
(11, 'shaiva', 'shaiva nur o mangaccat', 'Female', 'e9cb131d2ae83780ba1f09a682c5f504', 'palawan'),
(12, 'imgaypromise', 'john boknoy', 'Male', '0b9a54438fba2dc0d39be8f7c6c71a58', 'asshole'),
(13, 'mira mae', 'mira mae cabcad', 'Female', '5edd7a0c306fb3819fcd90e048584b26', '151991'),
(14, 'CHInX', 'raiza lim', 'Female', '82dd72139468ccefdb26ac6d9ab3f648', '09163651809'),
(15, 'hbaang', 'Henry', 'Male', '41dabe0c59a3233e3691f3c893eb789e', 'servant'),
(16, 'ranil', 'ranil jaramillo', 'Male', '980abc9511ec9ac91992e290eeabafa1', 'jaramillo'),
(17, 'carol9_pink', 'caroline', 'Female', '71af0cc74d03fb1219b3f80683886569', 'c9isabahai'),
(18, 'irenebatican@yahoo.com', 'irene', 'Female', '65285ac7c754ae478ed41fc4e5867e9e', 'exotic');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `address`, `gender`, `contactno`, `email`) VALUES
(4, 'oooo', 'ce7ce9108ae218e4ee612b0b36e3ed1d', 'oooo', '', 'Male', NULL, ''),
(3, 'jmngoho', '24bc8a6655a0623a7f4e402c12df4b9c', 'Julius Memar Ngoho', '', 'Male', NULL, ''),
(5, 'august', '5da2297bad6924526e48e00dbfc3c27a', 'Amor', '', 'Male', NULL, '');
