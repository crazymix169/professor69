<?

require "config.php";
        session_start();
        //Check whether the session variable SESS_ID is present or not
        if(!isset($_SESSION['SESS_USER_ID']) || (trim($_SESSION['SESS_USER_ID']) == '')) {
                header("location: login2.php");
                exit();
        }
        
   $username = $_SESSION['SESS_USER_USER_NAME'];
   //$userid = $_SESSION['SESS_USER_ID'];
        $color1 = "#CCFFCC"; 
    $color2 = "#BFD8BC";
        $kolzz="yellow";

?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Photo Gallery</title>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">
<style type="text/css">
body
{
background-color:#d0e4fe;
}
h1
{
color:orange;
text-align:center;
}
p
{
font-family:"Times New Roman";
font-size:20px;
}
</style>

<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/topbkg.gif">
  <tr>
    <td width="50%"><img border="0" src="img/rose.jpg" width="142" height="66"></td>
    <td width="50%">
      <p align="right"><img border="0" src="img/topright.gif" width="327" height="66"></td>
  </tr>
</table>

<?

$act = $_GET['act'];

if ($act=="")

{

        echo "<center><h2>My Photo Gallery</h2></center><hr>";
        if(!empty($username))
        {
        echo'
        <table border="0" width="100%">
         <tr>

            <td width="20%"><center><a href="upload.php">Upload Images</a></center></td>

             <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
                <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';
        }

        if(!empty($_GET[Start]))
        {
                $Start = $_GET[Start];
        }
        else
        {
                $Start = '0';
        }

        $Cols = 1;
        $Rows = 3;
        $Thumbnail_Image_width_heigh = 250;
        $Thumb_Size = 320;
        $ByPage = $Cols * $Rows;
        $Show_full_sized_image="Yes";
        $Display_File_name="Yes";

        $qnav = "select * from `images` where `Username` = '$username' and `Published` = 'Yes'";
        $rnav = mysql_query($qnav) or die(mysql_error());
        $rows = mysql_num_rows($rnav);
                /*
                if($rows > $ByPage)
                {

                                $NextPrev =  "<br><table align=center width=50%>";
                                $NextPrev .= "<td align=center><strong>Pages:</strong> | ";

                                $pages = ceil($rows/$ByPage);

                                for($i = 0; $i <= ($pages); $i++)
                                {
                                        $PageStart = $ByPage*$i;

                                        $i2 = $i + 1;

                                        if($PageStart == $Start)
                                        {
                                                $links[] = " <strong>$i2</strong>\n\t ";
                                        }
                                        elseif($PageStart < $rows)
                                        {
                                                $links[] = " <a href=photos.php>$i2</a>\n\t";
                                        }
                                }

                                $links2 = implode(" | ", $links);
                        
                                $NextPrev .= $links2;

                                $NextPrev .=  "| </td>";

                                $NextPrev .= "</table><br>\n";

                }*/

        echo "<br><br><center>$NextPrev</center>";
                        $WidthHeight = explode(" x ","$aSettings[Popup_window]");

                        //$qData = "select * from `images` where `Username` = '$username' and `Published` = 'Yes' limit $Start, $ByPage";
                        $qData = "select * from `images` ";
                        $rData = mysql_query($qData) or die(mysql_error());
                        $Total = mysql_num_rows($rData);
                        if(mysql_num_rows($rData) == '0')
                        {
                                echo "<br><center><b>No Image found.</b></center>";
                        }
                        else
                        {
                                echo '<table border="0" cellspacing="1" width="750">';
                                $n = 1;
                                while($aData = mysql_fetch_array($rData))
                                {        
                                           $uzerid=$fields[userid];
                                           $b = $n%$Cols;
                                                if(!empty($aData[Image]))
                                                {
                                                         $xy = @getimagesize("upload/$aData[Image]");
                                                         $tx = $xy[0];
                                                         $ty = $xy[1];
                                                                
                                                        if($Thumbnail_Image_width_heigh == Height)
                                                        {
                                                                 $y = $Thumb_Size;
                                                                 $x = $tx/$ty;
                                                                 $x = $x * $Thumb_Size;
                                                        }
                                                        else
                                                        {
                                                                 $x = $Thumb_Size;
                                                                 $y = $ty/$tx;
                                                                 $y = $y * $Thumb_Size;
                                                        }
                                                                        
                                                        if($Show_full_sized_image==Yes)
                                                        {
                                                                        $image = "<a href=\"#\" onclick=\"javascript:window.open('upload/$aData[Image]', '_blank', 'width=$WidthHeight[0], height=$WidthHeight[1], scrollbars=yes');return false\"><img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                        }
                                                        else
                                                        {
                                                                        $image = "<img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                        }
                                                                
                                
                                                }
                                                        

                                        if($Display_File_name=="Yes")
                                        {
                                        $Title = "<br> $aData[Title]";

                                        }
                                                        
                                                        
                                                        
                                                        
                                        if($b == 1)
                                        {
                                        echo "<tr>";
                                        }


                                        //echo "<td><center>$image $Title <br><strong>Viewed:</strong> $aData[Viewed]</a><br><a href=\"deleteimage.php?ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                        echo "<td><center>$image $Title <br><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment $Title\n</a>";
                                        
                                                if($aData[userid]==$_SESSION['SESS_USER_ID'])
                                                {
                                                        //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                                        echo"<br><center><a href='photos.php?act=del&ImageID=$aData[ImageID]'>Delete $Title</a></center><br></td>\n";
                                                        //echo "anal sex\n";
                                                }
                                                else
                                                {
                                                        echo "</td>\n";
                                                }
                                                echo "<br>";
                                        //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                        //echo "<br><center><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment2</strong> </a>";


                                        if($b == 0)
                                        {
                                        echo "</tr>\n\n";
                                        }
                                        elseif($Total == $n)
                                        {
                                        echo "</tr>\n\n";
                                        }
                                                
                                        $n++;
                                        
                                }
                                echo'</table>';
                                echo"$NextPrev";
                        }


}
elseif($act=="del") //Confirm Deletion
{
   echo "Delete Selected";
   $ImageID = $_GET['ImageID'];
   $qry="SELECT * FROM images WHERE ImageID='$ImageID';";
   $result = @mysql_query($qry);
  
  while($fields = mysql_fetch_array($result))
        { 
          $mname=$fields[title];
        }
   echo "<br><br><br>";
                  echo "<blockquote>Are you sure to delete picture $mname with id number $ImageID ?<p>";
                  echo "<br><center>";
                  echo "<b>[<a href='photos.php?act=delete&ImageID=$ImageID'>Yes</a>]  /  [<a href='photos.php'>No</a>]</b><br><br>";
                  
}
elseif($act=="delete")
{
   $ImageID = $_GET['ImageID'];
   
   $qry="SELECT * FROM images WHERE ImageID='$ImageID';";
   $result = @mysql_query($qry);
   
   while($fields = mysql_fetch_array($result))
        { 
          $file=$fields[Image];
          //$file = "test.txt";
        }
   //$file="upload/"..
        if(file_exists("upload/$file"))
                if (!unlink("upload/$file"))
                  {
                  echo ("Error deleting $file");
                  die("Query failed mao ni...Continue to <a href='photos.php'>photos</a>");
                  }
                else
                  {
                  echo ("Deleted $file");
                  }
        else
                echo ("the file $file does not exist!!!");
        
        echo "<br>";
   $qry="DELETE FROM images WHERE ImageID='$ImageID';";
   
   $result = @mysql_query($qry);
   if($result)
   {
          
          
          
          $qry="DELETE FROM tblimgcmt WHERE ImgID='$ImageID';";
           $result = @mysql_query($qry);
           if($result)
           {
                        echo "Record Deleted. Continue to <a href='photos.php'>photos</a>"; 
           }
           else
           {
                        die("Query failed mao ni...Continue to <a href='photos.php'>photos</a>");
           }
          
   }else {die("Query failed mao ni...2Continue to <a href='photos.php'>photos</a>");}
}
elseif ($act=="ucomm")
{
   $ImageID = $_GET['ImageID'];
   
   echo "<h1>Add New Message Comment</h1><hr>
                 <form name='form1' action='photos.php?act=cmmnt&ImageID=$ImageID' method='POST'>
                 
                 <table>
                 <tr>
                 <p><td>Comment:</td><td> <input type='text' name='komento' size='100'></td><p>
                 </tr>
                 <tr>
                 <p><td><input type='submit' value='comment!'></td><td><input type='reset' value='Reset'></td><p>
                 </tr>
                 </table>
                 </form>
                ";
                echo "<br><a href='photos.php'>Go to Photo Gallery</a>";
                echo "<center><h2>My Photo</h2></center><hr>";
        if(!empty($username))
        {
        echo'
        <table border="0" width="100%">
          <tr>
                <td width="20%"><center><a href="upload.php">Upload Images</a></center></td>
                <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
                <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';
        }

        if(!empty($_GET[Start]))
        {
                $Start = $_GET[Start];
        }
        else
        {
                $Start = '0';
        }

        $Cols = 1;
        $Rows = 3;
        $Thumbnail_Image_width_heigh = 250;
        $Thumb_Size = 320;
        $ByPage = $Cols * $Rows;
        $Show_full_sized_image="Yes";
        $Display_File_name="Yes";

        $qnav = "select * from `images` where `Username` = '$username' and `Published` = 'Yes'";
        $rnav = mysql_query($qnav) or die(mysql_error());
        $rows = mysql_num_rows($rnav);
                /*
                if($rows > $ByPage)
                {

                                $NextPrev =  "<br><table align=center width=50%>";
                                $NextPrev .= "<td align=center><strong>Pages:</strong> | ";

                                $pages = ceil($rows/$ByPage);

                                for($i = 0; $i <= ($pages); $i++)
                                {
                                        $PageStart = $ByPage*$i;

                                        $i2 = $i + 1;

                                        if($PageStart == $Start)
                                        {
                                                $links[] = " <strong>$i2</strong>\n\t ";
                                        }
                                        elseif($PageStart < $rows)
                                        {
                                                $links[] = " <a href=photos.php>$i2</a>\n\t";
                                        }
                                }

                                $links2 = implode(" | ", $links);
                        
                                $NextPrev .= $links2;

                                $NextPrev .=  "| </td>";

                                $NextPrev .= "</table><br>\n";

                }*/

        echo "<br><br><center>$NextPrev</center>";
                        $WidthHeight = explode(" x ","$aSettings[Popup_window]");

                        //$qData = "select * from `images` where `Username` = '$username' and `Published` = 'Yes' limit $Start, $ByPage";
                        $qData = "select * from `images` where `ImageID`='$ImageID'";
                        $rData = mysql_query($qData) or die(mysql_error());
                        $Total = mysql_num_rows($rData);
                        if(mysql_num_rows($rData) == '0')
                        {
                                echo "<br><center><b>No Image found.</b></center>";
                        }
                        else
                        {
                                echo '<table border="0" cellspacing="1" width="750">';
                                $n = 1;
                                while($aData = mysql_fetch_array($rData))
                                {        
                                   $uzerid=$fields[userid];
                                   $b = $n%$Cols;
                                        if(!empty($aData[Image]))
                                        {
                                                 $xy = @getimagesize("upload/$aData[Image]");
                                                 $tx = $xy[0];
                                                 $ty = $xy[1];
                                                        
                                                if($Thumbnail_Image_width_heigh == Height)
                                                {
                                                         $y = $Thumb_Size;
                                                         $x = $tx/$ty;
                                                         $x = $x * $Thumb_Size;
                                                }
                                                else
                                                {
                                                         $x = $Thumb_Size;
                                                         $y = $ty/$tx;
                                                         $y = $y * $Thumb_Size;
                                                }
                                                                
                                                if($Show_full_sized_image==Yes)
                                                {
                                                                $image = "<a href=\"#\" onclick=\"javascript:window.open('upload/$aData[Image]', '_blank', 'width=$WidthHeight[0], height=$WidthHeight[1], scrollbars=yes');return false\"><img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                }
                                                else
                                                {
                                                                $image = "<img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                }
                                                        
                        
                                        }
                                                

                                if($Display_File_name=="Yes")
                                {
                                $Title = "<br> $aData[Title]";

                                }
                                                
                                                
                                                
                                                
                                if($b == 1)
                                {
                                echo "<tr>\n";
                                }


                                //echo "<td><center>$image $Title <br><strong>Viewed:</strong> $aData[Viewed]</a><br><a href=\"deleteimage.php?ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                echo "<td><center>$image $Title <br><br><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment2\n</a><br>";
                                
                                        if($aData[userid]==$_SESSION['SESS_USER_ID'])
                                        {
                                                //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                                echo"<br><center><a href='photos.php?act=del&ImageID=$aData[ImageID]'>Delete</a></center><br></td>\n";
                                                //echo "anal sex\n";
                                        }
                                        else
                                        {
                                                echo "</td>\n";
                                        }
                                //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                //echo "<br><center><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment2</strong> </a>";


                                if($b == 0)
                                {
                                echo "</tr>\n\n";
                                }
                                elseif($Total == $n)
                                {
                                echo "</tr>\n\n";
                                }
                                                
                                                $n++;
                                                }
                                echo'</table>';
                                echo"$NextPrev";
                        }
                        
                        $qry="SELECT * FROM tblimgcmt WHERE imgid='$ImageID';";
          $result = @mysql_query($qry);
          echo "<h1>Photo Comments</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz' align=left><b>Originator</b></th> 
                
                <th width='230' bgcolor='$kolzz' align=left><b>Photo commentor</b></th> 
                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>comment</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $msgcmtid=$fields[imgcmtid];
                        $msgid=$fields[imgid];
                        $msguid=$fields[imguid]; 
                        $msgpname=$fields[imgpname];
                        $msgcmtuid=$fields[imgcmtuid];
                        $msgcmtpname=$fields[imgcmtpname];
                        $date22=$fields[cdate2];
                        $time22=$fields[ctime2];
                        $cmt=$fields[cmt];
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                        if($msguid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='photos.php?act=comdel&mid=$msgcmtid'>Delete Comment</a>]</td>";
                        }
                        else if($msgcmtuid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='photos.php?act=comdel&mid=$msgcmtid'>Delete comment</a>]</td>";
                        }
                        else
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left></td>";
                        }
                        
                        echo "</tr>";
                        $row_count++;
                }
                echo "</table>
           <hr />";
                
}
elseif ($act=="cmmnt")
        {
           
           $ImageID = $_GET['ImageID'];
           //$mid=$mid;
           $qry="SELECT * FROM images WHERE ImageID='$ImageID';";
           $result = @mysql_query($qry);
                        if($result) 
                        {
                                if(mysql_num_rows($result) == 1)
                                
                                 {
                                        
                                        echo "<center><h2>My Photo Gallery</h2></center><hr>";
        if(!empty($username))
        {
        echo'
        <table border="0" width="100%">
          <tr>
                <td width="20%"><center><a href="upload.php">Upload Images</a></center></td>
                <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
                <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';
        }

        if(!empty($_GET[Start]))
        {
                $Start = $_GET[Start];
        }
        else
        {
                $Start = '0';
        }

        $Cols = 1;
        $Rows = 3;
        $Thumbnail_Image_width_heigh = 250;
        $Thumb_Size = 320;
        $ByPage = $Cols * $Rows;
        $Show_full_sized_image="Yes";
        $Display_File_name="Yes";

        $qnav = "select * from `images` where `Username` = '$username' and `Published` = 'Yes'";
        $rnav = mysql_query($qnav) or die(mysql_error());
        $rows = mysql_num_rows($rnav);
                /*
                if($rows > $ByPage)
                {

                                $NextPrev =  "<br><table align=center width=50%>";
                                $NextPrev .= "<td align=center><strong>Pages:</strong> | ";

                                $pages = ceil($rows/$ByPage);

                                for($i = 0; $i <= ($pages); $i++)
                                {
                                        $PageStart = $ByPage*$i;

                                        $i2 = $i + 1;

                                        if($PageStart == $Start)
                                        {
                                                $links[] = " <strong>$i2</strong>\n\t ";
                                        }
                                        elseif($PageStart < $rows)
                                        {
                                                $links[] = " <a href=photos.php>$i2</a>\n\t";
                                        }
                                }

                                $links2 = implode(" | ", $links);
                        
                                $NextPrev .= $links2;

                                $NextPrev .=  "| </td>";

                                $NextPrev .= "</table><br>\n";

                }*/

        echo "<br><br><center>$NextPrev</center>";
                        $WidthHeight = explode(" x ","$aSettings[Popup_window]");

                        //$qData = "select * from `images` where `Username` = '$username' and `Published` = 'Yes' limit $Start, $ByPage";
                        $qData = "select * from `images` WHERE ImageID='$ImageID';";
                        $rData = mysql_query($qData) or die(mysql_error());
                        $Total = mysql_num_rows($rData);
                        if(mysql_num_rows($rData) == '0')
                        {
                                echo "<br><center><b>No Image found.</b></center>";
                        }
                        else
                        {
                                echo '<table border="0" cellspacing="1" width="750">';
                                $n = 1;
                                while($aData = mysql_fetch_array($rData))
                                {        
                                   $uzerid=$fields[userid];
                                   $b = $n%$Cols;
                                        if(!empty($aData[Image]))
                                        {
                                                 $xy = @getimagesize("upload/$aData[Image]");
                                                 $tx = $xy[0];
                                                 $ty = $xy[1];
                                                        
                                                if($Thumbnail_Image_width_heigh == Height)
                                                {
                                                         $y = $Thumb_Size;
                                                         $x = $tx/$ty;
                                                         $x = $x * $Thumb_Size;
                                                }
                                                else
                                                {
                                                         $x = $Thumb_Size;
                                                         $y = $ty/$tx;
                                                         $y = $y * $Thumb_Size;
                                                }
                                                                
                                                if($Show_full_sized_image==Yes)
                                                {
                                                                $image = "<a href=\"#\" onclick=\"javascript:window.open('upload/$aData[Image]', '_blank', 'width=$WidthHeight[0], height=$WidthHeight[1], scrollbars=yes');return false\"><img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                }
                                                else
                                                {
                                                                $image = "<img border=\"0\" src=\"image.php?File=$aData[Image]&w=$x&h=$y\" width=\"$x\" height=\"$y\"></a>";
                                                }
                                                        
                        
                                        }
                                                

                                if($Display_File_name=="Yes")
                                {
                                $Title = "<br> $aData[Title]";

                                }
                                                
                                                
                                                
                                                
                                if($b == 1)
                                {
                                echo "<tr>\n";
                                }


                                //echo "<td><center>$image $Title <br><strong>Viewed:</strong> $aData[Viewed]</a><br><a href=\"deleteimage.php?ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                echo "<td><center>$image $Title <br><br><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment2\n</a>";
                                
                                        if($aData[userid]==$_SESSION['SESS_USER_ID'])
                                        {
                                                //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                                echo"<br><center><a href='photos.php?act=del&ImageID=$aData[ImageID]'>Delete</a></center><br></td>\n";
                                                //echo "anal sex\n";
                                        }
                                        else
                                        {
                                                echo "</td>\n";
                                        }
                                //echo"<br><a href=\"photos.php?act=del&ImageID=$aData[ImageID]\" onclick=\"return confirmLink(this, 'Delete Image?')\">Delete</a></center><br></td>\n";
                                //echo "<br><center><a href='photos.php?act=ucomm&ImageID=$aData[ImageID]'>Comment2</strong> </a>";


                                if($b == 0)
                                {
                                echo "</tr>\n\n";
                                }
                                elseif($Total == $n)
                                {
                                echo "</tr>\n\n";
                                }
                                                
                                                $n++;
                                                }
                                echo'</table>';
                                echo"$NextPrev";
                        }
                                        
                                        //Login Successful
                                        
                                        $member = mysql_fetch_assoc($result);
                                        $msgid2 = $member['imageid'];
                                        $msguid2 = $member['userid'];
                                        $msgpname2 = $member['Username'];
                                        
                                        function clean4($str) {
                                                $str = @trim($str);
                                                if(get_magic_quotes_gpc()) {
                                                        $str = stripslashes($str);
                                                }
                                                return mysql_real_escape_string($str);
                                        }
                                        date_default_timezone_set("ASia/Manila");
                                        $msgcmtuid=$_SESSION['SESS_USER_ID'];
                                        $msgcmtpname = $_SESSION['SESS_USER_USER_NAME'];
                                        $cdate2=date("Y.M.d");
                                        $ctime2=date("H.i.s");
                                        $cmt = clean4($_POST['komento']);
                                        
                                        
                                        
                                        //Create INSERT query
                                        $qry = "INSERT INTO `tblimgcmt` (`imgcmtid`,`imgid`,`imguid`, `imgpname`,`imgcmtuid`,`imgcmtpname`, `cdate2`, `ctime2`, `cmt`) VALUES (NULL, '$ImageID', '$msguid2', '$msgpname2', '$msgcmtuid', '$msgcmtpname', '$cdate2', '$ctime2', '$cmt');";
                                        $result = @mysql_query($qry);
                                        if($result) {
                                                 echo "New comment was successfully added. Continue to <a href='photos.php'>Photo Gallery22</a>";
                                                 
                                                 
                                                        
                                                        $qry="SELECT * FROM tblimgcmt WHERE imgid='$ImageID';";
                                                  $result = @mysql_query($qry);
                                                  echo "<h1>Photo Comments</h1><hr>
                                                        <table border='1'><thead><tr >
                                                        
                                                        <th width='230' bgcolor='$kolzz'  align=left><b>Originator</b></th> 
                                                        
                                                        <th width='230' bgcolor='$kolzz'  align=left><b>message commentor</b></th> 
                                                        <th width='100' bgcolor='$kolzz'  align=left><b>DATE</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>TIME</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>comment</b></th>
                                                        </tr></thead>";
                                                        $row_count=0;
                                                        while($fields = mysql_fetch_array($result))
                                                        {
                                                                $msgcmtid=$fields[imgcmtid];
                                                                $msgid=$fields[imgid];
                                                                $msguid=$fields[imguid]; 
                                                                $msgpname=$fields[imgpname];
                                                                $msgcmtuid=$fields[imgcmtuid];
                                                                $msgcmtpname=$fields[imgcmtpname];
                                                                $date22=$fields[cdate2];
                                                                $time22=$fields[ctime2];
                                                                $cmt=$fields[cmt];
                                                                if ($row_count % 2==o)
                                                                {
                                                                        $fields_color=$color1;
                                                                }
                                                                else
                                                                {
                                                                        $fields_color=$color2;
                                                                }
                                                                echo "<tr >";
                                                                
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                                                                
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                                                                
                                                                
                                                                
                                                                if($msguid==$_SESSION['SESS_USER_ID'])
                                                                {
                                                                        echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='photos.php?act=comdel&mid=$msgcmtid'>Delete Comment</a>]</td>";
                                                                }
                                                                else if($msgcmtuid==$_SESSION['SESS_USER_ID'])
                                                                {
                                                                        echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='photos.php?act=comdel&mid=$msgcmtid'>Delete comment</a>]</td>";
                                                                }
                                                                else
                                                                {
                                                                        echo "<td bgcolor='$fields_color' nowrap align=left></td>";
                                                                }
                                                                
                                                                echo "</tr>";
                                                                $row_count++;
                                                        }
                                                        echo "</table>
                                                   <hr />";
                                                 
                                                //$task="";
                                                //header("location: contacts.php");
                                                //exit();
                                        }
                                        else {die("Query failed to comment...Continue to <a href='photos.php'>Photo Gallery");}                                        
                                }
                                else 
                                {
                                        echo "Go to <a href='photos.php'>Photo Gallery</a>";
                                }
                        }
                        else 
                        {
                                echo "Not connected";
                                die("Query failed...Continue to <a href='photos.php'>Photo Gallery");
                                echo "Not connected";
                        }
           
        }

//delete comment
elseif($act=="comdel") //Confirm Deletion
{
   echo "Delete Selected";
   $mid = $_GET['mid'];
   $qry="SELECT * FROM tblimgcmt WHERE imgcmtid='$mid';";
   $result = @mysql_query($qry);
  
  while($fields = mysql_fetch_array($result))
        { 
          $mname=$fields[imgcmtpname];
        }
   echo "<br><br><br>";
                  echo "<blockquote>Are you sure to delete the message comment $mname with id number $mid ?<p>";
                  echo "<br><center>";
                  echo "<b>[<a href='photos.php?act=comdelete&mid=$mid'>Yes</a>]  /  [<a href='photos.php'>No</a>]</b><br><br>";
                  
}
elseif($act=="comdelete")
{
   $mid = $_GET['mid'];
   $qry="DELETE FROM tblimgcmt WHERE imgcmtid='$mid';";
   $result = @mysql_query($qry);
   if($result)
   {
          
          
          
          
                        echo "Commnent Deleted. Continue to <a href='photos.php'>Photo Gallery</a>"; 
                          
          
   }else {die("Query failed mao ni...Continue to <a href='photos.php'>Photo Gallery</a>");}
}


?>                  

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">This is a website created by August Tabucanon</font></p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">Submitted to Mr. Julius Memar J. Ngoho</font></p>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">In partial fulfillment of the Requirements in Information Systems and Security</font></p>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/botline.gif">
  <tr>
    <td width="100%"><img border="0" src="img/botline.gif" width="41" height="12"></td>
  </tr>
</table>


</body>

</html>        
        