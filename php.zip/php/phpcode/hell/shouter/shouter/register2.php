<?
   
        require "config.php";
        $task=$_GET['task'];

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Photo Gallery</title>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">
<style type="text/css">
body
{
background-color:#d0e4fe;
}
h1
{
color:orange;
text-align:center;
}
p
{
font-family:"Times New Roman";
font-size:20px;
}
</style>

<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/topbkg.gif">
  <tr>
    <td width="50%"><img border="0" src="img/rose.jpg" width="142" height="66"></td>
    <td width="50%">
      <p align="right"><img border="0" src="img/topright.gif" width="327" height="66"></td>
  </tr>
</table>
                                  <?
                                  
                                  function show_form()
                                        {
                                                 
                                                 echo'
                                                <table border="0" width="100% ">
                                                 <tr>
                                                        <td width="20%"><center><a href="register2.php?task=addnew">Add new user</a></center></td>
                                                        
                                                        <td width="20%"><center><a href="login2.php">Go to Login form</a></center></td>
                                                  </tr>
                                                </table>';

                                                 //echo "<p><a href='register2.php?task=addnew'>Add New User</a></p>";
                                                 //echo "<p><a href='login2.php'>GoTo LOgin Form</a></p>";
                                        }
                                        
          
          if ($task=='')
          {  
                 
                 
                show_form();
                //echo "<p><a href='register2.php?task=addnew'>Add New User</a></p>";
                 
          }
          elseif ($task=="addnew")
                {
                   echo "<h1>Add New Contact</h1><hr>
                                 <form name='form1' action='register2.php?task=savenew' method='POST'>
                                 <table>
                                 <tr>
                                 <p><td>*Username:</td><td> <input type='text'name='uname' size='20'></td><p>
                                 </tr>
                                 <tr>
                                 <p><td>*Name </td><td><input type='text' name='pname' size='50'></td><p>
                                 </tr>
                                 <tr>
                                 <p><td>Gender:</td><td> <select name='gender'><option>Male</option><option>Female</option></select></td><p>
                                 </tr>
                                 <tr>
                                 <p><td>*password:</td><td> <input type='password' name='uepass' size='20'></td><p>
                                 </tr>
                                 <tr>
                                 <p><td>*confirm password</td> <td><input type='password' name='cpass' size='20'></td><p>
                                 </tr>
                                 <tr>
                                 <p><td>*required</td><td></td><p>
                                 </tr>
                                 <tr>
                                 <p><td><input type='submit' value='Submit'></td><td><input type='reset' value='Reset'></td><p>
                                 </tr>
                                 </table>
                                 </form>
                                 ";

                                 echo'
                                                <table border="0" width="100% ">
                                                 <tr>
                                                        
                                                        
                                                        <td width="20%"><center><a href="login2.php">Go to Login form</a></center></td>
                                                  </tr>
                                                </table>';
                }
           elseif ($task=='savenew')
          {
                //Array to store validation errors
                $errmsg_arr = array();
                
                //Validation error flag
                $errflag = false;
                
                //Function to sanitize values received from the form. Prevents SQL injection
                function clean($str) {
                        $str = @trim($str);
                        if(get_magic_quotes_gpc()) {
                                $str = stripslashes($str);
                        }
                        return mysql_real_escape_string($str);
                }//fucntion clean
                
                //Sanitize the POST values
                $uname = clean($_POST['uname']);
                $pname = clean($_POST['pname']);
                $gender = clean($_POST['gender']);
                $uepass = clean($_POST['uepass']);
                $cpass = clean($_POST['cpass']);
                
                
                
                
                //Input Validations
                if($uname == '') {
                        $errmsg_arr[] = 'No username supplied, please choose your username';
                        $errflag = true;
                }
                if($uepass == '') {
                        $errmsg_arr[] = 'Password is missing';
                        $errflag = true;
                }
                if($cpass == '') {
                        $errmsg_arr[] = 'Confirm password is missing';
                        $errflag = true;
                }
                if( strcmp($uepass, $cpass) != 0 ) {
                        $errmsg_arr[] = 'Passwords did not match';
                        $errflag = true;
                }
                if($pname == '') {
                        $errmsg_arr[] = 'Name is missing';
                        $errflag = true;
                }
                
                
                //Check for duplicate login ID
                if($username != '') {
                        $qry = "SELECT * FROM tbluser WHERE uname='$uname'";
                        $result = mysql_query($qry);
                        if($result) {
                                if(mysql_num_rows($result) > 0) {
                                        $errmsg_arr[] = 'Username already in use';
                                        $errflag = true;
                                }
                                @mysql_free_result($result);
                        }
                        else {
                                die("Query failed sa username <a href='register2.php?task=addnew'> Back to Add New User</a>");
                        }
                 }
                 
                 
                 
                //If there are input validations, redirect back to the registration form
                if($errflag) {
                        $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
                        session_write_close();
                        echo "<blockquote>\n";
                        if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
                                echo "<h2>The following errors were encountered: </h2>\n<ul>";
                                foreach($_SESSION['ERRMSG_ARR'] as $msg) {
                                        echo "<li>",$msg,"</li>\n"; 
                                }
                                echo "</ul>\n";
                                unset($_SESSION['ERRMSG_ARR']);
                        }
                        echo "\n<h3>Please try again.</h3></blockquote>\n";
                        show_form();
                        //exit();
                }
                else
                {
                        //Create INSERT query
                        $qry = "INSERT INTO `tbluser` (
                                          `uname`, `pname`, 
                                           `gender`,`uepass`,`uupass`) 
                                          VALUES ('$uname','$pname', '$gender',
                                          '".md5($uepass)."', '$uepass');";
                                          
                        $result = @mysql_query($qry);
                        if($result) {
                                $task="";
                                echo "<blockquote><br>Congratulations! <br>You have successfully registered.<br>";
                                echo "You may now <a href='login2.php'>Login to continue</a>.<br><br></blockquote>";
                        }else {die("Query failed mao ni");}
                }
}                        
                                        
                                        
                                  ?>
                                  <p>&nbsp;</p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">This is a website created by August Tabucanon</font></p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">Submitted to Mr. Julius Memar J. Ngoho</font></p>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">In partial fulfillment of the Requirements in Information Systems and Security</font></p>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/botline.gif">
  <tr>
    <td width="100%"><img border="0" src="img/botline.gif" width="41" height="12"></td>
  </tr>
</table>


</body>

</html>
