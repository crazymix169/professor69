<?
require "config.php";
session_start();
//Check whether the session variable SESS_ID is present or not
if(!isset($_SESSION['SESS_USER_ID']) || (trim($_SESSION['SESS_USER_ID']) == '')) {
  header("location: login2.php");
  exit();
}
        
$username = $_SESSION['SESS_USER_USER_NAME'];
$userid = $_SESSION['SESS_USER_ID'];

if(isset($_POST[Are]))
{
$Cid = $_POST[Cid];
$Sid = $_POST[Sid];
$Title = $_POST[Title];
$Image = $_FILES[Image][name];
$Published = $_POST[Published];
$TimeStamp = time();
$t = time();



    function getFileExtension($str) {
        $i = strrpos($str,".");
        if (!$i) { return ""; }
        $l = strlen($str) - $i;
        $ext = substr($str,$i+1,$l);
        $ext = strtolower($ext);
                if($ext == jpg || $ext == jpeg || $ext == gif || $ext == png)
                {
                }
                else
                {
                echo"<strong>$ext</strong> type is not accepted.Please upload only JPG, Gif and PNG Extenstions";
                exit();
                }
        return $ext;
                 }






        if(!empty($Image))
                {
        $ExtImage = getFileExtension($Image);
                if($ExtImage  == jpeg)
                {
                $ExtImage  = jpg;
                }
                $NewImage = "$t.$ExtImage";
        copy($_FILES[Image][tmp_name], "upload/$NewImage");
                }

                
                $q1 = "INSERT INTO `images` (`ImageID` , `Cid` , `Sid` , `Title` , `Image` , `Viewed` , `Published` , `TimeStamp` ,`Userid`, `Username` ) VALUES ( '', '$Cid', '$_POST[Sid]', '$Title', '$NewImage', '$Viewed', 'Yes', '$TimeStamp' ,'$userid', '$username')";
                mysql_query($q1) or die(mysql_error());
                header("location:photos.php");
                
                }


?>
<tr> 
      <td width="252">&nbsp;</td>
      <td width="549">&nbsp;</td>
    </tr>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Photo Gallery</title>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">
<style type="text/css">
body
{
background-color:#d0e4fe;
}
h1
{
color:orange;
text-align:center;
}
p
{
font-family:"Times New Roman";
font-size:20px;
}
</style>

<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/topbkg.gif">
  <tr>
    <td width="50%"><img border="0" src="img/rose.jpg" width="142" height="66"></td>
    <td width="50%">
      <p align="right"><img border="0" src="img/topright.gif" width="327" height="66"></td>
  </tr>
</table>
<script language="JavaScript">
function imagesAddd(theForm)
{

  if (theForm.Title.value == "")
  {
        alert("Please enter your Title.");
        theForm.Title.focus();
        return (false);
  }
  
  if (theForm.Image.value == "")
  {
        alert("Please enter your Image.");
        theForm.Image.focus();
        return (false);
  }
  }
</script>        

<?

echo'
        <table border="0" width="100% ">
         <tr>
            <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
            <td width="20%"><center><a href="photos.php">Go to Photo Gallery</a></center></td>
            <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';

?>                                
                                
                                                  
                <center>
<h2>Upload Images</h2>
<form name="form" method="POST" enctype="multipart/form-data" action="upload.php" onsubmit="return imagesAddd(this)">
<table border="0" width="600">

<td width="252">Title:</td>
<td width="549"><input type="text" name="Title" size="20" maxlength="50"></td>
</tr>

<tr> 
      <td width="252">&nbsp;</td>
      <td width="549">&nbsp;</td>
    </tr>


<tr>
<td width="252">Image:</td>
<td width="549"><input type="file" name="Image" size="21"></td>
</tr>
    <tr> 
      <td width="252">&nbsp;</td>
      <td width="549">&nbsp;</td>
    </tr>
    <tr> 
      <td width="252">&nbsp;</td>
      <td width="549"><input type="submit" value="Upload Image" name="Are"></td>
    </tr>
</table>
</form>
</center>        
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">This is a website created by August Tabucanon</font></p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">Submitted to Mr. Julius Memar J. Ngoho</font></p>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">In partial fulfillment of the Requirements in Information Systems and Security</font></p>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/botline.gif">
  <tr>
    <td width="100%"><img border="0" src="img/botline.gif" width="41" height="12"></td>
  </tr>
</table>


</body>

</html>        
