<?
    require "config.php";
        session_start();
        //Check whether the session variable SESS_ID is present or not
        if(!isset($_SESSION['SESS_USER_ID']) || (trim($_SESSION['SESS_USER_ID']) == '')) {
                header("location: login2.php");
                exit();
        }
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Shoutbox</title>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">
<style type="text/css">
body
{
background-color:#d0e4fe;
}
h1
{
color:orange;
text-align:center;
}
p
{
font-family:"Times New Roman";
font-size:20px;
}
</style>

<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/topbkg.gif">
  <tr>
    <td width="50%"><img border="0" src="img/rose.jpg" width="142" height="66"></td>
    <td width="50%">
      <p align="right"><img border="0" src="img/topright.gif" width="327" height="66"></td>
  </tr>
</table>
<!--
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/blackline.gif">
  <tr>
    <td width="100%"><font color="#B8C0F0" face="Arial" size="2"><b>&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link</b></font></td>
  </tr>
</table>-->

<?        
    $pname = $_SESSION['SESS_USER_USER_NAME'];
        $uid = $_SESSION['SESS_USER_ID'];
        
    $qry="SELECT * FROM tblmsg;";
        $result = @mysql_query($qry);
        
        $act = $_GET['act']; 
        $color1 = "#CCFFCC"; 
    $color2 = "#BFD8BC";
        $kolzz="yellow"; 
    $row_count = 0;
        
        date_default_timezone_set("ASia/Manila");
        function AddNew()
        {
           
        }
        
  echo'
        <table border="0" width="100%">
         <tr>
            <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
            <td width="20%"><center><a href="photos.php">Go to Photo Gallery</a></center></td>
            <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';

  if ($act=="")
  {
  echo "<h1>Messages</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz' align=left><b>Name</b></th> 
                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>Message</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $mid=$fields[msgid]; 
                        $userid=$fields[uid];
                        $sname=$fields[pname];
                        $date22=$fields[date2];
                        $time22=$fields[time2];
                        $mess=$fields[mesg];
                        
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td  bgcolor='$fields_color' nowrap>$sname</td>";
                        echo "<td bgcolor='$fields_color' nowrap>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap>$mess</td>"; 
                        echo "<td  bgcolor='$fields_color' nowrap>[<a href='shout.php?act=view&mid=$mid'>View</a>]</td>";
                        echo "<td bgcolor='$fields_color' nowrap>[<a href='shout.php?act=ucomm&mid=$mid'>Comment</a>]</td>";
                        //echo "<td align=left>[<a href='contacts.php?act=edit&id=$id'>Edit</a>]</td>";
                        if($userid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td    bgcolor='$fields_color' nowrap>[<a href='shout.php?act=del&mid=$mid'>Delete</a>]</td>";
                        }
                        else
                        {
                                echo "<td    bgcolor='$fields_color' nowrap></td>";
                        }
                        
                        echo "</tr>";
                        $row_count++;
                }        
        echo "</table>
           <hr />
             <p><a href='shout.php?act=addnew'> Add New Message</a></p>";
                         echo"<p><a href='shout.php?act=epass'> Edit Password</a></p>";
                         echo "Go To <a href='shout.php'>Shout</a>";
                        // echo "Go To <a href='mchoice.php'>Numbers</a>";
        }
        elseif ($act=="addnew")
        {
           echo "<h1>Add New Message</h1><hr>
                 <form name='form1' action='shout.php?act=savenew' method='POST'>
                         
                         <table>
                         <tr>
                         <p><td>Message:</td><td> <input type='text' name='mesg' size='100'></td><p>
                         </tr>
                         <tr>
                         <p><td><input type='submit' value='Shout!'></td><td><input type='reset' value='Reset'></td><p>
                         </tr>
                         </table>
                         </form>
                ";
                        echo "Go To <a href='shout.php'>shoutbox</a>"; 
        }
        elseif ($act=="savenew")
        {
           AddNew();
           function clean($str) {
                        $str = @trim($str);
                        if(get_magic_quotes_gpc()) {
                                $str = stripslashes($str);
                        }
                        return mysql_real_escape_string($str);
                }
                date_default_timezone_set("ASia/Manila");
                $uid=$_SESSION['SESS_USER_ID'];
                $pname = $_SESSION['SESS_USER_USER_NAME'];
                $date2=date("Y.M.d");
                $time2=date("H.i.s");
                $mesg = clean($_POST['mesg']);
                
                //If there are input validations, redirect back to the registration form
                if($errflag) {
                        $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
                        session_write_close();
                        header("location: shout.php?m=error");
                        exit();
                }
           //Create INSERT query
                $qry = "INSERT INTO `tblmsg` (`msgid`,`uid`, `pname`, `date2`, `time2`, `mesg`) VALUES (NULL, '$uid', '$pname', '$date2', '$time2', '$mesg');";
                $result = @mysql_query($qry);
                if($result) {
                                 echo "New record was successfully added. Continue to <a href='shout.php'>Shoutbox</a>";
                                 $qry="SELECT * FROM tblmsg;";
                                 $result = @mysql_query($qry);
                                 
                                 echo "<h1>Messages</h1><hr>
                        <table border='1'><thead><tr >
                        
                        <th width='230' bgcolor='$kolzz' align=left><b>Name</b></th> 
                        <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                        <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                        <th width='150' bgcolor='$kolzz' align=left><b>Message</b></th>
                        </tr></thead>";
                        $row_count=0;
                        while($fields = mysql_fetch_array($result))
                        {
                                $mid=$fields[msgid]; 
                                $userid=$fields[uid];
                                $sname=$fields[pname];
                                $date22=$fields[date2];
                                $time22=$fields[time2];
                                $mess=$fields[mesg];
                                
                                //$fields_color = ($row_count % 2) ? $color1 : $color2;
                                
                                if ($row_count % 2==o)
                                {
                                        $fields_color=$color1;
                                }
                                else
                                {
                                        $fields_color=$color2;
                                }
                                
                                echo "<tr >";
                                
                                echo "<td  bgcolor='$fields_color' nowrap>$sname</td>";
                                echo "<td bgcolor='$fields_color' nowrap>$date22</td>";
                                echo "<td bgcolor='$fields_color' nowrap>$time22</td>";
                                echo "<td bgcolor='$fields_color' nowrap>$mess</td>"; 
                                echo "<td  bgcolor='$fields_color' nowrap>[<a href='shout.php?act=view&mid=$mid'>View</a>]</td>";
                                echo "<td bgcolor='$fields_color' nowrap>[<a href='shout.php?act=ucomm&mid=$mid'>Comment</a>]</td>";
                                //echo "<td align=left>[<a href='contacts.php?act=edit&id=$id'>Edit</a>]</td>";
                                if($userid==$_SESSION['SESS_USER_ID'])
                                {
                                        echo "<td    bgcolor='$fields_color' nowrap>[<a href='shout.php?act=del&mid=$mid'>Delete</a>]</td>";
                                }
                                else
                                {
                                        echo "<td    bgcolor='$fields_color' nowrap></td>";
                                }
                                
                                echo "</tr>";
                                $row_count++;
                        }        
                echo "</table>
                   <hr />";
            
                }else {die("Query failed mao ni...Continue to <a href='shout.php'>shoutbox");}
        }
        elseif ($act=="ucomm")
        {
           $mid = $_GET['mid'];
           
           echo "<h1>Add New Message Comment</h1><hr>
                 <form name='form1' action='shout.php?act=cmmnt&mid=$mid' method='POST'>
                         
                         <table>
                         <tr>
                         <p><td>Comment:</td><td> <input type='text' name='komento' size='100'></td><p>
                         </tr>
                         <tr>
                         <p><td><input type='submit' value='comment!'></td><td><input type='reset' value='Reset'></td><p>
                         </tr>
                         </table>
                         </form>
                ";
                //echo "Go To <a href='shout.php'>shoutbox</a>"; 
                
                $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
          $result = @mysql_query($qry);
          echo "<h1>Message</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz' align=left><b>Name</b></th> 
                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>Message</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $mid=$fields[msgid]; 
                        $userid=$fields[uid];
                        $sname=$fields[pname];
                        $date22=$fields[date2];
                        $time22=$fields[time2];
                        $mess=$fields[mesg];
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$sname</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$mess</td>"; 
                        
                        echo "</tr>";
                        $row_count++;
                }        
        echo "</table>
           <hr />";
                
                $qry="SELECT * FROM tblcmt WHERE msgid='$mid';";
          $result = @mysql_query($qry);
          echo "<h1>Message Comments</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz' align=left><b>Originator</b></th> 
                
                <th width='230' bgcolor='$kolzz' align=left><b>message commentor</b></th> 
                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz' align=left><b>comment</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $msgcmtid=$fields[msgcmtid];
                        $msgid=$fields[msgid];
                        $msguid=$fields[msguid]; 
                        $msgpname=$fields[msgpname];
                        $msgcmtuid=$fields[msgcmtuid];
                        $msgcmtpname=$fields[msgcmtpname];
                        $date22=$fields[cdate2];
                        $time22=$fields[ctime2];
                        $cmt=$fields[cmt];
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                        /*
                        if($msguid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete Comment</a>]</td>";
                        }
                        else if($msgcmtuid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete comment</a>]</td>";
                        }
                        else
                        {
                                echo "<td align=left></td>";
                        } */
                        
                        echo "</tr>";
                        $row_count++;
                }
                echo "</table>
           <hr />";
        }
        elseif ($act=="cmmnt")
        {
           
           $mid = $_GET['mid'];
           //$mid=$mid;
           $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
           $result = @mysql_query($qry);
                        if($result) 
                        {
                                if(mysql_num_rows($result) == 1)
                                 {
                                        //Login Successful
                                        
                                        $member = mysql_fetch_assoc($result);
                                        $msgid2 = $member['msgid'];
                                        $msguid2 = $member['uid'];
                                        $msgpname2 = $member['pname'];
                                        
                                        function clean4($str) {
                                                $str = @trim($str);
                                                if(get_magic_quotes_gpc()) {
                                                        $str = stripslashes($str);
                                                }
                                                return mysql_real_escape_string($str);
                                        }
                                        date_default_timezone_set("ASia/Manila");
                                        $msgcmtuid=$_SESSION['SESS_USER_ID'];
                                        $msgcmtpname = $_SESSION['SESS_USER_USER_NAME'];
                                        $cdate2=date("Y.M.d");
                                        $ctime2=date("H.i.s");
                                        $cmt = clean4($_POST['komento']);
                                        
                                        
                                        
                                        //Create INSERT query
                                        $qry = "INSERT INTO `tblcmt` (`msgcmtid`,`msgid`,`msguid`, `msgpname`,`msgcmtuid`,`msgcmtpname`, `cdate2`, `ctime2`, `cmt`) VALUES (NULL, '$msgid2', '$msguid2', '$msgpname2', '$msgcmtuid', '$msgcmtpname', '$cdate2', '$ctime2', '$cmt');";
                                        $result = @mysql_query($qry);
                                        if($result) {
                                                 echo "New comment was successfully added. Continue to <a href='shout.php'>Shoutbox</a>";
                                                 
                                                 $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
                                                  $result = @mysql_query($qry);
                                                  echo "<h1>Message</h1><hr>
                                                        <table border='1'><thead><tr >
                                                        
                                                        <th width='230' bgcolor='$kolzz'  align=left><b>Name</b></th> 
                                                        <th width='100' bgcolor='$kolzz'  align=left><b>DATE</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>TIME</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>Message</b></th>
                                                        </tr></thead>";
                                                        $row_count=0;
                                                        while($fields = mysql_fetch_array($result))
                                                        {
                                                                $mid=$fields[msgid]; 
                                                                $userid=$fields[uid];
                                                                $sname=$fields[pname];
                                                                $date22=$fields[date2];
                                                                $time22=$fields[time2];
                                                                $mess=$fields[mesg];
                                                                if ($row_count % 2==o)
                                                                {
                                                                        $fields_color=$color1;
                                                                }
                                                                else
                                                                {
                                                                        $fields_color=$color2;
                                                                }
                                                                echo "<tr >";
                                                                
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$sname</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$mess</td>"; 
                                                                
                                                                echo "</tr>";
                                                                $row_count++;
                                                        }        
                                                echo "</table>
                                                   <hr />";
                                                        
                                                        $qry="SELECT * FROM tblcmt WHERE msgid='$mid';";
                                                  $result = @mysql_query($qry);
                                                  echo "<h1>Message Comments</h1><hr>
                                                        <table border='1'><thead><tr >
                                                        
                                                        <th width='230' bgcolor='$kolzz'  align=left><b>Originator</b></th> 
                                                        
                                                        <th width='230' bgcolor='$kolzz'  align=left><b>message commentor</b></th> 
                                                        <th width='100' bgcolor='$kolzz'  align=left><b>DATE</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>TIME</b></th>
                                                        <th width='150' bgcolor='$kolzz'  align=left><b>comment</b></th>
                                                        </tr></thead>";
                                                        $row_count=0;
                                                        while($fields = mysql_fetch_array($result))
                                                        {
                                                                $msgcmtid=$fields[msgcmtid];
                                                                $msgid=$fields[msgid];
                                                                $msguid=$fields[msguid]; 
                                                                $msgpname=$fields[msgpname];
                                                                $msgcmtuid=$fields[msgcmtuid];
                                                                $msgcmtpname=$fields[msgcmtpname];
                                                                $date22=$fields[cdate2];
                                                                $time22=$fields[ctime2];
                                                                $cmt=$fields[cmt];
                                                                if ($row_count % 2==o)
                                                                {
                                                                        $fields_color=$color1;
                                                                }
                                                                else
                                                                {
                                                                        $fields_color=$color2;
                                                                }
                                                                echo "<tr >";
                                                                
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                                                                
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                                                                echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                                                                /*
                                                                if($msguid==$_SESSION['SESS_USER_ID'])
                                                                {
                                                                        echo "<td align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete Comment</a>]</td>";
                                                                }
                                                                else if($msgcmtuid==$_SESSION['SESS_USER_ID'])
                                                                {
                                                                        echo "<td align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete comment</a>]</td>";
                                                                }
                                                                else
                                                                {
                                                                        echo "<td align=left></td>";
                                                                } */
                                                                
                                                                echo "</tr>";
                                                                $row_count++;
                                                        }
                                                        echo "</table>
                                                   <hr />";
                                                 
                                                //$task="";
                                                //header("location: contacts.php");
                                                //exit();
                                        }
                                        else {die("Query failed to comment...Continue to <a href='shout.php'>shoutbox");}                                        
                                }
                                else 
                                {
                                        echo "Go to <a href='shout.php'>Shoutbox</a>";
                                }
                        }
                        else 
                        {
                                echo "Not connected";
                                die("Query failed...Continue to <a href='shout.php'>shoutbox");
                                echo "Not connected";
                        }
           
        }
        elseif ($act=="view") //View Record Only
        {
          $mid = $_GET['mid'];
          $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
          $result = @mysql_query($qry);
          echo "<h1>Messages</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz'  align=left><b>Name</b></th> 
                <th width='100' bgcolor='$kolzz'  align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz'  align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz'  align=left><b>Message</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $mid=$fields[msgid]; 
                        $userid=$fields[uid];
                        $sname=$fields[pname];
                        $date22=$fields[date2];
                        $time22=$fields[time2];
                        $mess=$fields[mesg];
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$sname</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$mess</td>"; 
                        
                        echo "</tr>";
                        $row_count++;
                }        
        echo "</table>
           <hr />";
           
           $qry="SELECT * FROM tblcmt WHERE msgid='$mid';";
          $result = @mysql_query($qry);
          echo "<h1>Message Comments</h1><hr>
        <table border='1'><thead><tr >
                
                <th width='230' bgcolor='$kolzz'  align=left><b>Originator</b></th> 
                
                <th width='230' bgcolor='$kolzz'  align=left><b>message commentor</b></th> 
                <th width='100' bgcolor='$kolzz'  align=left><b>DATE</b></th>
                <th width='150' bgcolor='$kolzz'  align=left><b>TIME</b></th>
                <th width='150' bgcolor='$kolzz'  align=left><b>comment</b></th>
                </tr></thead>";
                $row_count=0;
        while($fields = mysql_fetch_array($result))
                {
                        $msgcmtid=$fields[msgcmtid];
                        $msgid=$fields[msgid];
                        $msguid=$fields[msguid]; 
                        $msgpname=$fields[msgpname];
                        $msgcmtuid=$fields[msgcmtuid];
                        $msgcmtpname=$fields[msgcmtpname];
                        $date22=$fields[cdate2];
                        $time22=$fields[ctime2];
                        $cmt=$fields[cmt];
                        if ($row_count % 2==o)
                        {
                                $fields_color=$color1;
                        }
                        else
                        {
                                $fields_color=$color2;
                        }
                        echo "<tr >";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                        
                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                        echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                        
                        if($msguid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete Comment</a>]</td>";
                        }
                        else if($msgcmtuid==$_SESSION['SESS_USER_ID'])
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left>[<a href='shout.php?act=comdel&mid=$msgcmtid'>Delete comment</a>]</td>";
                        }
                        else
                        {
                                echo "<td bgcolor='$fields_color' nowrap align=left></td>";
                        } 
                        
                        echo "</tr>";
                        $row_count++;
                }        
        echo "</table>
           <hr />";
           
                           echo "<p>[<a href='shout.php?act=ucomm&mid=$mid'>add new Comment</a>]</p>";
             echo"<p><a href='shout.php?act=addnew'> Add New Message</a></p>";
                         echo "Go To <a href='shout.php'>shoutbox</a>"; 
        }
        elseif($act=="del") //Confirm Deletion
        {
           echo "Delete Selected";
           $mid = $_GET['mid'];
           $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
           $result = @mysql_query($qry);
          
          while($fields = mysql_fetch_array($result))
                { 
                  $mname=$fields[pname];
                }
           echo "<br><br><br>";
                  echo "<blockquote>Are you sure to delete message $mname with id number $mid ?<p>";
                          echo "<br><center>";
                          echo "<b>[<a href='shout.php?act=delete&mid=$mid'>Yes</a>]  /  [<a href='shout.php'>No</a>]</b><br><br>";
                          
        }
        elseif($act=="delete")
        {
           $mid = $_GET['mid'];
           $qry="DELETE FROM tblmsg WHERE msgid='$mid';";
           $result = @mysql_query($qry);
           if($result)
           {
                  
                  
                  
                  $qry="DELETE FROM tblcmt WHERE msgid='$mid';";
                   $result = @mysql_query($qry);
                   if($result)
                   {
                                   echo "Record Deleted. Continue to <a href='shout.php'>shoutbox</a>"; 
                   }
                   else
                   {
                                   die("Query failed mao ni...Continue to <a href='shout.php'>shoutbox</a>");
                   }
                  
           }else {die("Query failed mao ni...Continue to <a href='shout.php'>shoutbox</a>");}
        }
        //delete comment
        elseif($act=="comdel") //Confirm Deletion
        {
           echo "Delete Selected";
           $mid = $_GET['mid'];
           $qry="SELECT * FROM tblcmt WHERE msgcmtid='$mid';";
           $result = @mysql_query($qry);
          
          while($fields = mysql_fetch_array($result))
                { 
                  $mname=$fields[msgcmtpname];
                }
           echo "<br><br><br>";
           echo "<blockquote>Are you sure to delete the message comment $mname with id number $mid ?<p>";
           echo "<br><center>";
           echo "<b>[<a href='shout.php?act=comdelete&mid=$mid'>Yes</a>]  /  [<a href='shout.php'>No</a>]</b><br><br>";
                          
        }
        elseif($act=="comdelete")
        {
           $mid = $_GET['mid'];
           $qry="DELETE FROM tblcmt WHERE msgcmtid='$mid';";
           $result = @mysql_query($qry);
           if($result)
           {
                  
                  
                  
                  
                                   echo "Commnent Deleted. Continue to <a href='shout.php'>shoutbox</a>"; 
                                     
                  
           }else {die("Query failed mao ni...Continue to <a href='shout.php'>shoutbox</a>");}
        }
        elseif($act=="epass") //edit password
        {
           echo "<h1>Edit You Password</h1><hr>
                 <form name='form1' action='shout.php?act=epassword' method='POST'>
                         
                         <table>
                         <tr>
                         <p><td>Type current password:</td><td> <input type='password' name='ouserpass' size='100'></td><p>
                         </tr>
                         <tr>
                         <p><td>Type new password:</td><td> <input type='password' name='nuserpass' size='100'></td><p>
                         </tr>
                         <tr>
                         <p><td>confirm new password:</td><td> <input type='password' name='vuserpass' size='100'></td><p>
                         </tr>
                         <tr>
                         <p><td><input type='submit' value='Change Password'></td><td><input type='reset' value='Reset'></td><p>
                         </tr>
                         </table>
                         </form>
                ";
                        echo "Go to <a href='shout.php'>shoutbox</a>"; 
                          
        }
        elseif($act=="epassword")//edit password
        {
                function clean2($str) {
                        $str = @trim($str);
                        if(get_magic_quotes_gpc()) {
                                $str = stripslashes($str);
                        }
                        return mysql_real_escape_string($str);
                }
                //date_default_timezone_set("ASia/Manila");
                $uid=$_SESSION['SESS_USER_ID'];
                //$pname = $_SESSION['SESS_USER_USER_NAME'];
                //$date2=date("Y.M.d");
                //$time2=date("H.i.s");
                $oldpass = clean2($_POST['ouserpass']);
                $newpass = clean2($_POST['nuserpass']);
                $vnewpass = clean2($_POST['vuserpass']);
                
                //Input Validations
                if($oldpass == '') {
                        $errmsg_arr[] = 'No username supplied, please choose your username';
                        $errflag = true;
                }
                if($newpass == '') {
                        $errmsg_arr[] = 'Password is missing';
                        $errflag = true;
                }
                if($vnewpass == '') {
                        $errmsg_arr[] = 'Confirm password is missing';
                        $errflag = true;
                }
                if( strcmp($newpass, $vnewpass) != 0 ) {
                        $errmsg_arr[] = 'Passwords did not match';
                        $errflag = true;
                }
                
                
                if($errflag)
                {
                        $_SESSION['ERRMSG_ARR'] = $errmsg_arr;
                        session_write_close();
                        echo "<blockquote>\n";
                        if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
                                echo "<h2>The following errors were encountered: </h2>\n<ul>";
                                foreach($_SESSION['ERRMSG_ARR'] as $msg) {
                                        echo "<li>",$msg,"</li>\n"; 
                                }
                                echo "</ul>\n";
                                unset($_SESSION['ERRMSG_ARR']);
                        }
                        echo "\n<h3>Please try again.</h3></blockquote>\n";
                        echo "<br>[ <a href='shout.php'>Continue to shoutbox</a> ]";
                        //show_form();
                        //exit();
                }
                else
                {
                        $qry=" SELECT * FROM tbluser WHERE uid='$uid' AND uepass='".md5($oldpass)."' ";
                        $result = @mysql_query($qry);
                
                        if($result) 
                        {
                                if(mysql_num_rows($result) == 1 && strcmp($newpass, $vnewpass) == 0) 
                                {
                                        //Login Successful
                                        
                                        //Create UPDATE query
                                        $qry = "UPDATE tbluser SET `uepass`='".md5($newpass)."',`uupass`='$newpass' WHERE uid = $uid;";
                                        $result = @mysql_query($qry);
                                        if($result)
                                        {
                                          echo "<br><br><br>";
                                          echo "<blockquote>password updated.<p>";
                                          echo "<br><center>";
                                          echo "<b>$uid</b> was successfully updated. <br><br>";
                                          echo "[ <a href='shout.php'>Continue to shoutbox</a> ]</center>";
                                          echo "<br><br></p></blockquote>";
                                        }
                                        else {die("Query failed wa niupdate...Continue to <a href='shout.php'>shoutbox</a>");}
                                        
                                        
                                }
                                else
                                {
                                        //Login failed
                                        echo "<blockquote><center>";
                                        echo "<font color=red>Failed to change ur password password. Please try again.</font>";
                                        echo "Continue to <a href='shout.php'>shoutbox</a>"; 
                                        echo "</blockquote></center>";
                                        //showForm();
                                }
                        }
                        else
                        {
                                echo "Not connected";
                                die("Query failed");
                                echo "Continue to <a href='shout.php'>shoutbox</a>"; 
                                //echo "Not connected";
                        }
                }
           
        } 
        else //Unknown query string encountered
        {
          echo "Unknown Action";
          echo "Continue to <a href='shout.php'>shoutbox</a>";
        }
        session_write_close();
        //echo "<br>Go to to <a href='photos.php'>Photo Gallery</a>";
        //echo "Continue to <a href='thee.php'>ASSHOLE</a>";  
        //echo "<br><a href='login2.php?do=logout'>Lougout ".$pname."</a>";
         echo'
        <table border="0" width="100%">
         <tr>
            <td width="20%"><center><a href="shout.php">Go to Shoutbox</a></center></td>
            <td width="20%"><center><a href="photos.php">Go to Photo Gallery</a></center></td>
            <td width="20%"><center><a href="login2.php?do=logout">Logout!</a></center></td>
          </tr>
        </table>';

?>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">This is a website created by August Tabucanon</font></p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">Submitted to Mr. Julius Memar J. Ngoho</font></p>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">In partial fulfillment of the Requirements in Information Systems and Security</font></p>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/botline.gif">
  <tr>
    <td width="100%"><img border="0" src="img/botline.gif" width="41" height="12"></td>
  </tr>
</table>


</body>

</html>		