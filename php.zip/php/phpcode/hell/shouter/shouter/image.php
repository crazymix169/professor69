<?
   function getFileExtension($str) {
        $i = strrpos($str,".");
        if (!$i) { return ""; }
        $l = strlen($str) - $i;
        $ext = substr($str,$i+1,$l);
        $ext = strtolower($ext);
		if($ext == jpg || $ext == jpeg || $ext == gif || $ext == png)
		{

		}
		else
		{
		echo"<strong>$ext</strong> type is not accepted.Please upload only JPG, Gif and PNG Extenstions";
		exit();
		}
        return $ext;
 		}
		


		

      function CopyImageFileGD($name,$ext,$newwidth,$newheight) {

          if($ext == "jpg"){

               $new_img = imagecreatefromjpeg("upload/$name");

           }elseif($ext == "png"){

               $new_img = imagecreatefrompng("upload/$name");

           }elseif($ext == "gif"){

               $new_img = imagecreatefromgif("upload/$name");

           }	   



           list($width, $height) = getimagesize("upload/$name");
		  

           if (function_exists(imagecreatetruecolor)){
           $resized_img = imagecreatetruecolor($newwidth,$newheight);
           }

           imagecopyresized($resized_img, $new_img, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
           ImageJpeg ($resized_img);
           ImageDestroy ($resized_img);
           ImageDestroy ($new_img);
			}
			
        $Ext = getFileExtension($_GET[File]);			



		if(!empty($_GET[File]) && !empty($_GET[w]) && !empty($_GET[h]))
		{
		
		include"config.php";		
		if(!empty($_GET[Large]))
		{
		$q1 = "update `images` set `Viewed` = Viewed+1 where `Image` = '$_GET[File]'";
		mysql_query($q1) or die(mysql_error());		

		}
		header('Content-Type: image/jpeg');
		$Image = CopyImageFileGD($_GET[File],$Ext,$_GET[w],$_GET[h]);
		}

		
?>