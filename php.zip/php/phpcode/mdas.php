<html>  
<body>  
<form method="post">  
Enter First Number:  
<input type="number" name="number1" /><br><br>  
Enter Second Number:  
<input type="number" name="number2" /><br><br>  
<input  type="submit" name="submit" value="Add"> 
<input  type="submit" name="submit2" value="Subtract">
<input  type="submit" name="submit3" value="Multiply">
<input  type="submit" name="submit4" value="Divide"> 
</form>  
<?php  
    if(isset($_POST['submit']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $sum =  $number1+$number2;     
echo "The sum of $number1 and $number2 is: ".$sum;   
}  
if(isset($_POST['submit2']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $difference =  $number1-$number2;     
echo "The difference of $number1 and $number2 is: ".$difference;   
}
if(isset($_POST['submit3']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $product =  $number1*$number2;     
echo "The product of $number1 and $number2 is: ".$product;   
}
if(isset($_POST['submit4']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $quotient =  $number1/$number2;     
echo "The sum of $number1 and $number2 is: ".$quotient;   
}
?>  
</body>  
</html> 