// SPDX-License-Identifier: GPL-2.0+
/*
 * rcar_cmm.c -- R-Car Display Unit Color Management Module
 *
 * Copyright (C) 2019 Jacopo Mondi <jacopo+renesas@jmondi.org>
 */

#include <linux/io.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/pm_runtime.h>

#include <drm/drm_color_mgmt.h>

#include "rcar_cmm.h"

#define CM2_LUT_CTRL		0x0000
#define CM2_LUT_CTRL_LUT_EN	BIT(0)
#define CM2_LUT_TBL_BASE	0x0600
#define CM2_LUT_TBL(__i)	(CM2_LUT_TBL_BASE + (__i) * 4)

struct rcar_cmm {
	void __iomem *base;

	/*
	 * @lut:		1D-LUT state
	 * @lut.enabled:	1D-LUT enabled flag
	 */
	struct {
		bool enabled;
	} lut;
};

static inline int rcar_cmm_read(struct rcar_cmm *rcmm, u32 reg)
{
	return ioread32(rcmm->base + reg);
}

static inline void rcar_cmm_write(struct rcar_cmm *rcmm, u32 reg, u32 data)
{
	iowrite32(data, rcmm->base + reg);
}

/*
 * rcar_cmm_lut_write() - Scale the DRM LUT table entries to hardware precision
 *			  and write to the CMM registers
 * @rcmm: Pointer to the CMM device
 * @drm_lut: Pointer to the DRM LUT table
 */
static void rcar_cmm_lut_write(struct rcar_cmm *rcmm,
			       const struct drm_color_lut *drm_lut)
{
	unsigned int i;

	for (i = 0; i < CM2_LUT_SIZE; ++i) {
		u32 entry = drm_color_lut_extract(drm_lut[i].red, 8) << 16
			  | drm_color_lut_extract(drm_lut[i].green, 8) << 8
			  | drm_color_lut_extract(drm_lut[i].blue, 8);

		rcar_cmm_write(rcmm, CM2_LUT_TBL(i), entry);
	}
}

/*
 * rcar_cmm_setup() - Configure the CMM unit
 * @pdev: The platform device associated with the CMM instance
 * @config: The CMM unit configuration
 *
 * Configure the CMM unit with the given configuration. Currently enabling,
 * disabling and programming of the 1-D LUT unit is supported.
 *
 * As rcar_cmm_setup() accesses the CMM registers the unit should be powered
 * and its functional clock enabled. To guarantee this, before any call to
 * this function is made, the CMM unit has to be enabled by calling
 * rcar_cmm_enable() first.
 *
 * TODO: Add support for LUT double buffer operations to avoid up