
<?php

        //require_once('G:/xampp/htdocs/shoutbox/config.php');
        //require_once('http://www.hunterwizard125.hostmefree.org/shoutbox2/config.php');
        //require_once('G:/xampp/htdocs/shoutbox2/config.php');
        require_once('G:/xampp/htdocs/shoutbox2/config.php');
		session_start();
        $task=$_GET['do'];
        
        $color1 = "#CCFFCC"; 
		$color2 = "#BFD8BC"; 
		$row_count = 0;
        $kolzz="yellow";        
        function showForm($color1,$color2,$kolzz)
        {
			?>
			/*
          echo "
				 <form id='login' action='login2.php?do=exec' method='post'> 
				   <h2>Login Details</h2>
						<p>
						  <label>Username</label>
						  <input type='text' name='uname' class='width50'/>
						</p>

						<p>
						  <label>Password</label>
						  <input type='password' name='uepass' class='width50'/>
						</p>
						<div class='lightBlueBg'>
						<p>
						<input type='checkbox' name='checkGroup' value='1' class='radio'/>
						Remember me in this computer.
						</p>
		
						<p>
						  <input type='submit' value='LOGIN' class='button' />
						  <input type='reset' value='RESET' class='button' />
						</p>
						<p><a href=''>Forgot password?</a> | <a href='register2.php'>Register</a>
						</p>
						</div>
						 </div>
				  </form>";*/
				  
				  <?php
						  
					$qry="SELECT * FROM tblmsg;";
					$result = @mysql_query($qry);
                                   ?>             
                                        echo "<h1>Messages</h1><hr>
                                        <table border='1'><thead><tr >
                                        
                                        <th width='230' bgcolor=<?php $kolzz ?> align=left><b>Name</b></th> 
                                        <th width='100' bgcolor=<?php $kolzz ?> align=left><b>DATE</b></th>
                                        <th width='150' bgcolor=<?php $kolzz ?> align=left><b>TIME</b></th>
                                        <th width='150' bgcolor=<?php $kolzz ?> align=left><b>Message</b></th>
                                        </tr></thead>";
										<?php
                                        $row_count=0;
                                        while($fields = mysql_fetch_array($result))
                                        {
                                                $mid=$fields[msgid]; 
                                                $userid=$fields[uid];
                                                $sname=$fields[pname];
                                                $date22=$fields[date2];
                                                $time22=$fields[time2];
                                                $mess=$fields[mesg];
                                                if ($row_count % 2==o)
                                                {
                                                        $fields_color=$color1;
                                                }
                                                else
                                                {
                                                        $fields_color=$color2;
                                                }?>
												/*
                                                
												
												*/
												
												<tr >                                                
                                                <td bgcolor="<?php $fields_color?>" nowrap align=left><?php $sname ?></td>
                                                <td bgcolor="<?php $fields_color?>" nowrap align=left><?php $date22 ?></td>
                                                <td bgcolor="<?php $fields_color?>" nowrap align=left><?php $time22 ?> </td>
                                                <td bgcolor="<?php $fields_color?>" nowrap align=left><?php $mess ?></td> 
                                                <td bgcolor="<?php $fields_color?>" nowrap align=left>[<a href="login2.php?do=<?php echo view&mid=$mid; ?>">View</a>]</td>
                                                <td align=left>[<a href="contacts.php?act=<?php echo edit&id=$id; ?>">Edit</a>]</td>
												<?php
                                                if($userid==$_SESSION['SESS_USER_ID'])
                                                { ?>
                                                        <td align=left>[<a href="shout.php?act=<?php echo del&mid=$mid; ?>">Delete</a>]</td>                                                }
                                                <?php
												else
                                                {?>
                                                        <td align=left></td>
                                                <?php
												}
                                                $row_count++;
                                        }?>
										
                                                </tr>
												<?php
        }?>
        



<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Login form</title>

</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginheight="0" marginwidth="0" bgcolor="#FFFFFF">

<style type="text/css">
body
{
background-color:#d0e4fe;
}
h1
{
color:orange;
text-align:center;
}
p
{
font-family:"Times New Roman";
font-size:20px;
}
</style>

<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/topbkg.gif">
  <tr>
    <td width="50%"><img border="0" src="img/rose.jpg" width="142" height="66"></td>
    <td width="50%">
      <p align="right"><img border="0" src="img/topright.gif" width="327" height="66"></td>
  </tr>
</table>
<!--
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/blackline.gif">
  <tr>
    <td width="100%"><font color="#B8C0F0" face="Arial" size="2"><b>&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link&nbsp;&nbsp; |&nbsp;&nbsp; your link&nbsp;&nbsp; |&nbsp;&nbsp;
      your link</b></font></td>
  </tr>
</table>-->
<h1><span class="dark">Member Login</span></h1>
        
                  <?
                  
                      if ($task=='exec') //Begin Login Exec
                                {
                                        //Function to sanitize values received from the form. Prevents SQL injection
                                        function clean($str) {
                                                $str = @trim($str);
                                                if(get_magic_quotes_gpc()) {
                                                        $str = stripslashes($str);
                                                }
                                                return mysql_real_escape_string($str);
                                        }
                                        
                                        //Sanitize the POST values
                                        $uname = clean($_POST['uname']);
                                        $uepass = clean($_POST['uepass']);
                                        
                                        //Create query
                                        
                                        //echo $username."<br>";
                                        //echo $password."<br>";
                                        //echo md5($password);

                                        $qry="SELECT * FROM tbluser WHERE uname='$uname' AND uepass='".md5($uepass)."'";
                                        
                                        $result=mysql_query($qry);
                                        
                                        //Check whether the query was successful or not
                                        if($result) {
                                                if(mysql_num_rows($result) == 1) {
                                                        //Login Successful
                                                        
                                                        $member = mysql_fetch_assoc($result);
                                                        $_SESSION['SESS_USER_ID'] = $member['uid'];
                                                        $_SESSION['SESS_USER_NAME'] = $member['uname'];
                                                        $_SESSION['SESS_USER_USER_NAME'] = $member['pname'];
                                                        
                                                        session_write_close();
                                                
                                                        $link="shout.php";
                                                        
                                                        $name = $_SESSION['SESS_USER_NAME'];
                                                        echo "<br><blockquote><hr size='10' noshade><center>Welcome!<br>";
                                                        echo "<br>You are logged in as $uname</b><br>[ <a href='$link'>Click here to proceed to the main page.</a> ]";
                                                        echo "<br>[ <a href='login2.php'>You are not $uname?</a> ]<br><br></blockquote></center>";
                                                }else {
                                                        //Login failed
                                                        echo "<blockquote><center>";
                                                        echo "<font color=red>Invalid username and/or password. Please try again.</font>";
                                                        echo "</blockquote></center>";
                                                        showForm($color1,$color2,$kolzz);
                                                }
                                        }else {
                                            echo "Not connected";
                                                die("Query failed");
                                                echo "Not connected";
                                        }
                                        
                                } // End of Login Exec
                                
                                elseif ($task=='logout') //Logout
                                
                                {
                                 //Start session
                                session_start();
                                $username=$_SESSION['SESS_USER_NAME'];
                                echo "<br><blockquote><hr size='10' noshade><center>Thank you <b>$username</b>!<br>";
                                echo "<b>You are now logged out.</b>";
                                echo "<br>[ <a href='login2.php'>Show Login Form</a> ]<br><br></blockquote></center>";
                                
                                //Unset the variables stored in session
                                unset($_SESSION['SESS_USER_ID']);
                                unset($_SESSION['SESS_NAME']);
                                unset($_SESSION['SESS_USER_NAME']);
                                session_write_close();
                                //header("location: login2.php");
                                }
                                elseif ($task=='view')
                                {
                                          $mid = $_GET['mid'];
                                          $qry="SELECT * FROM tblmsg WHERE msgid='$mid';";
                                          $result = @mysql_query($qry);
                                          echo "<h1>Messages</h1><hr>
                                                <table border='1'><thead><tr >
                                                
                                                <th width='230' bgcolor='$kolzz' align=left><b>Name</b></th> 
                                                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                                                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                                                <th width='150' bgcolor='$kolzz' align=left><b>Message</b></th>
                                                </tr></thead>";
                                                $row_count=0;
                                                while($fields = mysql_fetch_array($result))
                                                {
                                                        $mid=$fields[msgid]; 
                                                        $userid=$fields[uid];
                                                        $sname=$fields[pname];
                                                        $date22=$fields[date2];
                                                        $time22=$fields[time2];
                                                        $mess=$fields[mesg];
                                                        if ($row_count % 2==o)
                                                        {
                                                                $fields_color=$color1;
                                                        }
                                                        else
                                                        {
                                                                $fields_color=$color2;
                                                        }
                                                        echo "<tr >";
                                                        
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$sname</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$mess</td>"; 
                                                        
                                                        echo "</tr>";
                                                        $row_count++;
                                                }        
                                        echo "</table>
                                           <hr />";
                                           
                                           $qry="SELECT * FROM tblcmt WHERE msgid='$mid';";
                                          $result = @mysql_query($qry);
                                          echo "<h1>Message Comments</h1><hr>
                                                <table border='1'><thead><tr >
                                                
                                                <th width='230' bgcolor='$kolzz' align=left><b>Originator</b></th> 
                                                
                                                <th width='230' bgcolor='$kolzz' align=left><b>message commentor</b></th> 
                                                <th width='100' bgcolor='$kolzz' align=left><b>DATE</b></th>
                                                <th width='150' bgcolor='$kolzz' align=left><b>TIME</b></th>
                                                <th width='150' bgcolor='$kolzz' align=left><b>comment</b></th>
                                                </tr></thead>";
                                                $row_count=0;
                                                while($fields = mysql_fetch_array($result))
                                                {
                                                        $msgcmtid=$fields[msgcmtid];
                                                        $msgid=$fields[msgid];
                                                        $msguid=$fields[msguid]; 
                                                        $msgpname=$fields[msgpname];
                                                        $msgcmtuid=$fields[msgcmtuid];
                                                        $msgcmtpname=$fields[msgcmtpname];
                                                        $date22=$fields[cdate2];
                                                        $time22=$fields[ctime2];
                                                        $cmt=$fields[cmt];
                                                        if ($row_count % 2==o)
                                                        {
                                                                $fields_color=$color1;
                                                        }
                                                        else
                                                        {
                                                                $fields_color=$color2;
                                                        }
                                                        echo "<tr >";
                                                        
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgpname</td>";
                                                        
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$msgcmtpname</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$date22</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$time22</td>";
                                                        echo "<td bgcolor='$fields_color' nowrap align=left>$cmt</td>";
                                                        
                                                        
                                                        
                                                        echo "</tr>";
                                                        $row_count++;
                                                }        
                                        echo "</table>
                                           <hr />";
                                           
                                                        echo "<p><a href='login2.php?do='/a>[back to login... ]</p>";
                                }
                        else
                            {
                                   showForm($color1,$color2,$kolzz);
                                   
                                }
                  ?>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">This is a website created by August Tabucanon</font></p>

<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">Submitted to Mr. Julius Memar J. Ngoho</font></p>
<p style="margin-left: 20" align="center"><font face="Arial" color="#000000" size="2">In partial fulfillment of the Requirements in Information Systems and Security</font></p>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="img/botline.gif">
  <tr>
    <td width="100%"><img border="0" src="img/botline.gif" width="41" height="12"></td>
  </tr>
</table>


</body>

</html>