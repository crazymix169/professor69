<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['update']))
{	
	$goodsid = $_POST['goodsid'];
	
	$name = $_POST['goodsname'];
	$description= $_POST['description'];
	$qty = $_POST['qty'];
	$price = $_POST['price'];	
	
	// checking empty fields
	if(empty($name) || empty($qty) || empty($price) || empty($description)) {
				
		if(empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		
		if(empty($qty)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}	
		if(empty($description)) {
			echo "<font color='red'>Description field is empty.</font><br/>";
		}	
	} else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE tbl_goods SET goodsname='$name',description='$description', qty='$qty', price='$price' WHERE goodsid=$id");
		
		//redirectig to the display page. In our case, it is view.php
		header("Location: goodsview.php");
	}
}
?>
<?php
//getting id from url
$goodsid = $_GET['goodsid'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM tbl_goods WHERE goodsid=$goodsid");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$description = $res['description'];
	$qty = $res['qty'];
	$price = $res['price'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="goodsview.php">View Goods</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	
	<form name="form1" method="post" action="goodsedit.php">
		<table border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $name;?>"></td>
			</tr>
			<tr> 
				<td>Quantity</td>
				<td><input type="text" name="qty" value="<?php echo $qty;?>"></td>
			</tr>
			<tr> 
				<td>Price</td>
				<td><input type="text" name="price" value="<?php echo $price;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="goodsid" value=<?php echo $_GET['goodsid'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
