<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
//$result = mysqli_query($mysqli, "SELECT * FROM products WHERE login_id=".$_SESSION['id']." ORDER BY id DESC");
$result = mysqli_query($mysqli, "SELECT * FROM tbl_goods ");

?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="goodsadd.html">Add New Data</a> | <a href="logout.php">Logout</a>
	<br/><br/>
        
        <?php
        $i=0;
        while($res = mysqli_fetch_array($result)) {
            $i++;
            //$vv=$res[id];
            break;
        }
        echo "<a href=\"goodsproductsearch.php?goodsid=$res[goodsid]\">Search For Products</a>" ?>
	<br/><br/>
	
		  
	<table width='80%' border=0>
		<tr bgcolor='#CCCCCC'>
			<td>Goods Name</td>
			<td>Description</td>
			<td>Quantity</td>
			<td>Price (euro)</td>
			<td>Update</td>
		</tr>
		<?php
		$result = mysqli_query($mysqli, "SELECT * FROM tbl_goods ");
		while($res = mysqli_fetch_array($result)) {		
			echo "<tr>";
			echo "<td>".$res['name']."</td>";
			echo "<td>".$res['description']."</td>";
			echo "<td>".$res['qty']."</td>";
			echo "<td>".$res['price']."</td>";	
			echo "<td><a href=\"goodsedit.php?goodsid=$res[goodsid]\">Edit</a> | <a href=\"goodsdelete.php?goodsid=$res[goodsid]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
		}
		?>
	</table>	
</body>
</html>
