<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");

try
{
	if(isset($_POST['Submit'])) {
		$goodsname = $_POST['goodsname'];
		$description = $_POST['description'];
		$qty = $_POST['qty'];
		$price = $_POST['price'];
		$loginId = $_SESSION['id'];

		// checking empty fields
		if(empty($goodsname) || empty($qty) || empty($price)|| empty($description)) {

			if(empty($goodsname)) {
				echo "<font color='red'>Name field is empty.</font><br/>";
			}

			if(empty($qty)) {
				echo "<font color='red'>Quantity field is empty.</font><br/>";
			}

			if(empty($price)) {
				echo "<font color='red'>Price field is empty.</font><br/>";
			}
			if(empty($description)) {
				echo "<font color='red'>Description field is empty.</font><br/>";
			}

			//link to the previous page
			echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
		} else {
			// if all the fields are filled (not empty)
			$result = mysqli_query($mysqli, "SELECT * FROM tbl_goods WHERE goodsname = '$name'");
			$counter=0;
			$val=0;
		
			while($res = mysqli_fetch_array($result))
			{
				$counter++;
				$val=$res[goodsid];
				$quantity=$res[quantity];
				$price2=$res[price];
			}

			if(counter==0)
			{
				//insert data to database
				$result = mysqli_query($mysqli, "INSERT INTO tbl_goods(goodsname, description, quantity, price) VALUES('$goodsname','$description','$qty', '$price')");

			}
			else
			{
				$qty=abs($qty);
				$price=abs($price);
				$qty=$qty+$quantity;
				$price=$price+$price2;
				$result = mysqli_query($mysqli, "UPDATE tbl_goods SET goodsname='$name',description='$description', qty='$qty', price='$price' WHERE goodsid=$val");
			}


			//display success message
			echo "<font color='green'>Data added successfully.";
			echo "<br/><a href='goodsview.php'>View Result</a>";
		}
	}
	throw new Exception("Null Value or Invalid Value");
}
catch(Exception $e)
{
	echo "<font color='red'>Error</font><br/>";
	header("Location: goodsview.php");
}
?>
</body>
</html>
