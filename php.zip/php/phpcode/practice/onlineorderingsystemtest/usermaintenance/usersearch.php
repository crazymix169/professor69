<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
// including the database connection file
include_once("connection.php");

if(isset($_POST['search']))
{	
	$username = $_POST['username'];	
	
	// checking empty fields
	if(empty($username)) {
				
		if(empty($username)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}
		/*
		if(empty($qty)) {
			echo "<font color='red'>Quantity field is empty.</font><br/>";
		}
		
		if(empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}	*/	
	} else {	
		//updating the table
		//$result = mysqli_query($mysqli, "UPDATE products SET name='$name', qty='$qty', price='$price' WHERE id=$id");
                //$result = mysqli_query($mysqli, "SELECT * FROM products WHERE name like '%$name%'");
            $result = mysqli_query($mysqli, "SELECT * FROM tbl_users WHERE username like '%$username%'");?>
			<table width='80%' border=0>
			<tr bgcolor='#CCCCCC'>
				<td>Name</td>
				<td>Email</td>
				<td>Username</td>
				<td>Password</td>
				<td>Update</td>
			</tr>
			<?php
			while($res = mysqli_fetch_array($result)) {		
				echo "<tr>";
				echo "<td>".$res['name']."</td>";
				echo "<td>".$res['email']."</td>";
				echo "<td>".$res['username']."</td>";	
				echo "<td>".$res['password']."</td>";		
				echo "<td><a href=\"useredit.php?userid=$res[userid]\">Edit</a> | <a href=\"userdelete.php?userid=$res[userid]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
			}
			?>
			</table>	
			

		<?php
                
                
		//redirectig to the display page. In our case, it is view.php
		//header("Location: view.php");
	}
        echo "<a href=\"userview.php?\">View All Users</a>";
}
?>
<?php
//getting id from url
/*
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM products WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$qty = $res['qty'];
	$price = $res['price'];
}*/
?>

<!DOCTYPE html>
<html>
<head>	
	<title>Search    Data</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="userview.php">View Products</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	
        <form method="post" action="">
		<table border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="username" placeholder="search username"></td>
			</tr>
                        <tr> 
			
				
				<td><input type="submit" name="search" value="search username"></td>
			</tr> 
		</table>
	</form>
</body>
</html>

