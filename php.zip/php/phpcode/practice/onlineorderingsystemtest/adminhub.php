<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
//$result = mysqli_query($mysqli, "SELECT * FROM products WHERE login_id=".$_SESSION['id']." ORDER BY id DESC");
?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="logout.php">Logout</a>
	<br/><br/>
	<br/><br/>
	<a href="userview.php">User Maintenance</a> 
    <br/><br/>		
	<a href="goodsview.php">Goods Maintenance</a> 
	<br/><br/>
	<a href="add.html">Order Maintenance</a> 
	<br/><br/>
	<a href="add.html">Sales Maintenance</a> 
	
</body>
</html>