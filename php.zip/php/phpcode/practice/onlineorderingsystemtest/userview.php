<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
//$result = mysqli_query($mysqli, "SELECT * FROM products WHERE login_id=".$_SESSION['id']." ORDER BY id DESC");
$result = mysqli_query($mysqli, "SELECT * FROM tbl_users");

?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>
	<a href="index.php">Home</a> | <a href="useradd.html">Add New User</a> | <a href="logout.php">Logout</a>
	<br/><br/>
        
        <?php
        $i=0;
        while($res = mysqli_fetch_array($result)) {
            $i++;
            //$vv=$res[id];
            break;
        }
        echo "<a href=\"usersearch.php?userid=$res[userid]\">Search For Users</a>" ?>
	<br/><br/>
	
		  
	<table width='80%' border=0>
		<tr bgcolor='#CCCCCC'>
			<td>Name</td>
			<td>Email</td>
			<td>Username</td>
			<td>Password</td>
			<td>Update</td>
		</tr>
		<?php
		$result = mysqli_query($mysqli, "SELECT * FROM tbl_users");
		while($res = mysqli_fetch_array($result)) {		
			echo "<tr>";
			echo "<td>".$res['name']."</td>";
			echo "<td>".$res['email']."</td>";
			echo "<td>".$res['username']."</td>";	
			echo "<td>".$res['password']."</td>";	
			echo "<td><a href=\"useredit.php?userid=$res[userid]\">Edit</a> | <a href=\"userdelete.php?userid=$res[userid]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
		}
		?>
	</table>	
</body>
</html>
