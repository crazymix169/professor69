<?php session_start(); ?>

<?php
if(!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<html>
<head>
	<title>Add Data</title>
</head>

<body>
<?php
//including the database connection file
include_once("connection.php");


if(isset($_POST['Submit'])) {	
	$name = $_POST['name'];
	$email = $_POST['email'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$loginId = $_SESSION['id'];
	
	try
	{
		// checking empty fields
		if(empty($name) || empty($email) || empty($username)|| empty($password)) {
					
			if(empty($name)) {
				echo "<font color='red'>Name field is empty.</font><br/>";
			}
			
			if(empty($email)) {
				echo "<font color='red'>Quantity field is empty.</font><br/>";
			}
			
			if(empty($username)) {
				echo "<font color='red'>Price field is empty.</font><br/>";
			}
			if(empty($password)) {
				echo "<font color='red'>Price field is empty.</font><br/>";
			}
			
			//link to the previous page
			echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
		} else { 
			// if all the fields are filled (not empty) 
				
			//insert data to database	
			$result = mysqli_query($mysqli, "INSERT INTO tbl_users(name, email, username, password) VALUES('$name','$email','$username', '$password')");
			
			//display success message
			echo "<font color='green'>Data added successfully.";
			echo "<br/><a href='userview.php'>View Result</a>";
		}

		throw new Exception("Null Value or Invalid Value");
	}
	catch(Exception $e)
	{
		echo "<font color='red'>Error</font><br/>";
		header("Location: userview.php");
	}
	
}
?>
</body>
</html>
