<html>  
<body>  
<form method="post">  
Enter First Number:  
<input type="number" name="number1" /><br><br>  
Enter Second Number:  
<input type="number" name="number2" /><br><br>  
<input  type="submit" name="submit" value="find perimeter"> 
<input  type="submit" name="submit2" value="find area">

</form>  
<?php  
    if(isset($_POST['submit']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $perimeter =  2*$number1+2*$number2;     
echo "The perimeter of the rectangle with dimensions: $number1 and $number2 is: ".$perimeter;   
}  
if(isset($_POST['submit2']))  
    {  
        $number1 = $_POST['number1'];  
        $number2 = $_POST['number2'];  
        $area =  $number1*$number2;     
echo "The area of the rectangle with dimensions: $number1 and $number2 is: ".$area;   
}


?>  
</body>  
</html> 