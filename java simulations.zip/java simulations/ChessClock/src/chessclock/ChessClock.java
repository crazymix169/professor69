/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chessclock;

import javax.swing.JOptionPane;

/**
 *
 * @author owner
 */
public class ChessClock extends javax.swing.JFrame
{
    public static final Object lock = new Object();
    private volatile boolean paused = true;
    private volatile boolean paused2 = true;
    int t,t2;

    /**
     * Creates new form ChessClock
     */
    public ChessClock()
    {
        
        initComponents();
        counter.start();
        counter2.start();
        btnP1PauseResume.addActionListener(pauseResume);
        btnP2PauseResume.addActionListener(pauseResume2);
        btnPauseBoth.addActionListener(pauseBoth);
        t=Integer.parseInt(lbP1.getText());
        t2=Integer.parseInt(lbP2.getText());
        
        
        
        
    }
    /*
    Thread first = new Thread() 
    {
        public boolean hulat=true;
          
        @Override
        public void run()
        {
            
            int t=300;
            while(!Thread.currentThread().isInterrupted())
            {   
                try
                {
                    Thread.sleep(1000);
                    t--;    
                    lbP1.setText(String.valueOf(t));
                    
                    
                    if(t<0)
                        break;

                } 
                catch(InterruptedException ex) 
                {
                    //LOG.log(Level.SEVERE, "Unexpected interrupt", ex);
                    Thread.currentThread().interrupt();
                    
                    int x=t;    
                    lbP1.setText(String.valueOf(x));
                    //Thread.currentThread().interrupt();
                    //first = new Thread() 
                    
                    
                }
            }

        }
        
        void hulz()
        {
            hulat=false;
        }        
        
        
        
      
       
        
    };
    
    Thread second = new Thread() 
    {
        public boolean hulat=true;
        @Override
        public void run()
        {
            final long time = System.currentTimeMillis();
            final long duration = 10800000; //3 hours
            int t=300;
            while(!Thread.currentThread().isInterrupted())
            {   
                try
                {
                    Thread.sleep(1000);
                    t--;
                    lbP2.setText(String.valueOf(t));
                    
                    
                    if(t<0)
                        break;

                } 
                catch(InterruptedException ex) 
                {
                    //LOG.log(Level.SEVERE, "Unexpected interrupt", ex);
                    Thread.currentThread().interrupt();
                    int x=t;    
                    lbP2.setText(String.valueOf(x));
                    Thread.currentThread().interrupt();
                }
            }

        }
        void hulz()
        {
            hulat=false;
        }    
       
        
    };*/
    
    private Thread counter = new Thread(new Runnable() {
        @Override
        public void run() {
            while(true) {
                work();
            }
        }
    });
    
    private Thread counter2 = new Thread(new Runnable() {
        @Override
        public void run() {
            while(true) {
                work2();
            }
        }
    });
    
    private void work() {
        
            allowPause();
            
            int txx=Integer.parseInt(lblTurn.getText());
            while(true)
            {
               
                try
                {

                    Thread.sleep(1000);
                    t--;    
                    
                    lbP1.setText(String.valueOf(t));
                    if(t<0||(paused==true))
                    {   
                        lblTurn.setText("1");
                        break;
                    }    




                } 
                catch(InterruptedException ex) 
                {
                    //LOG.log(Level.SEVERE, "Unexpected interrupt", ex);



                    //Thread.currentThread().interrupt();
                    //first = new Thread() 


                }
            }
                
           
            
            sleep();
        
        done();
    }
    
    private void work2() {
        
            allowPause2();
            
            int txx=Integer.parseInt(lblTurn.getText());
            while(true)
            {
               
                try
                {

                    Thread.sleep(1000);
                    
                    t2--;    
                    lbP2.setText(String.valueOf(t2));
                    if(t2<0||(paused2==true))
                    {   
                        lblTurn.setText("2");
                        break;
                    }    
                        



                } 
                catch(InterruptedException ex) 
                {
                    //LOG.log(Level.SEVERE, "Unexpected interrupt", ex);



                    //Thread.currentThread().interrupt();
                    //first = new Thread() 


                }
            }
                
           
            
            sleep();
        
        done2();
    }
    
    private void allowPause() {
        synchronized(lock) {
            while(paused) {
                try {
                    lock.wait();
                } catch(InterruptedException e) {
                    // nothing
                }
            }
        }
    }
    
    private void allowPause2() {
        synchronized(lock) {
            while(paused2) {
                try {
                    lock.wait();
                } catch(InterruptedException e) {
                    // nothing
                }
            }
        }
    }
    
    private java.awt.event.ActionListener pauseResume =
        new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                    paused2 = !paused2;
                    //paused2=!paused2;
                    //paused2 = !paused;
                    if(paused2==true)
                    {    
                        paused=false;
                        //paused2=!paused;
                        
                        
                    }    
                    else
                    {    
                        paused=true;
                        //paused2=!paused;
                        
                        
                    }
                    
                    JOptionPane.showMessageDialog(null, "P1: "+paused+ " P2: "+paused2);
                    btnP1PauseResume.setText("Resume P2");
                    //btnP2PauseResume.setText(paused2?"Resume P1":"Pause P1");
                    btnP2PauseResume.setVisible(true);
                    btnP1PauseResume.setVisible(!true);
                    
                synchronized(lock) {
                    lock.notifyAll();
                }
            }
        };
    
    private java.awt.event.ActionListener pauseResume2 =
        new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                    paused = !paused;
                    //paused=!paused;
                    if(paused==true)
                    {    
                        paused2=false;
                        //paused2=!paused;
                        
                        
                    }    
                    else
                    {    
                        paused2=true;
                        //paused2=!paused;
                        
                        
                    }
                    
                    JOptionPane.showMessageDialog(null, "P1: "+paused+ " P2: "+paused2);
                    //paused=!paused2;
                    btnP2PauseResume.setText("Resume P1");
                    //btnP1PauseResume.setText(paused?"Resume P2":"Pause p2");
                    btnP1PauseResume.setVisible(true);
                    btnP2PauseResume.setVisible(!true);
                    
                synchronized(lock) {
                    lock.notifyAll();
                }
            }
        };
    
    private java.awt.event.ActionListener pauseBoth =
        new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                    paused = true;
                    paused2=true;
                    //btnP1PauseResume.setText(paused?"Resume":"Pause");
                    btnP2PauseResume.setText(paused2?"Resume P1":"Pause P1");
                    btnP1PauseResume.setText(paused?"Resume P2":"Pause p2");
                    btnP1PauseResume.setVisible(paused);
                    btnP2PauseResume.setVisible(paused2);
                synchronized(lock) {
                    lock.notifyAll();
                }
            }
        };
    
    private void sleep() {
        try {
            Thread.sleep(500);
        } catch(InterruptedException e) {
            // nothing
        }
    }
    
    private void done() {
        //button.setText("Start");
        paused = true;
        paused2 = !true;
    }
    private void done2() {
        //button.setText("Start");
        paused2 = true;
        paused = !true;
    }
    
    public void write(String str) {
        //textArea.append(str);
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        btnP1PauseResume = new javax.swing.JButton();
        lbP1 = new javax.swing.JLabel();
        btnP1Start = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblTurn = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnP2PauseResume = new javax.swing.JButton();
        lbP2 = new javax.swing.JLabel();
        btnP2Start = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        clockBegin = new javax.swing.JButton();
        btnPauseBoth = new javax.swing.JButton();
        btnP1Resume = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chess Clock Simulator");

        btnP1PauseResume.setText("Player 2 start clock");
        btnP1PauseResume.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnP1PauseResumeActionPerformed(evt);
            }
        });

        lbP1.setText("300");

        btnP1Start.setText("Player 1 Start");
        btnP1Start.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnP1StartActionPerformed(evt);
            }
        });

        jLabel1.setText("Player 1");

        lblTurn.setText("1");

        jLabel2.setText("Turn:");

        btnP2PauseResume.setText("Player 1 start clock");
        btnP2PauseResume.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnP2PauseResumeActionPerformed(evt);
            }
        });

        lbP2.setText("300");

        btnP2Start.setText("Player 2 Start");
        btnP2Start.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnP2StartActionPerformed(evt);
            }
        });

        jLabel3.setText("Player 1");

        clockBegin.setText("begin");
        clockBegin.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                clockBeginActionPerformed(evt);
            }
        });

        btnPauseBoth.setText("pause both");
        btnPauseBoth.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPauseBothActionPerformed(evt);
            }
        });

        btnP1Resume.setText("Player 1 resume clock");
        btnP1Resume.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnP1ResumeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(235, 235, 235)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clockBegin)
                    .addComponent(btnPauseBoth))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnP1PauseResume)
                                    .addComponent(lbP1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnP1Start)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(lblTurn, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(42, 42, 42))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnP1Resume)
                        .addGap(117, 117, 117)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnP2PauseResume)
                    .addComponent(lbP2)
                    .addComponent(btnP2Start)
                    .addComponent(jLabel3))
                .addGap(127, 127, 127))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(clockBegin)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPauseBoth)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnP2Start)
                                .addGap(4, 4, 4)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTurn)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbP2)
                        .addGap(18, 18, 18)
                        .addComponent(btnP2PauseResume))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnP1Start)
                        .addGap(4, 4, 4)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbP1)
                        .addGap(18, 18, 18)
                        .addComponent(btnP1PauseResume)))
                .addGap(116, 116, 116)
                .addComponent(btnP1Resume)
                .addContainerGap(117, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnP1PauseResumeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnP1PauseResumeActionPerformed
    {//GEN-HEADEREND:event_btnP1PauseResumeActionPerformed
        // TODO add your handling code here:
        
        //allowPause();
        
       
        
        

    }//GEN-LAST:event_btnP1PauseResumeActionPerformed

    private void btnP1StartActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnP1StartActionPerformed
    {//GEN-HEADEREND:event_btnP1StartActionPerformed
        // TODO add your handling code here:
        
        
        //paused = !paused;
                    //button.setText(paused?"Resume":"Pause");
        
        

        

    }//GEN-LAST:event_btnP1StartActionPerformed

    private void btnP2PauseResumeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnP2PauseResumeActionPerformed
    {//GEN-HEADEREND:event_btnP2PauseResumeActionPerformed
        // TODO add your handling code here:
       
        
        
        
    }//GEN-LAST:event_btnP2PauseResumeActionPerformed

    private void btnP2StartActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnP2StartActionPerformed
    {//GEN-HEADEREND:event_btnP2StartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnP2StartActionPerformed

    private void clockBeginActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_clockBeginActionPerformed
    {//GEN-HEADEREND:event_clockBeginActionPerformed
        // TODO add your handling code here:
        
        
        
        
        
    }//GEN-LAST:event_clockBeginActionPerformed

    private void btnPauseBothActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnPauseBothActionPerformed
    {//GEN-HEADEREND:event_btnPauseBothActionPerformed
        // TODO add your handling code here:
        
        
        
        
    }//GEN-LAST:event_btnPauseBothActionPerformed

    private void btnP1ResumeActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnP1ResumeActionPerformed
    {//GEN-HEADEREND:event_btnP1ResumeActionPerformed
        // TODO add your handling code here:
        paused = !paused;
                    //button.setText(paused?"Resume":"Pause");
        synchronized(lock) {
            lock.notify();
        }  
        //allowPause();
        
    }//GEN-LAST:event_btnP1ResumeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(ChessClock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(ChessClock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(ChessClock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(ChessClock.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new ChessClock().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnP1PauseResume;
    private javax.swing.JButton btnP1Resume;
    private javax.swing.JButton btnP1Start;
    private javax.swing.JButton btnP2PauseResume;
    private javax.swing.JButton btnP2Start;
    private javax.swing.JButton btnPauseBoth;
    private javax.swing.JButton clockBegin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lbP1;
    private javax.swing.JLabel lbP2;
    private javax.swing.JLabel lblTurn;
    // End of variables declaration//GEN-END:variables
}
