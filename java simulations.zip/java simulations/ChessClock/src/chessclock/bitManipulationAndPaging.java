package chessclock;
public class bitManipulationAndPaging
{
    public static void main(String[] args)
    {
        String v="11111111",v2=v,leftshift="",rightshift="";
        int x,i,bitshift=3;
        
        System.out.println("The initial string is: "+v);
        //left shift
        for(i=0;i<v.length();i++)
        {
            if(i+bitshift<v.length())
            {
                leftshift+=Character.toString(v.charAt(i+bitshift));
            }
            else
            {
                char c='0';
                leftshift+=Character.toString(c);
            }    
                
        }
        System.out.println("The leftshift is: "+leftshift);
        
        System.out.println("The initial string is: "+v);
        //right shift
        for(i=v2.length()-1;i>=0;i--)
        {
            if(i-v2.length()+bitshift<0)
            {
                rightshift+=Character.toString(v.charAt(i));
            }
            else
            {
                char c='0';
                rightshift+=Character.toString(c);
            }    
                
        }
        System.out.println("The leftshift is: "+rightshift);
        
        String xxx="happiness",page="";
        System.out.println("The initial string is: "+xxx);
        int substring=4,mainstringlength=xxx.length(),ctr;
        int pfaults=0;
        
        if(xxx.length()<=0)
        {
            System.out.println("Null String!");
        }
        /*
        else if(mainstringlength<=substring)
        {
            page=xxx;
        }*/
        else
        {
            page="";
            ctr=0;
            int g=0;
            pfaults=0;
            while(pfaults<=mainstringlength-substring)
            {
                while(g<substring-1)
                {
                    
                    for(i=0;i<=g;i++)
                    {
                        page+=Character.toString(xxx.charAt(i));
                    }
                    page+="\n";
                    ctr++;
                    g++;
                }   
                
                String substring1="";
                int[] a=new int[xxx.length()];
                for(i=0;i<substring;i++)
                {
                    page+=Character.toString(xxx.charAt(pfaults+i));
                    substring1+=Character.toString(xxx.charAt(pfaults+i));
                }  
                int[] b=new int[xxx.length()];
                int j;
                for(j=0;j<xxx.length();j++)
                {
                    a[j]=1;
                    if(j<substring1.length())
                        b[j]=1;
                    else
                        b[j]=0;
                }    
                
                page+="\n";
                pfaults++;
            }
            pfaults+=ctr;
            System.out.println(page);
            System.out.println("The number of page faults is/are: "+pfaults);
        }
    }
    static int isSubstring(String s1, String s2)
    {
        int M = s1.length();
        int N = s2.length();
 
        /* A loop to slide pat[] one by one */
        for (int i = 0; i <= N - M; i++) {
            int j;
 
            /* For current index i, check for
            pattern match */
            for (j = 0; j < M; j++)
                if (s2.charAt(i + j)
                    != s1.charAt(j))
                    break;
 
            if (j == M)
                return i;
        }
 
        return -1;
    }
}
