/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package CLASESS;

/**
 *
 * @author MOHAMMAD
 */
public class START {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MAIN_PAGE p=new MAIN_PAGE();

        }
}
