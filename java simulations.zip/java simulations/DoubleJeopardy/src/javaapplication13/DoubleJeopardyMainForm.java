/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package javaapplication13;

// Import the HashMap class
import java.util.HashMap;

/**
 *
 * @author owner
 */
public class DoubleJeopardyMainForm extends javax.swing.JFrame
{
    // Create a HashMap object called capitalCities
    HashMap<Integer, String> QuestionItems = new HashMap<>();
    HashMap<Integer, String> QuestionAnswerKey = new HashMap<>();
               
    
    String[][] options=
    {
        
        {"9 years", "19 Years", "29 years", "20 Years"},
        {"Hadji Mirza Husayn-Ali", "Mirza Ali-Muhammad", "Siyyid Ali-Muhammad", "Mirza Husayn Ali"},
        {"May 23, 1844", "July 9, 1850", "November 12, 1817", "October 20, 1819"},
        {"Tabriz, Persia", "Shiraz, Persia", "Baghdad, Iraq", "Mecca, Saudi Arabia"},
        {"Descendant of Prophet Zoroaster", "Descendant of Prophet Muhammad", "Decendant of David", "Descendant of Joshua"},
        {"Paternal Aunt", "Maternal Aunt", "Maternal Uncle", "Paternal Uncle"},
        {"Innate Knowledge", "Acquired Knowledge", "Conferred Infallibility", "Needs Education"},
        {"Kitab-i-Aqdas", "New Testament", "Quran", "Old Testament"},
        {"He had nothing to teach the Bab", "He still has something to teach", "Taught Him the Quran", "The Bab explaine the Quran Verse"},
        {"Worked as a minister", "Worked as a handyman", "Worked as a farmer", "Worked as a merchant"},
        {"Khadijih-Bagum", "Tahirih", "Bahiyyih Khanum", "Asiyih Khanum"},
        {"Khadijih-Bagum", "Ahmad", "Mulla Husayn", "Quddus"},
        {"Smooth and precise", "Easy and light", "Swift and Tragic", "Lengthy and tragic"},
        {"Siyyid Kazim", "Shayk Ahmad", "Mulla Husayn", "Quddus"},
        {"Siyyid Kazim", "Shayk Ahmad", "Quddus", "Mulla Husayn"},
        {"40 days", "30 days", "19 days", "25 days"},
        {"August 25, 1852", "October 20, 1844", "On the Eve of May 23, 1944", "July 9, 1850"},   
        {"Chiriq, Iran", "Tehran, Iran", "Shiraz, Iran", "Bushir, Iran"},
        {"Gate of God", "Glory of God", "Heaven's Peak", "Glorious Gate"},
        {"Gate of God", "Glory of God", "Heaven's Peak", "Babu'l-Bab"},
        {"The gate of that Gate", "Glory of God", "Gate of God", "Glorious Gate"},
    
    };


    /**
     * Creates new form NewJFrame
     */
    public DoubleJeopardyMainForm()
    {
        initComponents();
        
        QuestionItems.clear();
        QuestionAnswerKey.clear();
        QuestionItems.put(0, "How long is the dispensation of the Bab?");
        QuestionAnswerKey.put(0,"A");
        QuestionItems.put(1, "What is the Given Name of the Bab?");
        QuestionAnswerKey.put(1,"C");
        QuestionItems.put(2, "What is the Birthdate the Bab?");
        QuestionAnswerKey.put(2,"D");
        QuestionItems.put(3, "What is the Birthplace the Bab?");
        QuestionAnswerKey.put(3,"B");
        QuestionItems.put(4, "What is Siyyid 'title' of the Bab Mean?");
        QuestionAnswerKey.put(4,"B");
        QuestionItems.put(5, "When the Bab's father died, who raised Him afterwards?");
        QuestionAnswerKey.put(5,"C");
        QuestionItems.put(6, "What the Bab and other Manifestations of God have?");
        QuestionAnswerKey.put(6,"A");
        QuestionItems.put(7, "What was the Holy Book that the Bab's teacher asked Him to recite?");
        QuestionAnswerKey.put(7,"C");
        QuestionItems.put(8, "What did the teacher of the Bab noticed with Him?");
        QuestionAnswerKey.put(8,"A");
        QuestionItems.put(9, "After the Bab's maternal uncle was convined that He leave school, what did He do?");
        QuestionAnswerKey.put(9,"D");
        QuestionItems.put(10, "Who was the Bab's wife?");
        QuestionAnswerKey.put(10,"A");
        QuestionItems.put(11, "What was the name of the son of the Bab who died in infancy?");
        QuestionAnswerKey.put(11,"B");
        QuestionItems.put(12, "What was the 9-year Ministry of the Bab being Described?");
        QuestionAnswerKey.put(12,"C");
        QuestionItems.put(13, "Who is the first to see the coming of the advent of the Bab?");
        QuestionAnswerKey.put(13,"B");
        QuestionItems.put(14, "Who came after Shaykh Ahmad to see the coming of the advent of the Bab?");
        QuestionAnswerKey.put(14,"A");
        QuestionItems.put(15, "Who is Siyyid Kazim's most distinquished student?");
        QuestionAnswerKey.put(15,"D");
        QuestionItems.put(16, "How many days did Mullay Husayn fast and turned himself to God in prayer and Meditation?");
        QuestionAnswerKey.put(16,"A");
        QuestionItems.put(17, "When Did the Bab declare His Mission?");
        QuestionAnswerKey.put(17,"C");
        QuestionItems.put(18, "Where Did the Bab declare His Mission?");
        QuestionAnswerKey.put(18,"C");
        QuestionItems.put(19, "What does term 'the Bab' mean?");
        QuestionAnswerKey.put(19,"B");
        QuestionItems.put(20, "What title did the Bab gave to Mulla Husayn?");
        QuestionAnswerKey.put(20,"B");
        QuestionItems.put(21, "What does term 'Babu'u'l-Bab' mean?");
        QuestionAnswerKey.put(21,"B");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Double Jeopardy Game for the 178th Declaration of the Bab in May 24, 2022");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 617, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(DoubleJeopardyMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(DoubleJeopardyMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(DoubleJeopardyMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(DoubleJeopardyMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new DoubleJeopardyMainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
