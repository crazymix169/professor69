/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class ChurchInformationSystemIANServicesMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String churchid;
    String servicetype;
    String serviceid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public ChurchInformationSystemIANServicesMaintenance(String Userid, String Username) {
        
        super("Services Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }
    
    public ChurchInformationSystemIANServicesMaintenance() {
        super("Services Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        initComponents();
        
        DoConnect();
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_services";
            sql="";
            sql = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, tbl_church.description, "
                    + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church`"
                    + " WHERE tbl_church.churchid=tbl_services.churchid";
            sql="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                    + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                int serviceid = rs.getInt("serviceid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("servicetype");
                String servicedescription=rs.getString("tbl_services.description");           

                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription);          
            
            }
            
              
            
            viewall=0;
            viewall2=0;
            Show_Church_In_JTable();
            Show_Services_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANServicesTable> getServicesList()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> servicesList= new ArrayList<ChurchInformationSystemIANServicesTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                            + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                            + "WHERE tbl_church.churchid=tbl_services.churchid";
            }
            else if(viewall==1)
            {
                
                churchname=textChurchName.getText().trim();
                servicetype=textServiceType.getText().trim();
                
                query="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                    + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    +"(tbl_church.churchname like '%"+churchname+"%' or tbl_services.servicetype like '%"+servicetype+"%')";
            
            }
            else if(viewall==3) 
            {                
                serviceid=textServiceID.getText();
                int serviceid1=Integer.parseInt(serviceid);
                query="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                    + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and tbl_services.serviceid= "+serviceid1+" ";
            }
            else if(viewall==2)
            {                
                churchid=textChurchID.getText();
                int churchid1=Integer.parseInt(churchid);
                query="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                    + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and tbl_services.churchid= "+churchid1+" ";
            }
            
               

            int i=1;
           
            Statement st;          
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANServicesTable services1;
            
            while(rs.next())
            {
                services1 = new  ChurchInformationSystemIANServicesTable(rs.getInt("serviceid"),rs.getInt("churchid"),
                        rs.getString("churchname"),rs.getString("tbl_church.description"),
                        rs.getString("servicetype"),rs.getString("tbl_services.description"));
                servicesList.add(services1);
            }           
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+e.getMessage());
        }        
        return servicesList;     
    }
    
    public void Show_Services_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> list = getServicesList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[6];        
       
        model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getServiceID();
            row[1]=list.get(i).getChurchID();
            row[2]=list.get(i).getChurchsname();
            row[3]=list.get(i).getChurchDescription();
            row[4]=list.get(i).getServicetype();
            row[5]=list.get(i).getServiceDescription();
                                    
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANChurchTable> getChurchList()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> churchList= new ArrayList<ChurchInformationSystemIANChurchTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query = "Select * from tbl_church";
            }
            else if(viewall2==1)
            {
                churchname=textChurchName1.getText();
                query = "Select * from tbl_church where churchname like '%"+churchname+"%'";

            }
            else  if(viewall2==2)
            {
                churchid=textChurchID1.getText();
                int gg=Integer.parseInt(churchid);
                query="Select * from tbl_church where churchid= "+gg+"";
            }
            
               

            int i=1;
            
            Statement st;
                       
            st= connection.createStatement();
            rs2=st.executeQuery(query);           
            
            ChurchInformationSystemIANChurchTable church1;
            
            while(rs2.next())
            {
                church1 = new  ChurchInformationSystemIANChurchTable(rs2.getInt("churchid"), rs2.getString("churchname"), 
                              rs2.getString("description"));
                churchList.add(church1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+e.getMessage());
            
        }        
        return churchList;     
    }
    
    public void Show_Church_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> list = getChurchList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[3];        
       
        model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getChurchID();
            row[1]=list.get(i).getChurchName();
            row[2]=list.get(i).getChurchDescription();
                        
            model.addRow(row);            
        }        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textServiceType = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textChurchID = new javax.swing.JTextField();
        textChurchName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByChurchname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textServiceID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textChurchDescription = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textChurchID1 = new javax.swing.JTextField();
        textChurchName1 = new javax.swing.JTextField();
        btnSearchByChurchname1 = new javax.swing.JButton();
        btnSearchByChurchID = new javax.swing.JButton();
        btnSearchByChurchID1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textServiceDescription = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnSearchByServicesID = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Service ID", "Church ID", "Church Name", "Church Description", "Service Type", "Service Description"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Service type");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Church ID", "Church Name", "Church Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Church Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textChurchName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Church ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Church Name");

        btnSearchByChurchname.setText("Search by Church Name or service type in Available Churches");
        btnSearchByChurchname.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Service ID");

        textChurchDescription.setBackground(new java.awt.Color(51, 255, 255));
        textChurchDescription.setColumns(20);
        textChurchDescription.setRows(5);
        jScrollPane1.setViewportView(textChurchDescription);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Churich ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Church Name");

        textChurchName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByChurchname1.setText("Search by Church Name");
        btnSearchByChurchname1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchname1ActionPerformed(evt);
            }
        });

        btnSearchByChurchID.setText("Search by Church ID in Available Churches");
        btnSearchByChurchID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchIDActionPerformed(evt);
            }
        });

        btnSearchByChurchID1.setText("Search by Church ID");
        btnSearchByChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchID1ActionPerformed(evt);
            }
        });

        textServiceDescription.setBackground(new java.awt.Color(51, 255, 255));
        textServiceDescription.setColumns(20);
        textServiceDescription.setRows(5);
        jScrollPane2.setViewportView(textServiceDescription);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Service Description");

        btnSearchByServicesID.setText("Search by Services ID in Available Churches");
        btnSearchByServicesID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByServicesIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(92, 92, 92))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(14, 14, 14)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(16, 16, 16)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(10, 10, 10))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSearchByChurchID)
                            .addComponent(btnSearchByServicesID)
                            .addComponent(textChurchID, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                            .addComponent(textChurchName)
                            .addComponent(textServiceID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSearchByChurchID1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByChurchname1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(textChurchID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textChurchName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnSearchByChurchname)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(10, 10, 10))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(textServiceType, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByChurchname1)
                    .addComponent(btnSearchByChurchID1)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByServicesID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textServiceID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textChurchID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addGap(136, 136, 136))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                                .addComponent(btnSearchByChurchID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnSearchByChurchname)
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textServiceType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textServiceID.setText(model.getValueAt(i, 0).toString());
            textChurchID.setText(model.getValueAt(i, 1).toString());
            textChurchName.setText(model.getValueAt(i, 2).toString());
            textChurchDescription.setText(model.getValueAt(i, 3).toString());
            textServiceType.setText(model.getValueAt(i, 4).toString());
            textServiceDescription.setText(model.getValueAt(i, 5).toString());
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textServiceID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textServiceType.setText(model.getValueAt(i, 4).toString());          

            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String serviceid=textServiceID.getText().trim();
                int serviceid2=Integer.parseInt(serviceid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_services where serviceid="+serviceid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {                

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    

                    sql="DELETE FROM  tbl_services"
                    + " where serviceid="+serviceid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String serviceid=textServiceID.getText().trim();
                int serviceid2=Integer.parseInt(serviceid);

                String churchid=textChurchID.getText().trim();
                int churchid2=Integer.parseInt(churchid);
                
                String churchname=textChurchName.getText().trim();
                String churchdescription=textChurchDescription.getText().trim();
                String servicetype=textServiceType.getText().trim();
                String servicedescription=textServiceDescription.getText().trim();
                                               

                if(serviceid.equals("")|| churchid.equals("")||
                        servicetype.equals("")|| servicedescription.equals(""))
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {                   
                    stmt = con.createStatement( );
               
                    String sql="Select * from tbl_church where churchid="+churchid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {

                        rowCount++;
                    }

                    stmt = con.createStatement( );

                    sql="Select * from tbl_services where serviceid="+serviceid2+" or (churchid="+churchid2+" and servicetype='"+servicetype+"')";
                    rs = stmt.executeQuery(sql);

                    int rowCount2=0;

                    while ( rs.next( ) )
                    {

                        rowCount2++;
                    }

                    if(rowCount2==0||rowCount2==2||rowCount==0)
                    {
                        JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " Sorry, No Record Found! or duplicate upon edit! ");
                    }
                    else
                    {                   

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                     
                        sql="Update tbl_services"
                        + " SET  tbl_services.churchid="+churchid2+",tbl_services.servicetype='"+servicetype+"', tbl_services.description='"+servicedescription+"' "
                        + " where tbl_services.serviceid="+serviceid2+"";

                        stmt.executeUpdate(sql);

                        

                        stmt = con.createStatement( );
                        sql="Select * from tbl_services where serviceid="+serviceid2+" ";
                        sql="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                            + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                            + "WHERE tbl_church.churchid=tbl_services.churchid and serviceid="+serviceid2+"";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            serviceid2 = rs.getInt("serviceid");
                            churchid2 = rs.getInt("churchid");
                            churchname=rs.getString("churchname");
                            churchdescription=rs.getString("tbl_church.description");
                            servicetype=rs.getString("servicetype");
                            servicedescription=rs.getString("tbl_services.description");
                            
                            rowCount++;
                            if(rowCount==1)
                            {
                                textServiceID.setText(Integer.toString(serviceid2));
                                textChurchID.setText(Integer.toString(churchid2));
                                textChurchName.setText(churchname);
                                textChurchDescription.setText(churchdescription);
                                textServiceType.setText(servicetype);
                                textServiceDescription.setText(servicedescription);
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        //Show_Church_In_JTable();
                        //Show_Services_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save new record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
           

            String churchid=textChurchID.getText().trim();
            int churchid2=Integer.parseInt(churchid);

            String churchname=textChurchName.getText().trim();
            String churchdescription=textChurchDescription.getText().trim();
            String servicetype=textServiceType.getText().trim();
            String servicedescription=textServiceDescription.getText().trim();

           if(churchid.equals("")|| 
                        servicetype.equals("")|| servicedescription.equals(""))
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                String sql="Select * from tbl_church where churchid="+churchid2+" ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                
                stmt = con.createStatement( );
               
                sql="Select * from tbl_services where churchid="+churchid2+" and servicetype='"+servicetype+"'";
                rs = stmt.executeQuery(sql);

                int rowCount2=0;

                while ( rs.next( ) )
                {
                    
                    rowCount2++;
                }

                if(rowCount==0||rowCount2==1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " Sorry, church or church with service  already exists! ");
                }
                else
                {
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_services " + "VALUES (NULL,"+churchid2+", '"+servicetype+"','"+servicedescription+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                   
                    sql="SELECT tbl_services.serviceid,tbl_church.churchid,tbl_church.churchname, tbl_church.description, "
                            + "tbl_services.servicetype, tbl_services.description FROM `tbl_services`,`tbl_church` "
                            + "WHERE tbl_church.churchid=tbl_services.churchid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int serviceid2=rs.getInt("serviceid");

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " new inserted services item: "+Double.toString(serviceid2));

                   
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Church_In_JTable();
                    Show_Services_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, " error269: "+ex.getMessage());
            
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textServiceID.setText("");
            textChurchID.setText("");
            textChurchName.setText("");
            textChurchDescription.setText("");
            textServiceType.setText("");
            textServiceDescription.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try {
            rs.absolute( curRow );

            int serviceid = rs.getInt("serviceid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("servicetype");
            String servicedescription=rs.getString("tbl_services.description");           

            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int serviceid = rs.getInt("serviceid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("servicetype");
                String servicedescription=rs.getString("tbl_services.description");           

                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                textChurchID.setText("");
                textChurchName.setText("");
                textChurchDescription.setText("");

                textServiceID.setText("");
                textServiceDescription.setText("");
                textServiceType.setText("");

                textChurchID1.setText("");
                textChurchName1.setText("");
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                        
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        try
        {
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textChurchID.setText(model.getValueAt(i, 0).toString());
            textChurchName.setText(model.getValueAt(i, 1).toString());
            textChurchDescription.setText(model.getValueAt(i, 2).toString());
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:

        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        try
        {
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyTyped

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textChurchID.setText("");
        textChurchName.setText("");
        textChurchDescription.setText("");

        textServiceID.setText("");
        textServiceDescription.setText("");
        textServiceType.setText("");
        
        textChurchID1.setText("");
        textChurchName1.setText("");
       

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search By church Name and 
    private void btnSearchByChurchnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchnameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchnameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int serviceid = rs.getInt("serviceid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("servicetype");
                String servicedescription=rs.getString("tbl_services.description");           

                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //move first
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int serviceid = rs.getInt("serviceid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("servicetype");
            String servicedescription=rs.getString("tbl_services.description");           

            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to MDI Form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:
        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move Previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int serviceid = rs.getInt("serviceid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("servicetype");
                String servicedescription=rs.getString("tbl_services.description");           

                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int serviceid = rs.getInt("serviceid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("servicetype");
            String servicedescription=rs.getString("tbl_services.description");           

            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANServicesMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search by church Name
    private void btnSearchByChurchname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchname1ActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchname1ActionPerformed

    //search by church ID
    private void btnSearchByChurchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Services_In_JTable();
        
    }//GEN-LAST:event_btnSearchByChurchIDActionPerformed

    //search by church ID
    private void btnSearchByChurchID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchID1ActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchID1ActionPerformed

    //search by Services ID
    private void btnSearchByServicesIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByServicesIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByServicesIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByServicesIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByChurchID;
    private javax.swing.JButton btnSearchByChurchID1;
    private javax.swing.JButton btnSearchByChurchname;
    private javax.swing.JButton btnSearchByChurchname1;
    private javax.swing.JButton btnSearchByServicesID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea textChurchDescription;
    private javax.swing.JTextField textChurchID;
    private javax.swing.JTextField textChurchID1;
    private javax.swing.JTextField textChurchName;
    private javax.swing.JTextField textChurchName1;
    private javax.swing.JTextArea textServiceDescription;
    private javax.swing.JTextField textServiceID;
    private javax.swing.JTextField textServiceType;
    // End of variables declaration//GEN-END:variables
}
