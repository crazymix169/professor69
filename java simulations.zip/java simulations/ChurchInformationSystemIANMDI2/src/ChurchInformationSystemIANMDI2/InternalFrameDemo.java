/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;
import java.beans.PropertyVetoException;
import java.lang.System.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author crazymix69
 */
public class InternalFrameDemo extends javax.swing.JFrame { 
    


    /**
     * Creates new form InternalFrameDemo
     */
    
    JDesktopPane desktop;
    String Username;
    String Userid;
    
    Connection con;
    Statement stmt;
    ResultSet rs;
    //labelUserID=new javax.swing.JLabel();
    /*
    public InternalFrameDemo(String username, String userid) {
        
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        initComponents();
        labelUserID.setVisible(false);
        labelUserName.setVisible(false);
        labelUserID.setText(userid);
        labelUserName.setText(username);
        Userid=userid;
        Username=username;
        JOptionPane.showMessageDialog(null, labelUserName.getText(), labelUserID.getText(), HEIGHT);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }*/
    public void setID(String userid, String username) 
    {
        Userid = userid;
        Username=username;
    }
    
    public void enabler()
    {
        fileMenu.setEnabled(!false);
        TransactionMaintenanceMenu.setEnabled(!false);
        helpMenu.setEnabled(!false);
        jMenuLogger.setEnabled(!false);
        jMenuItemLogout.setVisible(!false);
        jMenuItemLoginForm.setVisible(false);
    }
    
    public void disabler()
    {
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuLogger.setEnabled(false);
        jMenuItemLogout.setVisible(false);
        jMenuItemLoginForm.setVisible(false);
        
    }       
    
    public void Logz()
    {
        jMenuItemLoginForm.setVisible(!false);
        jMenuItemLogout.setVisible(false);
        jMenuLogger.setEnabled(false);
    }      
    
    public void LogzBack()
    {
        jMenuItemLoginForm.setVisible(false);
        jMenuItemLogout.setVisible(!false);
        jMenuLogger.setEnabled(!false);
        
    }
    
    
    public InternalFrameDemo()
    {
        
        super("Church Information System");
        desktop = new JDesktopPane();
        //createFrame(); //Create first window
        setContentPane(desktop);
        
        
        //Make dragging a little faster but perhaps uglier.
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        
        
        
        
        initComponents();
        
        
        
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuItemLogout.setVisible(false);
        //jMenuLogger.setEnabled(false);
        
        
        
    //...Create the GUI and put it in the window...
    //...Then set the window size or call pack...
    
    
    }
    
    /*
    User Login, Logtrail and User maintenance Forms
    */
    
    protected void createUserMaintenanceFrame()
    {
        ChurchInformationSystemIANUserMaintenance frame = new ChurchInformationSystemIANUserMaintenance();
       
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //login form
    protected void createFrameLoginForm()
    {
        
        
        
        ChurchInformationSystemIANLoginForm frame = new ChurchInformationSystemIANLoginForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //logtrail maintenance
    protected void createFrameUserLogtrailMaintenance()
    {
        
        
        
        ChurchInformationSystemIANUserLogtrailMaintenance frame = new ChurchInformationSystemIANUserLogtrailMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    /*
    Transaction of Church Information System
    */
    
    //Church Maintenance
    protected void createFrameChurchMaintenance()
    {
        
        
        
        ChurchInformationSystemIANChurchMaintenance frame = new ChurchInformationSystemIANChurchMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Activities maintenance
    protected void createFrameActivitiesMaintenance()
    {
        
        
        
        ChurchInformationSystemIANActivitiesMaintenance frame = new ChurchInformationSystemIANActivitiesMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Annoucncement maintenance
    protected void createFrameAnnouncementMaintenance()
    {
        
        
        
        ChurchInformationSystemIANAnnouncementMaintenance frame = new ChurchInformationSystemIANAnnouncementMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Application Form Maintenance
    protected void createFrameApplicationFormMaintenance()
    {
        
        
        
        ChurchInformationSystemIANApplicationFormMaintenance frame = new ChurchInformationSystemIANApplicationFormMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Information Maintenance
    protected void createFrameInformationMaintenance()
    {
        
        
        
        ChurchInformationSystemIANInformationMaintenance frame = new ChurchInformationSystemIANInformationMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Priest Maintenance
    protected void createFramePriestMaintenance()
    {
        
        
        
        ChurchInformationSystemIANPriestMaintenance frame = new ChurchInformationSystemIANPriestMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Records Maintenance
    protected void createFrameRecordsMaintenance()
    {
        
        
        
        ChurchInformationSystemIANRecordsMaintenance frame = new ChurchInformationSystemIANRecordsMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Requirements Maintenance
    protected void createFrameRequirementsMaintenance()
    {
        
        
        
        ChurchInformationSystemIANRequirementsMaintenance frame = new ChurchInformationSystemIANRequirementsMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Schedule Maintenance
    protected void createFrameScheduleMaintenance()
    {
        
        
        
        ChurchInformationSystemIANScheduleMaintenance frame = new ChurchInformationSystemIANScheduleMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //Services Maintenance
    protected void createFrameServicesMaintenance()
    {
        
        
        
        ChurchInformationSystemIANServicesMaintenance frame = new ChurchInformationSystemIANServicesMaintenance();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    
    
    
    //content and about the author
    
    /*
    Content Form
    */
    protected void createFrameContentForm()
    {
        
        
        
        ChurchInformationSystemIANContentForm frame = new ChurchInformationSystemIANContentForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }
    
    //about the authoer
    protected void createFrameAboutTheAuthorForm()
    {
        
        
        
        ChurchInformationSystemIANAboutTheAuthorForm frame = new ChurchInformationSystemIANAboutTheAuthorForm();
        
        frame.setVisible(true);
        desktop.add(frame);
        try {
            frame.setSelected(true);
        } catch (java.beans.PropertyVetoException e) {}
        disabler();
    
    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        UserMaintenanceMenuItem = new javax.swing.JMenuItem();
        LogtrailMaintenanceMenuItem = new javax.swing.JMenuItem();
        TransactionMaintenanceMenu = new javax.swing.JMenu();
        ChurchMaintenanceMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        ActivitiesMaintenanceMenuItem = new javax.swing.JMenuItem();
        AnnouncementMaintenanceMenuItem = new javax.swing.JMenuItem();
        jMenuItemInformationMaintenance = new javax.swing.JMenuItem();
        jMenuItemRecordsMaintenance = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        jMenuItemServicesMaintenance = new javax.swing.JMenuItem();
        ApplicationFormMaintenanceMenuItem = new javax.swing.JMenuItem();
        jMenuItemRequirementsMaintenance = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        jMenuItemPriestMaintenance = new javax.swing.JMenuItem();
        jMenuItemScheduleMaintenance = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        contentMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();
        jMenuLogger = new javax.swing.JMenu();
        jMenuItemLoginForm = new javax.swing.JMenuItem();
        jMenuItemLogout = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        desktopPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        desktopPane.setName(""); // NOI18N

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        UserMaintenanceMenuItem.setMnemonic('o');
        UserMaintenanceMenuItem.setText("User Maintenance");
        UserMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                UserMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(UserMaintenanceMenuItem);

        LogtrailMaintenanceMenuItem.setMnemonic('s');
        LogtrailMaintenanceMenuItem.setText("Log Trail Maintenance");
        LogtrailMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                LogtrailMaintenanceMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(LogtrailMaintenanceMenuItem);

        menuBar.add(fileMenu);

        TransactionMaintenanceMenu.setMnemonic('e');
        TransactionMaintenanceMenu.setText("Transaction");

        ChurchMaintenanceMenuItem.setMnemonic('t');
        ChurchMaintenanceMenuItem.setText("Church Maintenance");
        ChurchMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                ChurchMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(ChurchMaintenanceMenuItem);
        TransactionMaintenanceMenu.add(jSeparator1);

        ActivitiesMaintenanceMenuItem.setMnemonic('y');
        ActivitiesMaintenanceMenuItem.setText("Activities Maintenance");
        ActivitiesMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                ActivitiesMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(ActivitiesMaintenanceMenuItem);

        AnnouncementMaintenanceMenuItem.setMnemonic('p');
        AnnouncementMaintenanceMenuItem.setText("Announcement Maintenance");
        AnnouncementMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                AnnouncementMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(AnnouncementMaintenanceMenuItem);

        jMenuItemInformationMaintenance.setText("Information Maintenance");
        jMenuItemInformationMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemInformationMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemInformationMaintenance);

        jMenuItemRecordsMaintenance.setText("Records Maintenance");
        jMenuItemRecordsMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemRecordsMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemRecordsMaintenance);
        TransactionMaintenanceMenu.add(jSeparator2);

        jMenuItemServicesMaintenance.setText("Services Maintenance");
        jMenuItemServicesMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemServicesMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemServicesMaintenance);

        ApplicationFormMaintenanceMenuItem.setMnemonic('d');
        ApplicationFormMaintenanceMenuItem.setText("Application Form Maintenance");
        ApplicationFormMaintenanceMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                ApplicationFormMaintenanceMenuItemActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(ApplicationFormMaintenanceMenuItem);

        jMenuItemRequirementsMaintenance.setText("RequirementsMaintenance");
        jMenuItemRequirementsMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemRequirementsMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemRequirementsMaintenance);
        TransactionMaintenanceMenu.add(jSeparator3);

        jMenuItemPriestMaintenance.setText("Priest Maintenance");
        jMenuItemPriestMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemPriestMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemPriestMaintenance);

        jMenuItemScheduleMaintenance.setText("Schedule Maintenance");
        jMenuItemScheduleMaintenance.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemScheduleMaintenanceActionPerformed(evt);
            }
        });
        TransactionMaintenanceMenu.add(jMenuItemScheduleMaintenance);

        menuBar.add(TransactionMaintenanceMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        contentMenuItem.setMnemonic('c');
        contentMenuItem.setText("Contents");
        contentMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                contentMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(contentMenuItem);

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        jMenuLogger.setText("Login or Logout");

        jMenuItemLoginForm.setText("Show Login Form");
        jMenuItemLoginForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemLoginFormActionPerformed(evt);
            }
        });
        jMenuLogger.add(jMenuItemLoginForm);

        jMenuItemLogout.setText("Logout");
        jMenuItemLogout.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jMenuItemLogoutActionPerformed(evt);
            }
        });
        jMenuLogger.add(jMenuItemLogout);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                exitMenuItemActionPerformed(evt);
            }
        });
        jMenuLogger.add(exitMenuItem);

        menuBar.add(jMenuLogger);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPane, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        desktopPane.getAccessibleContext().setAccessibleName("Sales and Inventory System");
        desktopPane.getAccessibleContext().setAccessibleParent(desktopPane);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            

            con.close();
            stmt.close();
            rs.close();
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        JOptionPane.showMessageDialog(InternalFrameDemo.this, "Exiting Application!");
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    //user maintenance
    private void UserMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        
        createUserMaintenanceFrame();
        
         
        
    }//GEN-LAST:event_UserMaintenanceMenuItemActionPerformed

    private void jMenuItemLoginFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLoginFormActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        
        createFrameLoginForm();
        jMenuItemLogout.setVisible(false);
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuLogger.setEnabled(false);
        
        
    }//GEN-LAST:event_jMenuItemLoginFormActionPerformed

    private void LogtrailMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogtrailMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //Username=labelUserName.getText();
        //Userid=labelUserID.getText();
        createFrameUserLogtrailMaintenance();
        //JOptionPane.showMessageDialog(null, Username, Userid, HEIGHT);
        
    }//GEN-LAST:event_LogtrailMaintenanceMenuItemActionPerformed

    private void ChurchMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChurchMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameChurchMaintenance();
    }//GEN-LAST:event_ChurchMaintenanceMenuItemActionPerformed

    private void ActivitiesMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActivitiesMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //createFrameStocksMaintenance();
        createFrameActivitiesMaintenance();
    }//GEN-LAST:event_ActivitiesMaintenanceMenuItemActionPerformed

    //announcement maintenance
    private void AnnouncementMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AnnouncementMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //createFrameSalesMaintenance();
        createFrameAnnouncementMaintenance();
    }//GEN-LAST:event_AnnouncementMaintenanceMenuItemActionPerformed

    //application form maintenance
    private void ApplicationFormMaintenanceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApplicationFormMaintenanceMenuItemActionPerformed
        // TODO add your handling code here:
        //createFramePaymentMaintenance();
        createFrameApplicationFormMaintenance();
    }//GEN-LAST:event_ApplicationFormMaintenanceMenuItemActionPerformed

    //content form
    private void contentMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contentMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameContentForm();
    }//GEN-LAST:event_contentMenuItemActionPerformed

    //about the author
    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        createFrameAboutTheAuthorForm();
    }//GEN-LAST:event_aboutMenuItemActionPerformed
    
    //Logout
    private void jMenuItemLogoutActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemLogoutActionPerformed
    {//GEN-HEADEREND:event_jMenuItemLogoutActionPerformed
        // TODO add your handling code here:
        try
        {

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            //String sql="Select * from users ";
            // rs = stmt.executeQuery(sql);
            //ResultSetMetaData rmet= rs.getMetaData();

            //con = DriverManager.getConnection( host, uName, uPass );

            //stmt = con.createStatement( );
            stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            /*
            String username="August";
            String userpass="august";*/
            
            String sql="Select * from tbl_users where username='"+Username+"' and userid="+Integer.parseInt(Userid)+"";
            rs = stmt.executeQuery(sql);

            rs.next();

            rs = stmt.executeQuery(sql);
            int x=0;
            String uname="";
            String userid="";
            while(rs.next())
            {
                x++;
                uname=rs.getString("username");
                userid=Integer.toString(rs.getInt("userid"));
            }
            //+combo.getSelectedItem()

            if(x==1)
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "Successful Admin Logout "+Username+ " will Logout!");

                Date now = new Date();
                System.out.println("toString(): " + now);  // dow mon dd hh:mm:ss zzz yyyy
                SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss");
                System.out.println("Format 2:   " + dateFormatter.format(now));

                stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                sql ="INSERT INTO tbl_userslogtrail " + "VALUES (NULL,"+Integer.parseInt(userid)+",'logout', CURDATE(), CURTIME())";

                stmt.executeUpdate(sql);

                //new SalesAndInventoryAugustAdminWelcome(userid, uname).setVisible(true);
                
                //new InternalFrameDemo(uname, userid);
                
                
                con.close();
                stmt.close();
                rs.close();
                
            }
            else
            {
                JOptionPane.showMessageDialog(InternalFrameDemo.this, "You are currently Logged out!");
            }
            
            con.close();
            stmt.close();
            rs.close();
            
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(InternalFrameDemo.this, " You are currently Logged out! "+ex.getMessage());
            //Logger.getLogger(FanLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        createFrameLoginForm();
        fileMenu.setEnabled(false);
        TransactionMaintenanceMenu.setEnabled(false);
        helpMenu.setEnabled(false);
        jMenuItemLoginForm.setVisible(!false);
    }//GEN-LAST:event_jMenuItemLogoutActionPerformed

    //information maintenance
    private void jMenuItemInformationMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemInformationMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemInformationMaintenanceActionPerformed
        // TODO add your handling code here:
        createFrameInformationMaintenance();
    }//GEN-LAST:event_jMenuItemInformationMaintenanceActionPerformed

    //records maintenance
    private void jMenuItemRecordsMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemRecordsMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemRecordsMaintenanceActionPerformed
        // TODO add your handling code here:
        createFrameRecordsMaintenance();
    }//GEN-LAST:event_jMenuItemRecordsMaintenanceActionPerformed

    //services maintenance
    private void jMenuItemServicesMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemServicesMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemServicesMaintenanceActionPerformed
        // TODO add your handling code here:
        createFrameServicesMaintenance();
    }//GEN-LAST:event_jMenuItemServicesMaintenanceActionPerformed

    //requirements maintenance
    private void jMenuItemRequirementsMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemRequirementsMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemRequirementsMaintenanceActionPerformed
        // TODO add your handling code here:
        createFrameRequirementsMaintenance();
    }//GEN-LAST:event_jMenuItemRequirementsMaintenanceActionPerformed

    //priest maintenance
    private void jMenuItemPriestMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemPriestMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemPriestMaintenanceActionPerformed
        // TODO add your handling code here:
        createFramePriestMaintenance();
    }//GEN-LAST:event_jMenuItemPriestMaintenanceActionPerformed

    //schedule maintenance
    private void jMenuItemScheduleMaintenanceActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jMenuItemScheduleMaintenanceActionPerformed
    {//GEN-HEADEREND:event_jMenuItemScheduleMaintenanceActionPerformed
        // TODO add your handling code here:
        createFrameScheduleMaintenance();
    }//GEN-LAST:event_jMenuItemScheduleMaintenanceActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InternalFrameDemo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InternalFrameDemo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem ActivitiesMaintenanceMenuItem;
    private javax.swing.JMenuItem AnnouncementMaintenanceMenuItem;
    private javax.swing.JMenuItem ApplicationFormMaintenanceMenuItem;
    private javax.swing.JMenuItem ChurchMaintenanceMenuItem;
    private javax.swing.JMenuItem LogtrailMaintenanceMenuItem;
    private javax.swing.JMenu TransactionMaintenanceMenu;
    private javax.swing.JMenuItem UserMaintenanceMenuItem;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JMenuItem contentMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem jMenuItemInformationMaintenance;
    private javax.swing.JMenuItem jMenuItemLoginForm;
    private javax.swing.JMenuItem jMenuItemLogout;
    private javax.swing.JMenuItem jMenuItemPriestMaintenance;
    private javax.swing.JMenuItem jMenuItemRecordsMaintenance;
    private javax.swing.JMenuItem jMenuItemRequirementsMaintenance;
    private javax.swing.JMenuItem jMenuItemScheduleMaintenance;
    private javax.swing.JMenuItem jMenuItemServicesMaintenance;
    private javax.swing.JMenu jMenuLogger;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JMenuBar menuBar;
    // End of variables declaration//GEN-END:variables

}
