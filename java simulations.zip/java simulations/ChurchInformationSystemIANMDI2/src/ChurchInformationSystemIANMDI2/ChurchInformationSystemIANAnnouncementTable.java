/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANAnnouncementTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int announcementid;
    int churchid;
    String churchname;
    String churchdescription;
    String announcement;
    String date;
       
    
    
    public ChurchInformationSystemIANAnnouncementTable
    (            
    int announcementid,
    int churchid,
    String churchname,
    String churchdescription,
    String announcement,
    String date
    
    )
            
    {
        
       
        
        this.announcementid=announcementid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.announcement=announcement;
        this.date=date;
       
               
        
    }
    
    public int getAnnouncementID()
    {
        return announcementid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchsname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getAnnouncement()
    {
        return announcement;
    }
    public String getDate()
    {
        return date;
    }
    
}
