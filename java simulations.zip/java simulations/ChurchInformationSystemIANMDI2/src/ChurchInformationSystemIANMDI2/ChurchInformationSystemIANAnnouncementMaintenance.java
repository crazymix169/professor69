/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class ChurchInformationSystemIANAnnouncementMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANAnnouncementMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String churchid;
    String announcement;
    String announcementid;

    /**
     * Creates new form SalesAndInventoryCristalStocksMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public ChurchInformationSystemIANAnnouncementMaintenance(String Userid, String Username) {
        
        super("Announcement Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }
    
    public ChurchInformationSystemIANAnnouncementMaintenance() {
        super("Announcement Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="Select * from tbl_announcement";
            sql="";
            
            sql = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                int announcementid = rs.getInt("announcementid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String announcement=rs.getString("announcement");
                String announcementdate=rs.getString("date");



                textAnnouncementID.setText(Integer.toString(announcementid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textAnnouncement.setText(announcement);
                textAnnouncementDate.setText(announcementdate);
            
            }               
            
            viewall=0;
            viewall2=0;
            Show_Church_In_JTable();
            Show_Announcement_In_JTable();
            
            
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
            //String sql="Select * from Workers where JOB_TITLE='Programmer'";
            
            //Statement stmt;
            //Statement stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            /*
            String sql="Select * from Workers ";
            rs = stmt.executeQuery(sql);
           
           
            rs.next();
            
           
            int id_col = rs.getInt("ID");
            String first_name = rs.getString("First_Name");
            String last_name = rs.getString("Last_Name");
            String job = rs.getString("Job_Title");

            //String p = id_col + " " + first_name + " " + last_name + " , " + job;
                //System.out.println( p );
            
            String id = Integer.toString( id_col );
            textID.setText(id);
            textFirstName.setText(first_name);
            textLastName.setText(last_name);
            textJobTitle.setText(job);*/
            
            return con;
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANAnnouncementTable> getAnnouncementList()
    {
        ArrayList<ChurchInformationSystemIANAnnouncementTable> announcementList= new ArrayList<ChurchInformationSystemIANAnnouncementTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {                
                query = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid";
            }
            else if(viewall==1)
            {
                
                churchname=textChurchName.getText().trim();
                announcement=textAnnouncement.getText().trim();
                
                query = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid and"
                        +"(tbl_church.churchname like '%"+churchname+"%' or tbl_announcement.announcement like '%"+announcement+"%')";
            
            }
            else if(viewall==2) 
            {
                churchid=textChurchID.getText();
                int churchid1=Integer.parseInt(churchid);
                               
                
                query = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid and tbl_announcement.churchid= "+churchid1+" ";
            }
            else if(viewall==1) 
            {
                
                /*
                query = "Select tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,"
                        +" tbl_announcement.activitiestype,tbl_announcement.description,"
                        +" tbl_announcement.date, tbl_announcement.time from tbl_announcement,tbl_church where"
                        +"tbl_church.churchid=tbl_announcement.churchid and tbl_announcement.churchid = "+churchid+" ";*/
                
                //query = "Select * from tbl_church where churchname like '%"+churchname+"%'";
                //query = "Select * from tbl_announcement where churchid = "+churchid+"";
                
                
                announcementid=textAnnouncementID.getText();
                int announcementid1=Integer.parseInt(announcementid);
                query = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid and tbl_announcement.announcementid= "+announcementid1+" ";
            }
            
               
//String s=textFirstName.getText();
            //String s="august";
            int i=1;
            //String i1=Integer.toString(i);
            // correct way to search a string: String query = "Select * from Workers where FIRST_NAME='"+s+"'";
            // correct way to search an integer: String query = "Select * from Workers where ID= "+i+"";
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANAnnouncementTable announcement1;
            
            while(rs.next())
            {
                announcement1 = new  ChurchInformationSystemIANAnnouncementTable(rs.getInt("announcementid"),rs.getInt("churchid"),
                        rs.getString("churchname"),rs.getString("tbl_church.description"),rs.getString("announcement"),rs.getString("date"));
                announcementList.add(announcement1);
            }
            
            
            
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
            
        }
        
        return announcementList;
     
    }
    
    public void Show_Announcement_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANAnnouncementTable> list = getAnnouncementList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[6];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getAnnouncementID();
            row[1]=list.get(i).getChurchID();
            row[2]=list.get(i).getChurchsname();
            row[3]=list.get(i).getChurchDescription();
            row[4]=list.get(i).getAnnouncement();
            row[5]=list.get(i).getDate();
            
                        
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANChurchTable> getChurchList()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> churchList= new ArrayList<ChurchInformationSystemIANChurchTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query = "Select * from tbl_church";
            }
            else if(viewall2==1)
            {
                churchname=textChurchName1.getText();
                query = "Select * from tbl_church where churchname like '%"+churchname+"%'";
            
            }
            else  if(viewall2==2)
            {
                churchid=textChurchID1.getText();
                int gg=Integer.parseInt(churchid);
                query="Select * from tbl_church where churchid= "+gg+"";
            }
                           

            int i=1;
            
            Statement st;
           // ResultSet rs;
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANChurchTable church1;
            
            while(rs2.next())
            {
                church1 = new  ChurchInformationSystemIANChurchTable(rs2.getInt("churchid"), rs2.getString("churchname"), 
                              rs2.getString("description"));
                churchList.add(church1);
            }
            
            
            
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
            
        }
        
        return churchList;
     
    }
    
    public void Show_Church_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANChurchTable> list = getChurchList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[3];
        
       
            model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getChurchID();
            row[1]=list.get(i).getChurchName();
            row[2]=list.get(i).getChurchDescription();
            
            
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textAnnouncement = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textChurchID = new javax.swing.JTextField();
        textChurchName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByChurchname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textAnnouncementID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textChurchDescription = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textChurchID1 = new javax.swing.JTextField();
        textChurchName1 = new javax.swing.JTextField();
        btnSearchByChurchname1 = new javax.swing.JButton();
        btnSearchByChurchID = new javax.swing.JButton();
        btnSearchByChurchID1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnSearchByAnnouncementID = new javax.swing.JButton();
        textAnnouncementDate = new javax.swing.JTextField();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Announcement ID", "Church ID", "Church Name", "Church Description", "Announcement", "Date"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Announcement");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Church ID", "Church Name", "Church Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Church Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textChurchName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Church ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Church Name");

        btnSearchByChurchname.setText("Search by Church Name or Announcement in Available Churches");
        btnSearchByChurchname.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Announcement ID");

        textChurchDescription.setBackground(new java.awt.Color(51, 255, 255));
        textChurchDescription.setColumns(20);
        textChurchDescription.setRows(5);
        jScrollPane1.setViewportView(textChurchDescription);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Churich ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Church Name");

        textChurchName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByChurchname1.setText("Search by Church Name");
        btnSearchByChurchname1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchname1ActionPerformed(evt);
            }
        });

        btnSearchByChurchID.setText("Search by Church ID in Available Churches");
        btnSearchByChurchID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchIDActionPerformed(evt);
            }
        });

        btnSearchByChurchID1.setText("Search by Church ID");
        btnSearchByChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchID1ActionPerformed(evt);
            }
        });

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Announcement Date");

        btnSearchByAnnouncementID.setText("Search by Announcement ID in Available Churches");
        btnSearchByAnnouncementID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByAnnouncementIDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(92, 92, 92))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(14, 14, 14)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(16, 16, 16)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(10, 10, 10))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnSearchByChurchID)
                            .addComponent(textChurchID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE)
                            .addComponent(textChurchName, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnSearchByAnnouncementID)
                            .addComponent(textAnnouncementID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnSearchByChurchID1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnSearchByChurchname1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(textChurchID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(textChurchName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnPrevious)
                                .addGap(25, 25, 25)
                                .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSaveRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelNewRecord)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(btnSearchByChurchname)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(10, 10, 10))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(textAnnouncement, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                                        .addComponent(textAnnouncementDate, javax.swing.GroupLayout.Alignment.LEADING)))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByChurchname1)
                    .addComponent(btnSearchByChurchID1)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByAnnouncementID))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(textAnnouncementID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textChurchID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnSearchByChurchID)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchByChurchname)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textAnnouncement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textAnnouncementDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(148, 148, 148))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textAnnouncementID.setText(model.getValueAt(i, 0).toString());
            textChurchID.setText(model.getValueAt(i, 1).toString());
            textChurchName.setText(model.getValueAt(i, 2).toString());
            textChurchDescription.setText(model.getValueAt(i, 3).toString());
            textAnnouncement.setText(model.getValueAt(i, 4).toString());
            textAnnouncementDate.setText(model.getValueAt(i, 5).toString());
        }
        catch(Exception e)
        {

        }

       
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textAnnouncementID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textAnnouncement.setText(model.getValueAt(i, 4).toString());
                textAnnouncementDate.setText(model.getValueAt(i, 5).toString());            

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textAnnouncementID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textAnnouncement.setText(model.getValueAt(i, 4).toString());
                textAnnouncementDate.setText(model.getValueAt(i, 5).toString());            

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String announcementid=textAnnouncementID.getText().trim();
                int announcementid2=Integer.parseInt(announcementid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_announcement where announcementid="+announcementid2+"";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                   

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    

                    sql="DELETE FROM  tbl_announcement"
                    + " where announcementid="+announcementid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit record
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                String announcementid=textAnnouncementID.getText().trim();
                int announcementid2=Integer.parseInt(announcementid);

                String churchid=textChurchID.getText().trim();
                int churchid2=Integer.parseInt(churchid);
                
                String churchname=textChurchName.getText().trim();
                String churchdescription=textChurchDescription.getText().trim();
                String announcement=textAnnouncement.getText().trim();
                String announcementdate=textAnnouncementDate.getText().trim();
                                               

                if(announcementid.equals("")|| churchid.equals("")||
                        announcement.equals("")|| announcementdate.equals(""))
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                    stmt = con.createStatement( );
               
                    String sql="SELECT * FROM `tbl_church` where churchid="+churchid2+" ";
                    rs = stmt.executeQuery(sql);

                    int rowCount2=0;

                    while ( rs.next( ) )
                    {

                        rowCount2++;
                    }
                    
                    stmt = con.createStatement( );
                    sql="SELECT * FROM `tbl_announcement` where announcementid="+announcementid2+" "
                            + "or (churchid="+churchid2+" and announcement='"+announcement+"') ";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {
                        
                        rowCount++;
                    }

                    if(rowCount==0||rowCount==2||rowCount2==0)
                    {
                        JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " Sorry, No Record Found! or duplicate upon editing! ");
                    }
                    else if(rowCount==1 && rowCount2==1)
                    {

                       

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                                
                        sql="UPDATE `tbl_announcement` "
                                + "SET `churchid`="+churchid2+","
                                + "`announcement`='"+announcement+"',`date`='"+announcementdate+"' WHERE "
                                + "tbl_announcement.announcementid="+announcementid2+"";
                        stmt.executeUpdate(sql);

                        

                        stmt = con.createStatement( );
                        sql="Select * from tbl_announcement where announcementid="+announcementid2+" ";
                        sql = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                                + " tbl_announcement.announcement, tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                                + "WHERE tbl_church.churchid=tbl_announcement.churchid and"
                                + " tbl_announcement.announcementid="+announcementid2+"";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        while ( rs.next( ) )
                        {
                            announcementid2 = rs.getInt("announcementid");
                            churchid2 = rs.getInt("churchid");
                            churchname=rs.getString("churchname");
                            churchdescription=rs.getString("tbl_church.description");
                            announcement=rs.getString("announcement");
                            announcementdate=rs.getString("date");

                            rowCount++;
                            if(rowCount==1)
                            {
                                textAnnouncementID.setText(Integer.toString(announcementid2));
                                textChurchID.setText(Integer.toString(churchid2));
                                textChurchName.setText(churchname);
                                textChurchDescription.setText(churchdescription);
                                textAnnouncement.setText(announcement);
                                textAnnouncementDate.setText(announcementdate);
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Record Successfully Modified!");
                        //new FanLogin().setVisible(true);
                        //this.dispose();

                        //Show_Church_In_JTable();
                        //Show_Announcement_In_JTable();

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
                //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save new record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
           

            String churchid=textChurchID.getText().trim();
            int churchid2=Integer.parseInt(churchid);

            String churchname=textChurchName.getText().trim();
            String churchdescription=textChurchDescription.getText().trim();
            String announcement=textAnnouncement.getText().trim();
            String announcementdate=textAnnouncementDate.getText().trim();

           if   (churchid.equals("")|| 
                        announcement.equals("")|| announcementdate.equals(""))
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
               
                String sql="SELECT * FROM `tbl_church` where churchid="+churchid2+" ";
                rs = stmt.executeQuery(sql);
                
                int rowCount2=0;

                while ( rs.next( ) )
                {
                    
                    rowCount2++;
                }
                
                stmt = con.createStatement( );
               
                sql="SELECT * FROM `tbl_announcement` where churchid="+churchid2+" and announcement='"+announcement+"' ";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }

                if(rowCount==1||rowCount2==0)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " Sorry, there will be duplicate or non-existent church! ");
                }
                else
                {
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_announcement " + "VALUES (NULL,"+churchid2+", '"+announcement+"','"+announcementdate+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    
                    sql = "SELECT tbl_announcement.announcementid,tbl_church.churchid,tbl_church.churchname,tbl_church.description,"
                            + " tbl_announcement.announcement,tbl_announcement.date FROM `tbl_announcement`,`tbl_church` "
                            + "WHERE tbl_announcement.churchid=tbl_church.churchid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    int announcementid2=rs.getInt("announcementid");

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " new inserted announcement item: "+Double.toString(announcementid2));

                    
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Church_In_JTable();
                    Show_Announcement_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textAnnouncementID.setText("");
            textChurchID.setText("");
            textChurchName.setText("");
            textChurchDescription.setText("");
            textAnnouncement.setText("");
            textAnnouncementDate.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try
        {
            rs.absolute( curRow );

            int announcementid = rs.getInt("announcementid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String announcement=rs.getString("announcement");
            String announcementdate=rs.getString("date");



            textAnnouncementID.setText(Integer.toString(announcementid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textAnnouncement.setText(announcement);
            textAnnouncementDate.setText(announcementdate);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int announcementid = rs.getInt("announcementid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String announcement=rs.getString("announcement");
                String announcementdate=rs.getString("date");



                textAnnouncementID.setText(Integer.toString(announcementid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textAnnouncement.setText(announcement);
                textAnnouncementDate.setText(announcementdate);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                textChurchID.setText("");
                textChurchName.setText("");
                textChurchDescription.setText("");

                textAnnouncementID.setText("");
                textAnnouncementDate.setText("");
                textAnnouncement.setText("");

                textChurchID1.setText("");
                textChurchName1.setText("");
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        try
        {    
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textChurchID.setText(model.getValueAt(i, 0).toString());
            textChurchName.setText(model.getValueAt(i, 1).toString());
            textChurchDescription.setText(model.getValueAt(i, 2).toString());
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textChurchID.setText(model.getValueAt(i, 0).toString());
                textChurchName.setText(model.getValueAt(i, 1).toString());
                textChurchDescription.setText(model.getValueAt(i, 2).toString());

            }
        }
        catch(Exception e)
        {

        }
    }//GEN-LAST:event_jTable2KeyTyped

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        textChurchID.setText("");
        textChurchName.setText("");
        textChurchDescription.setText("");

        textAnnouncementID.setText("");
        textAnnouncementDate.setText("");
        textAnnouncement.setText("");
        
        textChurchID1.setText("");
        textChurchName1.setText("");
       

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search by church Name or Announcement ID
    private void btnSearchByChurchnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchnameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchnameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int announcementid = rs.getInt("announcementid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String announcement=rs.getString("announcement");
                String announcementdate=rs.getString("date");



                textAnnouncementID.setText(Integer.toString(announcementid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textAnnouncement.setText(announcement);
                textAnnouncementDate.setText(announcementdate);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Church_In_JTable();
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //move first
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int announcementid = rs.getInt("announcementid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String announcement=rs.getString("announcement");
            String announcementdate=rs.getString("date");



            textAnnouncementID.setText(Integer.toString(announcementid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textAnnouncement.setText(announcement);
            textAnnouncementDate.setText(announcementdate);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to MDI form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move Previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int announcementid = rs.getInt("announcementid");
                int churchid = rs.getInt("churchid");
                String churchname=rs.getString("churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String announcement=rs.getString("announcement");
                String announcementdate=rs.getString("date");



                textAnnouncementID.setText(Integer.toString(announcementid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textAnnouncement.setText(announcement);
                textAnnouncementDate.setText(announcementdate);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move Last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int announcementid = rs.getInt("announcementid");
            int churchid = rs.getInt("churchid");
            String churchname=rs.getString("churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String announcement=rs.getString("announcement");
            String announcementdate=rs.getString("date");



            textAnnouncementID.setText(Integer.toString(announcementid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textAnnouncement.setText(announcement);
            textAnnouncementDate.setText(announcementdate);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANAnnouncementMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    //search by church NAme
    private void btnSearchByChurchname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchname1ActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchname1ActionPerformed

    //search by Church ID
    private void btnSearchByChurchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Announcement_In_JTable();
        
    }//GEN-LAST:event_btnSearchByChurchIDActionPerformed

    //search by church ID
    private void btnSearchByChurchID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchID1ActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Church_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchID1ActionPerformed

    //search by announcement ID
    private void btnSearchByAnnouncementIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByAnnouncementIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByAnnouncementIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Announcement_In_JTable();
    }//GEN-LAST:event_btnSearchByAnnouncementIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByAnnouncementID;
    private javax.swing.JButton btnSearchByChurchID;
    private javax.swing.JButton btnSearchByChurchID1;
    private javax.swing.JButton btnSearchByChurchname;
    private javax.swing.JButton btnSearchByChurchname1;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField textAnnouncement;
    private javax.swing.JTextField textAnnouncementDate;
    private javax.swing.JTextField textAnnouncementID;
    private javax.swing.JTextArea textChurchDescription;
    private javax.swing.JTextField textChurchID;
    private javax.swing.JTextField textChurchID1;
    private javax.swing.JTextField textChurchName;
    private javax.swing.JTextField textChurchName1;
    // End of variables declaration//GEN-END:variables
}
