/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.awt.Component;

import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.util.*;
import java.text.*;


/**
 *
 * @author owner
 */
public class ChurchInformationSystemIANRequirementsMaintenance extends javax.swing.JInternalFrame {

    /**
     * Creates new form ChurchInformationSystemIANActivitiesMaintenance
     */
    Connection con;
    Statement stmt,stmt2,stmt3;
    ResultSet rs,rs2,rs3;
    
    int curRow = 0,viewall=0,viewall2=0;
    String query;
    
    String username;
    String userid;
    String churchname;
    String churchid;
    String servicetype;
    String serviceid;

    /**
     * Creates new form RequirementsMaintenance
     */
    
    static int openFrameCount = 0;
    static final int xOffset = 30, yOffset = 30;
    
    
    public ChurchInformationSystemIANRequirementsMaintenance(String Userid, String Username) {
        
        super("Requirements Maintenance" , //++openFrameCount),
          true, //resizable
          true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        
        initComponents();
        
        DoConnect();
        
        userid=Userid;
        username=Username;
        
        
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }
    
    public ChurchInformationSystemIANRequirementsMaintenance() {
        super("Requirements Maintenance" , //++openFrameCount),
          true, //resizable
          !true, //closable
          true, //maximizable
          true);//iconifiable
        
         //Set the window's location.
        setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
        initComponents();
        
        DoConnect();
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }
    
    public void DoConnect()
    {
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );

            stmt = con.createStatement( );
            String sql="";
            
            sql = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                    + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_requirements.requirement, tbl_requirements.description "
                    + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    + "tbl_services.serviceid=tbl_requirements.serviceid";
            rs = stmt.executeQuery(sql);

            int rowCount=0;

            while(rs.next( ))
            {
                rowCount++;
            }
            
            if(rowCount>0)
            {
                rs.first();
                int requirementid = rs.getInt("tbl_requirements.requirementsid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description"); 
                String requirement=rs.getString("tbl_requirements.requirement");
                String requirementdescription=rs.getString("tbl_requirements.description");

                textRequirementID.setText(Integer.toString(requirementid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textRequirement.setText(requirement);
                textRequirementDescription.setText(requirementdescription);
            
            }
            
            
            
            viewall=0;
            viewall2=0;
            Show_Services_In_JTable();
            Show_Requirements_In_JTable();           
                    
        }
        catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+ex.getMessage());
            
        }
    }
    
    public Connection getConnection()
    {
        try
        {
        
            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            Connection   con = DriverManager.getConnection( host, uName, uPass );
            
            Statement stmt = con.createStatement( );
            
            return con;
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+e.getMessage());
            e.printStackTrace();
            return null;
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANRequirementsTable> getRequirementsList()
    {
        ArrayList<ChurchInformationSystemIANRequirementsTable> requirementsList= new ArrayList<ChurchInformationSystemIANRequirementsTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall==0)
            {
                query = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                    + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_requirements.requirement, tbl_requirements.description "
                    + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    + "tbl_services.serviceid=tbl_requirements.serviceid";
            }
            else if(viewall==1)
            {
                
                churchname=textChurchName.getText().trim();
                servicetype=textServiceType.getText().trim();
                String requirement=textRequirement.getText().trim();
                
                
                query = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                    + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_requirements.requirement, tbl_requirements.description "
                    + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    + "tbl_services.serviceid=tbl_requirements.serviceid and"
                        +"(tbl_church.churchname like '%"+churchname+"%' "
                        +"tbl_requirements.requirement like '%"+requirement+"%'or tbl_services.servicetype like '%"+servicetype+"%')";
            
            }
            else if(viewall==3) 
            {
                
                               
                serviceid=textServiceID.getText();
                int serviceid1=Integer.parseInt(serviceid);
                String requirementid=textRequirementID.getText().trim();
                int requirementid1=Integer.parseInt(requirementid);
                
                query = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                    + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_requirements.requirement, tbl_requirements.description "
                    + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    + "tbl_services.serviceid=tbl_requirements.serviceid "
                        + "and (tbl_services.churchid= "+serviceid1+" or tbl_requirements.requirementsid= "+requirementid1+")";
            }
            else 
            {
                
                churchid=textChurchID.getText();
                int churchid1=Integer.parseInt(churchid);
                
                query = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                    + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                    + "tbl_requirements.requirement, tbl_requirements.description "
                    + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                    + "WHERE tbl_church.churchid=tbl_services.churchid and "
                    + "tbl_services.serviceid=tbl_requirements.serviceid "
                        + "and and tbl_services.churchid= "+churchid1+"";
            }
            
               

            int i=1;
            
            Statement st;
           
            
            st= connection.createStatement();
            rs=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANRequirementsTable requirements1;
            
            while(rs.next())
            {
                requirements1 = new  ChurchInformationSystemIANRequirementsTable(rs.getInt("tbl_requirements.requirementsid"),
                        rs.getInt("tbl_services.serviceid"),rs.getInt("tbl_church.churchid"),
                        rs.getString("tbl_church.churchname"),rs.getString("tbl_church.description")
                ,rs.getString("tbl_services.servicetype"),rs.getString("tbl_services.description"),
                        rs.getString("tbl_requirements.requirement"),rs.getString("tbl_requirements.description"));
                requirementsList.add(requirements1);
            }
            
            
            
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+e.getMessage());
            
        }
        
        return requirementsList;
     
    }
    
    public void Show_Requirements_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANRequirementsTable> list = getRequirementsList();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
               
        Object[] row = new Object[9];
        
       
        model.setRowCount(0);
        
        
        for(int i=0; i < list.size(); i++)
        {
            
            row[0]=list.get(i).getRequirementsID();
            row[1]=list.get(i).getServiceID();
            row[2]=list.get(i).getChurchID();
            row[3]=list.get(i).getChurchsname();
            row[4]=list.get(i).getChurchDescription();
            row[5]=list.get(i).getServicetype();
            row[6]=list.get(i).getServiceDescription();
            row[7]=list.get(i).getRequirement();
            row[8]=list.get(i).getRequirementDescription();
                                    
            model.addRow(row);
            
        }
        
    }
    
    public ArrayList<ChurchInformationSystemIANServicesTable> getServicesList()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> servicesList= new ArrayList<ChurchInformationSystemIANServicesTable>();
        Connection connection = getConnection();
        
       
        
        try
        {
            if(viewall2==0)
            {
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid ";
            }
            else if(viewall2==1)
            {
                churchname=textChurchName1.getText();
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and "
                        +"tbl_church.churchname like '%"+churchname+"%'";
                
            
            }
            else if(viewall2==2)
            {
                int gg;
                    
                churchid=textChurchID1.getText();
                gg=Integer.parseInt(churchid);
                
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and tbl_services.churchid= "+gg+"";
                
            }
            
               

            int i=1;
            
            Statement st;
          
            
            st= connection.createStatement();
            rs2=st.executeQuery(query);
            
           
            
            ChurchInformationSystemIANServicesTable services1;
            
            while(rs2.next())
            {
                
                services1 = new  ChurchInformationSystemIANServicesTable(rs2.getInt("tbl_services.serviceid"),
                        rs2.getInt("tbl_church.churchid"), rs2.getString("tbl_church.churchname"),
                        rs2.getString("tbl_church.description"),rs2.getString("tbl_services.servicetype"),
                        rs2.getString("tbl_services.description"));
                servicesList.add(services1);
            }
            
            
            
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+e.getMessage());
        }
        
        return servicesList;
     
    }
    
    public void Show_Services_In_JTable()
    {
        ArrayList<ChurchInformationSystemIANServicesTable> list = getServicesList();
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
               
        Object[] row = new Object[6];        
       
        model.setRowCount(0);        
        
        for(int i=0; i < list.size(); i++)
        {
            //model.removeRow(i);
            row[0]=list.get(i).getServiceID();
            row[1]=list.get(i).getChurchID();
            row[2]=list.get(i).getChurchsname();
            row[3]=list.get(i).getChurchDescription();
            row[4]=list.get(i).getServicetype();
            row[5]=list.get(i).getServiceDescription();
                                    
            model.addRow(row);
            
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jScrollPane5 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        textServiceType = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnSaveRecord = new javax.swing.JButton();
        btnNewRecord = new javax.swing.JButton();
        btnCancelNewRecord = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnClearAll = new javax.swing.JButton();
        textChurchID = new javax.swing.JTextField();
        textChurchName = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSearchByChurchname = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnViewAll = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        textServiceID = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        textChurchDescription = new javax.swing.JTextArea();
        btnBackToMDIForm = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        textChurchID1 = new javax.swing.JTextField();
        textChurchName1 = new javax.swing.JTextField();
        btnSearchByChurchname1 = new javax.swing.JButton();
        btnSearchByChurchID = new javax.swing.JButton();
        btnSearchByChurchID1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textServiceDescription = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        btnSearchByRequirementsID = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        textRequirementID = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        textRequirement = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        textRequirementDescription = new javax.swing.JTextArea();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Requirements ID", "Service ID", "Church ID", "Church Name", "Church Description", "Service Type", "Service Description", "Requirement", "Requirements Description"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable1MouseClicked(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable1KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable1KeyTyped(evt);
            }
        });
        jScrollPane5.setViewportView(jTable1);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Service type");

        btnDelete.setText("Delete this Record");
        btnDelete.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnDeleteActionPerformed(evt);
            }
        });

        btnEdit.setText("Edit Record");
        btnEdit.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnEditActionPerformed(evt);
            }
        });

        btnSaveRecord.setText("Save New Record");
        btnSaveRecord.setEnabled(false);
        btnSaveRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSaveRecordActionPerformed(evt);
            }
        });

        btnNewRecord.setText("New Record");
        btnNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNewRecordActionPerformed(evt);
            }
        });

        btnCancelNewRecord.setText("Cancel New Record");
        btnCancelNewRecord.setEnabled(false);
        btnCancelNewRecord.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnCancelNewRecordActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][]
            {

            },
            new String []
            {
                "Service ID", "Church ID", "Church Name", "Church Description", "Service Type", "Service Description"
            }
        ));
        jTable2.setName("ddfsa"); // NOI18N
        jTable2.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseClicked(java.awt.event.MouseEvent evt)
            {
                jTable2MouseClicked(evt);
            }
        });
        jTable2.addKeyListener(new java.awt.event.KeyAdapter()
        {
            public void keyPressed(java.awt.event.KeyEvent evt)
            {
                jTable2KeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt)
            {
                jTable2KeyTyped(evt);
            }
        });
        jScrollPane6.setViewportView(jTable2);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Church Description");

        btnClearAll.setText("Clear All Text Boxes");
        btnClearAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnClearAllActionPerformed(evt);
            }
        });

        textChurchName.setBackground(new java.awt.Color(51, 255, 255));

        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("Church ID");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Church Name");

        btnSearchByChurchname.setText("Search by Church Name or Service Type or Requirement  in Available Churches");
        btnSearchByChurchname.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchnameActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnNext.setText("next");
        btnNext.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnNextActionPerformed(evt);
            }
        });

        btnViewAll.setText("View All Records");
        btnViewAll.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnViewAllActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnFirst.setText("first");
        btnFirst.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnFirstActionPerformed(evt);
            }
        });

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("Service ID");

        textChurchDescription.setBackground(new java.awt.Color(51, 255, 255));
        textChurchDescription.setColumns(20);
        textChurchDescription.setRows(5);
        jScrollPane1.setViewportView(textChurchDescription);

        btnBackToMDIForm.setText("Back to MDI Form");
        btnBackToMDIForm.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnBackToMDIFormActionPerformed(evt);
            }
        });

        btnPrevious.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnPrevious.setText("previous");
        btnPrevious.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnPreviousActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnLast.setText("last");
        btnLast.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnLastActionPerformed(evt);
            }
        });

        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Churich ID");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Church Name");

        textChurchName1.setBackground(new java.awt.Color(51, 255, 255));

        btnSearchByChurchname1.setText("Search by Church Name");
        btnSearchByChurchname1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchname1ActionPerformed(evt);
            }
        });

        btnSearchByChurchID.setText("Search by Church ID in Available Churches");
        btnSearchByChurchID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchIDActionPerformed(evt);
            }
        });

        btnSearchByChurchID1.setText("Search by Church ID");
        btnSearchByChurchID1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByChurchID1ActionPerformed(evt);
            }
        });

        textServiceDescription.setBackground(new java.awt.Color(51, 255, 255));
        textServiceDescription.setColumns(20);
        textServiceDescription.setRows(5);
        jScrollPane2.setViewportView(textServiceDescription);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Service Description");

        btnSearchByRequirementsID.setText("Search by Requirements ID in Available Churches");
        btnSearchByRequirementsID.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                btnSearchByRequirementsIDActionPerformed(evt);
            }
        });

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Requirements ID");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Requirement");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Requirement Description");

        textRequirementDescription.setBackground(new java.awt.Color(51, 255, 255));
        textRequirementDescription.setColumns(20);
        textRequirementDescription.setRows(5);
        jScrollPane3.setViewportView(textRequirementDescription);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(244, 244, 244))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textServiceType, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(btnSearchByChurchname))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(btnBackToMDIForm)
                                .addGap(30, 30, 30)
                                .addComponent(btnSearchByRequirementsID))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addContainerGap()
                                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(textRequirementID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(textServiceID, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnSearchByChurchID)
                                        .addComponent(textChurchID))))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textRequirement, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 461, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSearchByChurchID1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnSearchByChurchname1))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(textChurchName1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNewRecord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSaveRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancelNewRecord)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClearAll, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane5)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnPrevious)
                        .addGap(25, 25, 25)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnViewAll, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearchByChurchname1)
                    .addComponent(btnSearchByChurchID1)
                    .addComponent(btnBackToMDIForm)
                    .addComponent(btnSearchByRequirementsID))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(textChurchID1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel15))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textChurchName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(textRequirementID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(textServiceID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textChurchID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSearchByChurchID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(textChurchName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addComponent(btnSearchByChurchname)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(textServiceType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textRequirement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnViewAll)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEdit)
                        .addComponent(btnNewRecord)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnCancelNewRecord)
                        .addComponent(btnClearAll))
                    .addComponent(btnSaveRecord))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        // Display Selected Row in JTextFields

        try
        {    
            int i=jTable1.getSelectedRow();
            TableModel model=jTable1.getModel();

            textRequirementID.setText(model.getValueAt(i, 0).toString());
            textServiceID.setText(model.getValueAt(i, 1).toString());
            textChurchID.setText(model.getValueAt(i, 2).toString());
            textChurchName.setText(model.getValueAt(i, 3).toString());
            textChurchDescription.setText(model.getValueAt(i, 4).toString());
            textServiceType.setText(model.getValueAt(i, 5).toString());
            textServiceDescription.setText(model.getValueAt(i, 6).toString());
            textRequirement.setText(model.getValueAt(i, 7).toString());
            textRequirementDescription.setText(model.getValueAt(i, 8).toString());
        }
        catch(Exception e)
        {
            
        }

       
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        // TODO add your handling code here:

        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable1.getSelectedRow();
                TableModel model=jTable1.getModel();

                textRequirementID.setText(model.getValueAt(i, 0).toString());
                textServiceID.setText(model.getValueAt(i, 1).toString());
                textChurchID.setText(model.getValueAt(i, 2).toString());
                textChurchName.setText(model.getValueAt(i, 3).toString());
                textChurchDescription.setText(model.getValueAt(i, 4).toString());
                textServiceType.setText(model.getValueAt(i, 5).toString());
                textServiceDescription.setText(model.getValueAt(i, 6).toString());
                textRequirement.setText(model.getValueAt(i, 7).toString());
                textRequirementDescription.setText(model.getValueAt(i, 8).toString());


            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable1KeyPressed

    private void jTable1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1KeyTyped

    //delete record
    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Delete This Account?","Delete",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                
                
                String requirementid = textRequirementID.getText().trim();
                int requirementid2=Integer.parseInt(requirementid);

                stmt = con.createStatement( );
                String sql="Select * from tbl_requirements where requirementsid="+requirementid2+"";
                rs = stmt.executeQuery(sql);
                

                int rowCount=0;

                while ( rs.next( ) )
                {
                   

                    rowCount++;
                }

                if(rowCount!=1)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " Sorry, You can't delete a non-existing record! ");
                }
                else
                {
                   

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    

                    sql="DELETE FROM  tbl_requirements"
                    + " where requirementsid="+requirementid2+"";

                    stmt.executeUpdate(sql);

                    

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Record Successfully Deleted!");

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnDeleteActionPerformed

    //edit recordset
    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed

        int p=JOptionPane.showConfirmDialog(null, "Are You Sure to Update This Recordset?","Update",JOptionPane.YES_NO_OPTION);

        if(p==0)
        {

            try
            {
                // TODO add your handling code here:

                Class.forName("org.gjt.mm.mysql.Driver");
                String host;
                
                host = "jdbc:mysql://localhost:3306/churchinformationsystem";
                String uName= "root";
                String uPass= "";

                con = DriverManager.getConnection( host, uName, uPass );

                
                String requirementid = textRequirementID.getText().trim();
                int requirementid2=Integer.parseInt(requirementid);
                String serviceid=textServiceID.getText().trim();
                int serviceid2=Integer.parseInt(serviceid);
                String churchid=textChurchID.getText().trim();
                int churchid2=Integer.parseInt(churchid);

                String churchname=textChurchName.getText().trim();
                String churchdescription=textChurchDescription.getText().trim();
                String servicetype=textServiceType.getText().trim();
                String servicedescription=textServiceDescription.getText().trim();
                String requirement=textRequirement.getText().trim();
                String requirementdescription=textRequirementDescription.getText().trim();
                
                
                                               

                if(requirementid.equals("")||serviceid.equals("")|| 
                       requirementdescription.equals("")|| requirement.equals(""))
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " Sorry, Empty Field/s or Password Mismatch! ");
                }
                else
                {
                   

                    stmt = con.createStatement( );
                    String sql="SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                            + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, "
                            + "tbl_services.description, tbl_requirements.requirement, tbl_requirements.description "
                            + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid and "
                            + "tbl_services.serviceid=tbl_requirements.serviceid and "
                            + "(tbl_requirements.requirementsid="+requirementid2+" or (tbl_services.serviceid="+serviceid2+" and "
                            + "tbl_requirements.requirement='"+requirement+"'))";
                    rs = stmt.executeQuery(sql);

                    int rowCount=0;

                    while ( rs.next( ) )
                    {

                        rowCount++;
                    }
                    
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " vals! "+Double.toString(rowCount)+" rowVal: "+Double.toString(rowCount));

                    if(rowCount==0||rowCount==2)//)
                    {
                        JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " Sorry, No Record Found! ");
                    }
                    else if(rowCount==1)
                    {

                       

                        stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                                              
                        
                        sql="UPDATE `tbl_requirements` SET "
                                + " `serviceid`="+serviceid2+","
                                + " `requirement`='"+requirement+"',`description`='"+requirementdescription+"' "
                                + "WHERE tbl_requirements.requirementsid="+requirementid2+"";
                        
                        stmt.executeUpdate(sql);
                        stmt = con.createStatement( );
                        sql = "SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                            + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, tbl_services.description, "
                            + "tbl_requirements.requirement, tbl_requirements.description "
                            + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                            + "WHERE tbl_church.churchid=tbl_services.churchid and "
                            + "tbl_services.serviceid=tbl_requirements.serviceid "
                            + "and tbl_requirements.requirementsid= "+requirementid2+"";
                        rs = stmt.executeQuery(sql);

                        rowCount=0;

                        

                        
                        while ( rs.next( ) )
                        {
                            requirementid2 = rs.getInt("tbl_requirements.requirementsid");
                            serviceid2 = rs.getInt("tbl_services.serviceid");
                            churchid2 = rs.getInt("tbl_church.churchid");
                            churchname=rs.getString("tbl_church.churchname");
                            churchdescription=rs.getString("tbl_church.description");
                            servicetype=rs.getString("tbl_services.servicetype");
                            servicedescription=rs.getString("tbl_services.description"); 
                            requirement=rs.getString("tbl_requirements.requirement");
                            requirementdescription=rs.getString("tbl_requirements.description");

                            rowCount++;
                            if(rowCount==1)
                            {
                            textRequirementID.setText(Integer.toString(requirementid2));
                            textServiceID.setText(Integer.toString(serviceid2));
                            textChurchID.setText(Integer.toString(churchid2));
                            textChurchName.setText(churchname);
                            textChurchDescription.setText(churchdescription);
                            textServiceType.setText(servicetype);
                            textServiceDescription.setText(servicedescription); 
                            textRequirement.setText(requirement);
                            textRequirementDescription.setText(requirementdescription);
                              
                                break;
                            }
                        }

                        JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Record Successfully Modified!");
                        

                    }

                }

            } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException ex )
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+ex.getMessage());
                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Nothing is modified!");
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnEditActionPerformed

    //save new record
    private void btnSaveRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveRecordActionPerformed
        try
        {
            // TODO add your handling code here:

            Class.forName("org.gjt.mm.mysql.Driver");
            String host;
            //host = "jdbc:mysql://localhost:3306/cristalsalesandinventory?zeroDateTimeBehavior=convertToNull [root on Default schema]";
            host = "jdbc:mysql://localhost:3306/churchinformationsystem";
            String uName= "root";
            String uPass= "";

            con = DriverManager.getConnection( host, uName, uPass );
           
             
            String serviceid=textServiceID.getText().trim();
            int serviceid2=Integer.parseInt(serviceid);
            
           
            String requirement=textRequirement.getText().trim();
            String requirementdescription=textRequirementDescription.getText().trim();
            
            

           if(serviceid.equals("")||
                        requirement.equals("")|| requirementdescription.equals(""))
            {
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " Sorry, Either the churchname or password field/s is/are empty! ");
            }
            else
            {
                stmt = con.createStatement( );
                query = "SELECT tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description "
                        + "FROM `tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid  and tbl_services.serviceid= "+serviceid2+"";
                rs = stmt.executeQuery(query);
                int rowCount2=0;

                while ( rs.next( ) )
                {
                    
                    rowCount2++;
                }
                
                stmt = con.createStatement( );
               
                String sql="";
                            
                
                sql="SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, "
                            + "tbl_church.churchname, tbl_church.description, tbl_services.servicetype, "
                            + "tbl_services.description, tbl_requirements.requirement, tbl_requirements.description "
                            + "FROM `tbl_requirements`,`tbl_services`,`tbl_church` WHERE tbl_church.churchid=tbl_services.churchid and "
                            + "tbl_services.serviceid=tbl_requirements.serviceid and "
                            + " (tbl_services.serviceid="+serviceid2+" and "
                            + "tbl_requirements.requirement='"+requirement+"')";
                rs = stmt.executeQuery(sql);

                int rowCount=0;

                while ( rs.next( ) )
                {
                    
                    rowCount++;
                }
                

                if(rowCount==1||rowCount2==0)
                {
                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " Sorry, Record already exists! ");
                }
                else if(rowCount==0)
                {
            

                    stmt = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_requirements " + "VALUES (NULL,"+serviceid2+", '"+requirement+"','"+requirementdescription+"')";

                    stmt.executeUpdate(sql);

                    stmt = con.createStatement( );
                    //String sql="Select * from tbl_services where churchid="+churchid2+" ";
                    //sql="Select * from tbl_services ";
                    sql="SELECT tbl_requirements.requirementsid,tbl_services.serviceid, tbl_church.churchid, tbl_church.churchname, "
                        + "tbl_church.description, tbl_services.servicetype, tbl_services.description, tbl_requirements.requirement, "
                        + "tbl_requirements.description FROM `tbl_requirements`,`tbl_services`,`tbl_church` "
                        + "WHERE tbl_church.churchid=tbl_services.churchid and tbl_services.serviceid=tbl_requirements.serviceid";
                    rs = stmt.executeQuery(sql);

                    rowCount=0;

                    rs.last();

                    //serviceid2=rs.getInt("serviceid");
                    
                    
                    int requirementid = rs.getInt("tbl_requirements.requirementsid");
                    serviceid2 = rs.getInt("tbl_services.serviceid");
                    int churchid2 = rs.getInt("tbl_church.churchid");
                    churchname=rs.getString("tbl_church.churchname");
                    String churchdescription=rs.getString("tbl_church.description");
                    servicetype=rs.getString("tbl_services.servicetype");
                    String servicedescription=rs.getString("tbl_services.description"); 
                    requirement=rs.getString("tbl_requirements.requirement");
                    requirementdescription=rs.getString("tbl_requirements.description");

                    textRequirementID.setText(Integer.toString(requirementid));
                    textServiceID.setText(Integer.toString(serviceid2));
                    textChurchID.setText(Integer.toString(churchid2));
                    textChurchName.setText(churchname);
                    textChurchDescription.setText(churchdescription);
                    textServiceType.setText(servicetype);
                    textServiceDescription.setText(servicedescription); 
                    textRequirement.setText(requirement);
                    textRequirementDescription.setText(requirementdescription);

                    JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " new inserted record item: "+Double.toString(serviceid2));

                    /*
                    stmt2 = con.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
                    sql ="INSERT INTO tbl_stocktrail " + "VALUES (NULL,"+serviceid2+", 'stockin', '"+date+"', '"+time+"')";

                    stmt2.executeUpdate(sql);*/

                    //JOptionPane.showMessageDialog(ChurchInformationSystemIANActivitiesMaintenance.this,"A New Stock Item is Added!");
                    btnFirst.setEnabled( true );
                    btnPrevious.setEnabled( true ) ;
                    btnNext.setEnabled( true );
                    btnLast.setEnabled( true );
                    btnEdit.setEnabled( true );
                    btnDelete.setEnabled( true );
                    btnNewRecord.setEnabled( true );

                    btnSaveRecord.setEnabled( false );
                    btnCancelNewRecord.setEnabled( false );

                    Show_Services_In_JTable();
                    Show_Requirements_In_JTable();

                }

            }

        } catch (ClassNotFoundException | SQLException | NullPointerException | NumberFormatException  ex)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, " error269: "+ex.getMessage());
            //Logger.getLogger(FanRegisterAsAFan.class.getName()).log(Level.SEVERE, null, ex);
        }
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnSaveRecordActionPerformed

    //new record
    private void btnNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewRecordActionPerformed
        // TODO add your handling cotextGoodsID        trytry
        try
        {

            curRow = rs.getRow();
            
            textChurchID.setText("");
            textChurchName.setText("");
            textChurchDescription.setText("");

            textServiceID.setText("");
            textServiceDescription.setText("");
            textServiceType.setText("");

            textRequirementID.setText("");
            textRequirement.setText("");
            textRequirementDescription.setText("");

            textChurchID1.setText("");
            textChurchName1.setText("");
            

            btnFirst.setEnabled( false );
            btnPrevious.setEnabled( false ) ;
            btnNext.setEnabled( false );
            btnLast.setEnabled( false );
            btnEdit.setEnabled( false );
            btnDelete.setEnabled( false );
            btnNewRecord.setEnabled( false );

            btnSaveRecord.setEnabled( true );
            btnCancelNewRecord.setEnabled( true );
        }
        catch (SQLException err)
        {

            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this," Error: "+ err.getMessage());
            System.out.println(err.getMessage() );
        }
    }//GEN-LAST:event_btnNewRecordActionPerformed

    //cancel new record
    private void btnCancelNewRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelNewRecordActionPerformed
        // TODO add your handling code here:
        
        try
        {
            rs.absolute( curRow );

            int requirementid = rs.getInt("tbl_requirements.requirementsid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description"); 
            String requirement=rs.getString("tbl_requirements.requirement");
            String requirementdescription=rs.getString("tbl_requirements.description");

            textRequirementID.setText(Integer.toString(requirementid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textRequirement.setText(requirement);
            textRequirementDescription.setText(requirementdescription);

            btnFirst.setEnabled( true );
            btnPrevious.setEnabled( true ) ;
            btnNext.setEnabled( true );
            btnLast.setEnabled( true );
            btnEdit.setEnabled( true );
            btnDelete.setEnabled( true );
            btnNewRecord.setEnabled( true );

            btnSaveRecord.setEnabled( false );
            btnCancelNewRecord.setEnabled( false );
        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Error: "+ err.getMessage());
            //System.out.println(err.getMessage() );

            try
            {
                rs.first();

                int requirementid = rs.getInt("tbl_requirements.requirementsid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description"); 
                String requirement=rs.getString("tbl_requirements.requirement");
                String requirementdescription=rs.getString("tbl_requirements.description");

                textRequirementID.setText(Integer.toString(requirementid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textRequirement.setText(requirement);
                textRequirementDescription.setText(requirementdescription);

                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );

            }
            catch (SQLException e)
            {
                textChurchID.setText("");
                textChurchName.setText("");
                textChurchDescription.setText("");

                textServiceID.setText("");
                textServiceDescription.setText("");
                textServiceType.setText("");

                textRequirementID.setText("");
                textRequirement.setText("");
                textRequirementDescription.setText("");
                
                textChurchID1.setText("");
                textChurchName1.setText("");
                
                btnFirst.setEnabled( true );
                btnPrevious.setEnabled( true ) ;
                btnNext.setEnabled( true );
                btnLast.setEnabled( true );
                btnEdit.setEnabled( true );
                btnDelete.setEnabled( true );
                btnNewRecord.setEnabled( true );

                btnSaveRecord.setEnabled( false );
                btnCancelNewRecord.setEnabled( false );
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Error: "+ e.getMessage());
            }
        }
    }//GEN-LAST:event_btnCancelNewRecordActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        try
        {    
            
            int i=jTable2.getSelectedRow();
            TableModel model=jTable2.getModel();

            textServiceID.setText(model.getValueAt(i, 0).toString());
            textChurchID.setText(model.getValueAt(i, 1).toString());
            textChurchName.setText(model.getValueAt(i, 2).toString());
            textChurchDescription.setText(model.getValueAt(i, 3).toString());
            textServiceType.setText(model.getValueAt(i, 4).toString());
            textServiceDescription.setText(model.getValueAt(i, 5).toString());
            
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2MouseClicked

    private void jTable2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyPressed
        // TODO add your handling code here:

        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textServiceID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textServiceType.setText(model.getValueAt(i, 4).toString());
                textServiceDescription.setText(model.getValueAt(i, 5).toString());
            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyPressed

    private void jTable2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable2KeyTyped
        // TODO add your handling code here:
        try
        {    
            if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP)
            {
                int i=jTable2.getSelectedRow();
                TableModel model=jTable2.getModel();

                textServiceID.setText(model.getValueAt(i, 0).toString());
                textChurchID.setText(model.getValueAt(i, 1).toString());
                textChurchName.setText(model.getValueAt(i, 2).toString());
                textChurchDescription.setText(model.getValueAt(i, 3).toString());
                textServiceType.setText(model.getValueAt(i, 4).toString());
                textServiceDescription.setText(model.getValueAt(i, 5).toString());
            }
        }
        catch(Exception e)
        {
            
        }
    }//GEN-LAST:event_jTable2KeyTyped

    //clear all textboxes
    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
        // TODO add your handling code here:
        
        textChurchID.setText("");
        textChurchName.setText("");
        textChurchDescription.setText("");

        textServiceID.setText("");
        textServiceDescription.setText("");
        textServiceType.setText("");
        
        textRequirementID.setText("");
        textRequirement.setText("");
        textRequirementDescription.setText("");
        
        textChurchID1.setText("");
        textChurchName1.setText("");
        
        
       

    }//GEN-LAST:event_btnClearAllActionPerformed

    //search by church name or requirements
    private void btnSearchByChurchnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchnameActionPerformed
        // TODO add your handling code here:
        
        viewall=1;
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchnameActionPerformed

    //move next
    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:

        try {

            if (rs.next()) {

                int requirementid = rs.getInt("tbl_requirements.requirementsid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description"); 
                String requirement=rs.getString("tbl_requirements.requirement");
                String requirementdescription=rs.getString("tbl_requirements.description");

                textRequirementID.setText(Integer.toString(requirementid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textRequirement.setText(requirement);
                textRequirementDescription.setText(requirementdescription);

            }
            else {
                rs.previous();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, "End of File");
            }
        } catch (SQLException err ) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnNextActionPerformed

    //view all records
    private void btnViewAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAllActionPerformed
        // TODO add your handling code here:
        viewall=0;
        viewall2=0;
        Show_Services_In_JTable();
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnViewAllActionPerformed

    //move first
    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        try
        {
            rs.first();

            int requirementid = rs.getInt("tbl_requirements.requirementsid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description"); 
            String requirement=rs.getString("tbl_requirements.requirement");
            String requirementdescription=rs.getString("tbl_requirements.description");

            textRequirementID.setText(Integer.toString(requirementid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textRequirement.setText(requirement);
            textRequirementDescription.setText(requirementdescription);

        }
        catch (SQLException err)
        {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnFirstActionPerformed

    //back to MDI form
    private void btnBackToMDIFormActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackToMDIFormActionPerformed
        // TODO add your handling code here:

        
        InternalFrameDemo xx= (InternalFrameDemo) this.getTopLevelAncestor();
        
        xx.enabler();
        
        this.dispose();
    }//GEN-LAST:event_btnBackToMDIFormActionPerformed

    //move previous
    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        try {
            if ( rs.previous() ) {

                int requirementid = rs.getInt("tbl_requirements.requirementsid");
                int serviceid = rs.getInt("tbl_services.serviceid");
                int churchid = rs.getInt("tbl_church.churchid");
                String churchname=rs.getString("tbl_church.churchname");
                String churchdescription=rs.getString("tbl_church.description");
                String servicetype=rs.getString("tbl_services.servicetype");
                String servicedescription=rs.getString("tbl_services.description"); 
                String requirement=rs.getString("tbl_requirements.requirement");
                String requirementdescription=rs.getString("tbl_requirements.description");

                textRequirementID.setText(Integer.toString(requirementid));
                textServiceID.setText(Integer.toString(serviceid));
                textChurchID.setText(Integer.toString(churchid));
                textChurchName.setText(churchname);
                textChurchDescription.setText(churchdescription);
                textServiceType.setText(servicetype);
                textServiceDescription.setText(servicedescription); 
                textRequirement.setText(requirement);
                textRequirementDescription.setText(requirementdescription);

            }
            else {
                rs.next();
                JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, "Start of File");
            }
        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this,"Error: "+ err.getMessage());
        }
    }//GEN-LAST:event_btnPreviousActionPerformed

    //move last
    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        try {
            rs.last();

            int requirementid = rs.getInt("tbl_requirements.requirementsid");
            int serviceid = rs.getInt("tbl_services.serviceid");
            int churchid = rs.getInt("tbl_church.churchid");
            String churchname=rs.getString("tbl_church.churchname");
            String churchdescription=rs.getString("tbl_church.description");
            String servicetype=rs.getString("tbl_services.servicetype");
            String servicedescription=rs.getString("tbl_services.description"); 
            String requirement=rs.getString("tbl_requirements.requirement");
            String requirementdescription=rs.getString("tbl_requirements.description");

            textRequirementID.setText(Integer.toString(requirementid));
            textServiceID.setText(Integer.toString(serviceid));
            textChurchID.setText(Integer.toString(churchid));
            textChurchName.setText(churchname);
            textChurchDescription.setText(churchdescription);
            textServiceType.setText(servicetype);
            textServiceDescription.setText(servicedescription); 
            textRequirement.setText(requirement);
            textRequirementDescription.setText(requirementdescription);

        }
        catch (SQLException err) {
            JOptionPane.showMessageDialog(ChurchInformationSystemIANRequirementsMaintenance.this, "Error: "+err.getMessage());
        }
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnSearchByChurchname1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchname1ActionPerformed
        // TODO add your handling code here:
        viewall2=1;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchname1ActionPerformed

    //search by church ID
    private void btnSearchByChurchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchIDActionPerformed
        // TODO add your handling code here:
        viewall=2;
        Show_Requirements_In_JTable();
        
    }//GEN-LAST:event_btnSearchByChurchIDActionPerformed

    private void btnSearchByChurchID1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchByChurchID1ActionPerformed
        // TODO add your handling code here:
        viewall2=2;
        Show_Services_In_JTable();
    }//GEN-LAST:event_btnSearchByChurchID1ActionPerformed

    //search by requirements ID
    private void btnSearchByRequirementsIDActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_btnSearchByRequirementsIDActionPerformed
    {//GEN-HEADEREND:event_btnSearchByRequirementsIDActionPerformed
        // TODO add your handling code here:
        viewall=3;
        Show_Requirements_In_JTable();
    }//GEN-LAST:event_btnSearchByRequirementsIDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBackToMDIForm;
    private javax.swing.JButton btnCancelNewRecord;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNewRecord;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnSaveRecord;
    private javax.swing.JButton btnSearchByChurchID;
    private javax.swing.JButton btnSearchByChurchID1;
    private javax.swing.JButton btnSearchByChurchname;
    private javax.swing.JButton btnSearchByChurchname1;
    private javax.swing.JButton btnSearchByRequirementsID;
    private javax.swing.JButton btnViewAll;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea textChurchDescription;
    private javax.swing.JTextField textChurchID;
    private javax.swing.JTextField textChurchID1;
    private javax.swing.JTextField textChurchName;
    private javax.swing.JTextField textChurchName1;
    private javax.swing.JTextField textRequirement;
    private javax.swing.JTextArea textRequirementDescription;
    private javax.swing.JTextField textRequirementID;
    private javax.swing.JTextArea textServiceDescription;
    private javax.swing.JTextField textServiceID;
    private javax.swing.JTextField textServiceType;
    // End of variables declaration//GEN-END:variables
}
