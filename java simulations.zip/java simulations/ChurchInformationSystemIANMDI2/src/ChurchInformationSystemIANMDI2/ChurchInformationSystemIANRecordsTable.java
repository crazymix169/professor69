/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANRecordsTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int recordsid;
    int churchid;
    String churchname;
    String churchdescription;
    String recordstitle;
    String recordsdescription;
    
    
    
    
    
    public ChurchInformationSystemIANRecordsTable
    (            
    int recordsid,
    int churchid,
    String churchname,
    String churchdescription,
    String recordstitle,
    String recordsdescription
   
    )
            
    {        
        this.recordsid=recordsid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.recordstitle=recordstitle;
        this.recordsdescription=recordsdescription;
        
    }
    
    public int getRecordsID()
    {
        return recordsid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchsname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getRecordsTitle()
    {
        return recordstitle;
    }
    public String getRecordsDescription()
    {
        return recordsdescription;
    }
   
    
}
