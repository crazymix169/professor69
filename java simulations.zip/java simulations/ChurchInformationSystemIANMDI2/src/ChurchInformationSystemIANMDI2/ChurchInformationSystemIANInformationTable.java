/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANInformationTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    
    int informationid;
    int churchid;
    String churchname;
    String churchdescription;
    String informationtitle;
    String informationdescription;
    
    
    
    
    public ChurchInformationSystemIANInformationTable
    (            
        int informationid,
        int churchid,
        String churchname,
        String churchdescription,
        String informationtitle,
        String informationdescription    
    )
            
    {
        
       
        
        this.informationid=informationid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.informationtitle=informationtitle;
        this.informationdescription=informationdescription;
               
        
    }
    
    public int getInformationID()
    {
        return informationid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchsname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getInformationTitle()
    {
        return informationtitle;
    }
    public String getInformationDescription()
    {
        return informationdescription;
    }
    
}
