/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

/**
 *
 * @author crazymix69
 */

public class ChurchInformationSystemIANChurchTable
{
 
    int churchid;
    String churchname;
    String churchdescription;
    
    
    public ChurchInformationSystemIANChurchTable(int churchid, String churchname, String churchdescription)
    {
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;         
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    
    public String getChurchName()
    {
        return churchname;
    }
    
    public String getChurchDescription()
    {
        return churchdescription;
    }    
}
