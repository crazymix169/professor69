/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChurchInformationSystemIANMDI2;

import java.util.Date;

/**
 *
 * @author crazymix69
 */
public class ChurchInformationSystemIANServicesTable {

    /**
     * @param args the command line arguments
     */
    /*
    public static void main(String[] args) {
        // TODO code application logic here
    }*/
    
    int serviceid;
    int churchid;
    String churchname;
    String churchdescription;
    String servicetype;
    String servicedescription;
       
    
    public ChurchInformationSystemIANServicesTable
    (            
        int serviceid,
        int churchid,
        String churchname,
        String churchdescription,
        String servicetype,
        String servicedescription
    )
            
    {
                
        this.serviceid=serviceid;
        this.churchid=churchid;
        this.churchname=churchname;
        this.churchdescription=churchdescription;
        this.servicetype=servicetype;
        this.servicedescription=servicedescription;
               
        
    }
    
    public int getServiceID()
    {
        return serviceid;
    }
    
    public int getChurchID()
    {
        return churchid;
    }
    public String getChurchsname()
    {
        return churchname;
    }
    public String getChurchDescription()
    {
        return churchdescription;
    }
    public String getServicetype()
    {
        return servicetype;
    }
    public String getServiceDescription()
    {
        return servicedescription;
    }
    
}
